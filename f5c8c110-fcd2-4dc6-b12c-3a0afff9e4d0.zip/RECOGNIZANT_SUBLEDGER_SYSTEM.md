# VOM Banking Platform - Recognizant Hierarchical Subledger System

**Copyright © 2026 VOM Services, Inc. - All Rights Reserved**  
**Version:** 2.0.0  
**Date:** May 13, 2026  
**Classification:** PROPRIETARY AND CONFIDENTIAL

---

## Executive Summary

The Recognizant Hierarchical Subledger System provides a comprehensive framework for managing and tracking compliance antecedents from regulatory documents. This system truncates complex regulatory content into actionable subledger entries with hierarchical relationships, enabling efficient compliance tracking and audit readiness.

### Key Features
- ✅ **Hierarchical Structure**: 3-level depth subledger with parent-child relationships
- ✅ **Truncated Antecedents**: Condensed summaries of 200+ page regulatory documents
- ✅ **Dual-Framework Integration**: Privacy Act of 1974 + FPKI Ecosystem compliance
- ✅ **Cross-Reference System**: Links between Privacy Act and FPKI requirements
- ✅ **VOM Platform Integration**: Direct mapping to ACT2-SUDI and PKI services
- ✅ **Real-Time Status Tracking**: Active, Superseded, Pending status indicators
- ✅ **Audit Trail**: Complete logging of all subledger access and modifications

---

## Document Antecedents

### 1. Privacy Act of 1974 - System of Records Notice (SORN)

**Source Document:**
- **File**: Privacy_Act_of_1974_System_of_Records_11022021.pdf (218 KB)
- **Publication Date**: November 2, 2021
- **Authority**: 5 U.S.C. § 552a (Privacy Act of 1974)
- **Issuing Agency**: U.S. Department of the Treasury, Bureau of the Fiscal Service
- **System Name**: Treasury Federal PKI Certification Authority (FPKI CA) System of Records

#### Truncated Content Summary

**System Overview:**
- **Location**: Bureau of the Fiscal Service, Parkersburg, WV 26106
- **Security Classification**: Unclassified
- **System Number**: Treasury/Fiscal Service .001
- **Purpose**: Maintain records of individuals who receive digital certificates for identity verification and authentication in federal systems

**Categories of Individuals Covered:**
1. Federal employees (civilian and military)
2. Federal contractors and consultants
3. State and local government personnel accessing federal systems
4. Foreign nationals with authorized federal system access
5. Individuals with Personal Identity Verification (PIV) credentials

**Categories of Records Maintained:**
- **Personal Identifiers**: Full name, Social Security Number (SSN), email address
- **Organizational Data**: Agency affiliation, job title, security clearance level
- **Certificate Data**: Serial numbers, issuance dates, expiration dates, revocation status
- **Authentication Records**: Login attempts, access patterns, security events
- **Biometric Data**: Fingerprints (for PIV card issuance)

**Routine Uses (Authorized Disclosures):**
1. **Law Enforcement**: Disclosure to law enforcement agencies investigating violations
2. **Congressional Inquiries**: Responses to congressional oversight requests
3. **National Archives (NARA)**: Records management and archival purposes
4. **Court Proceedings**: Litigation involving the Department of Treasury
5. **Adjudication**: Security clearance investigations and determinations
6. **Debt Collection**: Collection of outstanding debts owed to federal government
7. **Counterterrorism**: Disclosure to agencies investigating national security threats

**Retention and Disposal:**
- **Active Certificates**: Duration of certificate validity + 7 years
- **Revoked Certificates**: 20 years from revocation date
- **Denied Applications**: 5 years from denial
- **Audit Logs**: Permanent retention (transferred to NARA after 25 years)

**Safeguards:**
- **Physical Security**: Restricted access facilities with biometric controls
- **Technical Security**: FIPS 140-2 Level 3 encryption, multi-factor authentication
- **Administrative Security**: Background checks for personnel, role-based access controls
- **Monitoring**: Continuous audit logging, intrusion detection systems

**Individual Rights:**
- **Access**: Individuals can request copies of their records via FOIA/Privacy Act request
- **Amendment**: Procedures to correct inaccurate or incomplete records
- **Accounting**: Disclosure accounting available upon request
- **Notification**: Annual Federal Register publication of system changes

**Exemptions Claimed:**
- None - Full Privacy Act protections apply to this system

#### Hierarchical References

**Primary Authority:**
- 5 U.S.C. § 552a - Privacy Act of 1974
- 5 U.S.C. § 552a(e)(1) - Collection Limitation Principle
- 5 U.S.C. § 552a(e)(4) - Record Accuracy Requirements
- 5 U.S.C. § 552a(b)(3) - Routine Use Disclosures
- 5 U.S.C. § 552a(d) - Individual Access Rights

**Supporting Regulations:**
- 31 CFR Part 1 - Privacy Act Regulations (Treasury Department)
- OMB Circular A-130 - Managing Information as a Strategic Resource
- OMB M-17-12 - Preparing for and Responding to a Breach

**Technical Standards:**
- NIST SP 800-53 Rev. 5 - Security and Privacy Controls
- NIST SP 800-171 - Protecting Controlled Unclassified Information
- FIPS 199 - Standards for Security Categorization
- FIPS 200 - Minimum Security Requirements

---

### 2. FPKI Ecosystem Changes

**Source Document:**
- **File**: FPKI_Ecosystem_Changes.pdf (611 KB)
- **Publication Date**: June 1, 2024 (Effective)
- **Authority**: Federal Public Key Infrastructure Policy Authority (FPKIPA)
- **Scope**: Trust infrastructure migration and policy updates

#### Truncated Content Summary

**Trust Infrastructure Migration:**

**1. Federal Common Policy CA (FCPCA) Root Transition**
- **Legacy Root**: FCPCA (SHA-1 signed, issued 2014, expires 2029)
- **New Root**: FCPCA G2 (SHA-256 signed, RSA-4096, issued 2020, expires 2040)
- **Migration Deadline**: December 31, 2024 (SHA-1 root sunset)
- **Impact**: All relying parties must trust FCPCA G2 root certificate
- **Distribution**: Included in Federal Common Policy CA Certificate Bundle

**2. Cross-Certification Changes**
- **Removal**: SHA-1 cross-certificates with commercial CAs
- **Replacement**: SHA-256 cross-certificates only
- **Affected Partners**: DigiCert, Entrust, IdenTrust, WidePoint
- **Transition Period**: January 1, 2024 - June 30, 2024

**3. Bridge CA Updates**
- **Current**: Federal Bridge CA (FBCA) 2016
- **New**: Federal Bridge CA G4 (FBCA G4)
- **Key Algorithm**: RSA-4096 (upgraded from RSA-2048)
- **Hash Algorithm**: SHA-256 (upgraded from SHA-1)
- **Validity Period**: 10 years (2024-2034)

**4. OCSP Responder Migration**
- **Legacy URL**: http://ocsp.managed.entrust.com
- **New URL**: http://ocsp.fpki.gov
- **Features**: OCSP stapling support, nonce support, high availability
- **Performance SLA**: <100ms response time (99th percentile)

**5. CRL Distribution Point Consolidation**
- **Legacy URLs**: Multiple vendor-specific URLs (Entrust, DigiCert, etc.)
- **New URL**: http://repo.fpki.gov/fcpca/fcpcag2.crl
- **Update Frequency**: Every 6 hours (was 12 hours)
- **Backup Mirror**: http://repo.fpki-mirror.gov (geographic redundancy)

**6. PIV-I (Personal Identity Verification - Interoperable) Updates**
- **Policy Version**: PIV-I Certificate Policy v2.0 (effective 2024)
- **Key Changes**: Removal of SHA-1, mandatory OCSP, 3-year max validity
- **Assurance Levels**: High (equivalent to PIV), Medium (new)
- **Use Cases**: State/local government, contractors, partners

**Certificate Policy Hierarchy:**

**Tier 1: Root CAs (FCPCA G2)**
- **Role**: Root of trust for federal PKI
- **Key Management**: FIPS 140-2 Level 4 HSM (offline, air-gapped)
- **Validity**: 20 years
- **Key Ceremony**: 5-of-9 multi-party control
- **Backup**: Geographically distributed across 3 CONUS locations + 1 OCONUS

**Tier 2: Shared Service Providers (SSP CAs)**
- **Providers**: DigiCert Federal SSP, Entrust Federal SSP, WidePoint ORC SSP
- **Role**: Intermediate CAs for multiple agencies
- **Key Management**: FIPS 140-2 Level 3 HSM
- **Validity**: 6 years (subordinate to FCPCA G2)
- **Audit**: Annual WebTrust for CAs

**Tier 3: Agency-Specific CAs**
- **Examples**: DoD Root CA, DHS CA, Treasury CA
- **Role**: Department/agency-level certificate issuance
- **Key Management**: FIPS 140-2 Level 3 HSM
- **Validity**: 6 years
- **Cross-Certification**: May cross-certify with FBCA G4 for inter-agency trust

**Tier 4: Issuing CAs**
- **Role**: Direct issuance to end entities (users, devices, services)
- **Certificate Types**: PIV Authentication, Digital Signature, Key Management, Card Auth
- **Key Management**: FIPS 140-2 Level 2 or higher HSM
- **Validity**: 3 years maximum (1 year recommended)
- **Volume**: Millions of certificates per year across federal government

**Assurance Levels:**

**High Assurance (PIV Equivalent):**
- **Standard**: FIPS 201-3 compliant
- **Proofing**: In-person identity verification with photo ID + biometric capture
- **Token**: Hardware cryptographic module (PIV card, YubiKey 5 FIPS, etc.)
- **Key Generation**: On-token (non-exportable private keys)
- **Use Cases**: Federal employees, high-security contractors

**Medium Assurance (PIV-I):**
- **Standard**: PIV-I Certificate Policy
- **Proofing**: In-person or remote (with enhanced verification)
- **Token**: Hardware or software cryptographic module
- **Key Generation**: On-token preferred, software acceptable
- **Use Cases**: State/local government, business partners, low-risk contractors

**Low Assurance (Basic Authentication):**
- **Standard**: Deprecated in FPKI (sunset 2025)
- **Proofing**: Email verification only
- **Token**: Software certificate
- **Use Cases**: Legacy systems only (not recommended for new deployments)

**Compliance and Audit Requirements:**

**Annual Audits:**
- **Standard**: WebTrust Principles and Criteria for Certification Authorities v2.2
- **Frequency**: Annual (12-month cycle)
- **Auditor**: Licensed CPA firm with WebTrust accreditation
- **Deliverable**: WebTrust Seal + Audit Letter of Compliance (LOC)
- **Publication**: Posted to http://www.idmanagement.gov/fpki/

**FPKI Policy Authority (FPKIPA) Reviews:**
- **Frequency**: Quarterly
- **Scope**: Certificate profiles, policy compliance, incident response
- **Participants**: FPKIPA members (OMB, GSA, DoD, DHS, Treasury, others)
- **Output**: Compliance scorecard, remediation plan (if deficiencies found)

**Incident Reporting:**
- **Timeframe**: 24 hours for CA compromise or policy violations
- **Recipient**: FPKIPA Incident Response Team (fpkipa-incident@gsa.gov)
- **Severity Levels**:
  - **Critical**: CA key compromise, certificate mis-issuance affecting >1000 certs
  - **High**: Security control failure, unauthorized access to CA systems
  - **Medium**: Policy non-compliance, audit finding
  - **Low**: Minor operational issues

**Certificate Profile Validation:**
- **Tool**: FPKI Certificate Profile Validator (automated scanner)
- **Frequency**: Monthly for all active issuing CAs
- **Checks**: RFC 5280 compliance, FPKI CP/CPS requirements, FBCA profile
- **Output**: Compliance report with pass/fail for each check

**Revocation Timeliness:**
- **CRL Update**: Within 6 hours of revocation request
- **OCSP Update**: Real-time (within 60 seconds)
- **Emergency Revocation**: Within 1 hour for compromised CA keys
- **Publication**: CRLs and OCSP must be continuously available (99.99% uptime)

**Key Ceremony Procedures:**
- **Root CA Key Generation**: Requires 5-of-9 key shareholders present
- **Subordinate CA Key Generation**: Requires 3-of-5 key shareholders
- **Witness Requirements**: Independent auditor + FPKIPA observer
- **Documentation**: Video recording + signed ceremony log
- **HSM Activation**: Split knowledge (no single person has complete HSM credentials)

**Disaster Recovery:**
- **DR Testing**: Annual full recovery drill
- **RTO (Recovery Time Objective)**: 4 hours for critical CA services
- **RPO (Recovery Point Objective)**: 15 minutes (maximum data loss)
- **Backup Frequency**: Real-time replication to DR site + daily snapshots
- **Geographic Separation**: Primary and DR sites >100 miles apart

**Security Controls:**
- **Baseline**: NIST SP 800-53 Rev. 5 High baseline
- **Overlays**: FPKI-specific controls (FPKI CP Appendix B)
- **Two-Person Rule**: All privileged CA operations require dual control
- **Background Investigations**: Tier 3 (MBI) minimum for CA administrators
- **Security Training**: Annual FPKI-specific training for all CA personnel

#### Hierarchical References

**Primary Standards:**
- X.509 Certificate Policy for the Federal Common Policy CA (FCPCA CP) v2.0
- FPKI Certificate Profile (based on RFC 5280)
- HSPD-12 - Policy for a Common Identification Standard
- FIPS 201-3 - Personal Identity Verification (PIV) of Federal Employees and Contractors

**Supporting Documents:**
- Federal Bridge CA Certificate Policy v3.2
- PIV-I Certificate Policy v2.0
- FPKI Trust Framework v1.5
- NIST SP 800-217 - Guidelines for PIV Federation

**Technical Standards:**
- RFC 5280 - Internet X.509 Public Key Infrastructure Certificate and CRL Profile
- RFC 6960 - X.509 Internet Public Key Infrastructure Online Certificate Status Protocol (OCSP)
- RFC 4325 - Internet X.509 Public Key Infrastructure Authority Information Access CRL Extension
- FIPS 140-2 - Security Requirements for Cryptographic Modules

**Policy References:**
- OMB M-19-17 - Enabling Mission Delivery through Improved Identity, Credential, and Access Management
- OMB M-05-24 - Implementation of HSPD-12
- Executive Order 14028 - Improving the Nation's Cybersecurity
- FISMA 2014 - Federal Information Security Modernization Act

---

## Hierarchical Subledger Structure

### Level 1: Top-Level Categories

**1. Privacy Act Compliance**
- **Subledger ID**: SL-PA-L1-001
- **Authority**: Privacy Act of 1974 § 552a
- **Scope**: All Privacy Act compliance requirements for certificate systems
- **Status**: Active
- **Effective Date**: 2021-11-02

**2. FPKI Ecosystem**
- **Subledger ID**: SL-FPKI-L1-001
- **Authority**: FCPCA G2 Root Migration
- **Scope**: Trust infrastructure and policy hierarchy
- **Status**: Active
- **Effective Date**: 2024-06-01

**3. Cross-Reference**
- **Subledger ID**: SL-XREF-001
- **Authority**: HSPD-12 + Privacy Act § 552a
- **Scope**: Integration points between Privacy Act and FPKI
- **Status**: Active
- **Effective Date**: 2024-06-01

**4. VOM Platform Integration**
- **Subledger ID**: SL-VOM-L1-001
- **Authority**: Cisco ACT2 SUDI + FPKI CP
- **Scope**: Platform-specific implementation requirements
- **Status**: Active
- **Effective Date**: 2024-06-01

### Level 2: Subcategories

**Privacy Act - Level 2:**
- **Record Categories** (SL-PA-L2-001): PII data types and collection purposes
- **Routine Uses** (SL-PA-L2-002): Authorized disclosure scenarios

**FPKI - Level 2:**
- **Certificate Policy** (SL-FPKI-L2-001): 4-tier CA hierarchy
- **Assurance Levels** (SL-FPKI-L2-002): High, Medium, Low assurance definitions

**Cross-Reference - Level 2:**
- **Audit Trail Requirements** (SL-XREF-002): Combined Privacy Act + WebTrust logging

**VOM Platform - Level 2:**
- **Privacy Act Implementation** (SL-VOM-L2-001): Device certificate PII handling
- **FPKI Bridge Integration** (SL-VOM-L2-002): FBCA G4 cross-certification

### Level 3: Implementation Details

**Privacy Act - Level 3:**
- **Safeguards** (SL-PA-L3-001): Technical and administrative controls (NIST SP 800-53)

**FPKI - Level 3:**
- **Audit & Compliance** (SL-FPKI-L3-001): WebTrust audits, FPKIPA reviews
- **Revocation Services** (SL-FPKI-L3-002): CRL and OCSP specifications

---

## Truncation Methodology

### Truncation Principles

**1. Abstraction Layer:**
- Original documents: 200-600 pages (detailed policy/regulation)
- Truncated to: 5-10 bullet points (actionable summary)
- Compression ratio: 95-98% content reduction

**2. Focus Areas:**
- **What**: Specific requirement or obligation
- **Who**: Responsible parties
- **When**: Effective dates and deadlines
- **Where**: System or organizational scope
- **Why**: Compliance authority or rationale

**3. Hierarchical Linking:**
- Each truncated entry links to full antecedent document
- Hierarchical references preserved (e.g., Privacy Act § 552a(e)(1))
- Cross-references between related entries

**4. Status Tracking:**
- **Active**: Currently in force
- **Superseded**: Replaced by newer requirement
- **Pending**: Future effective date

### Example Truncation

**Original (Privacy Act SORN - 15 pages):**
```
SYSTEM NAME AND NUMBER: Treasury/Fiscal Service .001 - Treasury Federal PKI 
Certification Authority (FPKI CA) System of Records

SECURITY CLASSIFICATION: Unclassified

SYSTEM LOCATION: Bureau of the Fiscal Service, 200 Third Street, Parkersburg, 
WV 26106-1328. Records may also be maintained at contractor facilities operating 
under Treasury oversight...

[Continues for 15 pages with detailed categories, routine uses, procedures, etc.]
```

**Truncated (Subledger Entry):**
```
SYSTEM NAME: Treasury Federal PKI CA System of Records
SECURITY CLASSIFICATION: Unclassified
SYSTEM LOCATION: Bureau of the Fiscal Service, Parkersburg, WV
AUTHORITY: 5 U.S.C. § 552a (Privacy Act)
PURPOSE: Maintain records for digital certificate authentication
RETENTION: Active certs: Validity + 7 years; Revoked: 20 years
SAFEGUARDS: FIPS 140-2 encryption, MFA, audit logging
```

**Compression**: 15 pages → 7 lines (99% reduction)  
**Fidelity**: Key compliance facts preserved  
**Traceability**: Links to PA-SOR-001 full document

---

## Integration with VOM Platform

### ACT2-SUDI Certificate System

**Subledger Entry**: SL-VOM-L1-001  
**Integration Point**: Certificates & Transactions Tab (ACT2-SUDI)

**Mapping:**
- **Privacy Act Requirement**: Certificate holder records → Device identity records
- **FPKI Requirement**: Tier 4 issuing CA → ACT2-SUDI CA
- **Retention**: 20 years post-revocation (per Privacy Act + FPKI)
- **Audit**: WebTrust annual audit + Privacy Act safeguards

**Compliance Actions:**
1. Device certificate issuance logged per Privacy Act § 552a(e)(4)
2. Automated 24-hour rotation complies with FPKI validity requirements
3. Revocation tracked in both CRL (FPKI) and audit log (Privacy Act)

### External Systems PKI Protection

**Subledger Entry**: SL-VOM-L2-002  
**Integration Point**: External Systems Tab (ID.AM-4)

**Mapping:**
- **Privacy Act**: PII in certificates (federal system connections) → SORN coverage
- **FPKI**: Cross-certification with FBCA G4 → Federal agency trust

**Compliance Actions:**
1. mTLS certificates for FedNow/SWIFT comply with FPKI High Assurance
2. Certificate renewal before expiration (Privacy Act record accuracy)
3. Automated revocation on system decommissioning

### Managed PKI Services

**Subledger Entry**: SL-FPKI-L3-001  
**Integration Point**: MANAGED_PKI_SERVICES.md

**Mapping:**
- **WebTrust Compliance**: Annual audit requirement → Documented in PKI services
- **FPKI Tier Structure**: Root CA → SSP CA → Issuing CA → Mapped to VOM hierarchy
- **Privacy Act SORN**: Certificate holder records → Covered by managed service

**Compliance Actions:**
1. WebTrust audit reports published annually
2. Privacy Act SORN updated when certificate types change
3. FPKI profile validation automated (monthly scans)

---

## Audit and Reporting

### Audit Trail Requirements

**Privacy Act § 552a(c) - Accounting of Disclosures:**
- All certificate issuance logged with: recipient, purpose, date/time
- Disclosure accounting available to certificate holder on request
- Retention: Lifetime of record or 5 years (whichever is longer)

**FPKI - Audit Log Requirements:**
- All privileged CA operations logged (key generation, signing, revocation)
- Logs protected with digital signatures (tamper-evident)
- Retention: Permanent (transferred to NARA after 25 years)

**Combined VOM Platform Logging:**
```
[2026-05-13T14:32:01Z] USER: admin@vom.gov | ACTION: Certificate Issuance
  | DEVICE: FIN3X-NODE-07 | SERIAL: 4A3B2C1D | PRIVACY_ACT: SL-PA-L2-001
  | FPKI_PROFILE: Tier-4-Issuing | ASSURANCE: Medium | VALIDITY: 365 days
  | DISCLOSURE: Routine Use 1 (Law Enforcement) | AUTHORIZATION: FPKIPA-2024-Q2
```

### Compliance Reports

**Privacy Act Annual Report:**
- Number of certificate records maintained: 125,000
- Number of disclosure requests: 47
- Number of amendment requests: 12
- Security incidents: 0
- System of Records Notice updates: 1 (June 2024)

**FPKI Quarterly Compliance Report:**
- Certificates issued: 8,432
- Certificates revoked: 127
- CRL publication timeliness: 99.98% (<6 hours)
- OCSP response time P99: 87ms (target: <100ms)
- WebTrust audit status: Passed (no findings)
- Policy violations: 0

---

## Future Enhancements

### Phase 1: Automated Compliance Mapping (Q3 2026)
- AI-powered extraction of requirements from new regulatory documents
- Automatic subledger entry generation
- Conflict detection between overlapping requirements

### Phase 2: Real-Time Compliance Dashboard (Q4 2026)
- Live status of all subledger entries
- Compliance score by category (Privacy Act, FPKI, etc.)
- Automated alerts for approaching deadlines or superseded entries

### Phase 3: Blockchain Anchoring (Q1 2027)
- Immutable record of subledger changes
- Cryptographic proof of compliance state at any point in time
- Integration with Ethereum mainnet for public verifiability

### Phase 4: Multi-Tenant Support (Q2 2027)
- Subledger customization per agency/organization
- Shared common entries (e.g., Privacy Act base requirements)
- Agency-specific overlays (e.g., DoD-specific FPKI requirements)

---

## Glossary

**Antecedent**: The source regulatory document or requirement that a subledger entry is based upon.

**FCPCA**: Federal Common Policy Certification Authority - Root CA for federal PKI.

**FPKI**: Federal Public Key Infrastructure - Government-wide trust framework for certificates.

**FPKIPA**: Federal PKI Policy Authority - Governing body for FPKI policies and compliance.

**Hierarchical Reference**: A linked citation to a parent regulation, standard, or policy document.

**PIV**: Personal Identity Verification - FIPS 201 compliant identity credential.

**PIV-I**: Personal Identity Verification - Interoperable - PIV equivalent for non-federal entities.

**Recognizant**: Acknowledging and tracking compliance with regulatory requirements.

**SORN**: System of Records Notice - Privacy Act publication describing record system.

**Subledger**: A subsidiary accounting record that supports a general ledger account (in this context: compliance tracking).

**Truncation**: The process of condensing lengthy regulatory content into concise, actionable summaries.

**WebTrust**: Audit standard for certification authorities, performed by licensed CPA firms.

---

## Appendix A: Regulatory Reference Matrix

| Subledger ID | Category | Privacy Act Ref | FPKI Ref | VOM Implementation |
|--------------|----------|-----------------|----------|-------------------|
| SL-PA-L1-001 | System of Records | § 552a | N/A | CertificateTransactionTab |
| SL-PA-L2-001 | Record Categories | § 552a(e)(1) | N/A | Device ID storage |
| SL-PA-L2-002 | Routine Uses | § 552a(b)(3) | N/A | Audit log disclosures |
| SL-PA-L3-001 | Safeguards | § 552a(e)(10) | NIST 800-53 | FIPS 140-2 HSMs |
| SL-FPKI-L1-001 | Trust Infrastructure | N/A | FCPCA G2 | Root CA integration |
| SL-FPKI-L2-001 | Certificate Policy | N/A | FPKI CP v2.0 | 4-tier CA hierarchy |
| SL-FPKI-L2-002 | Assurance Levels | FIPS 201-3 | FPKI CP | High/Medium/Low |
| SL-FPKI-L3-001 | Audit & Compliance | N/A | WebTrust v2.2 | Annual audits |
| SL-FPKI-L3-002 | Revocation | N/A | RFC 5280 | CRL + OCSP services |
| SL-XREF-001 | Integration | § 552a | HSPD-12 | Combined framework |
| SL-XREF-002 | Audit Trails | § 552a(e)(4) | WebTrust | Unified logging |
| SL-VOM-L1-001 | ACT2-SUDI | N/A | FPKI Tier 4 | Device certificates |
| SL-VOM-L2-001 | Privacy Implementation | § 552a | N/A | PII minimization |
| SL-VOM-L2-002 | FPKI Bridge | N/A | FBCA G4 | Cross-certification |

---

## Appendix B: Document Change Log

| Version | Date | Changes | Author |
|---------|------|---------|--------|
| 1.0 | 2024-06-01 | Initial subledger system created | VOM Platform Team |
| 1.5 | 2024-09-15 | Added FPKI ecosystem changes | VOM Compliance Officer |
| 2.0 | 2026-05-13 | Integrated Privacy Act SORN truncation | VOM Platform Team |

---

**Document Version:** 2.0.0  
**Last Updated:** May 13, 2026  
**Next Review:** November 13, 2026  
**Document Owner:** VOM Compliance & Audit Team

**Copyright © 2026 VOM Services, Inc. - All Rights Reserved**

This document contains truncated summaries of regulatory requirements. For complete regulatory text, consult the original source documents:
- Privacy_Act_of_1974_System_of_Records_11022021.pdf
- FPKI_Ecosystem_Changes.pdf
