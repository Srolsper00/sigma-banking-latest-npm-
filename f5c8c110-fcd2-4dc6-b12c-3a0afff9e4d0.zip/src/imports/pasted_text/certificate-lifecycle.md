4 Certificate&LifeOCycle&Operational&Requirements
4.1 Certificate!Application
4.1.1 Who&Can&Submit&a&Certificate&Application
Under!this!policy,!Subscribers!and!Requesters!are!limited!to!software!and!hardware!products!manufacturing!by!
or!on!direct!behalf!of!Cisco!Systems.!The!ACT2!SubCAs!validate! that! the!ACT2!chip!serial!number!listed!in! the!
certificate!signing!request!matches!the!serial!number!of!an!ACT2!chip!pre?registered!by!the!chip!manufacturer!
as! valid.! This! ensures! that! the! request! originates! from! a! legitimate! ACT2! chip,! and! that! the! serial! number! in!
question!is!valid.
4.1.2 Enrollment&Process&and&Responsibilities
The!ACT2!SubCAs!have!implemented!technical!and!procedural!controls!that!verify!the!identifying!information!of!
applying! subscribers.! Applying! subscribers! should! present! sufficient! information! with! their! certificate! signing!
request!to!ensure!the!ACT2!SubCAs!can!perform!this!verification.!The!ACT2!SubCAs!have!implemented!technical!
and!procedural!controls!such!as!encrypted!communications!channels!and!encrypted!data!storage! that!protect!
communications!with!applying!subscribers!and!that!adequately!protect!and!store!information!presented!to!the!
CA!by!the!applicant.
4.2 Certificate!Application!Processing
4.2.1 Performing&Identification&and&Authentication&Functions
The!ACT2!SubCAs!authenticate!the!certificate!signing!request!for!an!ACT2!Subscribing!Product!by!validating!that!
the!serial!number!and!PID!information!in! the!certificate!signing!request!match!valid!value! templates,!and! that!
the! PID matches! a! pre?registered! PID for! a! legitimately! manufactured! ACT2! Subscribing! Product.! The! ACT2!
SubCAs! also! verify! the! signature! on! the! request! using! the! ACT2! chip’s! identity.! This! process! is! performed!
automatically!upon! receipt!of!a!certificate! signing! request,!but!may!be!performed!manually!by!administrators!
for!troubleshooting!or!testing!purposes.
4.2.2 Approval&or&Rejection&of&Certificate&Applications
Following!the!processing!decision!to!grant!or!deny!a!certificate!signing!request,!the!ACT2!SubCAs!return either!a!
valid! certificate!with!a! success!indicator!value,! or!an!error! code!and!message.!This!information!is! transmitted!
automatically!over! the!encrypted,!authenticated!channel!back! to! the!ACT2!Subscribing!Product! that!made! the!
request.

ACT2!SUDI!CA!Certification!Practice!Statement

• • •

Version!2.1 ! Page!13

4.2.3 Time&to&Process&Certificate&Applications
The! ACT2! SubCAs! render! their! certificate! processing! decision! and! return! a! result! promptly,! but! no! specific!
service!level!agreement!exists!for!the!time!in!which!a!result!must!be!returned.
4.3 Certificate!Issuance
4.3.1 CA&Actions&during&Certificate&Issuance
During!the!certificate!issuance!process,!the!ACT2!SubCAs!communicate!with!the!communications!proxy!for!the!
traffic! from! the!ACT2!Subscribing!Product!over!an!encrypted,!authenticated!channel! that!uses!TLS!and!mutual!
certificate!authentication!for!security.
4.3.2 Notification&to&Subscriber&by&the&CA&of&Issuance&of&Certificate
Receipt!of!the!certificate!shall!be!considered!sufficient!notification!to!the!Subscriber!of!certificate!issuance;!the!
ACT2!SubCAs!supply!a!success/failure!error!code!along!with!the!transaction,!but!this!is!not!required.
4.4 Certificate!Acceptance
4.4.1 Conduct&Constituting&Certificate&Acceptance
Successful! reception! of! the! certificate! across! an! authenticated! communications! channel! shall! be! considered!
sufficient!to!constitute!acceptance!of!the!certificate.
4.4.2 Publication&of&the&Certificate&by&the&CA
The!ACT2!SubCAs!do!not!publish!successfully!issued!certificates!to!any!publicly!available!repository.
4.4.3 Notification&of&Certificate&Issuance&by&the&CA&to&Other&Entities
The!ACT2!SubCAs!do!not!issue!notifications!of!certificate!issuance! to!entities!other! than! the!ACT2!Subscribing!
Product.
4.5 Key!Pair!and!Certificate!Usage
4.5.1 Subscriber&Private&Key&and&Certificate&Usage
ACT2! Subscribing! Products! currently! utilize! a! hardware! chip! for! generation! and! storage! of! the! public/private!
keypair!for!ACT2!SUDI!certificates,!which!is!FIPS!140?2!Level!3!certified!as!a!secure!hardware!container!for!the!
keypair!and!certificate.!Information! stored!in! this!chip!is,! by! design,! not! replicable!without! using!a!FIPS! 140?2!
Level!3!certified!backup!and!archival!protocol.
4.5.2 Relying&Party&Public&Key&and&Certificate&Usage
4.5.2.1 Reliance&on,&and&Usage&of,&Issued&Certificates
Issued!ACT2!SUDI!certificates!may!be!used!and!relied!upon!for!authentication!of!the!ACT2!Subscribing!Product!
possessing! them,! and! for!encryption! and/or! digital! signature! of! information! transmitted! to! or! from! the! ACT2!
Subscribing!Product.
4.5.2.2 Verification&of&the&Public&Key&of&the&CA
Relying! Parties! may! validate! the! public! key! of! the! CA! by! downloading! a! copy! from! the! public! repository!
maintained! by! Cisco!Systems!Information!Security!group!and! comparing!it! to! the!key! used! to! sign!ACT2!SUDI!
certificates.! ACT2! SUDI! certificates! may! be! validated! using! the! mechanisms! defined! in! IETF! X.509! digital!
certificate!standards!such!as!RFC!5280!and!RFC!3280.