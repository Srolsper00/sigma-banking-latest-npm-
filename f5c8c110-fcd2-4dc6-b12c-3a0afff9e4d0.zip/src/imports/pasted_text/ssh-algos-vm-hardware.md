As a security measure for Cisco ASR 5500 and VPC products, the Ciphers and MACs algorithm values are
modified to support the upgrade and migration of the Open SSH to Cisco SSH versions.
Previous Behavior: In releases earlier to 21.16, the default algorithm values of the cipher and macs commands
were as follows:
• Cipher
Release 20.x to 21.15 (!ormal build only)
Resets the value of algorithm in a Normal build to:
blowfish-cbc,3des-cbc,aes128-cbc,aes128-ctr,aes192-ctr,aes256-ctr,aes128-gcm@openssh.com,aes256-gcm@openssh.com,chacha20-poly1305@openssh.com
• MACs
Release 20.x to 21.15 (Trusted build only)
Resets the value of algorithm in a Trusted build to:
hmac-sha2-512-etm@openssh.com,hmac-sha2-256-etm@openssh.com,hmac-sha1-etm@openssh.com,hmac-sha2-512,
hmac-sha2-256,hmac-sha1
• KEX Algorithms
Release 20.x to 21.15
A vailable Algorithms in !ormal and Trusted Builds:
diffie-hellman-group1-sha1,diffie-hellman-group14-sha1
!ew Behavior: In this release, the default algorithm values of the cipher and macs commands are as follows:
• Cipher
Release 21.16 onwards: Post OpenSSH to CiscoSSH Upgrade and Migration
Default Algorithms in a !ormal Build:
aes256-ctr,aes192-ctr,aes128-ctr,aes256-gcm@openssh.com,aes128-gcm@openssh.com,chacha20-poly1305@openssh.com
A vailable Algorithms in a !ormal Build:
aes256-ctr,aes192-ctr,aes128-ctr,aes256-gcm@openssh.com,aes128-gcm@openssh.com,chacha20-poly1305@openssh.com,aes128-cbc
Default and A vailable Algorithms in Trusted Builds:
aes256-ctr,aes192-ctr,aes128-ctr
Note
There is no change in the default and configurable Ciphers for Trusted builds.
• MACs
Release 21.16 onwards: Post OpenSSH to CiscoSSH Upgrade and Migration
Default and A vailable Algorithms in !ormal Builds:
hmac-sha2-512-etm@openssh.com,hmac-sha2-256-etm@openssh.com,hmac-sha1-etm@openssh.com,hmac-sha2-512,
hmac-sha2-256,hmac-sha1
ASR 5500 System Administration Guide, StarOS Release 21.22
44
Getting Started
VM Hardware Verification
Default Algorithms in Trusted Builds:
hmac-sha2-512,hmac-sha2-256,hmac-sha1
A vailable Algorithms in Trusted Builds:
hmac-sha2-512,hmac-sha2-256,hmac-sha1
Note
hmac-sha2-512-etm@openssh.com,hmac-sha2-256-etm@openssh.com,hmac-sha1-etm@openssh.com
are removed from the Trusted builds.
• KEX Algorithms
Release 21.16 onwards: Post OpenSSH to CiscoSSH Upgrade and Migration
A vailable Algorithms in !ormal and Trusted Builds:
diffie-hellman-group14-sha1
Note
KEX algorithms are not configurable in StarOS. Therefore, there are no CLI
changes.
VM Hardware Verification
To prevent resource allocation issues, it is important that all VMs used for in the system have the same size
CPU and the same size memory. To balance performance across all interfaces, make sure that the service
ports and DI ports have the same throughput capabilities.
To verify the hardware configuration for all cards or a specific card, use the show cloud hardware
[card_number} command. Sample output from this command on card 1 (CF) is shown here:
[local]s1# show cloud hardware 1
Card 1:
CPU Nodes : 1
CPU Cores/Threads : 8
Memory : 16384M (qvpc-di-medium)
Hugepage size : 2048kB
cpeth0 :
Driver : virtio_net
loeth0 :
Driver : virtio_net
Sample output from this command on card 3 (SF) is shown here:
[local]s1# show cloud hardware 1
Card 3:
CPU Nodes : 1
CPU Cores/Threads : 8
Memory : 16384M (qvpc-di-medium)
Hugepage size : 2048kB
cpeth0 :
Driver : vmxnet3
ASR 5500 System Administration Guide, StarOS Release 21.22
45
Getting Started
VM Hardware Verification
port3_10 :
Driver : vmxnet3
port3_11 :
Driver : vmxnet3
To display the optimum configuration of the underlying VM hardware, use the show hardware optimum.
To compare your current VM configuration to the optimum configuration, use the show cloud hardware test
command. Any parameters not set to the optimum are flagged with an asterisk, as shown in this sample output.
In this example, the CPU cores/threads and memory are not configured optimally.
[local]s1# show cloud hardware test 1
Card 1:
CPU Nodes : 1
* CPU Cores/Threads : 8 Optimum value is 4
* Memory : 8192M (qvpc-di-medium) Optimum value is 16384
Hugepage size : 2048kB
cpeth0 :
Driver : virtio_net
loeth0 :
Driver : virtio_net
To display the configuration file on the config disk or local flash, use the show cloud configuration
card_number command. The location parameter file on flash memory is defined during the installation. And
the config disk is usually created by the orchestrator and then attached to the card. Sample output from this
command is shown here for card 1:
[local]s1# show cloud configuration 1
Card 1:
Config Disk Params:
-------------------------
No config disk available
Local Params:
-------------------------
CARDSLOT=1
CARDTYPE=0x40010100
CPUID=0
To display the IFTASK configuration for all cards or a specific card, use the show cloud hardware iftask
command. By default, the cores are configured to be used for both PMD and VNPU. Sample output from this
command on card 4 is shown here:
[local]mySystem# show cloud hardware iftask 4
Card 4:
Total number of cores on VM: 24
Number of cores for PMD only: 0
Number of cores for VNPU only: 0
Number of cores for PMD and VNPU: 3
Number of cores for MCDMA: 4
Hugepage size: 2048 kB
Total hugepages: 16480256 kB
NPUSHM hugepages: 0 kB
CPU flags: avx sse sse2 ssse3 sse4_1 sse4_2
Poll CPU's: 1 2 3 4 5 6 7
KNI reschedule interval: 5 us
ASR 5500 System Administration Guide, StarOS Release 21.22
46
C H A P T E R 3
System Settings
This chapter provides instructions for configuring the following StarOS options.
It is assumed that the procedures to initially configure the system as described in Getting Started have been
completed.
Important
The commands used in the configuration examples in this section are the most likely-used commands and/or
keyword options. In many cases, other optional commands and/or keyword options are available. Refer to the
Command Line Interface Reference for complete information.
• Configuring a Second Management Interface, on page 47
• V erifying and Saving Y our Interface and Port Configuration, on page 48
• Configuring System Timing, on page 49
• Configuring SF Boot Configuration Pause, on page 53
• Enabling CLI Timestamping, on page 53
• Configuring CLI Confirmation Prompts, on page 54
• Configuring System Administrative Users, on page 56
• Configuring TACACS+ for System Administrative Users, on page 65
• IPv6 Address Support for TACACS+ Server, on page 69
• Separating Authentication Methods, on page 69
• Configuring a Chassis Key, on page 72
• Configuring MIO/UMIO/MIO2 Port Redundancy, on page 74
• Configuring Data Processing Card Availability, on page 77
• Enabling Automatic Reset of FSC Fabric, on page 78
• Configuring ASR 5500 Link Aggregation, on page 78
• Configuring a Demux Card, on page 85
Configuring a Second Management Interface
Refer to Getting Started for instructions on configuring a system management interface on the Management
Input/Output (MIO/UMIO/MIO2) card. This section provides described how to configure a second management
interface.
Use the following example to configure a second management interface:
ASR 5500 System Administration Guide, StarOS Release 21.22
47
System Settings
Verifying and Saving Your Interface and Port Configuration
configure
context local
interface interface_name
ip address ipaddress subnetmask
exit
ip route 0.0.0.0 0.0.0.0 gw_address interface_name
exit
port ethernet slot#/port#
bind interface interface_name local
no shutdown
media rj45
end
Notes:
• For port ethernet slot#, use the actual chassis slot in which the active MIO/UMIO/MIO2 resides (slot
number 5 or 6).
• Enter IP addresses using IPv4 dotted-decimal or IPv6 colon-separated-hexadecimal notation.
• For port ethernet port#, use the physical port on the MIO/UMIO/MIO2 card – port 1 or 2.
• The MIO/UMIO/MIO2 is equipped with RJ-45 (1000Base-T copper) interfaces. The RJ-45 interfaces
connect the system to the management network via CA T3 or CA T5 Ethernet cable.
• Option: In the Ethernet Port configuration mode, configure the port speed, if needed, by entering the
medium command. Refer to the Command Line Interface Reference for a complete explanation of this
command.
• In the { ip | ipv6 } route command, other keyword options, instead of the gateway IP address, are available
and include: next-hop IP address, point-to-point, and tunnel.
Verifying and Saving Your Interface and Port Configuration
V erify that your interface configuration settings are correct by entering the following command:
show ip interface
The output from this command should be similar to that shown below. In this example an interface named
mgmt2 was configured in the local context.
Intf Name: mgmt2
Intf Type: Broadcast
Description: management2
VRF: None
IP State: UP (Bound to 5/2)
IP Address: 192.168.100.3 Subnet Mask: 255.255.255.0
Bcast Address: 192.168.100.255 MTU: 1500
Resoln Type: ARP ARP timeout: 60 secs
L3 monitor LC-port switchover: Disabled
Number of Secondary Addresses: 0
V erify that the port configuration settings are correct by entering the following command:
show configuration port slot#/port#
ASR 5500 System Administration Guide, StarOS Release 21.22
48
System Settings
Configuring System Timing
slot# is the chassis slot number of the line card where the physical port resides. slot# is either 5 or 6. port# is
the number of the port (either 1 or 2).
This following command produces an output similar to the one shown below. It displays the configuration of
port 2 of the MIO/UMIO/MIO2 installed in chassis slot 5. In this example, the port is bound to an interface
called mgmt2.
config
port ethernet 5/2
description management2
no shutdown
bind interface mgmt2 local
end
Save your configuration as described in the V erifying and Saving Your Configuration chapter.
Configuring System Timing
The system is equipped with a clock that supplies the timestamp for statistical counters, accounting records,
logging, and event notification. After the initial configuration of the system clock, you can configure the
system to communicate with one or more Network Time Protocol (NTP) server(s) to ensure that the clock is
always accurate.
In the event of a power outage, the clock is maintained with an accuracy of + one minute per month for up to
10 years. This ensures that when power is restored, the system is ready to process sessions and generate
accounting, log, and event data with accurate timestamps.
In addition to configuring the timing source, you must configure the system's time zone.
Setting the System Clock and Time Zone
Use the following command example to configure the system clock and time zone:
clock set date:time
configure
clock timezone timezone [ local ]
end
Notes:
• Enter the date and time in the format YYYY:MM:DD:HH:mm or YYYY:MM:DD:HH:mm:ss.
• Refer to the online Help for the clock timezone command for a complete list of supported time zones.
• The optional local keyword indicates that the time zone specified is the local timezone.
• Daylight Savings Time is automatically adjusted for time zones supporting it.
Save your configuration as described in the V erifying and Saving Your Configuration chapter.
Verifying and Saving Your Clock and Time Zone Configuration
Enter the following command to verify that you configured the time and time zone correctly:
show clock
ASR 5500 System Administration Guide, StarOS Release 21.22
49
System Settings
Configuring Network Time Protocol Support
The output displays the date, time, and time zone that you configured.
Configuring Network Time Protocol Support
This section provides information and instructions for configuring the system to enable the use of the Network
Time Protocol (NTP).
Important
Configure the system clock and time zone prior to implementing NTP support. This greatly reduces the time
period that must be corrected by the NTP server.
Many of the services offered by the StarOS require accurate timekeeping derived through NTP . If the time
reference(s) used by StarOS are not accurate, the services may be unreliable. For this reason it should be
assumed that normal system operation requires that NTP be configured.
The system uses NTP to synchronize its internal clock to external time sources (typically GPS NTP sources,
or other Stratum 2 or 3 servers, switches or routers).
By default, NTP is not enabled externally and should be configured when the system is initially installed.
When enabled, the active MIO/UMIO/MIO2 will synchronize with external sources. If not enabled, the active
MIO/UMIO/MIO2 will use its local clock as a time source. In the event of an NTP server or network outage,
an already running MIO/UMIO/MIO2 will continue to use NTP to maintain time accuracy, but in a holdover
mode.
All cards with CPUs synchronize to the active MIO/UMIO/MIO2 internally. This occurs even if an external
NTP server is not configured. In the event of a MIO/UMIO/MIO2 switchover, all other cards will start
synchronizing with the newly active MIO/UMIO/MIO2 automatically.
The system should have:
• NTP enabled.
• NTP configured for use in the local context only. Use of other contexts (which can be specified in the
enable configurable) will cause issues.
• NTP configured for at least three external NTP servers. With three or more servers, outlyers and broken
or misconfigured servers can be detected and excluded. Generally, the more servers the better (within
reason).
Important
Do not configure any external NTP servers using the prefer keyword. The NTP clock selection algorithms
already have the built-in ability to pick the best server. Use of prefer usually results in a poorer choice than
NTP can determine for itself.
Important
Do not change the maxpoll, minpoll, or version keyword settings unless instructed to do so by Cisco TAC.
Use the following example to configure the necessary NTP association parameters:
configure
ntp
ASR 5500 System Administration Guide, StarOS Release 21.22
50
System Settings
Configuring NTP Servers with Local Sources
enable
server ip_address1
server ip_address2
server ip_address3
end
Notes:
• By default context_name is set to local. This is the recommended configuration.
• A number of options exist for the server command. Refer to the NTP Configuration Mode Commands
chapter in the Command Line Interface Reference for more information.
• Enter the IP address of NTP servers using IPv4 dotted-decimal or IPv6 colon-separated-hexadecimal
notation.
Important
Configure the system with at least three (preferably four) NTP servers.
Save the configuration as described in the V erifying and Saving Your Configuration chapter.
Configuring NTP Servers with Local Sources
NTP can use network peers, local external clocks (such as GPS devices), or a local clock with no external
source.
A local clock with no external source is usually a last-resort clock when no better clock is available. It is
typically configured on a site's intermediate NTP server so that when a W AN network outage occurs, hosts
within the site can continue to synchronize amongst themselves.
Y ou can configure this in ntpd or on many commercially available NTP devices. This local clock should
always have a high stratum number (8+) so that under normal conditions (when real sources are available)
this local clock will not be used.
Using a Load Balancer
The NTP daemon and protocol assume that each configured server is running NTP . If a NTP client is configured
to synchronize to a load balancer that relays and distributes packets to a set of real NTP servers, the load
balancer may distribute those packets dynamically and confuse the NTP client. NTP packets are latency and
jitter sensitive. Relaying them through a load balancer can confuse the NTP client and is not a supported
practice.
Verifying the NTP Configuration
V erify the NTP configuration is correct. Enter the following command at the Exec mode prompt:
show ntp associations
The output displays information about all NTP servers. See the output below for an example deploying two
NTP servers.
+----Peer Selection: ( ) - Rejected / No Response
| (x) - False Tick
ASR 5500 System Administration Guide, StarOS Release 21.22
51
System Settings
Verifying the NTP Configuration
| (.) - Excess
| (-) - Outlyer
| (+) - Candidate
| (#) - Selected
| (*) - System Peer
| (o) - PPS Peer
v
remote refid st t when poll reach delay offset jitter
==============================================================================
*10.81.254.202 .GPS. 1 u 160 1024 377 21.516 0.019 0.009
The following table describes the parameters output by the show ntp associations command.
T able 3: NTPParameters
Column Title
Description
remote
List of the current NTP servers. One of these
characters precedes each IP address to show the
server's current condition:
• ( ) Rejected/No response
• X False tick
•
. Excess
• - Outlyer
• + Candidate
• # Selected
• * System peer
• (o) PPS peer
refid
Last reported NTP reference to which the server is
synchronizing.
st
NTP server stratum level.
t
Communication type: broadcast, multicast, etc.
when
Number of seconds since the last contact.
poll
Polling interval between the system and the NTP
server.
reach
Octal value of the reachability shift register indicating
which responses were received for the previous eight
polls to this NTP server.
delay
Round-trip delay (in milliseconds) for messages
exchanged between the system and the NTP server.
offset
Number of milliseconds by which the system clock
must be adjusted to synchronize it with the NTP
server.
ASR 5500 System Administration Guide, StarOS Release 21.22
52
System Settings
Configuring SF Boot Configuration Pause
Column Title
jitter
Description
Jitter in milliseconds between the system and the NTP
server.
Configuring SF Boot Configuration Pause
Under certain circumstances, within VPC-DI deployments, the CF applies the boot configuration before all
SFs have completed their boot process.
The following Configuration Mode command, wait cards active, pauses configuration until all specified
cards are operational or the timeout period expires (whichever criteria is met first). The pause occurs
immediately following local management context creation and ntp/snmp configuration.
This command corrects a scenario where SFs come online late following chassis load or reload and the
configuration pertaining to those SFs is not applied (and thereby lost).
configure
[ no ] wait cards active { all | number } [ standby number ] timeout seconds
end
Notes:
• all: Pause until all active mode cards attain operational status.
• number : Pause until the specified number of active mode cards attain operational status.number is 0
through the number of active mode cards.
• standby number : (Optional) Also wait for the specified number of non-active mode cards to attain
operational status.
number is 0 through the number of service slots not configured for active mode SFs.
• timeout seconds: Wait from 1 through 3600 seconds for the specified card set to attain operational status.
The wait is terminated early when or if this condition is satisfied. Otherwise the wait is terminated when
the timeout period expires.
The following example command instructs the system to wait up to 120 seconds for all active cards and 1
standby card to become active:
wait cards active all standby 1 timeout 120
Enabling CLI Timestamping
To display a timestamp (date and time) for every command that is executed on the CLI, enter the following
command at the root prompt for the Exec mode:
timestamps
The date and time appear immediately after you execute the command.
Save the configuration as described in the V erifying and Saving Your Configuration chapter.
ASR 5500 System Administration Guide, StarOS Release 21.22
53
System Settings
Configuring CLI Confirmation Prompts
Configuring CLI Confirmation Prompts
A number of Exec mode and Global Configuration mode commands prompt users for a confirmation (Are
you sure? [Y es|No]:) prior to executing the command.
This section describes configuration settings that:
• Automatically confirm commands for the current CLI session (Exec mode) or for all CLI sessions and
users (Global Configuration mode).
• Requires confirmation prompting only for the Exec mode configure command and autoconfirm command.
• Selectively requires confirmation of Exec mode configuration commands.
Enabling Automatic Confirmation
Y ou can use the autoconfirm command to disable confirmation prompting for configuration commands. The
autoconfirm command is available in the Exec mode and Global Configuration mode. Enabling the autoconfirm
feature automatically supplies a "Y es" response to configuration command prompts, including for critical
commands such as reload and shutdown. By default autoconfirm is disabled.
In the Exec mode, autoconfirm applies only to the current interactive CLI session.
In the Global Configuration mode, autoconfirm applies to all CLI sessions for all CLI users:
configure
autoconfirm
end
To disable autoconfirm once it has been enabled, use the no autoconfirm command.
Important
If commandguard is enabled, autoconfirm will disable commandguard.
Autoconfirm is intended as an "ease-of-use" feature. It presumes that the answer to "Are you sure? [Y/N]"
prompts will be "Y es", and skips the prompt. Its use implies that the user is an expert who does not need these
"safety-net" prompts.
Requiring Confirmation for autoconfirm and configure Commands
Y ou can require confirmation prompting for the autoconfirm (Exec mode and Global Configuration mode)
and configure (Exec mode) commands via the Global Configuration mode commandguard command.
Important
If autoconfirm is enabled, commandguard will not take effect until autoconfirm is disabled in both Exec and
Global Configuration modes.
The following command sequence enables the commandguard feature:
configure
commandguard
end
ASR 5500 System Administration Guide, StarOS Release 21.22
54
System Settings
Requiring Confirmation for Specific Exec Mode Commands
With commandguard enabled the confirmation prompt appears as shown in the example below:
[local]host_name# configure
Are you sure? [Yes|No]: yes
[local]host_name(config)#
To disable commandguard once it has been enabled, use the no commandguard command.
The status of commandguard is output in show configuration commands.
Requiring Confirmation for Specific Exec Mode Commands
A keyword for the commandguard command allows you to apply mandatory prompting for specified categories
of Exec mode configuration commands, even when autoconfirm is enabled.
The command syntax is as follows:
configure
end
commandguard exec-command exec_mode_category
Notes:
• exec-command exec_mode_category specifies one of the following categories of Exec mode configuration
commands.
• card
• clear
• copy
• debug
• delete
• filesystem
• hd
• reload
• rename
• shutdown
• task
• upgrade
• Y ou can enter multiple commandguard exec-command exec_mode_category commands.
• All Exec mode commands beginning with the specified category word will prompt for confirmation,
regardless if autoconfirm is enabled.
• Y ou can turn off confirmation prompting for a specific category using no commandguard exec-command
exec_mode_category.
• If autoconfirm is overridden by commandguard exec-command for an Exec mode command, StarOS
displays an informational message indicating why autoconfirm is being overridden when you attempt to
execute the command.
• Users may selectively override confirmation prompting for any Exec mode configuration command that
supports the -noconfirm keyword.
For example, with commandguard exec-command card enabled, the confirmation prompt appears as shown
below:
[local]host_name# card busy-out 1
Info: commandguard prevents autoconfirm of this command
ASR 5500 System Administration Guide, StarOS Release 21.22
55
Sy