import { useState } from "react";
import {
  Server,
  Code,
  Network,
  Cloud,
  TrendingUp,
  Users,
  Building2,
  Shield,
  Lock,
  EyeOff,
  Download,
  Filter,
  Eye,
  Settings,
  ChevronRight,
  AlertTriangle,
  CheckCircle2,
  Clock,
  DollarSign,
  ArrowRight,
  Activity,
  FileKey,
  ArrowDownLeft,
  Cpu,
  Key,
  Zap,
  Radio,
  FileDown,
  BookOpen,
  Workflow,
  Package,
  Database,
} from "lucide-react";
import { AnimatedBackground } from "./components/AnimatedBackground";
import { SecurityHeader } from "./components/SecurityHeader";
import { ProcessFlowDashboard } from "./components/ProcessFlowDashboard";
import { DevicesTab } from "./components/DevicesTab";
import { SoftwareTab } from "./components/SoftwareTab";
import { DataFlowsTab } from "./components/DataFlowsTab";
import { ExternalSystemsTab } from "./components/ExternalSystemsTab";
import { ResourcesTab } from "./components/ResourcesTab";
import { RolesTab } from "./components/RolesTab";
import { BusinessTab } from "./components/BusinessTab";
import { DetectRespondTab } from "./components/DetectRespondTab";
import { CertificateTransactionTab } from "./components/CertificateTransactionTab";
import { IncomingTransactionTab } from "./components/IncomingTransactionTab";
import { FPGAHardwareTab } from "./components/FPGAHardwareTab";
import { FundsTransferPayloadTab } from "./components/FundsTransferPayloadTab";
import { PolicyManagementTab } from "./components/PolicyManagementTab";
import { LicenseManagementTab } from "./components/LicenseManagementTab";
import { Fina3xpres5LiveTab } from "./components/Fina3xpres5LiveTab";
import { Telecom5GTopologyTab } from "./components/Telecom5GTopologyTab";
import { ManuscriptExportTab } from "./components/ManuscriptExportTab";
import { TerminologyDossierTab } from "./components/TerminologyDossierTab";
import { ImportsTab } from "./components/ImportsTab";
import { RecognizantSubledgerTab } from "./components/RecognizantSubledgerTab";
import { SystemActivation } from "./components/SystemActivation";

const tabs = [
  {
    id: "process-flows",
    label: "Process Flows",
    icon: Workflow,
    code: "PROC-VIZ",
  },
  {
    id: "devices",
    label: "Devices",
    icon: Server,
    code: "ID.AM-1",
  },
  {
    id: "software",
    label: "Software",
    icon: Code,
    code: "ID.AM-2",
  },
  {
    id: "dataflows",
    label: "Data Flows",
    icon: Network,
    code: "ID.AM-3",
  },
  {
    id: "external",
    label: "External Systems",
    icon: Cloud,
    code: "ID.AM-4",
  },
  {
    id: "resources",
    label: "Resources",
    icon: TrendingUp,
    code: "ID.AM-5",
  },
  { id: "roles", label: "Roles", icon: Users, code: "ID.AM-6" },
  {
    id: "business",
    label: "Business",
    icon: Building2,
    code: "ID.BE",
  },
  {
    id: "detect",
    label: "Detect & Respond",
    icon: Activity,
    code: "DE.CM-4",
  },
  {
    id: "certx",
    label: "Certificates & Transactions",
    icon: FileKey,
    code: "ACT2-SUDI",
  },
  {
    id: "incoming",
    label: "Incoming Transactions",
    icon: ArrowDownLeft,
    code: "TXN-MON",
  },
  {
    id: "fpga",
    label: "FPGA Hardware",
    icon: Cpu,
    code: "HW-FPGA",
  },
  {
    id: "payload",
    label: "Funds Transfer Payload",
    icon: DollarSign,
    code: "FTP-BUILD",
  },
  {
    id: "policy",
    label: "Policy Management",
    icon: Shield,
    code: "NIST-171",
  },
  {
    id: "license",
    label: "License Management",
    icon: Key,
    code: "LIC-MGT",
  },
  {
    id: "fina-live",
    label: "Fina_3xpres5 Live",
    icon: Zap,
    code: "FINA-3X",
  },
  {
    id: "5g-topology",
    label: "5G Telecom Topology",
    icon: Radio,
    code: "5G-SA",
  },
  {
    id: "manuscript",
    label: "Manuscript Export",
    icon: FileDown,
    code: "DOC-EXP",
  },
  {
    id: "terminology",
    label: "Terminology & Dossier",
    icon: BookOpen,
    code: "TERM-DOC",
  },
  {
    id: "imports",
    label: "Imports",
    icon: Package,
    code: "SSH-VM",
  },
  {
    id: "subledger",
    label: "Recognizant Subledger",
    icon: Database,
    code: "HIER-SL",
  },
];

export default function App() {
  const [systemActivated, setSystemActivated] = useState(false);
  const [activeTab, setActiveTab] = useState("process-flows");
  const [secureMode, setSecureMode] = useState(true);
  const [auditLog, setAuditLog] = useState<string[]>([]);

  const logAudit = (action: string) => {
    const timestamp = new Date().toISOString();
    setAuditLog((prev) =>
      [`[${timestamp}] ${action}`, ...prev].slice(0, 100),
    );
    console.log(`AUDIT: ${action}`);
  };

  const toggleSecureMode = () => {
    const newMode = !secureMode;
    setSecureMode(newMode);
    logAudit(
      `Secure mode ${newMode ? "ENABLED" : "DISABLED"} - RBAC validation ${newMode ? "active" : "suspended"}`,
    );
  };

  const handleTabChange = (tabId: string) => {
    setActiveTab(tabId);
    logAudit(`Navigated to ${tabId.toUpperCase()} tab`);
  };

  const handleActivationComplete = () => {
    setSystemActivated(true);
    logAudit(
      "SYSTEM ACTIVATION COMPLETE - Platform now live and operational",
    );
  };

  if (!systemActivated) {
    return (
      <SystemActivation
        onActivationComplete={handleActivationComplete}
      />
    );
  }

  return (
    <div
      className="min-h-screen bg-[#0a0e1a] text-white relative overflow-hidden"
      style={{ fontFamily: "var(--font-rajdhani)" }}
    >
      <AnimatedBackground />

      <div className="relative z-10">
        <SecurityHeader
          secureMode={secureMode}
          onToggleSecure={toggleSecureMode}
          onAuditLog={logAudit}
        />

        {/* Tab Navigation */}
        <div className="border-b border-cyan-500/20 bg-gradient-to-r from-[#0a0e1a] via-[#0f1525] to-[#0a0e1a]">
          <div className="max-w-7xl mx-auto px-6">
            <div className="flex gap-1 overflow-x-auto scrollbar-hide">
              {tabs.map((tab, index) => {
                const Icon = tab.icon;
                const isActive = activeTab === tab.id;

                return (
                  <button
                    key={tab.id}
                    onClick={() => handleTabChange(tab.id)}
                    className={`
                      group relative px-6 py-4 transition-all duration-300 whitespace-nowrap
                      ${
                        isActive
                          ? "text-cyan-400"
                          : "text-gray-400 hover:text-cyan-300"
                      }
                    `}
                    style={{
                      animationDelay: `${index * 50}ms`,
                      animation:
                        "slideDown 0.5s ease-out forwards",
                    }}
                  >
                    <div className="flex items-center gap-3">
                      <Icon
                        className={`w-5 h-5 transition-transform duration-300 ${isActive ? "scale-110" : "group-hover:scale-105"}`}
                      />
                      <div className="text-left">
                        <div className="font-semibold text-sm tracking-wide uppercase">
                          {tab.label}
                        </div>
                        <div className="text-xs font-mono opacity-60">
                          {tab.code}
                        </div>
                      </div>
                    </div>

                    {isActive && (
                      <div
                        className="absolute bottom-0 left-0 right-0 h-0.5 bg-gradient-to-r from-transparent via-cyan-400 to-transparent"
                        style={{
                          animation:
                            "expandWidth 0.3s ease-out",
                        }}
                      />
                    )}

                    {isActive && (
                      <div
                        className="absolute inset-0 bg-cyan-400/5 backdrop-blur-sm"
                        style={{
                          animation: "fadeIn 0.3s ease-out",
                        }}
                      />
                    )}
                  </button>
                );
              })}
            </div>
          </div>
        </div>

        {/* Tab Content */}
        <div className="max-w-7xl mx-auto px-6 py-8">
          <div style={{ animation: "fadeIn 0.4s ease-out" }}>
            {activeTab === "process-flows" && (
              <ProcessFlowDashboard
                secureMode={secureMode}
                onAuditLog={logAudit}
              />
            )}
            {activeTab === "devices" && (
              <DevicesTab
                secureMode={secureMode}
                onAuditLog={logAudit}
              />
            )}
            {activeTab === "software" && (
              <SoftwareTab
                secureMode={secureMode}
                onAuditLog={logAudit}
              />
            )}
            {activeTab === "dataflows" && (
              <DataFlowsTab
                secureMode={secureMode}
                onAuditLog={logAudit}
              />
            )}
            {activeTab === "external" && (
              <ExternalSystemsTab
                secureMode={secureMode}
                onAuditLog={logAudit}
              />
            )}
            {activeTab === "resources" && (
              <ResourcesTab
                secureMode={secureMode}
                onAuditLog={logAudit}
              />
            )}
            {activeTab === "roles" && (
              <RolesTab
                secureMode={secureMode}
                onAuditLog={logAudit}
              />
            )}
            {activeTab === "business" && (
              <BusinessTab
                secureMode={secureMode}
                onAuditLog={logAudit}
              />
            )}
            {activeTab === "detect" && (
              <DetectRespondTab
                secureMode={secureMode}
                onAuditLog={logAudit}
              />
            )}
            {activeTab === "certx" && (
              <CertificateTransactionTab
                secureMode={secureMode}
                onAuditLog={logAudit}
              />
            )}
            {activeTab === "incoming" && (
              <IncomingTransactionTab
                secureMode={secureMode}
                onAuditLog={logAudit}
              />
            )}
            {activeTab === "fpga" && (
              <FPGAHardwareTab
                secureMode={secureMode}
                onAuditLog={logAudit}
              />
            )}
            {activeTab === "payload" && (
              <FundsTransferPayloadTab
                secureMode={secureMode}
                onAuditLog={logAudit}
              />
            )}
            {activeTab === "policy" && (
              <PolicyManagementTab
                secureMode={secureMode}
                onAuditLog={logAudit}
              />
            )}
            {activeTab === "license" && (
              <LicenseManagementTab
                secureMode={secureMode}
                onAuditLog={logAudit}
              />
            )}
            {activeTab === "fina-live" && (
              <Fina3xpres5LiveTab
                secureMode={secureMode}
                onAuditLog={logAudit}
              />
            )}
            {activeTab === "5g-topology" && (
              <Telecom5GTopologyTab
                secureMode={secureMode}
                onAuditLog={logAudit}
              />
            )}
            {activeTab === "manuscript" && (
              <ManuscriptExportTab
                secureMode={secureMode}
                onAuditLog={logAudit}
              />
            )}
            {activeTab === "terminology" && (
              <TerminologyDossierTab
                secureMode={secureMode}
                onAuditLog={logAudit}
              />
            )}
            {activeTab === "imports" && (
              <ImportsTab
                secureMode={secureMode}
                onAuditLog={logAudit}
              />
            )}
            {activeTab === "subledger" && (
              <RecognizantSubledgerTab
                secureMode={secureMode}
                onAuditLog={logAudit}
              />
            )}
          </div>
        </div>
      </div>

      <style>{`
        @keyframes slideDown {
          from {
            opacity: 0;
            transform: translateY(-10px);
          }
          to {
            opacity: 1;
            transform: translateY(0);
          }
        }

        @keyframes expandWidth {
          from {
            transform: scaleX(0);
          }
          to {
            transform: scaleX(1);
          }
        }

        @keyframes fadeIn {
          from {
            opacity: 0;
          }
          to {
            opacity: 1;
          }
        }

        .scrollbar-hide::-webkit-scrollbar {
          display: none;
        }

        .scrollbar-hide {
          -ms-overflow-style: none;
          scrollbar-width: none;
        }
      `}</style>
    </div>
  );
}