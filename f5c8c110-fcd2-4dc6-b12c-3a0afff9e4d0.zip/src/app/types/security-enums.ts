/**
 * VOM Banking Platform - Security Enumeration Types
 * Following Cisco ACT2 SUDI CA CPS v2.1 Guidelines
 * FIPS 140-2 Level 3 Compliance
 */

// Certificate Lifecycle Stages (Section 4.x)
export enum CertificateLifecycleStage {
  APPLICATION = 'APPLICATION',
  PROCESSING = 'PROCESSING',
  ISSUANCE = 'ISSUANCE',
  ACCEPTANCE = 'ACCEPTANCE',
  USAGE = 'USAGE',
  RENEWAL = 'RENEWAL',
  REVOCATION = 'REVOCATION',
  EXPIRATION = 'EXPIRATION'
}

// Certificate Application Status (4.1)
export enum CertificateApplicationStatus {
  PENDING_VALIDATION = 'PENDING_VALIDATION',
  SERIAL_NUMBER_VERIFIED = 'SERIAL_NUMBER_VERIFIED',
  PID_VALIDATED = 'PID_VALIDATED',
  SIGNATURE_VERIFIED = 'SIGNATURE_VERIFIED',
  APPROVED = 'APPROVED',
  REJECTED = 'REJECTED',
  ERROR = 'ERROR'
}

// Certificate Issuance Result (4.2.2)
export enum CertificateIssuanceResult {
  SUCCESS = 'SUCCESS',
  INVALID_SERIAL_NUMBER = 'INVALID_SERIAL_NUMBER',
  INVALID_PID = 'INVALID_PID',
  SIGNATURE_MISMATCH = 'SIGNATURE_MISMATCH',
  UNREGISTERED_CHIP = 'UNREGISTERED_CHIP',
  RATE_LIMIT_EXCEEDED = 'RATE_LIMIT_EXCEEDED',
  INTERNAL_ERROR = 'INTERNAL_ERROR'
}

// TLS Authentication Level (4.3.1)
export enum TLSAuthenticationLevel {
  TLS_1_3_MUTUAL_AUTH = 'TLS_1_3_MUTUAL_AUTH',
  TLS_1_2_MUTUAL_AUTH = 'TLS_1_2_MUTUAL_AUTH',
  TLS_1_3_SERVER_ONLY = 'TLS_1_3_SERVER_ONLY',
  MTLS_REQUIRED = 'MTLS_REQUIRED'
}

// Key Storage Security Level (4.5.1)
export enum KeyStorageSecurityLevel {
  FIPS_140_2_LEVEL_3 = 'FIPS_140_2_LEVEL_3',
  FIPS_140_2_LEVEL_2 = 'FIPS_140_2_LEVEL_2',
  HSM_BACKED = 'HSM_BACKED',
  SOFTWARE_PROTECTED = 'SOFTWARE_PROTECTED'
}

// Certificate Usage Purpose (4.5.2)
export enum CertificateUsagePurpose {
  DEVICE_AUTHENTICATION = 'DEVICE_AUTHENTICATION',
  DATA_ENCRYPTION = 'DATA_ENCRYPTION',
  DIGITAL_SIGNATURE = 'DIGITAL_SIGNATURE',
  KEY_EXCHANGE = 'KEY_EXCHANGE',
  TLS_CLIENT_AUTH = 'TLS_CLIENT_AUTH',
  TLS_SERVER_AUTH = 'TLS_SERVER_AUTH'
}

// Transaction Payload Type (Funds Transfer Schema)
export enum TransactionPayloadType {
  FUNDS_TRANSFER = 'FUNDS_TRANSFER',
  ACH_BATCH = 'ACH_BATCH',
  WIRE_TRANSFER = 'WIRE_TRANSFER',
  RTP_PAYMENT = 'RTP_PAYMENT',
  FEDNOW_PAYMENT = 'FEDNOW_PAYMENT',
  INTERNAL_TRANSFER = 'INTERNAL_TRANSFER'
}

// Ledger Effect Type
export enum LedgerEffectType {
  DEBIT = 'DEBIT',
  CREDIT = 'CREDIT',
  HOLD = 'HOLD',
  RELEASE = 'RELEASE'
}

// Transaction Status
export enum TransactionStatus {
  PENDING = 'PENDING',
  VALIDATING = 'VALIDATING',
  PROCESSING = 'PROCESSING',
  SETTLED = 'SETTLED',
  FAILED = 'FAILED',
  REVERSED = 'REVERSED',
  RECONCILED = 'RECONCILED'
}

// Encryption Algorithm (Defensible Parameterization)
export enum EncryptionAlgorithm {
  AES_256_GCM = 'AES_256_GCM',
  AES_256_CBC = 'AES_256_CBC',
  RSA_4096 = 'RSA_4096',
  RSA_2048 = 'RSA_2048',
  ECDSA_P256 = 'ECDSA_P256',
  ECDSA_P384 = 'ECDSA_P384'
}

// Hash Algorithm
export enum HashAlgorithm {
  SHA_256 = 'SHA_256',
  SHA_384 = 'SHA_384',
  SHA_512 = 'SHA_512',
  SHA3_256 = 'SHA3_256'
}

// Security Classification
export enum SecurityClassification {
  TOP_SECRET = 'TOP_SECRET',
  SECRET = 'SECRET',
  CONFIDENTIAL = 'CONFIDENTIAL',
  RESTRICTED = 'RESTRICTED',
  PUBLIC = 'PUBLIC'
}

// Data Sensitivity Level
export enum DataSensitivityLevel {
  HIGHLY_SENSITIVE = 'HIGHLY_SENSITIVE',
  SENSITIVE = 'SENSITIVE',
  INTERNAL = 'INTERNAL',
  PUBLIC = 'PUBLIC'
}

// Compliance Framework
export enum ComplianceFramework {
  CIS_CSC = 'CIS_CSC',
  COBIT_5 = 'COBIT_5',
  ISA_62443 = 'ISA_62443',
  ISO_27001_2013 = 'ISO_27001_2013',
  NIST_SP_800_53_REV_4 = 'NIST_SP_800_53_REV_4',
  PCI_DSS = 'PCI_DSS',
  FFIEC = 'FFIEC',
  SOC_2 = 'SOC_2'
}

// Audit Event Type
export enum AuditEventType {
  CERTIFICATE_ISSUED = 'CERTIFICATE_ISSUED',
  CERTIFICATE_RENEWED = 'CERTIFICATE_RENEWED',
  CERTIFICATE_REVOKED = 'CERTIFICATE_REVOKED',
  TRANSACTION_PROCESSED = 'TRANSACTION_PROCESSED',
  AUTHENTICATION_SUCCESS = 'AUTHENTICATION_SUCCESS',
  AUTHENTICATION_FAILURE = 'AUTHENTICATION_FAILURE',
  AUTHORIZATION_DENIED = 'AUTHORIZATION_DENIED',
  DATA_ACCESS = 'DATA_ACCESS',
  DATA_EXPORT = 'DATA_EXPORT',
  CONFIGURATION_CHANGE = 'CONFIGURATION_CHANGE',
  SECURITY_ALERT = 'SECURITY_ALERT'
}

// RBAC Permission Level
export enum RBACPermissionLevel {
  ADMIN = 'ADMIN',
  OPERATOR = 'OPERATOR',
  AUDITOR = 'AUDITOR',
  READ_ONLY = 'READ_ONLY',
  NO_ACCESS = 'NO_ACCESS'
}

// Cluster Node Status
export enum ClusterNodeStatus {
  ACTIVE = 'ACTIVE',
  STANDBY = 'STANDBY',
  DEGRADED = 'DEGRADED',
  MAINTENANCE = 'MAINTENANCE',
  OFFLINE = 'OFFLINE',
  FAILED = 'FAILED'
}

// Performance Tier
export enum PerformanceTier {
  TIER_1_CRITICAL = 'TIER_1_CRITICAL',
  TIER_2_HIGH = 'TIER_2_HIGH',
  TIER_3_MEDIUM = 'TIER_3_MEDIUM',
  TIER_4_LOW = 'TIER_4_LOW'
}

// Network Protocol
export enum NetworkProtocol {
  HTTPS_TLS_1_3 = 'HTTPS_TLS_1_3',
  HTTPS_TLS_1_2 = 'HTTPS_TLS_1_2',
  MTLS = 'MTLS',
  SFTP_TLS = 'SFTP_TLS',
  P2P_ENCRYPTED = 'P2P_ENCRYPTED',
  VPN_IPSEC = 'VPN_IPSEC'
}

// Firewall Rule Action
export enum FirewallRuleAction {
  ALLOW = 'ALLOW',
  DENY = 'DENY',
  LOG = 'LOG',
  RATE_LIMIT = 'RATE_LIMIT',
  QUARANTINE = 'QUARANTINE'
}

// Security Event Severity
export enum SecurityEventSeverity {
  CRITICAL = 'CRITICAL',
  HIGH = 'HIGH',
  MEDIUM = 'MEDIUM',
  LOW = 'LOW',
  INFO = 'INFO'
}
