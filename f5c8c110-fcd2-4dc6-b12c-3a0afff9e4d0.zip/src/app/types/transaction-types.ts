/**
 * VOM Banking Platform - Transaction Type Definitions
 * Defensible Parameterization with Encrypted Schema
 * Following NIST, ISO/IEC 27001, and Cisco Security Guidelines
 */

import {
  TransactionPayloadType,
  LedgerEffectType,
  TransactionStatus,
  EncryptionAlgorithm,
  HashAlgorithm
} from './security-enums';

/**
 * Funds Transfer Transaction Payload
 * Encrypted at rest and in transit
 */
export interface FundsTransferPayload {
  payload_type: TransactionPayloadType.FUNDS_TRANSFER;
  version: number;

  txn_id: string; // UUID v4

  originator_account: AccountIdentifier;
  beneficiary_account: AccountIdentifier;

  amount: MonetaryAmount;
  ledger_effect: LedgerEffectType;

  event_ts: Date;    // BSON Timestamp (second precision)
  ingest_ts: Date;   // Full millisecond precision

  metadata: TransactionMetadata;
}

/**
 * Account Identifier with Tokenization
 * Account numbers are tokenized using HashiCorp Vault
 */
export interface AccountIdentifier {
  institution: string;
  routing_number: string;
  account_number_token: string; // Tokenized - never store plaintext
}

/**
 * Monetary Amount
 * Uses integer representation to avoid floating point errors
 */
export interface MonetaryAmount {
  currency: CurrencyCode;
  units: number;      // Integer dollars (NumberLong)
  nanos: number;      // 0-999,999,999 (NumberInt)
}

/**
 * ISO 4217 Currency Codes
 */
export enum CurrencyCode {
  USD = 'USD',
  EUR = 'EUR',
  GBP = 'GBP',
  JPY = 'JPY',
  CAD = 'CAD',
  AUD = 'AUD',
  CHF = 'CHF'
}

/**
 * Transaction Metadata with Cryptographic Verification
 */
export interface TransactionMetadata {
  source: TransactionSource;
  idempotency_key: string;  // Required for duplicate detection
  hash: string;             // SHA-256 over canonical form (hex string)
  signature?: string;       // Optional RSA-4096 signature (base64)

  // Audit trail
  created_by?: string;
  approved_by?: string;
  ip_address?: string;
  user_agent?: string;

  // Compliance
  compliance_checked: boolean;
  fraud_score?: number;
  aml_cleared?: boolean;
}

/**
 * Transaction Source Types
 */
export enum TransactionSource {
  INGEST_API = 'INGEST_API',
  CUSTOMER_PORTAL = 'CUSTOMER_PORTAL',
  MOBILE_APP = 'MOBILE_APP',
  BATCH_PROCESSOR = 'BATCH_PROCESSOR',
  INTERNAL_SYSTEM = 'INTERNAL_SYSTEM',
  FEDWIRE = 'FEDWIRE',
  ACH_NETWORK = 'ACH_NETWORK',
  RTP_NETWORK = 'RTP_NETWORK',
  FEDNOW = 'FEDNOW'
}

/**
 * ACH Batch Transaction
 */
export interface ACHBatchPayload {
  payload_type: TransactionPayloadType.ACH_BATCH;
  version: number;

  batch_id: string;
  batch_header: ACHBatchHeader;
  transactions: FundsTransferPayload[];

  total_debit_amount: MonetaryAmount;
  total_credit_amount: MonetaryAmount;
  entry_count: number;

  settlement_date: Date;
  effective_date: Date;

  metadata: TransactionMetadata;
}

/**
 * ACH Batch Header (NACHA format compliance)
 */
export interface ACHBatchHeader {
  company_name: string;
  company_identification: string;
  standard_entry_class: ACHStandardEntryClass;
  company_entry_description: string;
  company_descriptive_date?: string;
  effective_entry_date: Date;
  originating_dfi_identification: string;
  batch_number: number;
}

/**
 * ACH Standard Entry Class Codes
 */
export enum ACHStandardEntryClass {
  PPD = 'PPD',  // Prearranged Payment and Deposit
  CCD = 'CCD',  // Corporate Credit or Debit
  CTX = 'CTX',  // Corporate Trade Exchange
  WEB = 'WEB',  // Internet-Initiated Entry
  TEL = 'TEL',  // Telephone-Initiated Entry
  POS = 'POS',  // Point-of-Sale Entry
  IAT = 'IAT'   // International ACH Transaction
}

/**
 * Wire Transfer Payload (Fedwire)
 */
export interface WireTransferPayload {
  payload_type: TransactionPayloadType.WIRE_TRANSFER;
  version: number;

  wire_id: string;
  imad: string; // Input Message Accountability Data
  omad: string; // Output Message Accountability Data

  originator: WireParty;
  beneficiary: WireParty;
  intermediary_bank?: WireParty;

  amount: MonetaryAmount;
  value_date: Date;

  business_function_code: string;
  charges?: MonetaryAmount;

  metadata: TransactionMetadata;
}

/**
 * Wire Transfer Party Information
 */
export interface WireParty {
  name: string;
  account_number_token: string;
  routing_number: string;
  address?: string;
  city?: string;
  state?: string;
  postal_code?: string;
  country?: string;
}

/**
 * Real-Time Payment (RTP/FedNow) Payload
 */
export interface RealTimePaymentPayload {
  payload_type: TransactionPayloadType.RTP_PAYMENT | TransactionPayloadType.FEDNOW_PAYMENT;
  version: number;

  payment_id: string;
  end_to_end_id: string;
  transaction_id: string;

  debtor: RTParty;
  creditor: RTParty;

  amount: MonetaryAmount;
  settlement_method: SettlementMethod;

  remittance_information?: string;
  payment_purpose?: string;

  metadata: TransactionMetadata;
}

/**
 * Real-Time Payment Party
 */
export interface RTParty {
  name: string;
  account_number_token: string;
  routing_number: string;
  bank_name: string;
}

/**
 * Settlement Methods
 */
export enum SettlementMethod {
  INSTANT = 'INSTANT',
  DEFERRED = 'DEFERRED',
  SAME_DAY = 'SAME_DAY',
  NEXT_DAY = 'NEXT_DAY'
}

/**
 * Complete Transaction Record (Database Storage)
 */
export interface TransactionRecord {
  // Identity
  id: string;
  txn_id: string;
  idempotency_key: string;

  // Type & Status
  payload_type: TransactionPayloadType;
  status: TransactionStatus;
  version: number;

  // Payload (encrypted at rest)
  payload: FundsTransferPayload | ACHBatchPayload | WireTransferPayload | RealTimePaymentPayload;

  // Cryptographic Verification
  hash: string;
  signature?: string;
  hash_algorithm: HashAlgorithm;
  encryption_algorithm: EncryptionAlgorithm;

  // Timestamps
  created_at: Date;
  updated_at: Date;
  processed_at?: Date;
  settled_at?: Date;

  // Audit Trail
  created_by: string;
  approved_by?: string;
  processed_by?: string;

  // Compliance & Security
  compliance_checked: boolean;
  fraud_score: number;
  aml_cleared: boolean;
  sanctions_checked: boolean;

  // Error Handling
  error_code?: string;
  error_message?: string;
  retry_count: number;
  max_retries: number;

  // Blockchain Backup (optional)
  blockchain_hash?: string;
  blockchain_block_number?: number;
}

/**
 * Transaction Validation Result
 */
export interface TransactionValidationResult {
  valid: boolean;
  errors: ValidationError[];
  warnings: ValidationWarning[];

  // Security checks
  signature_valid: boolean;
  hash_valid: boolean;
  idempotency_check_passed: boolean;

  // Business rules
  amount_within_limits: boolean;
  accounts_valid: boolean;
  compliance_passed: boolean;

  // Fraud detection
  fraud_score: number;
  suspicious_activity_detected: boolean;
}

/**
 * Validation Error
 */
export interface ValidationError {
  field: string;
  code: string;
  message: string;
  severity: 'CRITICAL' | 'ERROR';
}

/**
 * Validation Warning
 */
export interface ValidationWarning {
  field: string;
  code: string;
  message: string;
  severity: 'WARNING' | 'INFO';
}

/**
 * Transaction Query Filters
 */
export interface TransactionQueryFilter {
  // Identity
  txn_id?: string;
  idempotency_key?: string;

  // Type & Status
  payload_type?: TransactionPayloadType;
  status?: TransactionStatus | TransactionStatus[];

  // Accounts (tokenized)
  originator_account_token?: string;
  beneficiary_account_token?: string;

  // Amount range
  min_amount?: number;
  max_amount?: number;
  currency?: CurrencyCode;

  // Time range
  created_after?: Date;
  created_before?: Date;
  settled_after?: Date;
  settled_before?: Date;

  // Metadata
  source?: TransactionSource;
  created_by?: string;

  // Pagination
  limit?: number;
  offset?: number;
  sort_by?: string;
  sort_order?: 'ASC' | 'DESC';
}
