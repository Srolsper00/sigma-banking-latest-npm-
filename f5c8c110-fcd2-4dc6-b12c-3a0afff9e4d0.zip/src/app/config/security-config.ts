/**
 * VOM Banking Platform - Security Configuration
 * Encrypted Build Configuration with Syntax Protection Firewall
 * Defensible Parameterization Following Cisco ACT2 SUDI Guidelines
 */

import {
  TLSAuthenticationLevel,
  KeyStorageSecurityLevel,
  EncryptionAlgorithm,
  HashAlgorithm,
  ComplianceFramework,
  FirewallRuleAction,
} from "../types/security-enums";

/**
 * Encrypted Configuration Parameters
 * NOTE: In production, these should be loaded from encrypted environment variables
 * or secure vault (HashiCorp Vault, AWS Secrets Manager, etc.)
 */
export const SECURITY_CONFIG = {
  // Certificate Management (ACT2 SUDI CA)
  certificate: {
    ca: {
      name: "ACT2_SUDI_CA",
      version: "2.1",
      tlsLevel: TLSAuthenticationLevel.TLS_1_3_MUTUAL_AUTH,
      keyStorage: KeyStorageSecurityLevel.FIPS_140_2_LEVEL_3,
      autoRenewal: true,
      renewalThresholdDays: 30,
      maxCertLifetimeDays: 365,
    },
    validation: {
      requireSerialNumberMatch: true,
      requirePIDValidation: true,
      requireSignatureVerification: true,
      validateChipRegistration: true,
      allowUnregisteredChips: false,
    },
    issuance: {
      autoApproval: true,
      requireManualReview: false,
      maxIssuanceTimeMs: 5000,
      retryAttempts: 3,
      retryDelayMs: 1000,
    },
  },

  // Encryption Settings
  encryption: {
    atRest: {
      algorithm: EncryptionAlgorithm.AES_256_GCM,
      keyRotationDays: 90,
      requireHardwareBackedKeys: true,
    },
    inTransit: {
      algorithm: EncryptionAlgorithm.AES_256_GCM,
      tlsMinVersion: "1.3",
      cipherSuites: [
        "TLS_AES_256_GCM_SHA384",
        "TLS_CHACHA20_POLY1305_SHA256",
        "TLS_AES_128_GCM_SHA256",
      ],
      requireMutualAuth: true,
      allowWeakCiphers: false,
    },
    signing: {
      algorithm: EncryptionAlgorithm.RSA_4096,
      hashAlgorithm: HashAlgorithm.SHA_256,
      requireTimestamp: true,
      allowSelfSigned: false,
    },
  },

  // Firewall Configuration - Syntax Protection
  firewall: {
    enabled: true,
    mode: "STRICT",
    rules: [
      {
        name: "BLOCK_SQL_INJECTION",
        pattern:
          /(\bUNION\b|\bSELECT\b|\bDROP\b|\bINSERT\b|\bUPDATE\b|\bDELETE\b)/i,
        action: FirewallRuleAction.DENY,
        severity: "CRITICAL",
        logEvent: true,
      },
      {
        name: "BLOCK_XSS",
        pattern: /<script|javascript:|onerror=|onload=/i,
        action: FirewallRuleAction.DENY,
        severity: "CRITICAL",
        logEvent: true,
      },
      {
        name: "BLOCK_COMMAND_INJECTION",
        pattern: /(\||;|&&|\$\(|\`)/,
        action: FirewallRuleAction.DENY,
        severity: "CRITICAL",
        logEvent: true,
      },
      {
        name: "BLOCK_PATH_TRAVERSAL",
        pattern: /(\.\.\/|\.\.\\)/,
        action: FirewallRuleAction.DENY,
        severity: "HIGH",
        logEvent: true,
      },
      {
        name: "RATE_LIMIT_API",
        pattern: /^\/api\//,
        action: FirewallRuleAction.RATE_LIMIT,
        severity: "MEDIUM",
        maxRequestsPerMinute: 100,
        logEvent: false,
      },
    ],
    ipWhitelist: [
      // Production: Load from environment
      "10.0.0.0/8", // Internal network
      "172.16.0.0/12", // VPC network
      "192.168.0.0/16", // Private network
    ],
    blockByDefault: false,
    logAllRequests: true,
  },

  // Transaction Processing Security
  transaction: {
    validation: {
      requireSignature: true,
      requireIdempotencyKey: true,
      requireHashVerification: true,
      maxTransactionSize: 10485760, // 10MB
      allowedPayloadTypes: [
        "FUNDS_TRANSFER",
        "ACH_BATCH",
        "WIRE_TRANSFER",
        "RTP_PAYMENT",
        "FEDNOW_PAYMENT",
      ],
    },
    limits: {
      maxAmountUSD: 10000000, // $10M
      dailyLimitUSD: 100000000, // $100M
      requireDualApprovalAbove: 1000000, // $1M
      blockSuspiciousPatterns: true,
    },
    audit: {
      logAllTransactions: true,
      immutableStorage: true,
      blockchainBackup: true,
      retentionDays: 2555, // 7 years
    },
  },

  // RBAC & Access Control
  accessControl: {
    rbac: {
      enabled: true,
      requireMFA: true,
      sessionTimeoutMinutes: 30,
      maxFailedAttempts: 3,
      lockoutDurationMinutes: 15,
    },
    apiKeys: {
      requireRotation: true,
      rotationDays: 90,
      allowMultipleKeys: true,
      maxKeysPerUser: 5,
      requireEncryptedStorage: true,
    },
    audit: {
      logAllAccess: true,
      logFailedAttempts: true,
      logExports: true,
      alertOnSuspiciousActivity: true,
    },
  },

  // Compliance Requirements
  compliance: {
    frameworks: [
      ComplianceFramework.CIS_CSC,
      ComplianceFramework.COBIT_5,
      ComplianceFramework.ISA_62443,
      ComplianceFramework.ISO_27001_2013,
      ComplianceFramework.NIST_SP_800_53_REV_4,
      ComplianceFramework.PCI_DSS,
      ComplianceFramework.FFIEC,
    ],
    dataRetention: {
      auditLogsDays: 2555, // 7 years
      transactionsDays: 2555, // 7 years
      certificatesDays: 730, // 2 years
      sessionLogsDays: 90, // 90 days
    },
    encryption: {
      requireAtRest: true,
      requireInTransit: true,
      requireEndToEnd: true,
      allowUnencryptedStorage: false,
    },
  },

  // Performance & Monitoring
  monitoring: {
    metrics: {
      enabled: true,
      intervalSeconds: 30,
      retentionDays: 90,
    },
    alerts: {
      enabled: true,
      channels: ["email", "slack", "pagerduty"],
      criticalResponseTimeMinutes: 5,
      highResponseTimeMinutes: 30,
    },
    healthChecks: {
      enabled: true,
      intervalSeconds: 30,
      timeout: 5000,
      retries: 3,
    },
  },
} as const;

/**
 * Syntax Protection Firewall Validator
 */
export class SyntaxFirewall {
  private static instance: SyntaxFirewall;

  private constructor() {}

  public static getInstance(): SyntaxFirewall {
    if (!SyntaxFirewall.instance) {
      SyntaxFirewall.instance = new SyntaxFirewall();
    }
    return SyntaxFirewall.instance;
  }

  /**
   * Validate input against firewall rules
   */
  public validate(
    input: string,
    context: string = "unknown",
  ): ValidationResult {
    if (!SECURITY_CONFIG.firewall.enabled) {
      return { valid: true, sanitized: input };
    }

    for (const rule of SECURITY_CONFIG.firewall.rules) {
      if (rule.pattern.test(input)) {
        if (rule.action === FirewallRuleAction.DENY) {
          this.logSecurityEvent(
            rule.name,
            input,
            context,
            rule.severity,
          );
          return {
            valid: false,
            error: `Security violation: ${rule.name}`,
            blocked: true,
          };
        } else if (
          rule.action === FirewallRuleAction.RATE_LIMIT
        ) {
          // Rate limiting logic would go here
          if (rule.logEvent) {
            this.logSecurityEvent(
              rule.name,
              input,
              context,
              rule.severity,
            );
          }
        }
      }
    }

    return {
      valid: true,
      sanitized: this.sanitize(input),
    };
  }

  /**
   * Sanitize input by removing dangerous characters
   */
  private sanitize(input: string): string {
    return input
      .replace(/</g, "&lt;")
      .replace(/>/g, "&gt;")
      .replace(/"/g, "&quot;")
      .replace(/'/g, "&#x27;")
      .replace(/\//g, "&#x2F;");
  }

  /**
   * Log security event
   */
  private logSecurityEvent(
    ruleName: string,
    input: string,
    context: string,
    severity: string,
  ): void {
    const event = {
      timestamp: new Date().toISOString(),
      type: "FIREWALL_BLOCK",
      severity,
      rule: ruleName,
      context,
      inputLength: input.length,
      // Don't log full input for security reasons
      inputSample: input.substring(0, 100),
    };

    console.error("[SECURITY FIREWALL]", event);

    // In production, send to SIEM/logging system
    if (SECURITY_CONFIG.monitoring.alerts.enabled) {
      // this.sendAlert(event);
    }
  }
}

export interface ValidationResult {
  valid: boolean;
  sanitized?: string;
  error?: string;
  blocked?: boolean;
}

/**
 * Encryption Utilities
 */
export class EncryptionUtils {
  /**
   * Generate secure hash for transaction
   */
  public static async hashTransaction(
    data: any,
  ): Promise<string> {
    const canonical = this.canonicalize(data);
    const encoder = new TextEncoder();
    const dataBuffer = encoder.encode(canonical);

    const hashBuffer = await crypto.subtle.digest(
      SECURITY_CONFIG.encryption.signing.hashAlgorithm.replace(
        "_",
        "-",
      ),
      dataBuffer,
    );

    return this.bufferToHex(hashBuffer);
  }

  /**
   * Canonicalize object for consistent hashing
   */
  private static canonicalize(obj: any): string {
    if (obj === null) return "null";
    if (typeof obj !== "object") return JSON.stringify(obj);

    if (Array.isArray(obj)) {
      return (
        "[" +
        obj.map((item) => this.canonicalize(item)).join(",") +
        "]"
      );
    }

    const keys = Object.keys(obj).sort();
    const pairs = keys.map(
      (key) => `"${key}":${this.canonicalize(obj[key])}`,
    );
    return "{" + pairs.join(",") + "}";
  }

  /**
   * Convert buffer to hex string
   */
  private static bufferToHex(buffer: ArrayBuffer): string {
    return Array.from(new Uint8Array(buffer))
      .map((b) => b.toString(16).padStart(2, "0"))
      .join("");
  }
}

// Export singleton instance
export const syntaxFirewall = SyntaxFirewall.getInstance();