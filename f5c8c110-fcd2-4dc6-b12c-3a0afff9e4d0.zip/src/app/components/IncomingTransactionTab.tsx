import { useEffect, useState } from "react";
import { StateBadge } from "./StateBadge";
import { ExceptionBadge } from "./ExceptionBadge";
import {
  ArrowDownLeft,
  Shield,
  TrendingUp,
  AlertTriangle,
  CheckCircle2,
  Activity,
  RefreshCw,
  Filter,
  Download,
} from "lucide-react";

type TransactionState =
  | "INITIATED"
  | "VALIDATING"
  | "RISK_CHECK"
  | "COMPLIANCE_CHECK"
  | "APPROVED"
  | "POSTED_TO_LEDGER"
  | "SETTLED"
  | "COMPLETED"
  | "BLOCKED"
  | "FAILED";

type ExceptionType =
  | "FRAUD_DETECTED"
  | "AML_VIOLATION"
  | "SANCTIONS_MATCH"
  | "DUPLICATE_TRANSACTION"
  | "INSUFFICIENT_FUNDS"
  | "VELOCITY_LIMIT"
  | "GEOLOCATION_RISK"
  | "UNAUTHORIZED_COUNTERPARTY";

interface Transaction {
  transactionId: string;
  type: string;
  amount: number;
  state: TransactionState;
  fraudScore: number;
  complianceStatus: string;
  exception?: ExceptionType;
  timestamp: string;
  source: string;
  destination: string;
}

interface IncomingTransactionTabProps {
  secureMode: boolean;
  onAuditLog: (action: string) => void;
}

const TRANSACTION_TYPES = [
  "WIRE",
  "ACH",
  "SWIFT",
  "SEPA",
  "RTP",
  "CRYPTO",
];
const STATES: TransactionState[] = [
  "INITIATED",
  "VALIDATING",
  "RISK_CHECK",
  "COMPLIANCE_CHECK",
  "APPROVED",
  "POSTED_TO_LEDGER",
  "SETTLED",
  "COMPLETED",
  "BLOCKED",
  "FAILED",
];

const EXCEPTIONS: ExceptionType[] = [
  "FRAUD_DETECTED",
  "AML_VIOLATION",
  "SANCTIONS_MATCH",
  "DUPLICATE_TRANSACTION",
  "INSUFFICIENT_FUNDS",
  "VELOCITY_LIMIT",
  "GEOLOCATION_RISK",
  "UNAUTHORIZED_COUNTERPARTY",
];

const SOURCES = [
  "ACCT-4521-8873",
  "ACCT-9012-3345",
  "ACCT-6677-4421",
  "EXT-CHASE-001",
  "EXT-WELLS-002",
  "EXT-HSBC-003",
];

const DESTINATIONS = [
  "ACCT-X90-602690",
  "ACCT-5566-7788",
  "ACCT-9900-1122",
  "EXT-CFSB-026073008-85086694142",
  "EXT-CITI-271070801-0143573253",
];

// Generate realistic mock transaction data
function generateMockTransaction(id: number): Transaction {
  const hasException = Math.random() < 0.15;
  const state = hasException
    ? Math.random() < 0.5
      ? "BLOCKED"
      : "FAILED"
    : STATES[Math.floor(Math.random() * (STATES.length - 2))]; // Exclude BLOCKED and FAILED for non-exception

  return {
    transactionId: `TXN-${Date.now()}-${id.toString().padStart(4, "0")}`,
    type: TRANSACTION_TYPES[
      Math.floor(Math.random() * TRANSACTION_TYPES.length)
    ],
    amount: Math.floor(Math.random() * 1000000) + 1000,
    state,
    fraudScore: hasException
      ? Math.floor(Math.random() * 30) + 70
      : Math.floor(Math.random() * 40),
    complianceStatus: hasException
      ? "FLAGGED"
      : Math.random() < 0.9
        ? "PASS"
        : "REVIEW",
    exception: hasException
      ? EXCEPTIONS[
          Math.floor(Math.random() * EXCEPTIONS.length)
        ]
      : undefined,
    timestamp: new Date().toISOString(),
    source: SOURCES[Math.floor(Math.random() * SOURCES.length)],
    destination:
      DESTINATIONS[
        Math.floor(Math.random() * DESTINATIONS.length)
      ],
  };
}

// Simulate transaction state progression
function progressTransaction(txn: Transaction): Transaction {
  const currentIndex = STATES.indexOf(txn.state);

  // Don't progress BLOCKED, FAILED, or COMPLETED states
  if (
    txn.state === "BLOCKED" ||
    txn.state === "FAILED" ||
    txn.state === "COMPLETED"
  ) {
    return txn;
  }

  // Random chance to progress
  if (Math.random() < 0.3) {
    const nextIndex = Math.min(
      currentIndex + 1,
      STATES.indexOf("COMPLETED"),
    );
    return {
      ...txn,
      state: STATES[nextIndex],
    };
  }

  return txn;
}

export function IncomingTransactionTab({
  secureMode,
  onAuditLog,
}: IncomingTransactionTabProps) {
  const [transactions, setTransactions] = useState<
    Transaction[]
  >([]);
  const [isRefreshing, setIsRefreshing] = useState(false);
  const [stats, setStats] = useState({
    total: 0,
    blocked: 0,
    flagged: 0,
    completed: 0,
  });

  // Initialize with mock data
  useEffect(() => {
    const initialTransactions = Array.from(
      { length: 12 },
      (_, i) => generateMockTransaction(i),
    );
    setTransactions(initialTransactions);
    onAuditLog(
      "Incoming Transaction Dashboard initialized - Real-time monitoring active",
    );
  }, []);

  // Simulate real-time updates
  useEffect(() => {
    const interval = setInterval(() => {
      setTransactions((prev) => {
        let updated = prev.map(progressTransaction);

        // Randomly add new transaction (20% chance)
        if (Math.random() < 0.2 && updated.length < 20) {
          updated = [
            generateMockTransaction(Date.now()),
            ...updated,
          ];
        }

        // Remove old completed transactions if we have too many
        if (updated.length > 15) {
          updated = updated.slice(0, 15);
        }

        return updated;
      });
    }, 3000);

    return () => clearInterval(interval);
  }, []);

  // Update stats when transactions change
  useEffect(() => {
    setStats({
      total: transactions.length,
      blocked: transactions.filter((t) => t.state === "BLOCKED")
        .length,
      flagged: transactions.filter((t) => t.exception).length,
      completed: transactions.filter(
        (t) => t.state === "COMPLETED",
      ).length,
    });
  }, [transactions]);

  const handleRefresh = () => {
    setIsRefreshing(true);
    onAuditLog("Manual transaction refresh triggered");

    setTimeout(() => {
      const newTransactions = Array.from(
        { length: 12 },
        (_, i) => generateMockTransaction(i),
      );
      setTransactions(newTransactions);
      setIsRefreshing(false);
    }, 500);
  };

  const handleExport = () => {
    onAuditLog(
      "Transaction data export requested - Generating encrypted report",
    );
  };

  return (
    <div className="space-y-6">
      {/* Header with Stats */}
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-4">
          <div className="flex items-center gap-3">
            <div className="p-3 rounded-lg bg-cyan-500/10 border border-cyan-500/30">
              <ArrowDownLeft className="w-6 h-6 text-cyan-400" />
            </div>
            <div>
              <h2 className="text-2xl font-bold text-white tracking-wider">
                INCOMING TRANSACTION VALIDATION
              </h2>
              <p className="text-sm text-gray-400 font-mono">
                Real-time monitoring • Auto-refresh: 3s • NIST
                CSF: DE.CM-4
              </p>
            </div>
          </div>
        </div>

        <div className="flex items-center gap-3">
          <button
            onClick={handleRefresh}
            disabled={!secureMode}
            className="flex items-center gap-2 px-4 py-2 bg-cyan-500/10 hover:bg-cyan-500/20 border border-cyan-500/30 rounded text-cyan-400 transition-all disabled:opacity-50 disabled:cursor-not-allowed"
          >
            <RefreshCw
              className={`w-4 h-4 ${isRefreshing ? "animate-spin" : ""}`}
            />
            <span className="text-sm font-mono tracking-wide">
              REFRESH
            </span>
          </button>

          <button
            onClick={handleExport}
            disabled={!secureMode}
            className="flex items-center gap-2 px-4 py-2 bg-cyan-500/10 hover:bg-cyan-500/20 border border-cyan-500/30 rounded text-cyan-400 transition-all disabled:opacity-50 disabled:cursor-not-allowed"
          >
            <Download className="w-4 h-4" />
            <span className="text-sm font-mono tracking-wide">
              EXPORT
            </span>
          </button>
        </div>
      </div>

      {/* Stats Grid */}
      <div className="grid grid-cols-4 gap-4">
        <div className="p-4 rounded-lg bg-gradient-to-br from-cyan-500/10 to-blue-500/10 border border-cyan-500/20">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-xs text-gray-400 font-mono uppercase tracking-wider">
                Total Active
              </p>
              <p className="text-3xl font-bold text-cyan-400 mt-1">
                {stats.total}
              </p>
            </div>
            <Activity className="w-8 h-8 text-cyan-400/50" />
          </div>
        </div>

        <div className="p-4 rounded-lg bg-gradient-to-br from-green-500/10 to-emerald-500/10 border border-green-500/20">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-xs text-gray-400 font-mono uppercase tracking-wider">
                Completed
              </p>
              <p className="text-3xl font-bold text-green-400 mt-1">
                {stats.completed}
              </p>
            </div>
            <CheckCircle2 className="w-8 h-8 text-green-400/50" />
          </div>
        </div>

        <div className="p-4 rounded-lg bg-gradient-to-br from-red-500/10 to-orange-500/10 border border-red-500/20">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-xs text-gray-400 font-mono uppercase tracking-wider">
                Blocked
              </p>
              <p className="text-3xl font-bold text-red-400 mt-1">
                {stats.blocked}
              </p>
            </div>
            <Shield className="w-8 h-8 text-red-400/50" />
          </div>
        </div>

        <div className="p-4 rounded-lg bg-gradient-to-br from-yellow-500/10 to-amber-500/10 border border-yellow-500/20">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-xs text-gray-400 font-mono uppercase tracking-wider">
                Flagged
              </p>
              <p className="text-3xl font-bold text-yellow-400 mt-1">
                {stats.flagged}
              </p>
            </div>
            <AlertTriangle className="w-8 h-8 text-yellow-400/50" />
          </div>
        </div>
      </div>

      {/* Transaction Table */}
      <div className="rounded-lg border border-cyan-500/20 bg-[#0f1525]/50 backdrop-blur-sm overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full">
            <thead>
              <tr className="bg-cyan-500/5 border-b border-cyan-500/20">
                <th className="px-4 py-3 text-left">
                  <span className="text-xs font-mono text-cyan-400 uppercase tracking-wider">
                    Transaction ID
                  </span>
                </th>
                <th className="px-4 py-3 text-left">
                  <span className="text-xs font-mono text-cyan-400 uppercase tracking-wider">
                    Type
                  </span>
                </th>
                <th className="px-4 py-3 text-left">
                  <span className="text-xs font-mono text-cyan-400 uppercase tracking-wider">
                    Amount
                  </span>
                </th>
                <th className="px-4 py-3 text-left">
                  <span className="text-xs font-mono text-cyan-400 uppercase tracking-wider">
                    Route
                  </span>
                </th>
                <th className="px-4 py-3 text-left">
                  <span className="text-xs font-mono text-cyan-400 uppercase tracking-wider">
                    State
                  </span>
                </th>
                <th className="px-4 py-3 text-left">
                  <span className="text-xs font-mono text-cyan-400 uppercase tracking-wider">
                    Fraud Score
                  </span>
                </th>
                <th className="px-4 py-3 text-left">
                  <span className="text-xs font-mono text-cyan-400 uppercase tracking-wider">
                    Compliance
                  </span>
                </th>
                <th className="px-4 py-3 text-left">
                  <span className="text-xs font-mono text-cyan-400 uppercase tracking-wider">
                    Exception
                  </span>
                </th>
              </tr>
            </thead>
            <tbody>
              {transactions.map((txn, idx) => (
                <tr
                  key={txn.transactionId}
                  className="border-b border-cyan-500/10 hover:bg-cyan-500/5 transition-colors"
                  style={{
                    animation: "fadeIn 0.3s ease-out",
                    animationDelay: `${idx * 30}ms`,
                  }}
                >
                  <td className="px-4 py-3">
                    <span className="font-mono text-sm text-gray-300">
                      {txn.transactionId}
                    </span>
                  </td>
                  <td className="px-4 py-3">
                    <span className="inline-flex px-2 py-1 rounded bg-blue-500/10 border border-blue-500/30 text-blue-400 text-xs font-mono">
                      {txn.type}
                    </span>
                  </td>
                  <td className="px-4 py-3">
                    <span className="font-mono text-sm text-white font-semibold">
                      ${txn.amount.toLocaleString()}
                    </span>
                  </td>
                  <td className="px-4 py-3">
                    <div className="flex items-center gap-2 text-xs font-mono">
                      <span className="text-gray-400">
                        {txn.source}
                      </span>
                      <span className="text-cyan-400">→</span>
                      <span className="text-gray-400">
                        {txn.destination}
                      </span>
                    </div>
                  </td>
                  <td className="px-4 py-3">
                    <StateBadge state={txn.state} />
                  </td>
                  <td className="px-4 py-3">
                    <div className="flex items-center gap-2">
                      <div className="flex-1 h-2 bg-gray-700 rounded-full overflow-hidden">
                        <div
                          className="h-full rounded-full transition-all duration-300"
                          style={{
                            width: `${txn.fraudScore}%`,
                            backgroundColor:
                              txn.fraudScore > 70
                                ? "#ef4444"
                                : txn.fraudScore > 40
                                  ? "#f59e0b"
                                  : "#10b981",
                          }}
                        />
                      </div>
                      <span
                        className="font-mono text-xs font-bold"
                        style={{
                          color:
                            txn.fraudScore > 70
                              ? "#ef4444"
                              : txn.fraudScore > 40
                                ? "#f59e0b"
                                : "#10b981",
                        }}
                      >
                        {txn.fraudScore}
                      </span>
                    </div>
                  </td>
                  <td className="px-4 py-3">
                    <span
                      className={`inline-flex px-2 py-1 rounded text-xs font-mono font-semibold ${
                        txn.complianceStatus === "PASS"
                          ? "bg-green-500/10 border border-green-500/30 text-green-400"
                          : txn.complianceStatus === "FLAGGED"
                            ? "bg-red-500/10 border border-red-500/30 text-red-400"
                            : "bg-yellow-500/10 border border-yellow-500/30 text-yellow-400"
                      }`}
                    >
                      {txn.complianceStatus}
                    </span>
                  </td>
                  <td className="px-4 py-3">
                    {txn.exception ? (
                      <ExceptionBadge
                        exception={txn.exception}
                      />
                    ) : (
                      <span className="text-gray-600 font-mono text-sm">
                        —
                      </span>
                    )}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {/* Security Notice */}
      {!secureMode && (
        <div className="p-4 rounded-lg bg-red-500/10 border border-red-500/30 flex items-center gap-3">
          <AlertTriangle className="w-5 h-5 text-red-400" />
          <div>
            <p className="text-sm text-red-400 font-semibold">
              SECURE MODE DISABLED
            </p>
            <p className="text-xs text-gray-400 mt-1">
              RBAC validation suspended. Enable secure mode for
              full transaction monitoring capabilities.
            </p>
          </div>
        </div>
      )}
    </div>
  );
}