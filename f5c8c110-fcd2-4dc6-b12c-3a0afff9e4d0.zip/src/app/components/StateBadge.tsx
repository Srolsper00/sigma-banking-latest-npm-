import { CheckCircle2, Clock, Shield, AlertTriangle, XCircle, Lock } from 'lucide-react';

type TransactionState =
  | 'INITIATED'
  | 'VALIDATING'
  | 'RISK_CHECK'
  | 'COMPLIANCE_CHECK'
  | 'APPROVED'
  | 'POSTED_TO_LEDGER'
  | 'SETTLED'
  | 'COMPLETED'
  | 'BLOCKED'
  | 'FAILED';

interface StateBadgeProps {
  state: TransactionState;
}

const stateConfig: Record<TransactionState, {
  label: string;
  color: string;
  bgColor: string;
  borderColor: string;
  icon: any;
  pulseColor?: string;
}> = {
  INITIATED: {
    label: 'INITIATED',
    color: '#60a5fa',
    bgColor: 'rgba(96, 165, 250, 0.1)',
    borderColor: 'rgba(96, 165, 250, 0.3)',
    icon: Clock,
    pulseColor: 'rgba(96, 165, 250, 0.4)'
  },
  VALIDATING: {
    label: 'VALIDATING',
    color: '#fbbf24',
    bgColor: 'rgba(251, 191, 36, 0.1)',
    borderColor: 'rgba(251, 191, 36, 0.3)',
    icon: Shield,
    pulseColor: 'rgba(251, 191, 36, 0.4)'
  },
  RISK_CHECK: {
    label: 'RISK CHECK',
    color: '#f59e0b',
    bgColor: 'rgba(245, 158, 11, 0.1)',
    borderColor: 'rgba(245, 158, 11, 0.3)',
    icon: AlertTriangle,
    pulseColor: 'rgba(245, 158, 11, 0.4)'
  },
  COMPLIANCE_CHECK: {
    label: 'COMPLIANCE',
    color: '#8b5cf6',
    bgColor: 'rgba(139, 92, 246, 0.1)',
    borderColor: 'rgba(139, 92, 246, 0.3)',
    icon: Shield,
    pulseColor: 'rgba(139, 92, 246, 0.4)'
  },
  APPROVED: {
    label: 'APPROVED',
    color: '#10b981',
    bgColor: 'rgba(16, 185, 129, 0.1)',
    borderColor: 'rgba(16, 185, 129, 0.3)',
    icon: CheckCircle2
  },
  POSTED_TO_LEDGER: {
    label: 'POSTED',
    color: '#00d9ff',
    bgColor: 'rgba(0, 217, 255, 0.1)',
    borderColor: 'rgba(0, 217, 255, 0.3)',
    icon: CheckCircle2
  },
  SETTLED: {
    label: 'SETTLED',
    color: '#22c55e',
    bgColor: 'rgba(34, 197, 94, 0.1)',
    borderColor: 'rgba(34, 197, 94, 0.3)',
    icon: CheckCircle2
  },
  COMPLETED: {
    label: 'COMPLETED',
    color: '#00ff88',
    bgColor: 'rgba(0, 255, 136, 0.1)',
    borderColor: 'rgba(0, 255, 136, 0.3)',
    icon: CheckCircle2
  },
  BLOCKED: {
    label: 'BLOCKED',
    color: '#ef4444',
    bgColor: 'rgba(239, 68, 68, 0.1)',
    borderColor: 'rgba(239, 68, 68, 0.3)',
    icon: Lock
  },
  FAILED: {
    label: 'FAILED',
    color: '#dc2626',
    bgColor: 'rgba(220, 38, 38, 0.1)',
    borderColor: 'rgba(220, 38, 38, 0.3)',
    icon: XCircle
  }
};

export function StateBadge({ state }: StateBadgeProps) {
  const config = stateConfig[state];
  const Icon = config.icon;
  const isPulsing = config.pulseColor;

  return (
    <div className="relative inline-flex">
      <div
        className="flex items-center gap-2 px-3 py-1.5 rounded border font-mono text-xs tracking-wider"
        style={{
          color: config.color,
          backgroundColor: config.bgColor,
          borderColor: config.borderColor,
          boxShadow: `0 0 10px ${config.bgColor}`
        }}
      >
        <Icon className="w-3.5 h-3.5" />
        <span className="font-semibold">{config.label}</span>
      </div>

      {isPulsing && (
        <>
          <div
            className="absolute inset-0 rounded animate-ping opacity-75"
            style={{
              backgroundColor: config.pulseColor,
              animationDuration: '2s'
            }}
          />
          <div
            className="absolute inset-0 rounded"
            style={{
              backgroundColor: config.pulseColor,
              opacity: 0.3
            }}
          />
        </>
      )}
    </div>
  );
}
