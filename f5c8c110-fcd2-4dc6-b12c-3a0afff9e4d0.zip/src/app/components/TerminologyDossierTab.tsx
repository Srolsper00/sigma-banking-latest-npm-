import { useState, useEffect } from 'react';
import {
  BookOpen,
  FileText,
  Copyright,
  Shield,
  Database,
  Hash,
  CheckCircle2,
  AlertTriangle,
  Download,
  Upload,
  Search,
  Filter,
  FileCheck,
  Briefcase,
  Scale
} from 'lucide-react';

interface TerminologyEntry {
  id: string;
  term: string;
  category: 'Financial' | 'Legal' | 'Technical' | 'Compliance' | 'Blockchain';
  definition: string;
  references: string[];
  merkleHash?: string;
}

interface DossierExhibit {
  id: string;
  exhibitNumber: string;
  title: string;
  type: 'CSV' | 'PDF' | 'JSON' | 'XML' | 'SQL';
  category: 'Journal-Entry' | 'Financial-Report' | 'Legal-Document' | 'Compliance-Certificate' | 'Blockchain-Manifest';
  fileSize: string;
  merkleRoot?: string;
  blockchainAnchor?: string;
  createdDate: string;
  status: 'verified' | 'pending' | 'archived';
  s3Location?: string;
}

interface ArticleOfFormation {
  id: string;
  documentType: 'Articles-of-Incorporation' | 'Operating-Agreement' | 'Bylaws' | 'Amendment' | 'Certificate-of-Formation';
  entityName: string;
  jurisdiction: string;
  filingDate: string;
  status: 'active' | 'amended' | 'dissolved';
  registrationNumber: string;
  copyrightRegistered: boolean;
  merkleHash: string;
}

interface CopyrightEntry {
  id: string;
  workTitle: string;
  copyrightType: 'Literary' | 'Software' | 'Documentation' | 'Database' | 'Artwork';
  registrationNumber: string;
  registrationDate: string;
  owner: string;
  status: 'registered' | 'pending' | 'renewed';
  expirationDate: string;
  blockchainProof: string;
}

interface TerminologyDossierTabProps {
  secureMode: boolean;
  onAuditLog: (message: string) => void;
}

export function TerminologyDossierTab({ secureMode, onAuditLog }: TerminologyDossierTabProps) {
  const [selectedView, setSelectedView] = useState<'terminology' | 'exhibits' | 'articles' | 'copyright'>('terminology');
  const [searchTerm, setSearchTerm] = useState('');

  const [terminologyEntries] = useState<TerminologyEntry[]>([
    {
      id: 'TERM-001',
      term: 'Merkle Tree Hashing',
      category: 'Blockchain',
      definition: 'Cryptographic hash tree structure where each leaf node is a hash of a data block, and each non-leaf node is a hash of its children. Used for efficient and secure verification of large data structures.',
      references: ['RFC 6962', 'Bitcoin Whitepaper', 'NIST SP 800-107'],
      merkleHash: '0x8f3a4b2c9d1e7f5a6b8c3d2e1f4a5b6c'
    },
    {
      id: 'TERM-002',
      term: 'ACH/NACHA Classification',
      category: 'Financial',
      definition: 'Automated Clearing House network classification system defining Standard Entry Class (SEC) codes for different transaction types: CCD (Corporate Credit/Debit), PPD (Prearranged Payment), CTX (Corporate Trade Exchange).',
      references: ['NACHA Operating Rules', '12 CFR Part 210', 'Regulation E'],
      merkleHash: '0x2a3f8e1c5b7d9a4f6e8c2b1d3a5f7e9c'
    },
    {
      id: 'TERM-003',
      term: 'Journal Entry Manifold',
      category: 'Financial',
      definition: 'A comprehensive set of accounting journal entries with debit/credit classifications, Merkle tree verification, blockchain anchoring, and ACH/NACHA compliance mapping for immutable financial record-keeping.',
      references: ['GAAP Standards', 'IFRS Framework', 'FASB ASC 105'],
      merkleHash: '0x5e9b2f4a8c1d6e3a7f9b4c8e2d5a1f6b'
    },
    {
      id: 'TERM-004',
      term: 'Articles of Formation',
      category: 'Legal',
      definition: 'Legal documents filed with state authorities to formally establish a limited liability company (LLC) or corporation, including entity name, purpose, registered agent, and ownership structure.',
      references: ['Revised Uniform LLC Act', 'Model Business Corporation Act', 'State Corporate Statutes'],
      merkleHash: '0x1c4f7e9a2b5d8f3e6a9c1b4f7e2d5a8c'
    },
    {
      id: 'TERM-005',
      term: 'Blockchain Anchoring',
      category: 'Blockchain',
      definition: 'Process of recording a cryptographic hash (Merkle root) of off-chain data onto a blockchain network, providing tamper-proof timestamp and immutability verification without storing full data on-chain.',
      references: ['Chainpoint Protocol', 'OpenTimestamps', 'ERC-1948'],
      merkleHash: '0x9f3e6b2a5c8d1f4e7a9b3c6f2e5d8a1c'
    },
    {
      id: 'TERM-006',
      term: 'Copyright Registration',
      category: 'Legal',
      definition: 'Federal registration of original works of authorship with the U.S. Copyright Office, providing legal evidence of ownership and enabling statutory damages in infringement cases.',
      references: ['17 U.S.C. § 101 et seq.', 'Copyright Act of 1976', 'Berne Convention'],
      merkleHash: '0x4a7f2e9c5b8d1f3e6a9c2b5f8e1d4a7c'
    }
  ]);

  const [dossierExhibits, setDossierExhibits] = useState<DossierExhibit[]>([
    {
      id: 'EX-001',
      exhibitNumber: 'A-1',
      title: 'Journal Entry Manifold - Network Clearing DR 1327711016401',
      type: 'CSV',
      category: 'Journal-Entry',
      fileSize: '2.3 MB',
      merkleRoot: '0xa3f5e8b2c9d1f4a6e7b3c5d8f2a4e9b1',
      blockchainAnchor: 'ETH:0x742d35Cc6634C0532925a3b844Bc454e4438f44e',
      createdDate: new Date(Date.now() - 86400000 * 2).toISOString(),
      status: 'verified',
      s3Location: 's3://financial-bucket/reports/csv/journal_entry_JE-2026-05-12-001.csv'
    },
    {
      id: 'EX-002',
      exhibitNumber: 'A-2',
      title: 'Merkle Tree Verification Manifest',
      type: 'JSON',
      category: 'Blockchain-Manifest',
      fileSize: '156 KB',
      merkleRoot: '0x8c2f5a9b3e1d7f4a6e8b2c5d9f1a3e7b',
      blockchainAnchor: 'ETH:0x742d35Cc6634C0532925a3b844Bc454e4438f44e',
      createdDate: new Date(Date.now() - 86400000 * 2).toISOString(),
      status: 'verified',
      s3Location: 's3://financial-bucket/blockchain/merkle_manifest_2026-05-12.json'
    },
    {
      id: 'EX-003',
      exhibitNumber: 'B-1',
      title: 'ACH/NACHA Classification Report - Payroll Distribution',
      type: 'PDF',
      category: 'Financial-Report',
      fileSize: '1.8 MB',
      merkleRoot: '0x5f9a3e7b1c4d8f2a6e9b5c3d7f1a4e8b',
      createdDate: new Date(Date.now() - 86400000 * 1).toISOString(),
      status: 'verified',
      s3Location: 's3://financial-bucket/reports/pdf/ach_nacha_payroll_2026-05-12.pdf'
    },
    {
      id: 'EX-004',
      exhibitNumber: 'C-1',
      title: 'SQL INSERT Statements - Complete Transaction Set',
      type: 'SQL',
      category: 'Journal-Entry',
      fileSize: '87 KB',
      merkleRoot: '0x2e8f5b9a1c6d3f7a4e9b2c5d8f1a6e3b',
      createdDate: new Date(Date.now() - 86400000 * 1).toISOString(),
      status: 'verified',
      s3Location: 's3://financial-bucket/sql/journal_inserts_2026-05-12.sql'
    },
    {
      id: 'EX-005',
      exhibitNumber: 'D-1',
      title: 'Corporate Formation Documents - VOM Services LLC',
      type: 'PDF',
      category: 'Legal-Document',
      fileSize: '4.5 MB',
      merkleRoot: '0x7b3f9e2a5c8d1f4e6a9b3c5f8e2d1a4c',
      blockchainAnchor: 'ETH:0x8a92f5e3c1b6d4a9e7f2c5b8d1a6f3e9',
      createdDate: new Date(Date.now() - 86400000 * 30).toISOString(),
      status: 'verified',
      s3Location: 's3://legal-bucket/formation/vom_services_llc_articles.pdf'
    }
  ]);

  const [articlesOfFormation] = useState<ArticleOfFormation[]>([
    {
      id: 'AOF-001',
      documentType: 'Articles-of-Incorporation',
      entityName: 'VOM Services Corporation',
      jurisdiction: 'Delaware',
      filingDate: '2024-03-15',
      status: 'active',
      registrationNumber: 'DE-7542891',
      copyrightRegistered: true,
      merkleHash: '0x9e3a5f7b2c8d1f4e6a9b3c5d8f2a1e4b'
    },
    {
      id: 'AOF-002',
      documentType: 'Operating-Agreement',
      entityName: 'VOM Services LLC',
      jurisdiction: 'Delaware',
      filingDate: '2024-03-20',
      status: 'active',
      registrationNumber: 'DE-LLC-8934567',
      copyrightRegistered: true,
      merkleHash: '0x4f8e2a9b5c1d7f3e6a9b2c5d8f1a4e7b'
    },
    {
      id: 'AOF-003',
      documentType: 'Bylaws',
      entityName: 'VOM Services Corporation',
      jurisdiction: 'Delaware',
      filingDate: '2024-03-25',
      status: 'active',
      registrationNumber: 'DE-BY-5678234',
      copyrightRegistered: true,
      merkleHash: '0x2a5f9e3b7c1d8f4e6a9b3c5d7f2a1e8b'
    }
  ]);

  const [copyrightEntries] = useState<CopyrightEntry[]>([
    {
      id: 'CR-001',
      workTitle: 'FINA_3XPRES5 Financial Terminology System',
      copyrightType: 'Software',
      registrationNumber: 'TXu 2-456-789',
      registrationDate: '2024-04-01',
      owner: 'VOM Services Corporation',
      status: 'registered',
      expirationDate: '2124-04-01',
      blockchainProof: '0x5e9a3f7b2c8d1f4e6a9b3c5d8f2a1e4b'
    },
    {
      id: 'CR-002',
      workTitle: 'VOM Banking Platform - Asset Management System',
      copyrightType: 'Software',
      registrationNumber: 'TXu 2-789-456',
      registrationDate: '2024-04-15',
      owner: 'VOM Services Corporation',
      status: 'registered',
      expirationDate: '2124-04-15',
      blockchainProof: '0x8f2a5e9b3c1d7f4e6a9b2c5d8f1a3e7b'
    },
    {
      id: 'CR-003',
      workTitle: 'Financial Journal Entry Manifold Documentation',
      copyrightType: 'Literary',
      registrationNumber: 'TX 9-234-567',
      registrationDate: '2024-05-01',
      owner: 'VOM Services Corporation',
      status: 'registered',
      expirationDate: '2124-05-01',
      blockchainProof: '0x3c5f8e2a9b1d7f4e6a9b3c5d8f2a1e4b'
    },
    {
      id: 'CR-004',
      workTitle: 'ACH/NACHA Classification Database Schema',
      copyrightType: 'Database',
      registrationNumber: 'TXu 2-345-678',
      registrationDate: '2024-05-10',
      owner: 'VOM Services Corporation',
      status: 'registered',
      expirationDate: '2124-05-10',
      blockchainProof: '0x7b9f3e5a2c8d1f4e6a9b3c5d8f2a1e4b'
    }
  ]);

  useEffect(() => {
    const interval = setInterval(() => {
      // Simulate new exhibit generation (5% probability)
      if (Math.random() < 0.05) {
        const exhibitTypes: DossierExhibit['type'][] = ['CSV', 'PDF', 'JSON', 'XML', 'SQL'];
        const categories: DossierExhibit['category'][] = ['Journal-Entry', 'Financial-Report', 'Legal-Document', 'Compliance-Certificate', 'Blockchain-Manifest'];

        const newExhibit: DossierExhibit = {
          id: `EX-${Date.now()}`,
          exhibitNumber: `A-${Math.floor(Math.random() * 100)}`,
          title: `Generated Exhibit - ${new Date().toLocaleDateString()}`,
          type: exhibitTypes[Math.floor(Math.random() * exhibitTypes.length)],
          category: categories[Math.floor(Math.random() * categories.length)],
          fileSize: `${(Math.random() * 5 + 0.1).toFixed(1)} MB`,
          merkleRoot: `0x${Math.random().toString(16).substring(2, 34)}`,
          createdDate: new Date().toISOString(),
          status: 'pending',
          s3Location: `s3://financial-bucket/exhibits/exhibit_${Date.now()}.pdf`
        };

        setDossierExhibits(prev => [newExhibit, ...prev].slice(0, 20));
        onAuditLog(`New dossier exhibit generated: ${newExhibit.title}`);
      }
    }, 8000);

    return () => clearInterval(interval);
  }, [onAuditLog]);

  const handleViewChange = (view: typeof selectedView) => {
    setSelectedView(view);
    onAuditLog(`Switched to ${view} view in Terminology & Dossier`);
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="bg-gradient-to-r from-purple-900/20 via-indigo-900/20 to-purple-900/20 border border-purple-500/30 rounded-lg p-6">
        <div className="flex items-center justify-between mb-4">
          <div className="flex items-center gap-3">
            <BookOpen className="w-8 h-8 text-purple-400" />
            <div>
              <h1 className="text-2xl font-bold text-white">Terminology Manifold & Dossier Exhibits</h1>
              <p className="text-sm text-gray-400 mt-1">Articles of Formation • Copyright Registry • Blockchain-Verified Documentation</p>
            </div>
          </div>
          <div className="text-right">
            <div className="text-xs text-gray-400">Total Exhibits</div>
            <div className="text-3xl font-bold text-purple-400">{dossierExhibits.length}</div>
          </div>
        </div>

        {/* Quick Stats */}
        <div className="grid grid-cols-4 gap-4">
          <div className="bg-black/40 border border-purple-500/20 rounded-lg p-3 text-center">
            <div className="text-2xl font-bold text-purple-400">{terminologyEntries.length}</div>
            <div className="text-xs text-gray-400 mt-1">Terminology Entries</div>
          </div>
          <div className="bg-black/40 border border-cyan-500/20 rounded-lg p-3 text-center">
            <div className="text-2xl font-bold text-cyan-400">{dossierExhibits.filter(e => e.status === 'verified').length}</div>
            <div className="text-xs text-gray-400 mt-1">Verified Exhibits</div>
          </div>
          <div className="bg-black/40 border border-green-500/20 rounded-lg p-3 text-center">
            <div className="text-2xl font-bold text-green-400">{articlesOfFormation.length}</div>
            <div className="text-xs text-gray-400 mt-1">Formation Documents</div>
          </div>
          <div className="bg-black/40 border border-orange-500/20 rounded-lg p-3 text-center">
            <div className="text-2xl font-bold text-orange-400">{copyrightEntries.length}</div>
            <div className="text-xs text-gray-400 mt-1">Copyrights Registered</div>
          </div>
        </div>
      </div>

      {/* View Selector */}
      <div className="flex gap-2 overflow-x-auto scrollbar-hide">
        {[
          { id: 'terminology', label: 'Financial Terminology', icon: BookOpen },
          { id: 'exhibits', label: 'Dossier Exhibits', icon: FileText },
          { id: 'articles', label: 'Articles of Formation', icon: Briefcase },
          { id: 'copyright', label: 'Copyright Registry', icon: Copyright }
        ].map(view => {
          const Icon = view.icon;
          return (
            <button
              key={view.id}
              onClick={() => handleViewChange(view.id as typeof selectedView)}
              className={`flex items-center gap-2 px-4 py-2 rounded-lg text-sm font-semibold uppercase tracking-wide whitespace-nowrap transition-all duration-300 ${
                selectedView === view.id
                  ? 'bg-purple-500/30 text-purple-400 border border-purple-500/50'
                  : 'bg-gray-500/10 text-gray-400 border border-gray-500/30 hover:bg-gray-500/20'
              }`}
            >
              <Icon className="w-4 h-4" />
              {view.label}
            </button>
          );
        })}
      </div>

      {/* Search Bar */}
      <div className="relative">
        <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 w-4 h-4 text-gray-400" />
        <input
          type="text"
          placeholder={`Search ${selectedView}...`}
          value={searchTerm}
          onChange={(e) => setSearchTerm(e.target.value)}
          className="w-full bg-black/40 border border-purple-500/20 rounded-lg pl-10 pr-4 py-3 text-white placeholder-gray-500 focus:outline-none focus:border-purple-400"
        />
      </div>

      {/* Content */}
      <div style={{ animation: 'fadeIn 0.3s ease-out' }}>
        {selectedView === 'terminology' && (
          <TerminologyContent entries={terminologyEntries} searchTerm={searchTerm} onAuditLog={onAuditLog} />
        )}
        {selectedView === 'exhibits' && (
          <ExhibitsContent exhibits={dossierExhibits} searchTerm={searchTerm} secureMode={secureMode} onAuditLog={onAuditLog} />
        )}
        {selectedView === 'articles' && (
          <ArticlesContent articles={articlesOfFormation} searchTerm={searchTerm} onAuditLog={onAuditLog} />
        )}
        {selectedView === 'copyright' && (
          <CopyrightContent copyrights={copyrightEntries} searchTerm={searchTerm} onAuditLog={onAuditLog} />
        )}
      </div>

      <style>{`
        @keyframes fadeIn {
          from { opacity: 0; }
          to { opacity: 1; }
        }
        .scrollbar-hide::-webkit-scrollbar {
          display: none;
        }
        .scrollbar-hide {
          -ms-overflow-style: none;
          scrollbar-width: none;
        }
      `}</style>
    </div>
  );
}

function TerminologyContent({ entries, searchTerm, onAuditLog }: { entries: TerminologyEntry[]; searchTerm: string; onAuditLog: (msg: string) => void }) {
  const filteredEntries = entries.filter(entry =>
    entry.term.toLowerCase().includes(searchTerm.toLowerCase()) ||
    entry.definition.toLowerCase().includes(searchTerm.toLowerCase())
  );

  const getCategoryColor = (category: string) => {
    switch(category) {
      case 'Financial': return { bg: 'bg-green-500/10', text: 'text-green-400', border: 'border-green-500/30' };
      case 'Legal': return { bg: 'bg-blue-500/10', text: 'text-blue-400', border: 'border-blue-500/30' };
      case 'Technical': return { bg: 'bg-cyan-500/10', text: 'text-cyan-400', border: 'border-cyan-500/30' };
      case 'Compliance': return { bg: 'bg-purple-500/10', text: 'text-purple-400', border: 'border-purple-500/30' };
      case 'Blockchain': return { bg: 'bg-orange-500/10', text: 'text-orange-400', border: 'border-orange-500/30' };
      default: return { bg: 'bg-gray-500/10', text: 'text-gray-400', border: 'border-gray-500/30' };
    }
  };

  return (
    <div className="space-y-4">
      {filteredEntries.map((entry, idx) => {
        const colors = getCategoryColor(entry.category);
        return (
          <div
            key={entry.id}
            className={`p-6 rounded-lg border backdrop-blur-sm ${colors.bg} ${colors.border}`}
            style={{
              animation: 'slideIn 0.4s ease-out forwards',
              animationDelay: `${idx * 60}ms`,
              opacity: 0
            }}
          >
            <div className="flex items-start justify-between mb-3">
              <div className="flex-1">
                <div className="flex items-center gap-3 mb-2">
                  <h3 className="text-xl font-bold text-white">{entry.term}</h3>
                  <span className={`px-2 py-1 rounded text-xs font-bold uppercase ${colors.text} ${colors.bg} border ${colors.border}`}>
                    {entry.category}
                  </span>
                </div>
                <p className="text-sm text-gray-300 mb-3">{entry.definition}</p>

                {entry.references.length > 0 && (
                  <div className="mb-3">
                    <div className="text-xs text-gray-400 mb-1">References:</div>
                    <div className="flex flex-wrap gap-2">
                      {entry.references.map((ref, refIdx) => (
                        <span key={refIdx} className="px-2 py-1 bg-black/40 border border-gray-500/20 rounded text-xs text-gray-300">
                          {ref}
                        </span>
                      ))}
                    </div>
                  </div>
                )}

                {entry.merkleHash && (
                  <div className="flex items-center gap-2 text-xs">
                    <Hash className="w-3 h-3 text-purple-400" />
                    <span className="text-gray-400">Merkle Hash:</span>
                    <span className="font-mono text-purple-400">{entry.merkleHash}</span>
                  </div>
                )}
              </div>
            </div>
          </div>
        );
      })}

      <style>{`
        @keyframes slideIn {
          from { opacity: 0; transform: translateY(20px); }
          to { opacity: 1; transform: translateY(0); }
        }
      `}</style>
    </div>
  );
}

function ExhibitsContent({ exhibits, searchTerm, secureMode, onAuditLog }: { exhibits: DossierExhibit[]; searchTerm: string; secureMode: boolean; onAuditLog: (msg: string) => void }) {
  const filteredExhibits = exhibits.filter(exhibit =>
    exhibit.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
    exhibit.exhibitNumber.toLowerCase().includes(searchTerm.toLowerCase())
  );

  const getTypeColor = (type: string) => {
    switch(type) {
      case 'CSV': return 'bg-green-500/20 text-green-400';
      case 'PDF': return 'bg-red-500/20 text-red-400';
      case 'JSON': return 'bg-blue-500/20 text-blue-400';
      case 'XML': return 'bg-orange-500/20 text-orange-400';
      case 'SQL': return 'bg-purple-500/20 text-purple-400';
      default: return 'bg-gray-500/20 text-gray-400';
    }
  };

  const handleDownload = (exhibit: DossierExhibit) => {
    if (!secureMode) {
      onAuditLog(`Download failed for ${exhibit.exhibitNumber} - secure mode required`);
      return;
    }
    onAuditLog(`Downloaded exhibit ${exhibit.exhibitNumber}: ${exhibit.title}`);
  };

  return (
    <div className="space-y-4">
      {filteredExhibits.map((exhibit, idx) => (
        <div
          key={exhibit.id}
          className="p-6 bg-black/40 border border-purple-500/20 rounded-lg"
          style={{
            animation: 'slideIn 0.4s ease-out forwards',
            animationDelay: `${idx * 60}ms`,
            opacity: 0
          }}
        >
          <div className="flex items-start justify-between mb-4">
            <div className="flex-1">
              <div className="flex items-center gap-3 mb-2">
                <FileText className="w-5 h-5 text-purple-400" />
                <span className="font-mono text-sm text-cyan-400">Exhibit {exhibit.exhibitNumber}</span>
                <span className={`px-2 py-1 rounded text-xs font-bold ${getTypeColor(exhibit.type)}`}>
                  {exhibit.type}
                </span>
                <span className={`px-2 py-1 rounded text-xs font-bold ${
                  exhibit.status === 'verified' ? 'bg-green-500/20 text-green-400' :
                  exhibit.status === 'pending' ? 'bg-yellow-500/20 text-yellow-400' :
                  'bg-gray-500/20 text-gray-400'
                }`}>
                  {exhibit.status}
                </span>
              </div>
              <h3 className="text-lg font-bold text-white mb-2">{exhibit.title}</h3>

              <div className="grid grid-cols-2 gap-3 mb-3">
                <div className="text-xs">
                  <span className="text-gray-400">Category:</span>
                  <span className="text-purple-400 ml-2">{exhibit.category}</span>
                </div>
                <div className="text-xs">
                  <span className="text-gray-400">File Size:</span>
                  <span className="text-gray-300 ml-2">{exhibit.fileSize}</span>
                </div>
                <div className="text-xs">
                  <span className="text-gray-400">Created:</span>
                  <span className="text-gray-300 ml-2">{new Date(exhibit.createdDate).toLocaleDateString()}</span>
                </div>
                {exhibit.s3Location && (
                  <div className="text-xs">
                    <span className="text-gray-400">S3 Location:</span>
                    <span className="font-mono text-cyan-400 ml-2 text-[10px]">{exhibit.s3Location.substring(0, 40)}...</span>
                  </div>
                )}
              </div>

              {exhibit.merkleRoot && (
                <div className="flex items-center gap-2 text-xs mb-2">
                  <Hash className="w-3 h-3 text-purple-400" />
                  <span className="text-gray-400">Merkle Root:</span>
                  <span className="font-mono text-purple-400">{exhibit.merkleRoot}</span>
                </div>
              )}

              {exhibit.blockchainAnchor && (
                <div className="flex items-center gap-2 text-xs">
                  <Shield className="w-3 h-3 text-green-400" />
                  <span className="text-gray-400">Blockchain Anchor:</span>
                  <span className="font-mono text-green-400">{exhibit.blockchainAnchor}</span>
                </div>
              )}
            </div>

            <button
              onClick={() => handleDownload(exhibit)}
              disabled={!secureMode}
              className={`px-4 py-2 rounded-lg text-sm font-semibold flex items-center gap-2 ${
                secureMode
                  ? 'bg-purple-600 text-white hover:bg-purple-500'
                  : 'bg-gray-700 text-gray-500 cursor-not-allowed'
              }`}
            >
              <Download className="w-4 h-4" />
              Download
            </button>
          </div>
        </div>
      ))}

      <style>{`
        @keyframes slideIn {
          from { opacity: 0; transform: translateY(20px); }
          to { opacity: 1; transform: translateY(0); }
        }
      `}</style>
    </div>
  );
}

function ArticlesContent({ articles, searchTerm, onAuditLog }: { articles: ArticleOfFormation[]; searchTerm: string; onAuditLog: (msg: string) => void }) {
  const filteredArticles = articles.filter(article =>
    article.entityName.toLowerCase().includes(searchTerm.toLowerCase()) ||
    article.documentType.toLowerCase().includes(searchTerm.toLowerCase())
  );

  return (
    <div className="space-y-4">
      {filteredArticles.map((article, idx) => (
        <div
          key={article.id}
          className="p-6 bg-gradient-to-br from-blue-900/20 to-indigo-900/20 border border-blue-500/30 rounded-lg"
          style={{
            animation: 'slideIn 0.4s ease-out forwards',
            animationDelay: `${idx * 60}ms`,
            opacity: 0
          }}
        >
          <div className="flex items-start justify-between mb-4">
            <div className="flex-1">
              <div className="flex items-center gap-3 mb-3">
                <Briefcase className="w-6 h-6 text-blue-400" />
                <h3 className="text-xl font-bold text-white">{article.entityName}</h3>
                <span className={`px-2 py-1 rounded text-xs font-bold ${
                  article.status === 'active' ? 'bg-green-500/20 text-green-400' :
                  article.status === 'amended' ? 'bg-yellow-500/20 text-yellow-400' :
                  'bg-gray-500/20 text-gray-400'
                }`}>
                  {article.status}
                </span>
                {article.copyrightRegistered && (
                  <span className="px-2 py-1 bg-purple-500/20 text-purple-400 rounded text-xs font-bold flex items-center gap-1">
                    <Copyright className="w-3 h-3" />
                    Copyrighted
                  </span>
                )}
              </div>

              <div className="grid grid-cols-2 gap-4 mb-3">
                <div>
                  <div className="text-xs text-gray-400 mb-1">Document Type</div>
                  <div className="text-sm font-semibold text-cyan-400">{article.documentType}</div>
                </div>
                <div>
                  <div className="text-xs text-gray-400 mb-1">Jurisdiction</div>
                  <div className="text-sm font-semibold text-blue-400">{article.jurisdiction}</div>
                </div>
                <div>
                  <div className="text-xs text-gray-400 mb-1">Registration Number</div>
                  <div className="text-sm font-mono text-purple-400">{article.registrationNumber}</div>
                </div>
                <div>
                  <div className="text-xs text-gray-400 mb-1">Filing Date</div>
                  <div className="text-sm text-gray-300">{new Date(article.filingDate).toLocaleDateString()}</div>
                </div>
              </div>

              <div className="flex items-center gap-2 text-xs pt-3 border-t border-gray-500/20">
                <Hash className="w-3 h-3 text-purple-400" />
                <span className="text-gray-400">Merkle Hash:</span>
                <span className="font-mono text-purple-400">{article.merkleHash}</span>
              </div>
            </div>
          </div>
        </div>
      ))}

      <style>{`
        @keyframes slideIn {
          from { opacity: 0; transform: translateY(20px); }
          to { opacity: 1; transform: translateY(0); }
        }
      `}</style>
    </div>
  );
}

function CopyrightContent({ copyrights, searchTerm, onAuditLog }: { copyrights: CopyrightEntry[]; searchTerm: string; onAuditLog: (msg: string) => void }) {
  const filteredCopyrights = copyrights.filter(copyright =>
    copyright.workTitle.toLowerCase().includes(searchTerm.toLowerCase()) ||
    copyright.registrationNumber.toLowerCase().includes(searchTerm.toLowerCase())
  );

  const getTypeColor = (type: string) => {
    switch(type) {
      case 'Software': return { bg: 'bg-cyan-500/10', text: 'text-cyan-400', border: 'border-cyan-500/30' };
      case 'Literary': return { bg: 'bg-blue-500/10', text: 'text-blue-400', border: 'border-blue-500/30' };
      case 'Database': return { bg: 'bg-purple-500/10', text: 'text-purple-400', border: 'border-purple-500/30' };
      case 'Documentation': return { bg: 'bg-green-500/10', text: 'text-green-400', border: 'border-green-500/30' };
      default: return { bg: 'bg-gray-500/10', text: 'text-gray-400', border: 'border-gray-500/30' };
    }
  };

  return (
    <div className="space-y-4">
      {filteredCopyrights.map((copyright, idx) => {
        const colors = getTypeColor(copyright.copyrightType);
        const yearsRemaining = Math.floor((new Date(copyright.expirationDate).getTime() - Date.now()) / (1000 * 60 * 60 * 24 * 365));

        return (
          <div
            key={copyright.id}
            className={`p-6 rounded-lg border backdrop-blur-sm ${colors.bg} ${colors.border}`}
            style={{
              animation: 'slideIn 0.4s ease-out forwards',
              animationDelay: `${idx * 60}ms`,
              opacity: 0
            }}
          >
            <div className="flex items-start justify-between mb-4">
              <div className="flex-1">
                <div className="flex items-center gap-3 mb-3">
                  <Copyright className="w-6 h-6 text-orange-400" />
                  <h3 className="text-xl font-bold text-white">{copyright.workTitle}</h3>
                  <span className={`px-2 py-1 rounded text-xs font-bold ${colors.text} ${colors.bg} border ${colors.border}`}>
                    {copyright.copyrightType}
                  </span>
                  <span className={`px-2 py-1 rounded text-xs font-bold ${
                    copyright.status === 'registered' ? 'bg-green-500/20 text-green-400' :
                    copyright.status === 'pending' ? 'bg-yellow-500/20 text-yellow-400' :
                    'bg-blue-500/20 text-blue-400'
                  }`}>
                    {copyright.status}
                  </span>
                </div>

                <div className="grid grid-cols-3 gap-4 mb-3">
                  <div>
                    <div className="text-xs text-gray-400 mb-1">Registration Number</div>
                    <div className="text-sm font-mono text-purple-400">{copyright.registrationNumber}</div>
                  </div>
                  <div>
                    <div className="text-xs text-gray-400 mb-1">Owner</div>
                    <div className="text-sm font-semibold text-blue-400">{copyright.owner}</div>
                  </div>
                  <div>
                    <div className="text-xs text-gray-400 mb-1">Registration Date</div>
                    <div className="text-sm text-gray-300">{new Date(copyright.registrationDate).toLocaleDateString()}</div>
                  </div>
                </div>

                <div className="grid grid-cols-2 gap-4 mb-3">
                  <div>
                    <div className="text-xs text-gray-400 mb-1">Expiration Date</div>
                    <div className="text-sm text-gray-300">{new Date(copyright.expirationDate).toLocaleDateString()}</div>
                    <div className="text-xs text-cyan-400 mt-1">{yearsRemaining} years remaining</div>
                  </div>
                  <div>
                    <div className="text-xs text-gray-400 mb-1">Blockchain Proof</div>
                    <div className="text-xs font-mono text-green-400">{copyright.blockchainProof}</div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        );
      })}

      <style>{`
        @keyframes slideIn {
          from { opacity: 0; transform: translateY(20px); }
          to { opacity: 1; transform: translateY(0); }
        }
      `}</style>
    </div>
  );
}
