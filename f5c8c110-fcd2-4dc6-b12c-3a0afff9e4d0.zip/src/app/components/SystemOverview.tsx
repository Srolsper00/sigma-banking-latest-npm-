import { useState } from 'react';
import { X, Server, Zap, Shield, Lock, Database, Cloud, Activity } from 'lucide-react';

interface SystemOverviewProps {
  onClose: () => void;
}

export function SystemOverview({ onClose }: SystemOverviewProps) {
  const [activeView, setActiveView] = useState<'architecture' | 'modules' | 'processes' | 'security'>('architecture');

  const views = [
    { id: 'architecture' as const, label: 'Architecture', icon: Server },
    { id: 'modules' as const, label: 'Modules', icon: Zap },
    { id: 'processes' as const, label: 'Processes', icon: Activity },
    { id: 'security' as const, label: 'Security', icon: Shield }
  ];

  return (
    <div className="fixed inset-0 bg-black/60 backdrop-blur-sm z-50 flex items-center justify-center p-6">
      <div className="bg-gradient-to-br from-gray-900 to-gray-800 border border-cyan-500/30 rounded-lg max-w-6xl w-full max-h-[90vh] overflow-hidden shadow-2xl">
        {/* Header */}
        <div className="border-b border-cyan-500/20 p-6 flex items-center justify-between">
          <div>
            <h2 className="text-2xl font-bold text-white mb-1">VOM Banking Platform</h2>
            <p className="text-gray-400">System Architecture & Documentation</p>
          </div>
          <button
            onClick={onClose}
            className="p-2 hover:bg-gray-700/50 rounded-lg transition-colors"
          >
            <X className="w-6 h-6 text-gray-400" />
          </button>
        </div>

        {/* Navigation */}
        <div className="border-b border-cyan-500/20 px-6 flex gap-2">
          {views.map(view => {
            const Icon = view.icon;
            return (
              <button
                key={view.id}
                onClick={() => setActiveView(view.id)}
                className={`px-6 py-3 flex items-center gap-2 border-b-2 transition-all ${
                  activeView === view.id
                    ? 'border-cyan-400 text-cyan-400'
                    : 'border-transparent text-gray-400 hover:text-gray-300'
                }`}
              >
                <Icon className="w-4 h-4" />
                <span className="font-semibold">{view.label}</span>
              </button>
            );
          })}
        </div>

        {/* Content */}
        <div className="p-6 overflow-y-auto max-h-[calc(90vh-180px)]">
          {activeView === 'architecture' && (
            <div className="space-y-6">
              <h3 className="text-xl font-bold text-white mb-4">5-Layer Architecture</h3>
              <div className="space-y-4">
                {[
                  { layer: 'Presentation Layer', tech: 'React 18.3.1 + TypeScript 5.6.2 + Tailwind CSS v4', desc: 'User interface with 19 interactive modules' },
                  { layer: 'Application Layer', tech: '18-Node Distributed Processing Array', desc: 'Horizontal topographic architecture for parallel processing' },
                  { layer: 'Security Layer', tech: 'FIPS 140-2 Level 3 + FPGA Acceleration', desc: 'Military-grade encryption with hardware acceleration' },
                  { layer: 'Integration Layer', tech: '5G SA URLLC + External System APIs', desc: 'Ultra-low latency network with 5 external integrations' },
                  { layer: 'Data Layer', tech: 'MongoDB + DynamoDB + S3 + Blockchain', desc: 'Multi-cloud persistence with Ethereum anchoring' }
                ].map((item, idx) => (
                  <div key={idx} className="bg-gray-800/50 border border-cyan-500/20 rounded-lg p-4">
                    <div className="flex items-center gap-3 mb-2">
                      <div className="w-8 h-8 bg-cyan-500/20 rounded flex items-center justify-center">
                        <span className="text-cyan-400 font-bold">{idx + 1}</span>
                      </div>
                      <h4 className="font-bold text-white">{item.layer}</h4>
                    </div>
                    <p className="text-sm text-cyan-400 mb-1">{item.tech}</p>
                    <p className="text-sm text-gray-400">{item.desc}</p>
                  </div>
                ))}
              </div>
            </div>
          )}

          {activeView === 'modules' && (
            <div className="space-y-6">
              <h3 className="text-xl font-bold text-white mb-4">19 Platform Modules</h3>
              <div className="grid grid-cols-2 gap-4">
                {[
                  { name: 'Process Flows', code: 'PROC-VIZ', desc: 'Real-time workflow visualization' },
                  { name: 'Devices', code: 'ID.AM-1', desc: 'Physical asset inventory' },
                  { name: 'Software', code: 'ID.AM-2', desc: 'Software platform catalog' },
                  { name: 'Data Flows', code: 'ID.AM-3', desc: 'Communication mapping' },
                  { name: 'External Systems', code: 'ID.AM-4', desc: 'Integration catalog' },
                  { name: 'Resources', code: 'ID.AM-5', desc: 'Recovery objectives' },
                  { name: 'Roles', code: 'ID.AM-6', desc: 'Cybersecurity roles' },
                  { name: 'Business', code: 'ID.BE', desc: 'Business controls' },
                  { name: 'Detect & Respond', code: 'DE.CM-4', desc: 'Security monitoring' },
                  { name: 'Certificates & Transactions', code: 'ACT2-SUDI', desc: 'PKI lifecycle' },
                  { name: 'Incoming Transactions', code: 'TXN-MON', desc: 'Transaction ingestion' },
                  { name: 'FPGA Hardware', code: 'HW-FPGA', desc: 'Hardware acceleration' },
                  { name: 'Funds Transfer Payload', code: 'FTP-BUILD', desc: 'Payment construction' },
                  { name: 'Policy Management', code: 'NIST-171', desc: 'Compliance policies' },
                  { name: 'License Management', code: 'LIC-MGT', desc: 'License tracking' },
                  { name: 'Fina_3xpres5 Live', code: 'FINA-3X', desc: 'Real-time processing' },
                  { name: '5G Telecom Topology', code: '5G-SA', desc: '5G network & banking' },
                  { name: 'Manuscript Export', code: 'DOC-EXP', desc: 'Document pooling' },
                  { name: 'Terminology & Dossier', code: 'TERM-DOC', desc: 'Legal documentation' }
                ].map((module, idx) => (
                  <div key={idx} className="bg-gray-800/50 border border-cyan-500/20 rounded-lg p-4">
                    <div className="flex items-center justify-between mb-2">
                      <h4 className="font-bold text-white">{module.name}</h4>
                      <span className="text-xs font-mono text-cyan-400 bg-cyan-500/10 px-2 py-1 rounded">{module.code}</span>
                    </div>
                    <p className="text-sm text-gray-400">{module.desc}</p>
                  </div>
                ))}
              </div>
            </div>
          )}

          {activeView === 'processes' && (
            <div className="space-y-6">
              <h3 className="text-xl font-bold text-white mb-4">6 Core Workflows</h3>
              <div className="space-y-4">
                {[
                  { name: 'Transaction Processing', time: '~248ms', rate: '99.7%', desc: '10-step workflow from initiation to completion' },
                  { name: 'PKI Certificate Rotation', time: '~868ms', rate: '100%', desc: 'Automated 24-hour lifecycle with zero-downtime' },
                  { name: 'Banking Statement Generation', time: '~418ms', rate: '99.9%', desc: 'GAAP/IFRS/Basel-III/FDIC-Reg compliance' },
                  { name: '5G Network Slice Management', time: '~390ms', rate: '99.99%', desc: 'URLLC slice allocation and QoS enforcement' },
                  { name: 'Document Export Workflow', time: '~630ms', rate: '99.8%', desc: 'Multi-format conversion with blockchain anchoring' },
                  { name: 'System Initialization', time: '~5.9s', rate: '100%', desc: 'Complete platform bootstrap sequence' }
                ].map((process, idx) => (
                  <div key={idx} className="bg-gray-800/50 border border-cyan-500/20 rounded-lg p-4">
                    <div className="flex items-center justify-between mb-2">
                      <h4 className="font-bold text-white">{process.name}</h4>
                      <div className="flex gap-3">
                        <span className="text-xs text-cyan-400">{process.time}</span>
                        <span className="text-xs text-green-400">{process.rate}</span>
                      </div>
                    </div>
                    <p className="text-sm text-gray-400">{process.desc}</p>
                  </div>
                ))}
              </div>
            </div>
          )}

          {activeView === 'security' && (
            <div className="space-y-6">
              <h3 className="text-xl font-bold text-white mb-4">Security & Compliance</h3>
              <div className="space-y-6">
                <div>
                  <h4 className="font-bold text-cyan-400 mb-3">Encryption</h4>
                  <div className="grid grid-cols-2 gap-3">
                    <div className="bg-gray-800/50 border border-cyan-500/20 rounded-lg p-3">
                      <p className="text-sm font-semibold text-white mb-1">Transport</p>
                      <p className="text-xs text-gray-400">TLS 1.3 + mTLS</p>
                    </div>
                    <div className="bg-gray-800/50 border border-cyan-500/20 rounded-lg p-3">
                      <p className="text-sm font-semibold text-white mb-1">At-Rest</p>
                      <p className="text-xs text-gray-400">AES-256-GCM</p>
                    </div>
                    <div className="bg-gray-800/50 border border-cyan-500/20 rounded-lg p-3">
                      <p className="text-sm font-semibold text-white mb-1">Hardware</p>
                      <p className="text-xs text-gray-400">FIPS 140-2 Level 3</p>
                    </div>
                    <div className="bg-gray-800/50 border border-cyan-500/20 rounded-lg p-3">
                      <p className="text-sm font-semibold text-white mb-1">Blockchain</p>
                      <p className="text-xs text-gray-400">SHA-256 Merkle Trees</p>
                    </div>
                  </div>
                </div>
                <div>
                  <h4 className="font-bold text-cyan-400 mb-3">Compliance Frameworks (18 Total)</h4>
                  <div className="space-y-2">
                    {[
                      'NIST CSF, SP 800-53 Rev.4, SP 800-171',
                      'ISO/IEC 27001:2013',
                      'PCI-DSS Level 1, SOX, HIPAA',
                      'FDIC, OCC, CFPB, Federal Reserve, FinCEN',
                      'GAAP, IFRS, Basel-III',
                      'CIS CSC, COBIT 5, ISA 62443'
                    ].map((framework, idx) => (
                      <div key={idx} className="bg-gray-800/50 border border-green-500/20 rounded px-3 py-2">
                        <p className="text-sm text-gray-300">{framework}</p>
                      </div>
                    ))}
                  </div>
                </div>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
