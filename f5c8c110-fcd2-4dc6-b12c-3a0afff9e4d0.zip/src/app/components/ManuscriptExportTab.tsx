import { useState, useEffect } from "react";
import {
  FileText,
  Download,
  Printer,
  CheckCircle2,
  Clock,
  FileCheck,
  FolderOpen,
  Archive,
  Filter,
  Search,
  FileDown,
  AlertCircle,
  Trash2,
  Eye,
  Package,
} from "lucide-react";

interface ManuscriptDocument {
  id: string;
  fileName: string;
  documentType:
    | "Transaction-Report"
    | "Banking-Statement"
    | "Compliance-Certificate"
    | "Audit-Log"
    | "Policy-Document"
    | "License-Record"
    | "5G-Network-Report"
    | "FPGA-Analysis"
    | "Certificate-Chain";
  sourceModule: string;
  generatedDate: string;
  fileSize: string;
  format: "PDF" | "CSV" | "JSON" | "XML" | "TXT";
  status: "ready" | "pending" | "archived" | "in-pool";
  methodology?: string;
  complianceTag?: string;
  pooled: boolean;
}

interface ExportPool {
  id: string;
  name: string;
  documentCount: number;
  totalSize: string;
  createdDate: string;
  status: "active" | "exported" | "printing";
  exportFormat: "PDF" | "ZIP" | "Multi-PDF";
}

interface ManuscriptExportTabProps {
  secureMode: boolean;
  onAuditLog: (message: string) => void;
}

export function ManuscriptExportTab({
  secureMode,
  onAuditLog,
}: ManuscriptExportTabProps) {
  const [documents, setDocuments] = useState<
    ManuscriptDocument[]
  >([
    {
      id: "doc-001",
      fileName: "Sutton_Bank_Statement_2026-05-12.pdf",
      documentType: "Banking-Statement",
      sourceModule: "Telecom 5G Topology",
      generatedDate: new Date(
        Date.now() - 3600000,
      ).toISOString(),
      fileSize: "2.4 MB",
      format: "PDF",
      status: "ready",
      methodology: "GAAP",
      complianceTag: "FDIC-Compliant",
      pooled: false,
    },
    {
      id: "doc-002",
      fileName: "Transaction_Audit_Log_Daily.csv",
      documentType: "Audit-Log",
      sourceModule: "Incoming Transactions",
      generatedDate: new Date(
        Date.now() - 7200000,
      ).toISOString(),
      fileSize: "856 KB",
      format: "CSV",
      status: "ready",
      complianceTag: "SOX-Compliant",
      pooled: false,
    },
    {
      id: "doc-003",
      fileName: "ACT2_SUDI_Certificate_Chain.json",
      documentType: "Certificate-Chain",
      sourceModule: "Certificates & Transactions",
      generatedDate: new Date(
        Date.now() - 10800000,
      ).toISOString(),
      fileSize: "124 KB",
      format: "JSON",
      status: "ready",
      complianceTag: "Cisco-ACT2",
      pooled: false,
    },
    {
      id: "doc-004",
      fileName: "NIST_171_Policy_Compliance.pdf",
      documentType: "Policy-Document",
      sourceModule: "Policy Management",
      generatedDate: new Date(
        Date.now() - 14400000,
      ).toISOString(),
      fileSize: "1.8 MB",
      format: "PDF",
      status: "ready",
      complianceTag: "NIST-800-171",
      pooled: false,
    },
    {
      id: "doc-005",
      fileName: "Capital_One_Transaction_Report.pdf",
      documentType: "Transaction-Report",
      sourceModule: "Funds Transfer Payload",
      generatedDate: new Date(
        Date.now() - 18000000,
      ).toISOString(),
      fileSize: "3.2 MB",
      format: "PDF",
      status: "ready",
      methodology: "Basel-III",
      complianceTag: "OCC-Approved",
      pooled: false,
    },
    {
      id: "doc-006",
      fileName: "5G_Network_Topology_Analysis.xml",
      documentType: "5G-Network-Report",
      sourceModule: "Telecom 5G Topology",
      generatedDate: new Date(
        Date.now() - 21600000,
      ).toISOString(),
      fileSize: "456 KB",
      format: "XML",
      status: "ready",
      complianceTag: "3GPP-R16",
      pooled: false,
    },
    {
      id: "doc-007",
      fileName: "FPGA_Hardware_Diagnostics.txt",
      documentType: "FPGA-Analysis",
      sourceModule: "FPGA Hardware",
      generatedDate: new Date(
        Date.now() - 25200000,
      ).toISOString(),
      fileSize: "89 KB",
      format: "TXT",
      status: "ready",
      pooled: false,
    },
    {
      id: "doc-008",
      fileName: "License_Registry_Export.csv",
      documentType: "License-Record",
      sourceModule: "License Management",
      generatedDate: new Date(
        Date.now() - 28800000,
      ).toISOString(),
      fileSize: "234 KB",
      format: "CSV",
      status: "ready",
      pooled: false,
    },
  ]);

  const [exportPools, setExportPools] = useState<ExportPool[]>([
    {
      id: "pool-001",
      name: "Daily Banking Reports",
      documentCount: 3,
      totalSize: "7.4 MB",
      createdDate: new Date(
        Date.now() - 86400000,
      ).toISOString(),
      status: "active",
      exportFormat: "ZIP",
    },
    {
      id: "pool-002",
      name: "Compliance Package Q2-2026",
      documentCount: 5,
      totalSize: "12.1 MB",
      createdDate: new Date(
        Date.now() - 172800000,
      ).toISOString(),
      status: "exported",
      exportFormat: "Multi-PDF",
    },
  ]);

  const [searchTerm, setSearchTerm] = useState("");
  const [filterType, setFilterType] = useState<string>("all");
  const [selectedDocs, setSelectedDocs] = useState<string[]>(
    [],
  );

  useEffect(() => {
    const interval = setInterval(() => {
      // Simulate new document generation (8% probability)
      if (Math.random() < 0.08) {
        const docTypes: ManuscriptDocument["documentType"][] = [
          "Transaction-Report",
          "Banking-Statement",
          "Compliance-Certificate",
          "Audit-Log",
          "Policy-Document",
          "License-Record",
          "5G-Network-Report",
          "FPGA-Analysis",
          "Certificate-Chain",
        ];
        const formats: ManuscriptDocument["format"][] = [
          "PDF",
          "CSV",
          "JSON",
          "XML",
          "TXT",
        ];
        const modules = [
          "Telecom 5G Topology",
          "Incoming Transactions",
          "Certificates & Transactions",
          "Policy Management",
          "Funds Transfer Payload",
          "FPGA Hardware",
          "License Management",
          "Business Operations",
          "Detect & Respond",
        ];

        const newDoc: ManuscriptDocument = {
          id: `doc-${Date.now()}`,
          fileName: `Document_${Date.now()}.${formats[Math.floor(Math.random() * formats.length)].toLowerCase()}`,
          documentType:
            docTypes[
              Math.floor(Math.random() * docTypes.length)
            ],
          sourceModule:
            modules[Math.floor(Math.random() * modules.length)],
          generatedDate: new Date().toISOString(),
          fileSize: `${(Math.random() * 5 + 0.1).toFixed(1)} MB`,
          format:
            formats[Math.floor(Math.random() * formats.length)],
          status: "ready",
          pooled: false,
        };

        setDocuments((prev) => [newDoc, ...prev].slice(0, 50));
        onAuditLog(
          `New manuscript document generated: ${newDoc.fileName} from ${newDoc.sourceModule}`,
        );
      }
    }, 3000);

    return () => clearInterval(interval);
  }, [onAuditLog]);

  const toggleDocumentInPool = (docId: string) => {
    setDocuments((prev) =>
      prev.map((doc) =>
        doc.id === docId
          ? {
              ...doc,
              pooled: !doc.pooled,
              status: doc.pooled ? "ready" : "in-pool",
            }
          : doc,
      ),
    );
    const doc = documents.find((d) => d.id === docId);
    if (doc) {
      onAuditLog(
        `Document ${doc.pooled ? "removed from" : "added to"} export pool: ${doc.fileName}`,
      );
    }
  };

  const handleExportPool = () => {
    const pooledDocs = documents.filter((d) => d.pooled);
    if (pooledDocs.length === 0) {
      onAuditLog(
        "Export pool is empty - no documents to export",
      );
      return;
    }

    const newPool: ExportPool = {
      id: `pool-${Date.now()}`,
      name: `Export Pool ${new Date().toLocaleDateString()}`,
      documentCount: pooledDocs.length,
      totalSize:
        pooledDocs
          .reduce(
            (acc, doc) => acc + parseFloat(doc.fileSize),
            0,
          )
          .toFixed(1) + " MB",
      createdDate: new Date().toISOString(),
      status: "active",
      exportFormat: "ZIP",
    };

    setExportPools((prev) => [newPool, ...prev]);
    onAuditLog(
      `Export pool created: ${pooledDocs.length} documents (${newPool.totalSize})`,
    );
  };

  const handlePrintPool = () => {
    const pooledDocs = documents.filter((d) => d.pooled);
    if (pooledDocs.length === 0) {
      onAuditLog(
        "Print queue is empty - no documents to print",
      );
      return;
    }
    onAuditLog(
      `Sending ${pooledDocs.length} documents to print queue`,
    );
  };

  const filteredDocuments = documents.filter((doc) => {
    const matchesSearch =
      doc.fileName
        .toLowerCase()
        .includes(searchTerm.toLowerCase()) ||
      doc.sourceModule
        .toLowerCase()
        .includes(searchTerm.toLowerCase());
    const matchesFilter =
      filterType === "all" || doc.documentType === filterType;
    return matchesSearch && matchesFilter;
  });

  const pooledCount = documents.filter((d) => d.pooled).length;
  const totalPoolSize = documents
    .filter((d) => d.pooled)
    .reduce((acc, doc) => acc + parseFloat(doc.fileSize), 0)
    .toFixed(1);

  return (
    <div className="space-y-6">
      {/* Header Section */}
      <div className="bg-gradient-to-r from-indigo-900/20 via-purple-900/20 to-indigo-900/20 border border-indigo-500/30 rounded-lg p-6">
        <div className="flex items-center justify-between mb-4">
          <div className="flex items-center gap-3">
            <FileText className="w-8 h-8 text-indigo-400" />
            <div>
              <h1 className="text-2xl font-bold text-indigo-400">
                Manuscript Export & Document Pool
              </h1>
              <p className="text-sm text-gray-400 mt-1">
                Collect, print, and export platform-generated
                documents
              </p>
            </div>
          </div>
          <div className="text-right">
            <div className="text-xs text-gray-400">
              Total Documents
            </div>
            <div className="text-3xl font-bold text-indigo-400">
              {documents.length}
            </div>
          </div>
        </div>

        {/* Quick Stats */}
        <div className="grid grid-cols-4 gap-4">
          <div className="bg-black/40 border border-green-500/20 rounded-lg p-3">
            <div className="text-xs text-gray-400 mb-1">
              Ready to Export
            </div>
            <div className="text-xl font-bold text-green-400">
              {
                documents.filter((d) => d.status === "ready")
                  .length
              }
            </div>
          </div>
          <div className="bg-black/40 border border-purple-500/20 rounded-lg p-3">
            <div className="text-xs text-gray-400 mb-1">
              In Export Pool
            </div>
            <div className="text-xl font-bold text-purple-400">
              {pooledCount}
            </div>
          </div>
          <div className="bg-black/40 border border-cyan-500/20 rounded-lg p-3">
            <div className="text-xs text-gray-400 mb-1">
              Pool Size
            </div>
            <div className="text-xl font-bold text-cyan-400">
              {totalPoolSize} MB
            </div>
          </div>
          <div className="bg-black/40 border border-orange-500/20 rounded-lg p-3">
            <div className="text-xs text-gray-400 mb-1">
              Export Pools
            </div>
            <div className="text-xl font-bold text-orange-400">
              {exportPools.length}
            </div>
          </div>
        </div>
      </div>

      {/* Pool Actions & Search */}
      <div className="bg-gradient-to-br from-[#0f172a] to-[#1e293b] border border-indigo-500/20 rounded-lg p-6">
        <div className="flex items-center justify-between gap-4 mb-4">
          <div className="flex-1 relative">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 w-4 h-4 text-gray-400" />
            <input
              type="text"
              placeholder="Search documents by name or source module..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="w-full bg-black/40 border border-cyan-500/20 rounded-lg pl-10 pr-4 py-2 text-sm text-white placeholder-gray-500 focus:outline-none focus:border-cyan-400"
            />
          </div>
          <select
            value={filterType}
            onChange={(e) => setFilterType(e.target.value)}
            className="bg-black/40 border border-cyan-500/20 rounded-lg px-4 py-2 text-sm text-white focus:outline-none focus:border-cyan-400"
          >
            <option value="all">All Types</option>
            <option value="Transaction-Report">
              Transaction Reports
            </option>
            <option value="Banking-Statement">
              Banking Statements
            </option>
            <option value="Compliance-Certificate">
              Compliance Certificates
            </option>
            <option value="Audit-Log">Audit Logs</option>
            <option value="Policy-Document">
              Policy Documents
            </option>
            <option value="License-Record">
              License Records
            </option>
            <option value="5G-Network-Report">
              5G Network Reports
            </option>
            <option value="FPGA-Analysis">FPGA Analysis</option>
            <option value="Certificate-Chain">
              Certificate Chains
            </option>
          </select>
        </div>

        <div className="flex gap-3">
          <button
            onClick={handleExportPool}
            disabled={pooledCount === 0 || !secureMode}
            className={`flex items-center gap-2 px-6 py-3 rounded-lg font-semibold transition-all ${
              pooledCount === 0 || !secureMode
                ? "bg-gray-700 text-gray-500 cursor-not-allowed"
                : "bg-gradient-to-r from-green-600 to-green-500 text-white hover:from-green-500 hover:to-green-400"
            }`}
          >
            <Download className="w-5 h-5" />
            Export Pool ({pooledCount})
          </button>
          <button
            onClick={handlePrintPool}
            disabled={pooledCount === 0 || !secureMode}
            className={`flex items-center gap-2 px-6 py-3 rounded-lg font-semibold transition-all ${
              pooledCount === 0 || !secureMode
                ? "bg-gray-700 text-gray-500 cursor-not-allowed"
                : "bg-gradient-to-r from-purple-600 to-purple-500 text-white hover:from-purple-500 hover:to-purple-400"
            }`}
          >
            <Printer className="w-5 h-5" />
            Print Pool
          </button>
          {!secureMode && (
            <div className="flex items-center gap-2 px-4 py-3 bg-red-900/20 border border-red-500/30 rounded-lg">
              <AlertCircle className="w-4 h-4 text-red-400" />
              <span className="text-xs text-red-400">
                Secure mode required for export operations
              </span>
            </div>
          )}
        </div>
      </div>

      {/* Main Content Grid */}
      <div className="grid grid-cols-3 gap-6">
        {/* Available Documents */}
        <div className="col-span-2 bg-gradient-to-br from-[#0f172a] to-[#1e293b] border border-indigo-500/20 rounded-lg p-6">
          <h2 className="text-xl font-bold text-indigo-400 mb-4 flex items-center gap-2">
            <FolderOpen className="w-5 h-5" />
            Available Manuscripts ({filteredDocuments.length})
          </h2>
          <div className="space-y-2 max-h-[600px] overflow-y-auto">
            {filteredDocuments.map((doc) => (
              <div
                key={doc.id}
                className={`bg-black/40 border rounded-lg p-4 transition-all ${
                  doc.pooled
                    ? "border-purple-400/50 bg-purple-400/10"
                    : "border-cyan-500/10 hover:border-cyan-400/30"
                }`}
              >
                <div className="flex items-start justify-between">
                  <div className="flex-1">
                    <div className="flex items-center gap-2 mb-2">
                      <FileText
                        className={`w-4 h-4 ${doc.pooled ? "text-purple-400" : "text-cyan-400"}`}
                      />
                      <span className="font-semibold text-white text-sm">
                        {doc.fileName}
                      </span>
                      <span
                        className={`px-2 py-0.5 rounded text-xs ${
                          doc.format === "PDF"
                            ? "bg-red-500/20 text-red-400"
                            : doc.format === "CSV"
                              ? "bg-green-500/20 text-green-400"
                              : doc.format === "JSON"
                                ? "bg-blue-500/20 text-blue-400"
                                : doc.format === "XML"
                                  ? "bg-orange-500/20 text-orange-400"
                                  : "bg-gray-500/20 text-gray-400"
                        }`}
                      >
                        {doc.format}
                      </span>
                    </div>
                    <div className="grid grid-cols-2 gap-2 text-xs">
                      <div className="flex justify-between">
                        <span className="text-gray-400">
                          Type:
                        </span>
                        <span className="text-cyan-400">
                          {doc.documentType}
                        </span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-gray-400">
                          Size:
                        </span>
                        <span className="text-gray-200">
                          {doc.fileSize}
                        </span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-gray-400">
                          Source:
                        </span>
                        <span className="text-purple-400 text-[10px]">
                          {doc.sourceModule}
                        </span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-gray-400">
                          Generated:
                        </span>
                        <span className="text-gray-500 text-[10px]">
                          {new Date(
                            doc.generatedDate,
                          ).toLocaleString()}
                        </span>
                      </div>
                      {doc.methodology && (
                        <div className="flex justify-between">
                          <span className="text-gray-400">
                            Methodology:
                          </span>
                          <span className="text-orange-400 font-mono text-[10px]">
                            {doc.methodology}
                          </span>
                        </div>
                      )}
                      {doc.complianceTag && (
                        <div className="flex justify-between">
                          <span className="text-gray-400">
                            Compliance:
                          </span>
                          <span className="text-green-400 text-[10px]">
                            {doc.complianceTag}
                          </span>
                        </div>
                      )}
                    </div>
                  </div>
                  <div className="flex flex-col gap-2 ml-4">
                    <button
                      onClick={() =>
                        toggleDocumentInPool(doc.id)
                      }
                      className={`px-3 py-1.5 rounded text-xs font-semibold transition-all ${
                        doc.pooled
                          ? "bg-purple-600 text-white hover:bg-purple-500"
                          : "bg-cyan-600 text-white hover:bg-cyan-500"
                      }`}
                    >
                      {doc.pooled ? "Remove" : "Add to Pool"}
                    </button>
                    <span
                      className={`px-2 py-1 rounded text-xs text-center ${
                        doc.status === "ready"
                          ? "bg-green-500/20 text-green-400"
                          : doc.status === "in-pool"
                            ? "bg-purple-500/20 text-purple-400"
                            : doc.status === "pending"
                              ? "bg-yellow-500/20 text-yellow-400"
                              : "bg-gray-500/20 text-gray-400"
                      }`}
                    >
                      {doc.status}
                    </span>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Export Pools */}
        <div className="bg-gradient-to-br from-[#0f172a] to-[#1e293b] border border-indigo-500/20 rounded-lg p-6">
          <h2 className="text-xl font-bold text-indigo-400 mb-4 flex items-center gap-2">
            <Package className="w-5 h-5" />
            Export Pools
          </h2>
          <div className="space-y-3 max-h-[600px] overflow-y-auto">
            {exportPools.map((pool) => (
              <div
                key={pool.id}
                className="bg-black/40 border border-indigo-500/20 rounded-lg p-4"
              >
                <div className="flex items-center justify-between mb-3">
                  <span className="text-sm font-semibold text-white">
                    {pool.name}
                  </span>
                  <span
                    className={`px-2 py-0.5 rounded text-xs ${
                      pool.status === "active"
                        ? "bg-green-500/20 text-green-400"
                        : pool.status === "exported"
                          ? "bg-blue-500/20 text-blue-400"
                          : "bg-purple-500/20 text-purple-400"
                    }`}
                  >
                    {pool.status}
                  </span>
                </div>
                <div className="space-y-1 text-xs">
                  <div className="flex justify-between">
                    <span className="text-gray-400">
                      Documents:
                    </span>
                    <span className="text-cyan-400">
                      {pool.documentCount}
                    </span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-gray-400">
                      Total Size:
                    </span>
                    <span className="text-gray-200">
                      {pool.totalSize}
                    </span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-gray-400">
                      Format:
                    </span>
                    <span className="text-purple-400">
                      {pool.exportFormat}
                    </span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-gray-400">
                      Created:
                    </span>
                    <span className="text-gray-500 text-[10px]">
                      {new Date(
                        pool.createdDate,
                      ).toLocaleDateString()}
                    </span>
                  </div>
                </div>
                {pool.status === "active" && (
                  <button
                    onClick={() =>
                      onAuditLog(
                        `Downloading export pool: ${pool.name}`,
                      )
                    }
                    className="w-full mt-3 px-3 py-1.5 bg-gradient-to-r from-green-600 to-green-500 text-white rounded text-xs font-semibold hover:from-green-500 hover:to-green-400 transition-all"
                  >
                    <Download className="w-3 h-3 inline mr-1" />
                    Download
                  </button>
                )}
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Document Type Distribution */}
      <div className="bg-gradient-to-br from-[#0f172a] to-[#1e293b] border border-indigo-500/20 rounded-lg p-6">
        <h2 className="text-xl font-bold text-indigo-400 mb-4 flex items-center gap-2">
          <Archive className="w-5 h-5" />
          Document Type Distribution
        </h2>
        <div className="grid grid-cols-5 gap-3">
          {[
            "Transaction-Report",
            "Banking-Statement",
            "Compliance-Certificate",
            "Audit-Log",
            "Policy-Document",
          ].map((type) => {
            const count = documents.filter(
              (d) => d.documentType === type,
            ).length;
            return (
              <div
                key={type}
                className="bg-black/40 border border-cyan-500/10 rounded-lg p-3 text-center"
              >
                <div className="text-2xl font-bold text-cyan-400">
                  {count}
                </div>
                <div className="text-xs text-gray-400 mt-1">
                  {type.replace("-", " ")}
                </div>
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
}