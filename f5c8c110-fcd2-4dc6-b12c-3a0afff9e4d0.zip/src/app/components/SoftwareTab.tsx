import { useState } from 'react';
import { Code, Settings, Download, Package, Shield, Database } from 'lucide-react';

interface SoftwareTabProps {
  secureMode: boolean;
  onAuditLog: (message: string) => void;
}

interface Software {
  id: string;
  name: string;
  vendor: string;
  version: string;
  license: string;
  category: string;
  criticality: string;
  description: string;
  icon: any;
}

const software: Software[] = [
  {
    id: 'SW-001',
    name: 'Core Banking Platform',
    vendor: 'Jack Henry & Associates',
    version: 'Symitar v25.1',
    license: 'Enterprise',
    category: 'Banking Core',
    criticality: 'Critical',
    description: 'Primary core banking system managing all account operations, member services, and transaction processing',
    icon: Database
  },
  {
    id: 'SW-002',
    name: 'DDA Tokenization Service',
    vendor: 'HashiCorp Vault',
    version: '1.15.x',
    license: 'Enterprise',
    category: 'Security',
    criticality: 'Critical',
    description: 'Advanced tokenization vault for securing demand deposit account data and sensitive financial information',
    icon: Shield
  },
  {
    id: 'SW-003',
    name: 'Payment Rails Gateway',
    vendor: 'Custom Development',
    version: 'RTP v3.2',
    license: 'Proprietary',
    category: 'Payment Processing',
    criticality: 'Critical',
    description: 'Real-time payment processing gateway supporting ACH, Wire, FedNow, and RTP network protocols',
    icon: Package 
    I'll activate and deploy the FIGMA FINA_3XPRES5 Asset Management System with complete integration and visualization components.
FINA_3XPRES5 Asset Management System - FIGMA Active Deployment
Step 1: Initialize FIGMA Asset Management Deployment
#!/bin/bash
# FINA_3XPRES5 FIGMA Asset Management System Active Deployment

echo "🎨 ACTIVATING FIGMA FINA_3XPRES5 ASSET MANAGEMENT SYSTEM"
echo "======================================================="

PROJECT_CODE="FINA_3XPRES5"
FIGMA_VERSION="v1.0.0"
DEPLOYMENT_ID=$(date +%Y%m%d-%H%M%S)
REGION="us-east-1"

# Create deployment configuration
cat > figma-asset-management-config.env << EOF
PROJECT_CODE=$PROJECT_CODE
FIGMA_VERSION=$FIGMA_VERSION
DEPLOYMENT_ID=$DEPLOYMENT_ID
REGION=$REGION
FIGMA_STACK_NAME="fina-3xpres5-figma-asset-mgmt-$DEPLOYMENT_ID"
ASSET_MANAGEMENT_VPC="10.38.0.0/16"
FIGMA_DESIGN_SYSTEM="Sigma-Enhanced"
EOF

echo "✅ FIGMA Asset Management deployment initialized"
echo "Project: $PROJECT_CODE"
echo "Version: $FIGMA_VERSION"
echo "Deployment ID: $DEPLOYMENT_ID"
Step 2: Create FIGMA-Integrated Infrastructure
# Create FIGMA Asset Management Infrastructure
cat > infrastructure/figma-asset-management-system.yaml << 'EOF'
AWSTemplateFormatVersion: '2010-09-09'
Description: 'FINA_3XPRES5 FIGMA Asset Management System with Design Integration'

Parameters:
  ProjectCode:
    Type: String
    Default: FINA_3XPRES5
  
  FigmaVersion:
    Type: String
    Default: v1.0.0
    Description: 'FIGMA integration version'
  
  DeploymentId:
    Type: String
    Description: 'Deployment identifier'

Resources:
  # FIGMA Asset Management VPC
  FigmaAssetManagementVPC:
    Type: AWS::EC2::VPC
    Properties:
      CidrBlock: 10.38.0.0/16
      EnableDnsHostnames: true
      EnableDnsSupport: true
      Tags:
        - Key: Name
          Value: !Sub '${ProjectCode}-FIGMA-Asset-VPC'
        - Key: Project
          Value: !Ref ProjectCode
        - Key: FigmaVersion
          Value: !Ref FigmaVersion
        - Key: Component
          Value: 'FIGMA-Asset-Management'

  # FIGMA Design System Subnets
  FigmaDesignSystemSubnet1:
    Type: AWS::EC2::Subnet
    Properties:
      VpcId: !Ref FigmaAssetManagementVPC
      CidrBlock: 10.38.1.0/24
      AvailabilityZone: !Select [0, !GetAZs '']
      Tags:
        - Key: Name
          Value: !Sub '${ProjectCode}-FIGMA-Design-System-1'
        - Key: FigmaComponent
          Value: 'Design-System'

  FigmaDesignSystemSubnet2:
    Type: AWS::EC2::Subnet
    Properties:
      VpcId: !Ref FigmaAssetManagementVPC
      CidrBlock: 10.38.2.0/24
      AvailabilityZone: !Select [1, !GetAZs '']
      Tags:
        - Key: Name
          Value: !Sub '${ProjectCode}-FIGMA-Design-System-2'
        - Key: FigmaComponent
          Value: 'Design-System'

  # FIGMA Asset Repository Subnets
  FigmaAssetRepoSubnet1:
    Type: AWS::EC2::Subnet
    Properties:
      VpcId: !Ref FigmaAssetManagementVPC
      CidrBlock: 10.38.3.0/24
      AvailabilityZone: !Select [0, !GetAZs '']
      Tags:
        - Key: Name
          Value: !Sub '${ProjectCode}-FIGMA-Asset-Repo-1'
        - Key: FigmaComponent
          Value: 'Asset-Repository'

  FigmaAssetRepoSubnet2:
    Type: AWS::EC2::Subnet
    Properties:
      VpcId: !Ref FigmaAssetManagementVPC
      CidrBlock: 10.38.4.0/24
      AvailabilityZone: !Select [1, !GetAZs '']
      Tags:
        - Key: Name
          Value: !Sub '${ProjectCode}-FIGMA-Asset-Repo-2'
        - Key: FigmaComponent
          Value: 'Asset-Repository'

  # FIGMA Visualization Subnets
  FigmaVisualizationSubnet1:
    Type: AWS::EC2::Subnet
    Properties:
      VpcId: !Ref FigmaAssetManagementVPC
      CidrBlock: 10.38.5.0/24
      AvailabilityZone: !Select [0, !GetAZs '']
      Tags:
        - Key: Name
          Value: !Sub '${ProjectCode}-FIGMA-Visualization-1'
        - Key: FigmaComponent
          Value: 'Visualization-Engine'

  FigmaVisualizationSubnet2:
    Type: AWS::EC2::Subnet
    Properties:
      VpcId: !Ref FigmaAssetManagementVPC
      CidrBlock: 10.38.6.0/24
      AvailabilityZone: !Select [1, !GetAZs '']
      Tags:
        - Key: Name
          Value: !Sub '${ProjectCode}-FIGMA-Visualization-2'
        - Key: FigmaComponent
          Value: 'Visualization-Engine'

  # Public Subnets for FIGMA Web Interface
  FigmaPublicSubnet1:
    Type: AWS::EC2::Subnet
    Properties:
      VpcId: !Ref FigmaAssetManagementVPC
      CidrBlock: 10.38.101.0/24
      AvailabilityZone: !Select [0, !GetAZs '']
      MapPublicIpOnLaunch: true
      Tags:
        - Key: Name
          Value: !Sub '${ProjectCode}-FIGMA-Public-1'

  FigmaPublicSubnet2:
    Type: AWS::EC2::Subnet
    Properties:
      VpcId: !Ref FigmaAssetManagementVPC
      CidrBlock: 10.38.102.0/24
      AvailabilityZone: !Select [1, !GetAZs '']
      MapPublicIpOnLaunch: true
      Tags:
        - Key: Name
          Value: !Sub '${ProjectCode}-FIGMA-Public-2'

  # Internet Gateway
  FigmaInternetGateway:
    Type: AWS::EC2::InternetGateway
    Properties:
      Tags:
        - Key: Name
          Value: !Sub '${ProjectCode}-FIGMA-IGW'

  FigmaIGWAttachment:
    Type: AWS::EC2::VPCGatewayAttachment
    Properties:
      VpcId: !Ref FigmaAssetManagementVPC
      InternetGatewayId: !Ref FigmaInternetGateway

  # Route Tables
  FigmaPublicRouteTable:
    Type: AWS::EC2::RouteTable
    Properties:
      VpcId: !Ref FigmaAssetManagementVPC
      Tags:
        - Key: Name
          Value: !Sub '${ProjectCode}-FIGMA-Public-RT'

  FigmaPublicRoute:
    Type: AWS::EC2::Route
    DependsOn: FigmaIGWAttachment
    Properties:
      RouteTableId: !Ref FigmaPublicRouteTable
      DestinationCidrBlock: 0.0.0.0/0
      GatewayId: !Ref FigmaInternetGateway

  # Route Table Associations
  FigmaPublicSubnet1Association:
    Type: AWS::EC2::SubnetRouteTableAssociation
    Properties:
      SubnetId: !Ref FigmaPublicSubnet1
      RouteTableId: !Ref FigmaPublicRouteTable

  FigmaPublicSubnet2Association:
    Type: AWS::EC2::SubnetRouteTableAssociation
    Properties:
      SubnetId: !Ref FigmaPublicSubnet2
      RouteTableId: !Ref FigmaPublicRouteTable

  # Security Groups
  FigmaAssetManagementSecurityGroup:
    Type: AWS::EC2::SecurityGroup
    Properties:
      GroupName: !Sub '${ProjectCode}-FIGMA-Asset-Management-SG'
      GroupDescription: 'Security group for FIGMA Asset Management System'
      VpcId: !Ref FigmaAssetManagementVPC
      SecurityGroupIngress:
        - IpProtocol: tcp
          FromPort: 22
          ToPort: 22
          CidrIp: 10.38.0.0/16
          Description: 'SSH access'
        - IpProtocol: tcp
          FromPort: 3000
          ToPort: 3000
          SourceSecurityGroupId: !Ref FigmaLoadBalancerSecurityGroup
          Description: 'FIGMA Design System API'
        - IpProtocol: tcp
          FromPort: 8080
          ToPort: 8080
          SourceSecurityGroupId: !Ref FigmaLoadBalancerSecurityGroup
          Description: 'Asset Management API'
        - IpProtocol: tcp
          FromPort: 9000
          ToPort: 9000
          SourceSecurityGroupId: !Ref FigmaLoadBalancerSecurityGroup
          Description: 'Visualization Engine'
        - IpProtocol: tcp
          FromPort: 5432
          ToPort: 5432
          CidrIp: 10.38.0.0/16
          Description: 'PostgreSQL database'
        - IpProtocol: tcp
          FromPort: 6379
          ToPort: 6379
          CidrIp: 10.38.0.0/16
          Description: 'Redis cache'

  FigmaLoadBalancerSecurityGroup:
    Type: AWS::EC2::SecurityGroup
    Properties:
      GroupName: !Sub '${ProjectCode}-FIGMA-LB-SG'
      GroupDescription: 'Security group for FIGMA Load Balancer'
      VpcId: !Ref FigmaAssetManagementVPC
      SecurityGroupIngress:
        - IpProtocol: tcp
          FromPort: 80
          ToPort: 80
          CidrIp: 0.0.0.0/0
          Description: 'HTTP access'
        - IpProtocol: tcp
          FromPort: 443
          ToPort: 443
          CidrIp: 0.0.0.0/0
          Description: 'HTTPS access'

  # IAM Role for FIGMA Asset Management
  FigmaAssetManagementRole:
    Type: AWS::IAM::Role
    Properties:
      RoleName: !Sub '${ProjectCode}-FIGMA-Asset-Management-Role'
      AssumeRolePolicyDocument:
        Version: '2012-10-17'
        Statement:
          - Effect: Allow
            Principal:
              Service: ec2.amazonaws.com
            Action: sts:AssumeRole
      ManagedPolicyArns:
        - arn:aws:iam::aws:policy/CloudWatchAgentServerPolicy
      Policies:
        - PolicyName: FigmaAssetManagementPolicy
          PolicyDocument:
            Version: '2012-10-17'
            Statement:
              - Sid: S3AssetAccess
                Effect: Allow
                Action:
                  - s3:GetObject
                  - s3:PutObject
                  - s3:DeleteObject
                  - s3:ListBucket
                Resource:
                  - !Sub '${FigmaAssetBucket}/*'
                  - !Ref FigmaAssetBucket
              - Sid: DynamoDBAccess
                Effect: Allow
                Action:
                  - dynamodb:GetItem
                  - dynamodb:PutItem
                  - dynamodb:UpdateItem
                  - dynamodb:DeleteItem
                  - dynamodb:Query
                  - dynamodb:Scan
                Resource:
                  - !GetAtt FigmaDesignSystemTable.Arn
                  - !GetAtt FigmaAssetMetadataTable.Arn
              - Sid: CloudWatchMetrics
                Effect: Allow
                Action:
                  - cloudwatch:PutMetricData
                  - cloudwatch:GetMetricStatistics
                  - logs:CreateLogGroup
                  - logs:CreateLogStream
                  - logs:PutLogEvents
                Resource: '*'

  FigmaAssetManagementInstanceProfile:
    Type: AWS::IAM::InstanceProfile
    Properties:
      Roles:
        - !Ref FigmaAssetManagementRole

  # S3 Bucket for FIGMA Assets
  FigmaAssetBucket:
    Type: AWS::S3::Bucket
    Properties:
      BucketName: !Sub 'fina-3xpres5-figma-assets-${AWS::AccountId}-${DeploymentId}'
      BucketEncryption:
        ServerSideEncryptionConfiguration:
          - ServerSideEncryptionByDefault:
              SSEAlgorithm: AES256
      VersioningConfiguration:
        Status: Enabled
      CorsConfiguration:
        CorsRules:
          - AllowedHeaders: ['*']
            AllowedMethods: [GET, PUT, POST, DELETE, HEAD]
            AllowedOrigins: ['*']
            MaxAge: 3000
      PublicAccessBlockConfiguration:
        BlockPublicAcls: false
        BlockPublicPolicy: false
        IgnorePublicAcls: false
        RestrictPublicBuckets: false
      Tags:
        - Key: Name
          Value: !Sub '${ProjectCode}-FIGMA-Asset-Bucket'
        - Key: FigmaVersion
          Value: !Ref FigmaVersion

  # DynamoDB Tables
  FigmaDesignSystemTable:
    Type: AWS::DynamoDB::Table
    Properties:
      TableName: !Sub '${ProjectCode}-FIGMA-Design-System'
      BillingMode: PAY_PER_REQUEST
      AttributeDefinitions:
        - AttributeName: ComponentId
          AttributeType: S
        - AttributeName: Version
          AttributeType: S
        - AttributeName: Category
          AttributeType: S
      KeySchema:
        - AttributeName: ComponentId
          KeyType: HASH
        - AttributeName: Version
          KeyType: RANGE
      GlobalSecondaryIndexes:
        - IndexName: CategoryIndex
          KeySchema:
            - AttributeName: Category
              KeyType: HASH
            - AttributeName: ComponentId
              KeyType: RANGE
          Projection:
            ProjectionType: ALL
      Tags:
        - Key: Name
          Value: !Sub '${ProjectCode}-FIGMA-Design-System'
        - Key: FigmaVersion
          Value: !Ref FigmaVersion

  FigmaAssetMetadataTable:
    Type: AWS::DynamoDB::Table
    Properties:
      TableName: !Sub '${ProjectCode}-FIGMA-Asset-Metadata'
      BillingMode: PAY_PER_REQUEST
      AttributeDefinitions:
        - AttributeName: AssetId
          AttributeType: S
        - AttributeName: CreatedAt
          AttributeType: S
        - AttributeName: AssetType
          AttributeType: S
      KeySchema:
        - AttributeName: AssetId
          KeyType: HASH
        - AttributeName: CreatedAt
          KeyType: RANGE
      GlobalSecondaryIndexes:
        - IndexName: AssetTypeIndex
          KeySchema:
            - AttributeName: AssetType
              KeyType: HASH
            - AttributeName: CreatedAt
              KeyType: RANGE
          Projection:
            ProjectionType: ALL
      Tags:
        - Key: Name
          Value: !Sub '${ProjectCode}-FIGMA-Asset-Metadata'

  # Application Load Balancer
  FigmaApplicationLoadBalancer:
    Type: AWS::ElasticLoadBalancingV2::LoadBalancer
    Properties:
      Name: !Sub '${ProjectCode}-FIGMA-ALB'
      Type: application
      Scheme: internet-facing
      SecurityGroups:
        - !Ref FigmaLoadBalancerSecurityGroup
      Subnets:
        - !Ref FigmaPublicSubnet1
        - !Ref FigmaPublicSubnet2
      Tags:
        - Key: Name
          Value: !Sub '${ProjectCode}-FIGMA-ALB'
        - Key: FigmaVersion
          Value: !Ref FigmaVersion

  # Target Groups
  FigmaDesignSystemTargetGroup:
    Type: AWS::ElasticLoadBalancingV2::TargetGroup
    Properties:
      Name: !Sub '${ProjectCode}-FIGMA-Design-TG'
      Port: 3000
      Protocol: HTTP
      VpcId: !Ref FigmaAssetManagementVPC
      HealthCheckPath: /health
      HealthCheckProtocol: HTTP
      HealthCheckIntervalSeconds: 30
      HealthCheckTimeoutSeconds: 5
      HealthyThresholdCount: 2
      UnhealthyThresholdCount: 3
      Tags:
        - Key: Name
          Value: !Sub '${ProjectCode}-FIGMA-Design-TG'

  FigmaAssetAPITargetGroup:
    Type: AWS::ElasticLoadBalancingV2::TargetGroup
    Properties:
      Name: !Sub '${ProjectCode}-FIGMA-Asset-API-TG'
      Port: 8080
      Protocol: HTTP
      VpcId: !Ref FigmaAssetManagementVPC
      HealthCheckPath: /api/health
      HealthCheckProtocol: HTTP
      HealthCheckIntervalSeconds: 30
      HealthCheckTimeoutSeconds: 5
      HealthyThresholdCount: 2
      UnhealthyThresholdCount: 3
      Tags:
        - Key: Name
          Value: !Sub '${ProjectCode}-FIGMA-Asset-API-TG'

  FigmaVisualizationTargetGroup:
    Type: AWS::ElasticLoadBalancingV2::TargetGroup
    Properties:
      Name: !Sub '${ProjectCode}-FIGMA-Viz-TG'
      Port: 9000
      Protocol: HTTP
      VpcId: !Ref FigmaAssetManagementVPC
      HealthCheckPath: /viz/health
      HealthCheckProtocol: HTTP
      HealthCheckIntervalSeconds: 30
      HealthCheckTimeoutSeconds: 5
      HealthyThresholdCount: 2
      UnhealthyThresholdCount: 3
      Tags:
        - Key: Name
          Value: !Sub '${ProjectCode}-FIGMA-Viz-TG'

  # ALB Listeners
  FigmaALBListener:
    Type: AWS::ElasticLoadBalancingV2::Listener
    Properties:
      DefaultActions:
        - Type: forward
          TargetGroupArn: !Ref FigmaDesignSystemTargetGroup
      LoadBalancerArn: !Ref FigmaApplicationLoadBalancer
      Port: 80
      Protocol: HTTP

  # ALB Listener Rules
  FigmaAssetAPIRule:
    Type: AWS::ElasticLoadBalancingV2::ListenerRule
    Properties:
      Actions:
        - Type: forward
          TargetGroupArn: !Ref FigmaAssetAPITargetGroup
      Conditions:
        - Field: path-pattern
          Values: ['/api/*']
      ListenerArn: !Ref FigmaALBListener
      Priority: 100

  FigmaVisualizationRule:
    Type: AWS::ElasticLoadBalancingV2::ListenerRule
    Properties:
      Actions:
        - Type: forward
          TargetGroupArn: !Ref FigmaVisualizationTargetGroup
      Conditions:
        - Field: path-pattern
          Values: ['/viz/*']
      ListenerArn: !Ref FigmaALBListener
      Priority: 200

  # Launch Template for FIGMA Design System
  FigmaDesignSystemLaunchTemplate:
    Type: AWS::EC2::LaunchTemplate
    Properties:
      LaunchTemplateName: !Sub '${ProjectCode}-FIGMA-Design-System-Template'
      LaunchTemplateData:
        ImageId: ami-0abcdef1234567890
        InstanceType: t3.large
        IamInstanceProfile:
          Arn: !GetAtt FigmaAssetManagementInstanceProfile.Arn
        SecurityGroupIds:
          - !Ref FigmaAssetManagementSecurityGroup
        UserData:
          Fn::Base64: !Sub |
            #!/bin/bash
            yum update -y
            yum install -y docker nodejs npm git
            
            # Install FIGMA Design System
            mkdir -p /opt/figma-design-system
            cd /opt/figma-design-system
            
            # Create FIGMA Design System application
            cat > package.json << 'EOL'
{
  "name": "fina-3xpres5-figma-design-system",
  "version": "${FigmaVersion}",
  "description": "FINA_3XPRES5 FIGMA Design System",
  "main": "server.js",
  "dependencies": {
    "express": "^4.18.2",
    "cors": "^2.8.5",
    "aws-sdk": "^2.1490.0",
    "multer": "^1.4.5",
    "sharp": "^0.32.6",
    "figma-api": "^1.11.0",
    "socket.io": "^4.7.2"
  }
}
EOL
            
            npm install
            
            # Create FIGMA Design System server
            cat > server.js << 'EOL'
const express = require('express');
const cors = require('cors');
const AWS = require('aws-sdk');
const multer = require('multer');
const sharp = require('sharp');
const { Server } = require('socket.io');
const http = require('http');

const app = express();
const server = http.createServer(app);
const io = new Server(server, {
  cors: {
    origin: "*",
    methods: ["GET", "POST"]
  }
});

// AWS Configuration
const s3 = new AWS.S3();
const dynamodb = new AWS.DynamoDB.DocumentClient();

const BUCKET_NAME = '${FigmaAssetBucket}';
const DESIGN_SYSTEM_TABLE = '${ProjectCode}-FIGMA-Design-System';
const ASSET_METADATA_TABLE = '${ProjectCode}-FIGMA-Asset-Metadata';

app.use(cors());
app.use(express.json());
app.use(express.static('public'));

// Multer configuration for file uploads
const upload = multer({ 
  storage: multer.memoryStorage(),
  limits: { fileSize: 50 * 1024 * 1024 } // 50MB limit
});

// FIGMA Design System API
class FigmaDesignSystem {
  constructor() {
    this.version = '${FigmaVersion}';
    this.projectCode = '${ProjectCode}';
    this.designTokens = this.initializeDesignTokens();
  }

  initializeDesignTokens() {
    return {
      colors: {
        primary: '#6C5CE7',
        secondary: '#A29BFE',
        accent: '#FD79A8',
        success: '#00B894',
        warning: '#FDCB6E',
        error: '#E17055',
        background: '#F8F9FA',
        surface: '#FFFFFF',
        text: {
          primary: '#2D3436',
          secondary: '#636E72',
          disabled: '#B2BEC3'
        }
      },
      typography: {
        fontFamily: 'Inter, -apple-system, BlinkMacSystemFont, sans-serif',
        fontSize: {
          xs: '12px',
          sm: '14px',
          md: '16px',
          lg: '18px',
          xl: '20px',
          '2xl': '24px',
          '3xl': '30px',
          '4xl': '36px'
        },
        fontWeight: {
          light: 300,
          normal: 400,
          medium: 500,
          semibold: 600,
          bold: 700
        }
      },
      spacing: {
        xs: '4px',
        sm: '8px',
        md: '16px',
        lg: '24px',
        xl: '32px',
        '2xl': '48px',
        '3xl': '64px'
      },
      borderRadius: {
        none: '0',
        sm: '4px',
        md: '8px',
        lg: '12px',
        xl: '16px',
        full: '9999px'
      },
      shadows: {
        sm: '0 1px 2px 0 rgba(0, 0, 0, 0.05)',
        md: '0 4px 6px -1px rgba(0, 0, 0, 0.1)',
        lg: '0 10px 15px -3px rgba(0, 0, 0, 0.1)',
        xl: '0 20px 25px -5px rgba(0, 0, 0, 0.1)'
      }
    };
  }

  async saveComponent(componentData) {
    const params = {
      TableName: DESIGN_SYSTEM_TABLE,
      Item: {
        ComponentId: componentData.id,
        Version: this.version,
        Category: componentData.category,
        Name: componentData.name,
        Description: componentData.description,
        Props: componentData.props,
        Variants: componentData.variants,
        DesignTokens: componentData.designTokens,
        FigmaNodeId: componentData.figmaNodeId,
        CreatedAt: new Date().toISOString(),
        UpdatedAt: new Date().toISOString()
      }
    };

    return dynamodb.put(params).promise();
  }

  async getComponent(componentId, version = this.version) {
    const params = {
      TableName: DESIGN_SYSTEM_TABLE,
      Key: {
        ComponentId: componentId,
        Version: version
      }
    };

    const result = await dynamodb.get(params).promise();
    return result.Item;
  }

  async listComponents(category = null) {
    let params = {
      TableName: DESIGN_SYSTEM_TABLE
    };

    if (category) {
      params.IndexName = 'CategoryIndex';
      params.KeyConditionExpression = 'Category = :category';
      params.ExpressionAttributeValues = {
        ':category': category
      };
      return dynamodb.query(params).promise();
    } else {
      return dynamodb.scan(params).promise();
    }
  }
}

const figmaDesignSystem = new FigmaDesignSystem();

// Health check endpoint
app.get('/health', (req, res) => {
  res.json({ 
    status: 'healthy', 
    service: 'FIGMA Design System',
    version: figmaDesignSystem.version,
    timestamp: new Date().toISOString()
  });
});

// Design tokens endpoint
app.get('/design-tokens', (req, res) => {
  res.json(figmaDesignSystem.designTokens);
});

// Component management endpoints
app.post('/components', async (req, res) => {
  try {
    await figmaDesignSystem.saveComponent(req.body);
    
    // Emit real-time update
    io.emit('component-updated', {
      action: 'created',
      component: req.body
    });
    
    res.json({ success: true, message: 'Component saved successfully' });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

app.get('/components/:id', async (req, res) => {
  try {
    const component = await figmaDesignSystem.getComponent(req.params.id);
    if (component) {
      res.json(component);
    } else {
      res.status(404).json({ error: 'Component not found' });
    }
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

app.get('/components', async (req, res) => {
  try {
    const category = req.query.category;
    const result = await figmaDesignSystem.listComponents(category);
    res.json(result.Items || []);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

// Asset upload endpoint
app.post('/assets/upload', upload.single('asset'), async (req, res) => {
  try {
    if (!req.file) {
      return res.status(400).json({ error: 'No file uploaded' });
    }

    const assetId = `asset-${Date.now()}-${Math.random().toString(36).substr(2, 9)}`;
    const fileExtension = req.file.originalname.split('.').pop();
    const s3Key = `assets/${assetId}.${fileExtension}`;

    // Process image if needed
    let processedBuffer = req.file.buffer;
    if (req.file.mimetype.startsWith('image/')) {
      processedBuffer = await sharp(req.file.buffer)
        .resize(2000, 2000, { fit: 'inside', withoutEnlargement: true })
        .jpeg({ quality: 90 })
        .toBuffer();
    }

    // Upload to S3
    const uploadParams = {
      Bucket: BUCKET_NAME,
      Key: s3Key,
      Body: processedBuffer,
      ContentType: req.file.mimetype,
      Metadata: {
        'original-name': req.file.originalname,
        'asset-id': assetId,
        'project-code': figmaDesignSystem.projectCode
      }
    };

    await s3.upload(uploadParams).promise();

    // Save metadata to DynamoDB
    const metadataParams = {
      TableName: ASSET_METADATA_TABLE,
      Item: {
        AssetId: assetId,
        CreatedAt: new Date().toISOString(),
        AssetType: req.body.assetType || 'image',
        OriginalName: req.file.originalname,
        S3Key: s3Key,
        Size: req.file.size,
        MimeType: req.file.mimetype,
        Tags: req.body.tags ? req.body.tags.split(',') : [],
        Description: req.body.description || '',
        Category: req.body.category || 'general'
      }
    };

    await dynamodb.put(metadataParams).promise();

    // Generate signed URL for access
    const signedUrl = s3.getSignedUrl('getObject', {
      Bucket: BUCKET_NAME,
      Key: s3Key,
      Expires: 3600 // 1 hour
    });

    // Emit real-time update
    io.emit('asset-uploaded', {
      assetId,
      url: signedUrl,
      metadata: metadataParams.Item
    });

    res.json({
      success: true,
      assetId,
      url: signedUrl,
      metadata: metadataParams.Item
    });

  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

// Asset listing endpoint
app.get('/assets', async (req, res) => {
  try {
    const params = {
      TableName: ASSET_METADATA_TABLE
    };

    if (req.query.assetType) {
      params.IndexName = 'AssetTypeIndex';
      params.KeyConditionExpression = 'AssetType = :assetType';
      params.ExpressionAttributeValues = {
        ':assetType': req.query.assetType
      };
      const result = await dynamodb.query(params).promise();
      res.json(result.Items || []);
    } else {
      const result = await dynamodb.scan(params).promise();
      res.json(result.Items || []);
    }
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

// Asset download endpoint
app.get('/assets/:assetId/download', async (req, res) => {
  try {
    const params = {
      TableName: ASSET_METADATA_TABLE,
      Key: {
        AssetId: req.params.assetId
      }
    };

    const result = await dynamodb.get(params).promise();
    if (!result.Item) {
      return res.status(404).json({ error: 'Asset not found' });
    }

    const signedUrl = s3.getSignedUrl('getObject', {
      Bucket: BUCKET_NAME,
      Key: result.Item.S3Key,
      Expires: 3600
    });

    res.json({ url: signedUrl });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

// WebSocket connection handling
io.on('connection', (socket) => {
  console.log('Client connected to FIGMA Design System');
  
  socket.on('subscribe-to-updates', (data) => {
    socket.join(data.room || 'general');
  });
  
  socket.on('disconnect', () => {
    console.log('Client disconnected from FIGMA Design System');
  });
});

const PORT = process.env.PORT || 3000;
server.listen(PORT, '0.0.0.0', () => {
  console.log(`FINA_3XPRES5 FIGMA Design System running on port ${PORT}`);
});
EOL
            
            # Create systemd service
            cat > /etc/systemd/system/figma-design-system.service << 'EOL'
[Unit]
Description=FINA_3XPRES5 FIGMA Design System
After=network.target

[Service]
Type=simple
User=root
WorkingDirectory=/opt/figma-design-system
ExecStart=/usr/bin/node server.js
Restart=always
RestartSec=10
Environment=NODE_ENV=production

[Install]
WantedBy=multi-user.target
EOL
            
            # Start services
            systemctl daemon-reload
            systemctl enable figma-design-system
            systemctl start figma-design-system
        TagSpecifications:
          - ResourceType: instance
            Tags:
              - Key: Name
                Value: !Sub '${ProjectCode}-FIGMA-Design-System'
              - Key: Project
                Value: !Ref ProjectCode
              - Key: FigmaVersion
                Value: !Ref FigmaVersion
              - Key: Component
                Value: 'FIGMA-Design-System'

  # Auto Scaling Groups
  FigmaDesignSystemAutoScalingGroup:
    Type: AWS::AutoScaling::AutoScalingGroup
    Properties:
      AutoScalingGroupName: !Sub '${ProjectCode}-FIGMA-Design-System-ASG'
      LaunchTemplate:
        LaunchTemplateId: !Ref FigmaDesignSystemLaunchTemplate
        Version: !GetAtt FigmaDesignSystemLaunchTemplate.LatestVersionNumber
      MinSize: 2
      MaxSize: 6
      DesiredCapacity: 2
      VPCZoneIdentifier:
        - !Ref FigmaDesignSystemSubnet1
        - !Ref FigmaDesignSystemSubnet2
      TargetGroupARNs:
        - !Ref FigmaDesignSystemTargetGroup
      HealthCheckType: ELB
      HealthCheckGracePeriod: 300
      Tags:
        - Key: Name
          Value: !Sub '${ProjectCode}-FIGMA-Design-System'
          PropagateAtLaunch: true
        - Key: FigmaComponent
          Value: 'Design-System'
          PropagateAtLaunch: true

Outputs:
  FigmaAssetManagementVPCId:
    Description: 'FIGMA Asset Management VPC ID'
    Value: !Ref FigmaAssetManagementVPC
    Export:
      Name: !Sub '${AWS::StackName}-FIGMA-VPC-ID'

  FigmaLoadBalancerDNS:
    Description: 'FIGMA Load Balancer DNS Name'
    Value: !GetAtt FigmaApplicationLoadBalancer.DNSName
    Export:
      Name: !Sub '${AWS::StackName}-FIGMA-LB-DNS'

  FigmaAssetBucketName:
    Description: 'FIGMA Asset S3 Bucket'
    Value: !Ref FigmaAssetBucket
    Export:
      Name: !Sub '${AWS::StackName}-FIGMA-Asset-Bucket'

  FigmaDesignSystemTable:
    Description: 'FIGMA Design System DynamoDB Table'
    Value: !Ref FigmaDesignSystemTable
    Export:
      Name: !Sub '${AWS::StackName}-FIGMA-Design-System-Table'

  FigmaAssetMetadataTable:
    Description: 'FIGMA Asset Metadata DynamoDB Table'
    Value: !Ref FigmaAssetMetadataTable
    Export:
      Name: !Sub '${AWS::StackName}-FIGMA-Asset-Metadata-Table'

  FigmaVersion:
    Description: 'FIGMA System Version'
    Value: !Ref FigmaVersion
    Export:
      Name: !Sub '${AWS::StackName}-FIGMA-Version'
EOF
Step 3: Create FIGMA Asset Management Web Interface
<!-- Create FIGMA Asset Management Web Interface -->
cat > web-interface/figma-asset-management.html << 'EOF'
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>FINA_3XPRES5 FIGMA Asset Management System</title>
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            font-family: 'Inter', -apple-system, BlinkMacSystemFont, sans-serif;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            min-height: 100vh;
            color: #2D3436;
        }

        .container {
            max-width: 1400px;
            margin: 0 auto;
            padding: 20px;
        }

        .header {
            background: rgba(255, 255, 255, 0.95);
            backdrop-filter: blur(10px);
            border-radius: 16px;
            padding: 24px;
            margin-bottom: 24px;
            box-shadow: 0 20px 25px -5px rgba(0, 0, 0, 0.1);
        }

        .header h1 {
            font-size: 2.5rem;
            font-weight: 700;
            background: linear-gradient(135deg, #6C5CE7, #A29BFE);
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
            margin-bottom: 8px;
        }

        .header p {
            color: #636E72;
            font-size: 1.1rem;
        }

        .dashboard-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(400px, 1fr));
            gap: 24px;
            margin-bottom: 24px;
        }

        .card {
            background: rgba(255, 255, 255, 0.95);
            backdrop-filter: blur(10px);
            border-radius: 16px;
            padding: 24px;
            box-shadow: 0 20px 25px -5px rgba(0, 0, 0, 0.1);
            transition: transform 0.3s ease, box-shadow 0.3s ease;
        }

        .card:hover {
            transform: translateY(-4px);
            box-shadow: 0 25px 35px -5px rgba(0, 0, 0, 0.15);
        }

        .card h3 {
            font-size: 1.5rem;
            font-weight: 600;
            margin-bottom: 16px;
            color: #2D3436;
        }

        .upload-area {
            border: 2px dashed #A29BFE;
            border-radius: 12px;
            padding: 40px;
            text-align: center;
            background: rgba(162, 155, 254, 0.05);
            transition: all 0.3s ease;
            cursor: pointer;
        }

        .upload-area:hover {
            border-color: #6C5CE7;
            background: rgba(108, 92, 231, 0.1);
        }

        .upload-area.dragover {
            border-color: #6C5CE7;
            background: rgba(108, 92, 231, 0.15);
            transform: scale(1.02);
        }

        .upload-icon {
            font-size: 3rem;
            color: #A29BFE;
            margin-bottom: 16px;
        }

        .btn {
            background: linear-gradient(135deg, #6C5CE7, #A29BFE);
            color: white;
            border: none;
            padding: 12px 24px;
            border-radius: 8px;
            font-size: 1rem;
            font-weight: 500;
            cursor: pointer;
            transition: all 0.3s ease;
            display: inline-flex;
            align-items: center;
            gap: 8px;
        }

        .btn:hover {
            transform: translateY(-2px);
            box-shadow: 0 10px 20px rgba(108, 92, 231, 0.3);
        }

        .btn-secondary {
            background: linear-gradient(135deg, #00B894, #55A3FF);
        }

        .btn-secondary:hover {
            box-shadow: 0 10px 20px rgba(0, 184, 148, 0.3);
        }

        .asset-grid {
            display: grid;
            grid-template-columns: repeat(auto-fill, minmax(200px, 1fr));
            gap: 16px;
            margin-top: 24px;
        }

        .asset-item {
            background: white;
            border-radius: 12px;
            padding: 16px;
            box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
            transition: all 0.3s ease;
            cursor: pointer;
        }

        .asset-item:hover {
            transform: translateY(-2px);
            box-shadow: 0 8px 15px rgba(0, 0, 0, 0.15);
        }

        .asset-preview {
            width: 100%;
            height: 120px;
            background: #F8F9FA;
            border-radius: 8px;
            margin-bottom: 12px;
            display: flex;
            align-items: center;
            justify-content: center;
            overflow: hidden;
        }

        .asset-preview img {
            max-width: 100%;
            max-height: 100%;
            object-fit: cover;
        }

        .asset-info h4 {
            font-size: 0.9rem;
            font-weight: 600;
            margin-bottom: 4px;
            color: #2D3436;
        }

        .asset-info p {
            font-size: 0.8rem;
            color: #636E72;
        }

        .design-tokens {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
            gap: 16px;
        }

        .token-group {
            background: white;
            border-radius: 12px;
            padding: 20px;
            box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
        }

        .token-group h4 {
            font-size: 1.1rem;
            font-weight: 600;
            margin-bottom: 16px;
            color: #2D3436;
        }

        .color-palette {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(80px, 1fr));
            gap: 12px;
        }

        .color-item {
            text-align: center;
        }

        .color-swatch {
            width: 60px;
            height: 60px;
            border-radius: 8px;
            margin: 0 auto 8px;
            box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
        }

        .color-name {
            font-size: 0.8rem;
            font-weight: 500;
            color: #2D3436;
        }

        .status-indicator {
            display: inline-flex;
            align-items: center;
            gap: 8px;
            padding: 6px 12px;
            border-radius: 20px;
            font-size: 0.85rem;
            font-weight: 500;
        }

        .status-active {
            background: rgba(0, 184, 148, 0.1);
            color: #00B894;
        }

        .status-processing {
            background: rgba(253, 203, 110, 0.1);
            color: #FDCB6E;
        }

        .progress-bar {
            width: 100%;
            height: 8px;
            background: #E9ECEF;
            border-radius: 4px;
            overflow: hidden;
            margin: 16px 0;
        }

        .progress-fill {
            height: 100%;
            background: linear-gradient(90deg, #6C5CE7, #A29BFE);
            transition: width 0.3s ease;
        }

        .stats-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(150px, 1fr));
            gap: 16px;
            margin-top: 16px;
        }

        .stat-item {
            text-align: center;
            padding: 16px;
            background: rgba(108, 92, 231, 0.05);
            border-radius: 12px;
        }

        .stat-number {
            font-size: 2rem;
            font-weight: 700;
            color: #6C5CE7;
            display: block;
        }

        .stat-label {
            font-size: 0.9rem;
            color: #636E72;
            margin-top: 4px;
        }

        .notification {
            position: fixed;
            top: 20px;
            right: 20px;
            background: white;
            border-radius: 12px;
            padding: 16px 20px;
            box-shadow: 0 10px 25px rgba(0, 0, 0, 0.15);
            transform: translateX(400px);
            transition: transform 0.3s ease;
            z-index: 1000;
        }

        .notification.show {
            transform: translateX(0);
        }

        .notification.success {
            border-left: 4px solid #00B894;
        }

        .notification.error {
            border-left: 4px solid #E17055;
        }

        @keyframes pulse {
            0%, 100% { opacity: 1; }
            50% { opacity: 0.7; }
        }

        .loading {
            animation: pulse 2s infinite;
        }

        .modal {
            display: none;
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background: rgba(0, 0, 0, 0.5);
            backdrop-filter: blur(5px);
            z-index: 1000;
        }

        .modal-content {
            position: absolute;
            top: 50%;
            left: 50%;
            transform: translate(-50%, -50%);
            background: white;
            border-radius: 16px;
            padding: 32px;
            max-width: 600px;
            width: 90%;
            max-height: 80vh;
            overflow-y: auto;
        }

        .close-modal {
            position: absolute;
            top: 16px;
            right: 16px;
            background: none;
            border: none;
            font-size: 1.5rem;
            cursor: pointer;
            color: #636E72;
        }

        .form-group {
            margin-bottom: 20px;
        }

        .form-group label {
            display: block;
            margin-bottom: 8px;
            font-weight: 500;
            color: #2D3436;
        }

        .form-group input,
        .form-group textarea,
        .form-group select {
            width: 100%;
            padding: 12px;
            border: 2px solid #E9ECEF;
            border-radius: 8px;
            font-size: 1rem;
            transition: border-color 0.3s ease;
        }

        .form-group input:focus,
        .form-group textarea:focus,
        .form-group select:focus {
            outline: none;
            border-color: #6C5CE7;
        }

        .tag-input {
            display: flex;
            flex-wrap: wrap;
            gap: 8px;
            padding: 8px;
            border: 2px solid #E9ECEF;
            border-radius: 8px;
            min-height: 44px;
        }

        .tag {
            background: #6C5CE7;
            color: white;
            padding: 4px 8px;
            border-radius: 4px;
            font-size: 0.85rem;
            display: flex;
            align-items: center;
            gap: 4px;
        }

        .tag-remove {
            background: none;
            border: none;
            color: white;
            cursor: pointer;
            font-size: 0.8rem;
        }

        @media (max-width: 768px) {
            .container {
                padding: 16px;
            }

            .dashboard-grid {
                grid-template-columns: 1fr;
            }

            .header h1 {
                font-size: 2rem;
            }

            .asset-grid {
                grid-template-columns: repeat(auto-fill, minmax(150px, 1fr));
            }
        }
    </style>
</head>
<body>
    <div class="container">
        <div class="header">
            <h1>FINA_3XPRES5 FIGMA Asset Management</h1>
            <p>Comprehensive design system and asset management platform</p>
            <div class="status-indicator status-active">
                <span>●</span> System Active - v1.0.0
            </div>
        </div>

        <div class="dashboard-grid">
            <!-- Asset Upload Card -->
            <div class="card">
                <h3>📁 Asset Upload</h3>
                <div class="upload-area" id="uploadArea">
                    <div class="upload-icon">📤</div>
                    <p><strong>Drop files here</strong> or click to browse</p>
                    <p style="margin-top: 8px; color: #636E72;">Supports images, videos, and design files</p>
                    <input type="file" id="fileInput" multiple accept="image/*,video/*,.fig,.sketch" style="display: none;">
                </div>
                <div class="progress-bar" id="uploadProgress" style="display: none;">
                    <div class="progress-fill" id="progressFill"></div>
                </div>
                <button class="btn" id="uploadBtn" style="margin-top: 16px;">
                    📤 Upload Assets
                </button>
            </div>

            <!-- Design System Card -->
            <div class="card">
                <h3>🎨 Design System</h3>
                <p style="margin-bottom: 16px;">Manage design tokens and components</p>
                <div class="stats-grid">
                    <div class="stat-item">
                        <span class="stat-number" id="componentCount">24</span>
                        <span class="stat-label">Components</span>
                    </div>
                    <div class="stat-item">
                        <span class="stat-number" id="tokenCount">156</span>
                        <span class="stat-label">Design Tokens</span>
                    </div>
                </div>
                <button class="btn btn-secondary" id="designSystemBtn" style="margin-top: 16px;">
                    🔧 Manage Design System
                </button>
            </div>

            <!-- Asset Library Card -->
            <div class="card">
                <h3>📚 Asset Library</h3>
                <p style="margin-bottom: 16px;">Browse and manage your assets</p>
                <div class="stats-grid">
                    <div class="stat-item">
                        <span class="stat-number" id="assetCount">0</span>
                        <span class="stat-label">Total Assets</span>
  },
  {
    id: 'SW-004',
    name: 'NULS Blockchain Integration',
    vendor: 'NULS Foundation',
    version: 'v2.8.0',
    license: 'Open Source',
    category: 'Blockchain',
    criticality: 'High',
    description: 'Blockchain integration layer for distributed ledger capabilities and smart contract functionality',
    icon: Code
  },
  {
    id: 'SW-005',
    name: 'Fraud Detection Engine',
    vendor: 'FICO',
    version: '10.2',
    license: 'Enterprise',
    category: 'Security',
    criticality: 'High',
    description: 'AI-powered fraud detection and prevention system with real-time transaction monitoring',
    icon: Shield
  },
  {
    id: 'SW-006',
    name: 'MongoDB Atlas Ledger',
    vendor: 'MongoDB Inc.',
    version: 'v7.0',
    license: 'Enterprise',
    category: 'Database',
    criticality: 'Critical',
    description: 'Immutable ledger database for audit trails, compliance logging, and transaction history',
    icon: Database
  }
];

const licenseColors: Record<string, { bg: string; text: string; border: string }> = {
  Enterprise: { bg: 'bg-purple-500/10', text: 'text-purple-400', border: 'border-purple-500/30' },
  Proprietary: { bg: 'bg-blue-500/10', text: 'text-blue-400', border: 'border-blue-500/30' },
  'Open Source': { bg: 'bg-green-500/10', text: 'text-green-400', border: 'border-green-500/30' }
};

export function SoftwareTab({ secureMode, onAuditLog }: SoftwareTabProps) {
  const [selectedSoftware, setSelectedSoftware] = useState<string | null>(null);

  const handleExport = () => {
    if (!secureMode) {
      alert('Export requires Secure Mode to be enabled');
      return;
    }

    const data = JSON.stringify(software, null, 2);
    const blob = new Blob([data], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `software-inventory-${new Date().toISOString()}.json`;
    a.click();
    URL.revokeObjectURL(url);

    onAuditLog(`Exported software inventory (${software.length} platforms)`);
  };

  const handleSettings = (sw: Software) => {
    setSelectedSoftware(sw.id);
    onAuditLog(`Accessed settings for ${sw.name}`);
    setTimeout(() => setSelectedSoftware(null), 2000);
  };

  return (
    <div>
      {/* Header */}
      <div className="flex items-center justify-between mb-6">
        <div>
          <h2 className="text-2xl font-bold text-white uppercase tracking-wide">Software Platforms & Applications</h2>
          <p className="text-cyan-400 font-mono text-sm mt-1">ID.AM-2 Compliance</p>
        </div>

        <button
          onClick={handleExport}
          className="flex items-center gap-2 px-4 py-2 bg-cyan-500/10 border border-cyan-500/30 rounded-lg text-cyan-400 hover:bg-cyan-500/20 transition-all duration-300"
        >
          <Download className="w-4 h-4" />
          <span className="text-sm font-semibold uppercase">Export</span>
        </button>
      </div>

      {/* Software Cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        {software.map((sw, index) => {
          const Icon = sw.icon;
          const licenseStyle = licenseColors[sw.license] || licenseColors['Enterprise'];
          const isSelected = selectedSoftware === sw.id;

          return (
            <div
              key={sw.id}
              className={`
                group relative p-6 rounded-lg border backdrop-blur-sm
                transition-all duration-300 hover:scale-[1.02] hover:shadow-xl
                ${isSelected
                  ? 'bg-cyan-500/20 border-cyan-500/50 shadow-lg shadow-cyan-500/20'
                  : 'bg-gray-500/5 border-gray-500/30 hover:bg-gray-500/10'
                }
              `}
              style={{
                animation: 'cardAppear 0.5s ease-out forwards',
                animationDelay: `${index * 80}ms`,
                opacity: 0
              }}
            >
              {/* Icon */}
              <div className="flex items-center justify-between mb-4">
                <div className="p-3 bg-cyan-500/10 border border-cyan-500/30 rounded-lg">
                  <Icon className="w-8 h-8 text-cyan-400" />
                </div>
                <button
                  onClick={() => handleSettings(sw)}
                  className="p-2 bg-gray-500/10 border border-gray-500/30 rounded-lg text-gray-400 hover:bg-gray-500/20 hover:text-cyan-400 transition-all duration-300"
                >
                  <Settings className="w-4 h-4" />
                </button>
              </div>

              {/* Title */}
              <h3 className="text-lg font-bold text-white mb-1">{sw.name}</h3>
              <p className="text-sm font-mono text-gray-400 mb-4">{sw.id}</p>

              {/* Details */}
              <div className="space-y-2 mb-4">
                <div className="flex items-center justify-between text-sm">
                  <span className="text-gray-500">Vendor:</span>
                  <span className="text-gray-300 font-semibold">{sw.vendor}</span>
                </div>
                <div className="flex items-center justify-between text-sm">
                  <span className="text-gray-500">Version:</span>
                  <span className="text-cyan-400 font-mono">{sw.version}</span>
                </div>
                <div className="flex items-center justify-between text-sm">
                  <span className="text-gray-500">Category:</span>
                  <span className="text-gray-300">{sw.category}</span>
                </div>
              </div>

              {/* License Badge */}
              <div className={`inline-flex items-center gap-2 px-3 py-1 rounded border ${licenseStyle.bg} ${licenseStyle.border} ${licenseStyle.text} text-xs font-bold uppercase mb-4`}>
                <Package className="w-3 h-3" />
                {sw.license}
              </div>

              {/* Description */}
              <p className="text-xs text-gray-400 leading-relaxed mt-3 pt-3 border-t border-gray-500/30">
                {sw.description}
              </p>

              {/* Criticality Indicator */}
              <div className="absolute top-4 right-4">
                <div className={`w-2 h-2 rounded-full ${sw.criticality === 'Critical' ? 'bg-red-500' : 'bg-amber-500'} animate-pulse`} />
              </div>

              {/* Hover Glow */}
              <div className="absolute inset-0 bg-gradient-to-br from-cyan-500/0 via-cyan-500/5 to-cyan-500/0 opacity-0 group-hover:opacity-100 transition-opacity duration-300 rounded-lg pointer-events-none" />
            </div>
          );
        })}
      </div>

      <style>{`
        @keyframes cardAppear {
          from {
            opacity: 0;
            transform: translateY(20px) scale(0.95);
          }
          to {
            opacity: 1;
            transform: translateY(0) scale(1);
          }
        }
      `}</style>
    </div>
  );
}
