import { useState, useEffect } from 'react';
import { Radio, Antenna, Network, Server, Database, Shield, Zap, Activity, MapPin, Signal, Lock, Key, ArrowRight, Layers, Gauge, Wifi, TrendingUp, Cpu, BarChart3, Navigation } from 'lucide-react';

interface Telecom5GTopologyTabProps {
  secureMode: boolean;
  onAuditLog: (action: string) => void;
}

interface RequesterNode {
  id: string;
  name: string;
  type: 'UE' | 'gNodeB' | 'AMF' | 'SMF' | 'UPF' | 'UDM' | 'PCF' | 'AUSF' | 'NRF' | 'MEC';
  status: 'active' | 'degraded' | 'offline';
  ip: string;
  latency: number;
  throughput: number;
  connections: number;
  location: string;
  band: string;
  encryption: 'AES-256' | 'AES-128' | 'None';
  qosProfile: 'Critical' | 'High' | 'Medium' | 'Low';
  tunnelId?: string;
  certSerial?: string;
  requesterType: 'Banking-Terminal' | 'ATM-Cluster' | 'Mobile-App' | 'Core-Service' | 'Edge-Gateway' | 'Control-Function' | 'Data-Function' | 'Auth-Service' | 'MEC-Node';
  beamId?: string;
  spectrumEfficiency?: number;
  handoverCount?: number;
}

interface NetworkSlice {
  id: string;
  name: string;
  type: 'eMBB' | 'URLLC' | 'mMTC';
  bandwidth: string;
  latency: string;
  reliability: string;
  status: 'active' | 'standby' | 'inactive';
  sla: string;
  encryptionStandard: string;
  ueCount: number;
  orchestrationPolicy: string;
}

interface SecureTunnel {
  id: string;
  source: string;
  destination: string;
  protocol: 'IPsec/IKEv2' | 'mTLS' | 'GTP-U/TLS';
  encryption: string;
  throughput: number;
  status: 'active' | 'establishing' | 'error';
}

interface HandoverEvent {
  id: string;
  ueId: string;
  sourceCell: string;
  targetCell: string;
  timestamp: string;
  reason: 'Coverage' | 'Load-Balance' | 'QoS-Optimization' | 'Beam-Failure';
  success: boolean;
  duration: number;
}

interface SBAInterface {
  id: string;
  name: string;
  producer: string;
  consumer: string;
  requestRate: number;
  avgLatency: number;
  status: 'healthy' | 'degraded' | 'error';
}

interface SpectrumMetrics {
  band: string;
  centerFreq: string;
  bandwidth: string;
  utilization: number;
  prb_usage: number;
  interference: number;
}

interface Fina3xpres5Node {
  id: string;
  name: string;
  status: 'active' | 'degraded' | 'offline';
  connectedTo5G: string;
  txnProcessed: number;
  txnQueue: number;
  nonceGenRate: number;
  upstreamLatency: number;
  topographicPosition: number;
  ledgerQueue: { incoming: number; outgoing: number; };
  cpuUtilization: number;
  memoryUsage: number;
}

interface FinancialTransaction {
  id: string;
  type: 'incoming' | 'outgoing';
  amount: number;
  currency: string;
  routedThrough: string[];
  currentNode: string;
  nonce: string;
  sessionId: string;
  priority: 'Critical' | 'High' | 'Medium';
  status: 'processing' | 'routed' | 'completed' | 'failed';
  latency: number;
  timestamp: string;
}

interface LedgerTransaction {
  id: string;
  type: 'incoming' | 'outgoing';
  amount: number;
  nonce: string;
  assignedNode: string;
  status: 'queued' | 'processing' | 'posted' | 'verified';
  timestamp: string;
  '5gLatency': number;
}

interface TimedNonce {
  nonce: string;
  timestamp: string;
  txnId: string;
  validity: number;
  status: 'valid' | 'expired' | 'used';
  generatedBy: string;
}

interface BankingStatement {
  id: string;
  accountNumber: string;
  accountHolder: string;
  bankingPartner: 'Sutton-Bank' | 'Capital-One';
  statementType: 'Immediate' | 'Daily' | 'Monthly' | 'On-Demand';
  periodStart: string;
  periodEnd: string;
  transactionCount: number;
  balance: { opening: number; closing: number; available: number; };
  status: 'generating' | 'ready' | 'delivered' | 'archived';
  requestedVia5G: boolean;
  councilCompliance: string[];
  methodology: 'GAAP' | 'IFRS' | 'Basel-III' | 'FDIC-Reg';
  deliveryNode: string;
}

interface BankingTransaction {
  id: string;
  timestamp: string;
  type: 'debit' | 'credit' | 'transfer' | 'fee' | 'interest';
  amount: number;
  description: string;
  merchant?: string;
  category: string;
  methodology: string;
  internalLogId: string;
  councilApproval: boolean;
}

interface InternalStatementLog {
  id: string;
  timestamp: string;
  logType: 'Transaction' | 'Statement-Request' | 'Compliance-Check' | 'Council-Derived';
  severity: 'INFO' | 'WARN' | 'ERROR' | 'CRITICAL';
  message: string;
  methodology: string;
  associatedAccount?: string;
  regulatoryBody?: string;
  '5gSessionId'?: string;
}

interface CouncilDerivedRequirement {
  id: string;
  councilName: string;
  requirementType: 'Financial-Reporting' | 'Transaction-Logging' | 'Statement-Delivery' | 'Compliance-Audit';
  mandate: string;
  effectiveDate: string;
  status: 'active' | 'pending' | 'superseded';
  methodology: string;
}

export function Telecom5GTopologyTab({ secureMode, onAuditLog }: Telecom5GTopologyTabProps) {
  const [selectedNode, setSelectedNode] = useState<string | null>(null);
  const [liveMetrics, setLiveMetrics] = useState<Record<string, number>>({});
  const [currentTime, setCurrentTime] = useState(new Date());

  const [requesters, setRequesters] = useState<RequesterNode[]>([
    { id: 'ue-001', name: 'UE-Banking-Terminal-01', type: 'UE', status: 'active', ip: '10.5G.1.101', latency: 12, throughput: 850, connections: 1, location: 'Branch-HQ-Floor3', band: 'n77 (3.5GHz)', encryption: 'AES-256', qosProfile: 'Critical', tunnelId: 'tnl-ipsec-001', certSerial: '4A:3F:9C:2E:1D:7B', requesterType: 'Banking-Terminal', beamId: 'beam-77-001', spectrumEfficiency: 4.2, handoverCount: 3 },
    { id: 'ue-002', name: 'UE-ATM-Cluster-02', type: 'UE', status: 'active', ip: '10.5G.1.102', latency: 8, throughput: 920, connections: 24, location: 'ATM-Network-West', band: 'n78 (3.7GHz)', encryption: 'AES-256', qosProfile: 'Critical', tunnelId: 'tnl-ipsec-002', certSerial: '8D:2A:5F:6C:9E:4B', requesterType: 'ATM-Cluster', beamId: 'beam-78-002', spectrumEfficiency: 4.5, handoverCount: 1 },
    { id: 'ue-003', name: 'UE-Mobile-Banking-03', type: 'UE', status: 'degraded', ip: '10.5G.1.103', latency: 45, throughput: 340, connections: 156, location: 'Mobile-Edge-Cloud', band: 'n77 (3.5GHz)', encryption: 'AES-256', qosProfile: 'High', tunnelId: 'tnl-mtls-003', certSerial: '1C:7E:4D:8A:3F:2B', requesterType: 'Mobile-App', beamId: 'beam-77-003', spectrumEfficiency: 2.8, handoverCount: 12 },
    { id: 'ue-004', name: 'UE-POS-Terminal-04', type: 'UE', status: 'active', ip: '10.5G.1.104', latency: 10, throughput: 780, connections: 48, location: 'Retail-Branch-East', band: 'n77 (3.5GHz)', encryption: 'AES-256', qosProfile: 'High', tunnelId: 'tnl-ipsec-004', certSerial: '6F:1A:9D:4E:8C:7B', requesterType: 'Banking-Terminal', beamId: 'beam-77-004', spectrumEfficiency: 4.1, handoverCount: 2 },
    { id: 'ue-005', name: 'UE-Treasury-Workstation-05', type: 'UE', status: 'active', ip: '10.5G.1.105', latency: 6, throughput: 1050, connections: 3, location: 'Treasury-Ops-Center', band: 'n78 (3.7GHz)', encryption: 'AES-256', qosProfile: 'Critical', tunnelId: 'tnl-ipsec-005', certSerial: 'A2:8B:3C:5D:9F:1E', requesterType: 'Banking-Terminal', beamId: 'beam-78-005', spectrumEfficiency: 4.8, handoverCount: 0 },

    { id: 'gnb-001', name: 'gNodeB-Core-01', type: 'gNodeB', status: 'active', ip: '10.5G.2.10', latency: 3, throughput: 5200, connections: 48, location: 'Data-Center-Primary', band: 'n77/n78 (FR1)', encryption: 'AES-256', qosProfile: 'Critical', tunnelId: 'tnl-gtp-101', certSerial: 'D5:9A:2F:7C:4E:6B', requesterType: 'Core-Service', beamId: 'beam-massive-mimo-01', spectrumEfficiency: 5.2, handoverCount: 0 },
    { id: 'gnb-002', name: 'gNodeB-Edge-02', type: 'gNodeB', status: 'active', ip: '10.5G.2.11', latency: 4, throughput: 4800, connections: 52, location: 'Edge-Compute-Zone-A', band: 'n77/n78 (FR1)', encryption: 'AES-256', qosProfile: 'Critical', tunnelId: 'tnl-gtp-102', certSerial: '3B:6D:8A:1F:9C:4E', requesterType: 'Edge-Gateway', beamId: 'beam-massive-mimo-02', spectrumEfficiency: 5.0, handoverCount: 0 },
    { id: 'gnb-003', name: 'gNodeB-Branch-03', type: 'gNodeB', status: 'active', ip: '10.5G.2.12', latency: 5, throughput: 3900, connections: 38, location: 'Branch-Network-Hub', band: 'n77/n78 (FR1)', encryption: 'AES-256', qosProfile: 'High', tunnelId: 'tnl-gtp-103', certSerial: '7E:4A:2D:9F:5C:8B', requesterType: 'Edge-Gateway', beamId: 'beam-massive-mimo-03', spectrumEfficiency: 4.7, handoverCount: 0 },

    { id: 'mec-001', name: 'MEC-Banking-Apps-01', type: 'MEC', status: 'active', ip: '10.5G.5.50', latency: 2, throughput: 3200, connections: 89, location: 'Edge-DC-Zone-A', band: 'N/A', encryption: 'AES-256', qosProfile: 'Critical', tunnelId: 'tnl-mec-401', certSerial: 'E9:2B:7F:4A:8D:3C', requesterType: 'MEC-Node', spectrumEfficiency: 0, handoverCount: 0 },
    { id: 'mec-002', name: 'MEC-Risk-Analytics-02', type: 'MEC', status: 'active', ip: '10.5G.5.51', latency: 3, throughput: 2800, connections: 67, location: 'Edge-DC-Zone-B', band: 'N/A', encryption: 'AES-256', qosProfile: 'High', tunnelId: 'tnl-mec-402', certSerial: '7D:5A:9C:2E:6F:8B', requesterType: 'MEC-Node', spectrumEfficiency: 0, handoverCount: 0 },

    { id: 'amf-001', name: 'AMF-Control-Plane', type: 'AMF', status: 'active', ip: '10.5G.3.20', latency: 2, throughput: 0, connections: 245, location: 'Core-Network-DC1', band: 'N/A', encryption: 'AES-256', qosProfile: 'Critical', tunnelId: 'tnl-sbi-201', certSerial: 'B8:3C:7E:9A:2D:5F', requesterType: 'Control-Function', spectrumEfficiency: 0, handoverCount: 0 },
    { id: 'smf-001', name: 'SMF-Session-Manager', type: 'SMF', status: 'active', ip: '10.5G.3.21', latency: 2, throughput: 0, connections: 189, location: 'Core-Network-DC1', band: 'N/A', encryption: 'AES-256', qosProfile: 'Critical', tunnelId: 'tnl-sbi-202', certSerial: '5D:9F:2A:7B:4E:8C', requesterType: 'Control-Function', spectrumEfficiency: 0, handoverCount: 0 },
    { id: 'upf-001', name: 'UPF-User-Plane-01', type: 'UPF', status: 'active', ip: '10.5G.3.30', latency: 1, throughput: 12400, connections: 245, location: 'Data-Plane-DC1', band: 'N/A', encryption: 'AES-256', qosProfile: 'Critical', tunnelId: 'tnl-gtp-301', certSerial: '9C:4E:6B:3A:7F:2D', requesterType: 'Data-Function', spectrumEfficiency: 0, handoverCount: 0 },
    { id: 'upf-002', name: 'UPF-User-Plane-02', type: 'UPF', status: 'active', ip: '10.5G.3.31', latency: 1, throughput: 11800, connections: 198, location: 'Data-Plane-DC2', band: 'N/A', encryption: 'AES-256', qosProfile: 'Critical', tunnelId: 'tnl-gtp-302', certSerial: '2F:7C:9A:5D:8E:4B', requesterType: 'Data-Function', spectrumEfficiency: 0, handoverCount: 0 },

    { id: 'udm-001', name: 'UDM-Unified-Data', type: 'UDM', status: 'active', ip: '10.5G.4.40', latency: 5, throughput: 0, connections: 98, location: 'Core-Network-DC1', band: 'N/A', encryption: 'AES-256', qosProfile: 'High', certSerial: '6A:8D:3F:9C:5E:7B', requesterType: 'Auth-Service', spectrumEfficiency: 0, handoverCount: 0 },
    { id: 'pcf-001', name: 'PCF-Policy-Control', type: 'PCF', status: 'active', ip: '10.5G.4.41', latency: 3, throughput: 0, connections: 156, location: 'Core-Network-DC1', band: 'N/A', encryption: 'AES-256', qosProfile: 'High', certSerial: '4E:9B:7A:2D:6F:8C', requesterType: 'Control-Function', spectrumEfficiency: 0, handoverCount: 0 },
    { id: 'ausf-001', name: 'AUSF-Authentication', type: 'AUSF', status: 'active', ip: '10.5G.4.42', latency: 4, throughput: 0, connections: 67, location: 'Core-Network-DC1', band: 'N/A', encryption: 'AES-256', qosProfile: 'Critical', certSerial: '8C:5D:9F:3A:7E:4B', requesterType: 'Auth-Service', spectrumEfficiency: 0, handoverCount: 0 },
    { id: 'nrf-001', name: 'NRF-Repository', type: 'NRF', status: 'active', ip: '10.5G.4.43', latency: 2, throughput: 0, connections: 12, location: 'Core-Network-DC1', band: 'N/A', encryption: 'AES-256', qosProfile: 'Medium', certSerial: '3D:8A:6F:9C:2E:5B', requesterType: 'Control-Function', spectrumEfficiency: 0, handoverCount: 0 },
  ]);

  const [slices] = useState<NetworkSlice[]>([
    { id: 'slice-embb', name: 'Enhanced Mobile Broadband', type: 'eMBB', bandwidth: '100 Gbps', latency: '< 20ms', reliability: '99.9%', status: 'active', sla: 'Banking-General', encryptionStandard: 'AES-256-GCM', ueCount: 189, orchestrationPolicy: 'Dynamic-QoS' },
    { id: 'slice-urllc', name: 'Ultra-Reliable Low-Latency', type: 'URLLC', bandwidth: '10 Gbps', latency: '< 1ms', reliability: '99.9999%', status: 'active', sla: 'Financial-Critical', encryptionStandard: 'AES-256-GCM + mTLS', ueCount: 76, orchestrationPolicy: 'Priority-Based' },
    { id: 'slice-mmtc', name: 'Massive Machine-Type Comm', type: 'mMTC', bandwidth: '50 Gbps', latency: '< 100ms', reliability: '99.5%', status: 'standby', sla: 'IoT-Monitoring', encryptionStandard: 'AES-128-CBC', ueCount: 0, orchestrationPolicy: 'Best-Effort' },
  ]);

  const [handoverEvents, setHandoverEvents] = useState<HandoverEvent[]>([
    { id: 'ho-001', ueId: 'ue-003', sourceCell: 'gnb-001', targetCell: 'gnb-002', timestamp: new Date(Date.now() - 45000).toISOString(), reason: 'Coverage', success: true, duration: 23 },
    { id: 'ho-002', ueId: 'ue-001', sourceCell: 'gnb-002', targetCell: 'gnb-001', timestamp: new Date(Date.now() - 120000).toISOString(), reason: 'Load-Balance', success: true, duration: 18 },
    { id: 'ho-003', ueId: 'ue-003', sourceCell: 'gnb-002', targetCell: 'gnb-003', timestamp: new Date(Date.now() - 180000).toISOString(), reason: 'QoS-Optimization', success: true, duration: 31 },
    { id: 'ho-004', ueId: 'ue-004', sourceCell: 'gnb-001', targetCell: 'gnb-003', timestamp: new Date(Date.now() - 240000).toISOString(), reason: 'Coverage', success: true, duration: 27 },
  ]);

  const [sbaInterfaces] = useState<SBAInterface[]>([
    { id: 'sbi-001', name: 'Namf_Communication', producer: 'amf-001', consumer: 'smf-001', requestRate: 1250, avgLatency: 2.3, status: 'healthy' },
    { id: 'sbi-002', name: 'Nsmf_PDUSession', producer: 'smf-001', consumer: 'upf-001', requestRate: 890, avgLatency: 1.8, status: 'healthy' },
    { id: 'sbi-003', name: 'Nudm_UECM', producer: 'udm-001', consumer: 'amf-001', requestRate: 560, avgLatency: 4.2, status: 'healthy' },
    { id: 'sbi-004', name: 'Nausf_UEAuth', producer: 'ausf-001', consumer: 'amf-001', requestRate: 340, avgLatency: 3.5, status: 'healthy' },
    { id: 'sbi-005', name: 'Npcf_SMPolicyControl', producer: 'pcf-001', consumer: 'smf-001', requestRate: 720, avgLatency: 2.9, status: 'healthy' },
    { id: 'sbi-006', name: 'Nnrf_NFManagement', producer: 'nrf-001', consumer: 'amf-001', requestRate: 150, avgLatency: 1.2, status: 'healthy' },
  ]);

  const [spectrumMetrics] = useState<SpectrumMetrics[]>([
    { band: 'n77', centerFreq: '3.5 GHz', bandwidth: '100 MHz', utilization: 68, prb_usage: 72, interference: 12 },
    { band: 'n78', centerFreq: '3.7 GHz', bandwidth: '100 MHz', utilization: 74, prb_usage: 78, interference: 8 },
    { band: 'n79', centerFreq: '4.7 GHz', bandwidth: '200 MHz', utilization: 45, prb_usage: 48, interference: 15 },
  ]);

  const [secureTunnels] = useState<SecureTunnel[]>([
    { id: 'tnl-ipsec-001', source: 'ue-001', destination: 'upf-001', protocol: 'IPsec/IKEv2', encryption: 'AES-256-GCM', throughput: 850, status: 'active' },
    { id: 'tnl-ipsec-002', source: 'ue-002', destination: 'upf-001', protocol: 'IPsec/IKEv2', encryption: 'AES-256-GCM', throughput: 920, status: 'active' },
    { id: 'tnl-mtls-003', source: 'ue-003', destination: 'upf-002', protocol: 'mTLS', encryption: 'TLS 1.3 + AES-256', throughput: 340, status: 'active' },
    { id: 'tnl-ipsec-004', source: 'ue-004', destination: 'upf-001', protocol: 'IPsec/IKEv2', encryption: 'AES-256-GCM', throughput: 780, status: 'active' },
    { id: 'tnl-ipsec-005', source: 'ue-005', destination: 'upf-002', protocol: 'IPsec/IKEv2', encryption: 'AES-256-GCM', throughput: 1050, status: 'active' },
    { id: 'tnl-gtp-101', source: 'gnb-001', destination: 'upf-001', protocol: 'GTP-U/TLS', encryption: 'TLS 1.3', throughput: 5200, status: 'active' },
    { id: 'tnl-gtp-102', source: 'gnb-002', destination: 'upf-001', protocol: 'GTP-U/TLS', encryption: 'TLS 1.3', throughput: 4800, status: 'active' },
    { id: 'tnl-gtp-103', source: 'gnb-003', destination: 'upf-002', protocol: 'GTP-U/TLS', encryption: 'TLS 1.3', throughput: 3900, status: 'active' },
  ]);

  const [bankingStatements, setBankingStatements] = useState<BankingStatement[]>([
    { id: 'stmt-001', accountNumber: '****5470067', accountHolder: 'VOM Treasury Operations', bankingPartner: 'Sutton-Bank', statementType: 'Immediate', periodStart: new Date(Date.now() - 86400000).toISOString(), periodEnd: new Date().toISOString(), transactionCount: 47, balance: { opening: 2500000, closing: 2547300, available: 2540000 }, status: 'ready', requestedVia5G: true, councilCompliance: ['FDIC', 'OCC', 'CFPB', 'Basel-III'], methodology: 'GAAP', deliveryNode: 'ue-005' },
    { id: 'stmt-002', accountNumber: '****8934521', accountHolder: 'Capital One Business Account', bankingPartner: 'Capital-One', statementType: 'On-Demand', periodStart: new Date(Date.now() - 172800000).toISOString(), periodEnd: new Date().toISOString(), transactionCount: 89, balance: { opening: 1750000, closing: 1823450, available: 1820000 }, status: 'generating', requestedVia5G: true, councilCompliance: ['FDIC', 'Federal-Reserve', 'NCUA'], methodology: 'FDIC-Reg', deliveryNode: 'ue-001' },
    { id: 'stmt-003', accountNumber: '****2947183', accountHolder: 'Sutton Bank Corporate Treasury', bankingPartner: 'Sutton-Bank', statementType: 'Daily', periodStart: new Date(Date.now() - 86400000).toISOString(), periodEnd: new Date().toISOString(), transactionCount: 134, balance: { opening: 4200000, closing: 4389120, available: 4385000 }, status: 'delivered', requestedVia5G: false, councilCompliance: ['FDIC', 'OCC', 'FinCEN'], methodology: 'Basel-III', deliveryNode: 'ue-002' },
  ]);

  const [internalLogs, setInternalLogs] = useState<InternalStatementLog[]>([
    { id: 'log-001', timestamp: new Date(Date.now() - 5000).toISOString(), logType: 'Statement-Request', severity: 'INFO', message: 'Immediate statement requested for account ****5470067 via 5G session', methodology: 'GAAP', associatedAccount: '****5470067', regulatoryBody: 'FDIC', '5gSessionId': '5G-SES-78934' },
    { id: 'log-002', timestamp: new Date(Date.now() - 8000).toISOString(), logType: 'Transaction', severity: 'INFO', message: 'Wire transfer processed: $25,000 outgoing', methodology: 'IFRS', associatedAccount: '****8934521', '5gSessionId': '5G-SES-78935' },
    { id: 'log-003', timestamp: new Date(Date.now() - 12000).toISOString(), logType: 'Compliance-Check', severity: 'WARN', message: 'Large transaction requires council approval: $42,300', methodology: 'Basel-III', associatedAccount: '****2947183', regulatoryBody: 'OCC' },
    { id: 'log-004', timestamp: new Date(Date.now() - 15000).toISOString(), logType: 'Council-Derived', severity: 'INFO', message: 'CFPB mandate applied: Enhanced disclosure for consumer accounts', methodology: 'FDIC-Reg', regulatoryBody: 'CFPB' },
  ]);

  const [councilRequirements] = useState<CouncilDerivedRequirement[]>([
    { id: 'req-001', councilName: 'FDIC Council', requirementType: 'Statement-Delivery', mandate: 'Real-time statement delivery for accounts exceeding $1M must use encrypted 5G channels', effectiveDate: '2025-01-15', status: 'active', methodology: 'FDIC-Reg' },
    { id: 'req-002', councilName: 'OCC Banking Supervision', requirementType: 'Transaction-Logging', mandate: 'All wire transfers must log internal audit trail with methodology classification', effectiveDate: '2024-11-01', status: 'active', methodology: 'Basel-III' },
    { id: 'req-003', councilName: 'CFPB Consumer Protection', requirementType: 'Financial-Reporting', mandate: 'Immediate statement requests require consumer consent verification', effectiveDate: '2025-03-01', status: 'pending', methodology: 'GAAP' },
    { id: 'req-004', councilName: 'Federal Reserve Board', requirementType: 'Compliance-Audit', mandate: 'Capital One partnership accounts must maintain separate methodology tracking', effectiveDate: '2024-09-15', status: 'active', methodology: 'IFRS' },
    { id: 'req-005', councilName: 'FinCEN Anti-Money Laundering', requirementType: 'Transaction-Logging', mandate: 'Transactions exceeding $10K require enhanced logging with council approval flag', effectiveDate: '2024-06-01', status: 'active', methodology: 'FDIC-Reg' },
  ]);

  useEffect(() => {
    const timer = setInterval(() => {
      setCurrentTime(new Date());

      // Simulate live metric updates
      setRequesters(prev => prev.map(req => ({
        ...req,
        latency: req.latency + (Math.random() - 0.5) * 2,
        throughput: Math.max(0, req.throughput + (Math.random() - 0.5) * 50),
        connections: Math.max(0, req.connections + Math.floor((Math.random() - 0.5) * 3))
      })));

      setLiveMetrics({
        totalThroughput: Math.random() * 50000 + 30000,
        avgLatency: Math.random() * 5 + 10,
        activeConnections: Math.floor(Math.random() * 100 + 800),
        packetLoss: Math.random() * 0.5,
      });

      // Simulate occasional handover events (10% chance every 2 seconds)
      if (Math.random() < 0.1) {
        const ueIds = ['ue-001', 'ue-002', 'ue-003', 'ue-004', 'ue-005'];
        const cells = ['gnb-001', 'gnb-002', 'gnb-003'];
        const reasons: Array<'Coverage' | 'Load-Balance' | 'QoS-Optimization' | 'Beam-Failure'> = ['Coverage', 'Load-Balance', 'QoS-Optimization', 'Beam-Failure'];

        const randomUe = ueIds[Math.floor(Math.random() * ueIds.length)];
        const randomSource = cells[Math.floor(Math.random() * cells.length)];
        let randomTarget = cells[Math.floor(Math.random() * cells.length)];
        while (randomTarget === randomSource) {
          randomTarget = cells[Math.floor(Math.random() * cells.length)];
        }

        const newHandover: HandoverEvent = {
          id: `ho-${Date.now()}`,
          ueId: randomUe,
          sourceCell: randomSource,
          targetCell: randomTarget,
          timestamp: new Date().toISOString(),
          reason: reasons[Math.floor(Math.random() * reasons.length)],
          success: Math.random() > 0.05, // 95% success rate
          duration: Math.floor(Math.random() * 30) + 15
        };

        setHandoverEvents(prev => [newHandover, ...prev].slice(0, 20));
      }

      // Generate new internal statement logs (18% chance)
      if (Math.random() < 0.18) {
        const logTypes: Array<'Transaction' | 'Statement-Request' | 'Compliance-Check' | 'Council-Derived'> = ['Transaction', 'Statement-Request', 'Compliance-Check', 'Council-Derived'];
        const severities: Array<'INFO' | 'WARN' | 'ERROR' | 'CRITICAL'> = ['INFO', 'WARN', 'ERROR', 'CRITICAL'];
        const methodologies = ['GAAP', 'IFRS', 'Basel-III', 'FDIC-Reg'];
        const accounts = ['****5470067', '****8934521', '****2947183'];
        const regulators = ['FDIC', 'OCC', 'CFPB', 'Federal-Reserve', 'FinCEN'];

        const selectedLogType = logTypes[Math.floor(Math.random() * logTypes.length)];
        const logMessages = {
          'Transaction': `Wire transfer processed: $${(Math.random() * 50000 + 5000).toFixed(0)} ${Math.random() > 0.5 ? 'incoming' : 'outgoing'}`,
          'Statement-Request': `${Math.random() > 0.5 ? 'Immediate' : 'On-Demand'} statement requested via ${Math.random() > 0.5 ? '5G session' : 'standard channel'}`,
          'Compliance-Check': `${Math.random() > 0.5 ? 'Large transaction' : 'High-risk account'} requires ${Math.random() > 0.5 ? 'council approval' : 'enhanced monitoring'}`,
          'Council-Derived': `${regulators[Math.floor(Math.random() * regulators.length)]} mandate applied: ${Math.random() > 0.5 ? 'Enhanced disclosure' : 'Compliance verification'}`
        };

        const newLog: InternalStatementLog = {
          id: `log-${Date.now()}`,
          timestamp: new Date().toISOString(),
          logType: selectedLogType,
          severity: severities[Math.floor(Math.random() * severities.length)],
          message: logMessages[selectedLogType],
          methodology: methodologies[Math.floor(Math.random() * methodologies.length)],
          associatedAccount: Math.random() > 0.3 ? accounts[Math.floor(Math.random() * accounts.length)] : undefined,
          regulatoryBody: Math.random() > 0.4 ? regulators[Math.floor(Math.random() * regulators.length)] : undefined,
          '5gSessionId': Math.random() > 0.5 ? `5G-SES-${Math.floor(Math.random() * 90000) + 10000}` : undefined
        };

        setInternalLogs(prev => [newLog, ...prev].slice(0, 25));
      }

      // Generate immediate statement requests (10% chance)
      if (Math.random() < 0.1) {
        const partners: Array<'Sutton-Bank' | 'Capital-One'> = ['Sutton-Bank', 'Capital-One'];
        const types: Array<'Immediate' | 'Daily' | 'Monthly' | 'On-Demand'> = ['Immediate', 'Daily', 'Monthly', 'On-Demand'];
        const methodologies: Array<'GAAP' | 'IFRS' | 'Basel-III' | 'FDIC-Reg'> = ['GAAP', 'IFRS', 'Basel-III', 'FDIC-Reg'];
        const ueNodes = ['ue-001', 'ue-002', 'ue-004', 'ue-005'];

        const accountNum = `****${Math.floor(Math.random() * 9000000) + 1000000}`;
        const opening = Math.floor(Math.random() * 5000000) + 500000;
        const change = Math.floor(Math.random() * 500000) - 250000;
        const closing = opening + change;

        const newStatement: BankingStatement = {
          id: `stmt-${Date.now()}`,
          accountNumber: accountNum,
          accountHolder: Math.random() > 0.5 ? 'Capital One Business Account' : 'Sutton Bank Corporate Treasury',
          bankingPartner: partners[Math.floor(Math.random() * partners.length)],
          statementType: types[Math.floor(Math.random() * types.length)],
          periodStart: new Date(Date.now() - (Math.random() * 172800000)).toISOString(),
          periodEnd: new Date().toISOString(),
          transactionCount: Math.floor(Math.random() * 150) + 20,
          balance: { opening, closing, available: closing - Math.floor(Math.random() * 10000) },
          status: Math.random() > 0.7 ? 'generating' : 'ready',
          requestedVia5G: Math.random() > 0.3,
          councilCompliance: ['FDIC', 'OCC'].concat(Math.random() > 0.5 ? ['CFPB'] : []).concat(Math.random() > 0.6 ? ['Basel-III'] : []),
          methodology: methodologies[Math.floor(Math.random() * methodologies.length)],
          deliveryNode: ueNodes[Math.floor(Math.random() * ueNodes.length)]
        };

        setBankingStatements(prev => [newStatement, ...prev].slice(0, 15));
      }
    }, 2000);

    return () => clearInterval(timer);
  }, []);

  const handleNodeSelect = (nodeId: string) => {
    setSelectedNode(nodeId);
    onAuditLog(`5G Topology: Selected node ${nodeId}`);
  };

  const getNodeIcon = (type: RequesterNode['type']) => {
    switch (type) {
      case 'UE': return Radio;
      case 'gNodeB': return Antenna;
      case 'AMF': case 'SMF': return Server;
      case 'UPF': return Zap;
      case 'UDM': return Database;
      case 'PCF': return Shield;
      case 'AUSF': return Shield;
      case 'NRF': return Network;
      case 'MEC': return Cpu;
      default: return Activity;
    }
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'active': return 'text-green-400 bg-green-400/10 border-green-400/30';
      case 'degraded': return 'text-yellow-400 bg-yellow-400/10 border-yellow-400/30';
      case 'offline': return 'text-red-400 bg-red-400/10 border-red-400/30';
      case 'standby': return 'text-blue-400 bg-blue-400/10 border-blue-400/30';
      case 'healthy': return 'text-green-400 bg-green-400/10 border-green-400/30';
      case 'error': return 'text-red-400 bg-red-400/10 border-red-400/30';
      default: return 'text-gray-400 bg-gray-400/10 border-gray-400/30';
    }
  };

  const selectedNodeData = requesters.find(r => r.id === selectedNode);

  // Group nodes by type for topology visualization
  const ueNodes = requesters.filter(r => r.type === 'UE');
  const ranNodes = requesters.filter(r => r.type === 'gNodeB');
  const mecNodes = requesters.filter(r => r.type === 'MEC');
  const controlPlaneNodes = requesters.filter(r => ['AMF', 'SMF'].includes(r.type));
  const userPlaneNodes = requesters.filter(r => r.type === 'UPF');
  const supportNodes = requesters.filter(r => ['UDM', 'PCF', 'AUSF', 'NRF'].includes(r.type));

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold bg-gradient-to-r from-cyan-400 to-blue-400 bg-clip-text text-transparent">
            5G Telecom Requester Topology
          </h1>
          <p className="text-gray-400 mt-1">Real-time 5G SA (Standalone) network architecture with requester mapping</p>
        </div>
        <div className="flex items-center gap-4">
          <div className="text-right">
            <div className="text-sm text-gray-400">System Time</div>
            <div className="text-cyan-400 font-mono">{currentTime.toLocaleTimeString()}</div>
          </div>
        </div>
      </div>

      {/* Network Metrics Overview */}
      <div className="grid grid-cols-4 gap-4">
        <div className="bg-gradient-to-br from-[#0f172a] to-[#1e293b] border border-cyan-500/20 rounded-lg p-4">
          <div className="flex items-center gap-3 mb-2">
            <Activity className="w-5 h-5 text-cyan-400" />
            <span className="text-gray-400 text-sm">Total Throughput</span>
          </div>
          <div className="text-2xl font-bold text-cyan-400">{(liveMetrics.totalThroughput || 40000).toFixed(0)} Mbps</div>
        </div>

        <div className="bg-gradient-to-br from-[#0f172a] to-[#1e293b] border border-cyan-500/20 rounded-lg p-4">
          <div className="flex items-center gap-3 mb-2">
            <Zap className="w-5 h-5 text-green-400" />
            <span className="text-gray-400 text-sm">Avg Latency</span>
          </div>
          <div className="text-2xl font-bold text-green-400">{(liveMetrics.avgLatency || 12).toFixed(1)} ms</div>
        </div>

        <div className="bg-gradient-to-br from-[#0f172a] to-[#1e293b] border border-cyan-500/20 rounded-lg p-4">
          <div className="flex items-center gap-3 mb-2">
            <Network className="w-5 h-5 text-blue-400" />
            <span className="text-gray-400 text-sm">Active Connections</span>
          </div>
          <div className="text-2xl font-bold text-blue-400">{Math.floor(liveMetrics.activeConnections || 850)}</div>
        </div>

        <div className="bg-gradient-to-br from-[#0f172a] to-[#1e293b] border border-cyan-500/20 rounded-lg p-4">
          <div className="flex items-center gap-3 mb-2">
            <Signal className="w-5 h-5 text-purple-400" />
            <span className="text-gray-400 text-sm">Packet Loss</span>
          </div>
          <div className="text-2xl font-bold text-purple-400">{(liveMetrics.packetLoss || 0.2).toFixed(3)}%</div>
        </div>
      </div>

      {/* Sutton Bank / Capital One Statement Processing with Methodologies */}
      <div className="bg-gradient-to-br from-green-900/10 via-[#0f172a] to-[#1e293b] border border-green-500/30 rounded-lg p-6">
        <div className="flex items-center justify-between mb-6">
          <div>
            <h2 className="text-2xl font-bold bg-gradient-to-r from-green-400 via-blue-400 to-cyan-400 bg-clip-text text-transparent flex items-center gap-2">
              <FileKey className="w-6 h-6 text-green-400" />
              Banking Statement Processing & Internal Methodologies
            </h2>
            <p className="text-gray-400 text-sm mt-1">Sutton Bank & Capital One • Immediate statement requests • Council-derived compliance • 5G delivery</p>
          </div>
          <div className="text-right">
            <div className="text-sm text-gray-400">Live Processing</div>
            <div className="text-green-400 font-mono flex items-center gap-2">
              <Activity className="w-4 h-4 animate-pulse" />
              Active
            </div>
          </div>
        </div>

        <div className="grid grid-cols-3 gap-6 mb-6">
          {/* Immediate Statement Requests */}
          <div className="bg-black/30 border border-green-500/20 rounded-lg p-4">
            <h3 className="text-lg font-bold text-green-400 mb-3 flex items-center gap-2">
              <Zap className="w-5 h-5" />
              Immediate Statements
            </h3>
            <div className="space-y-2 max-h-80 overflow-y-auto">
              {bankingStatements.filter(s => s.statementType === 'Immediate' || s.statementType === 'On-Demand').map(stmt => (
                <div key={stmt.id} className="bg-black/40 border border-green-500/10 rounded p-3">
                  <div className="flex items-center justify-between mb-2">
                    <span className="text-xs font-mono text-green-400">{stmt.id}</span>
                    <span className={`px-1.5 py-0.5 rounded text-xs ${
                      stmt.status === 'ready' ? 'text-green-400 bg-green-400/10' :
                      stmt.status === 'delivered' ? 'text-blue-400 bg-blue-400/10' :
                      stmt.status === 'generating' ? 'text-yellow-400 bg-yellow-400/10' :
                      'text-gray-400 bg-gray-400/10'
                    }`}>
                      {stmt.status}
                    </span>
                  </div>
                  <div className="text-xs space-y-1">
                    <div className="flex justify-between">
                      <span className="text-gray-400">Account:</span>
                      <span className="text-cyan-400 font-mono">{stmt.accountNumber}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-gray-400">Partner:</span>
                      <span className={`font-semibold ${stmt.bankingPartner === 'Sutton-Bank' ? 'text-green-400' : 'text-blue-400'}`}>
                        {stmt.bankingPartner}
                      </span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-gray-400">Type:</span>
                      <span className="text-purple-400">{stmt.statementType}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-gray-400">Methodology:</span>
                      <span className="text-orange-400 font-mono text-[10px]">{stmt.methodology}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-gray-400">Balance:</span>
                      <span className="text-gray-200 font-semibold">${stmt.balance.closing.toLocaleString()}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-gray-400">TXN Count:</span>
                      <span className="text-cyan-400">{stmt.transactionCount}</span>
                    </div>
                    {stmt.requestedVia5G && (
                      <div className="flex items-center gap-1 mt-2 pt-2 border-t border-green-500/10">
                        <Network className="w-3 h-3 text-cyan-400" />
                        <span className="text-gray-400 text-[10px]">5G Delivery:</span>
                        <span className="text-cyan-400 font-mono text-[10px]">{stmt.deliveryNode}</span>
                      </div>
                    )}
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Internal Statement Logs */}
          <div className="bg-black/30 border border-cyan-500/20 rounded-lg p-4">
            <h3 className="text-lg font-bold text-cyan-400 mb-3 flex items-center gap-2">
              <Database className="w-5 h-5" />
              Internal Statement Logs
            </h3>
            <div className="space-y-2 max-h-80 overflow-y-auto">
              {internalLogs.slice(0, 12).map(log => (
                <div key={log.id} className="bg-black/40 border border-cyan-500/10 rounded p-3">
                  <div className="flex items-center justify-between mb-2">
                    <span className="text-xs font-mono text-gray-300">{log.logType}</span>
                    <span className={`px-1.5 py-0.5 rounded text-xs ${
                      log.severity === 'INFO' ? 'text-blue-400 bg-blue-400/10' :
                      log.severity === 'WARN' ? 'text-yellow-400 bg-yellow-400/10' :
                      log.severity === 'ERROR' ? 'text-orange-400 bg-orange-400/10' :
                      'text-red-400 bg-red-400/10'
                    }`}>
                      {log.severity}
                    </span>
                  </div>
                  <div className="text-xs space-y-1">
                    <div className="text-gray-200 mb-1">{log.message}</div>
                    <div className="flex justify-between">
                      <span className="text-gray-400">Methodology:</span>
                      <span className="text-purple-400 font-mono text-[10px]">{log.methodology}</span>
                    </div>
                    {log.associatedAccount && (
                      <div className="flex justify-between">
                        <span className="text-gray-400">Account:</span>
                        <span className="text-cyan-400 font-mono text-[10px]">{log.associatedAccount}</span>
                      </div>
                    )}
                    {log.regulatoryBody && (
                      <div className="flex justify-between">
                        <span className="text-gray-400">Regulator:</span>
                        <span className="text-green-400 text-[10px]">{log.regulatoryBody}</span>
                      </div>
                    )}
                    {log['5gSessionId'] && (
                      <div className="flex justify-between">
                        <span className="text-gray-400">5G Session:</span>
                        <span className="text-cyan-400 font-mono text-[10px]">{log['5gSessionId']}</span>
                      </div>
                    )}
                    <div className="text-gray-500 text-[10px] mt-1">{new Date(log.timestamp).toLocaleString()}</div>
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Council-Derived Requirements */}
          <div className="bg-black/30 border border-purple-500/20 rounded-lg p-4">
            <h3 className="text-lg font-bold text-purple-400 mb-3 flex items-center gap-2">
              <Shield className="w-5 h-5" />
              Council-Derived Requirements
            </h3>
            <div className="space-y-2 max-h-80 overflow-y-auto">
              {councilRequirements.map(req => (
                <div key={req.id} className="bg-black/40 border border-purple-500/10 rounded p-3">
                  <div className="flex items-center justify-between mb-2">
                    <span className="text-xs font-semibold text-purple-400">{req.councilName}</span>
                    <span className={`px-1.5 py-0.5 rounded text-xs ${
                      req.status === 'active' ? 'text-green-400 bg-green-400/10' :
                      req.status === 'pending' ? 'text-yellow-400 bg-yellow-400/10' :
                      'text-gray-400 bg-gray-400/10'
                    }`}>
                      {req.status}
                    </span>
                  </div>
                  <div className="text-xs space-y-1">
                    <div className="flex justify-between mb-1">
                      <span className="text-gray-400">Type:</span>
                      <span className="text-cyan-400 text-[10px]">{req.requirementType}</span>
                    </div>
                    <div className="text-gray-200 text-[11px] mb-2 italic">"{req.mandate}"</div>
                    <div className="flex justify-between">
                      <span className="text-gray-400">Methodology:</span>
                      <span className="text-orange-400 font-mono text-[10px]">{req.methodology}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-gray-400">Effective:</span>
                      <span className="text-gray-500 text-[10px]">{new Date(req.effectiveDate).toLocaleDateString()}</span>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>

        {/* Methodology Summary & Compliance Metrics */}
        <div className="grid grid-cols-4 gap-4">
          <div className="bg-gradient-to-br from-green-900/20 to-black/40 border border-green-500/30 rounded-lg p-4">
            <div className="text-gray-400 text-sm mb-1">Total Statements</div>
            <div className="text-2xl font-bold text-green-400">{bankingStatements.length}</div>
            <div className="text-xs text-gray-500 mt-1">
              {bankingStatements.filter(s => s.bankingPartner === 'Sutton-Bank').length} Sutton Bank
            </div>
          </div>
          <div className="bg-gradient-to-br from-blue-900/20 to-black/40 border border-blue-500/30 rounded-lg p-4">
            <div className="text-gray-400 text-sm mb-1">Capital One Accounts</div>
            <div className="text-2xl font-bold text-blue-400">
              {bankingStatements.filter(s => s.bankingPartner === 'Capital-One').length}
            </div>
            <div className="text-xs text-gray-500 mt-1">Partnership tracking</div>
          </div>
          <div className="bg-gradient-to-br from-cyan-900/20 to-black/40 border border-cyan-500/30 rounded-lg p-4">
            <div className="text-gray-400 text-sm mb-1">5G Delivered</div>
            <div className="text-2xl font-bold text-cyan-400">
              {bankingStatements.filter(s => s.requestedVia5G).length}
            </div>
            <div className="text-xs text-gray-500 mt-1">Via URLLC slice</div>
          </div>
          <div className="bg-gradient-to-br from-purple-900/20 to-black/40 border border-purple-500/30 rounded-lg p-4">
            <div className="text-gray-400 text-sm mb-1">Council Mandates</div>
            <div className="text-2xl font-bold text-purple-400">
              {councilRequirements.filter(r => r.status === 'active').length}
            </div>
            <div className="text-xs text-gray-500 mt-1">Active requirements</div>
          </div>
        </div>
      </div>

      {/* Spectrum Analytics & Handover Tracking */}
      <div className="grid grid-cols-2 gap-4">
        {/* Spectrum Utilization */}
        <div className="bg-gradient-to-br from-[#0f172a] to-[#1e293b] border border-cyan-500/20 rounded-lg p-6">
          <h2 className="text-xl font-bold text-cyan-400 mb-4 flex items-center gap-2">
            <Wifi className="w-5 h-5" />
            Spectrum Analytics (3GPP R16)
          </h2>
          <div className="space-y-4">
            {spectrumMetrics.map(spec => (
              <div key={spec.band} className="bg-black/30 border border-cyan-500/10 rounded p-3">
                <div className="flex items-center justify-between mb-3">
                  <div>
                    <div className="text-sm font-semibold text-cyan-400">Band {spec.band}</div>
                    <div className="text-xs text-gray-400">{spec.centerFreq} • {spec.bandwidth}</div>
                  </div>
                  <div className="text-right">
                    <div className="text-lg font-bold text-blue-400">{spec.utilization}%</div>
                    <div className="text-xs text-gray-400">Utilization</div>
                  </div>
                </div>
                <div className="space-y-2">
                  <div>
                    <div className="flex justify-between text-xs mb-1">
                      <span className="text-gray-400">PRB Usage</span>
                      <span className="text-cyan-400">{spec.prb_usage}%</span>
                    </div>
                    <div className="h-2 bg-black/50 rounded-full overflow-hidden">
                      <div
                        className="h-full bg-gradient-to-r from-cyan-500 to-blue-400"
                        style={{ width: `${spec.prb_usage}%` }}
                      />
                    </div>
                  </div>
                  <div>
                    <div className="flex justify-between text-xs mb-1">
                      <span className="text-gray-400">Interference Level</span>
                      <span className={spec.interference > 10 ? 'text-yellow-400' : 'text-green-400'}>{spec.interference} dB</span>
                    </div>
                    <div className="h-2 bg-black/50 rounded-full overflow-hidden">
                      <div
                        className={`h-full ${spec.interference > 10 ? 'bg-gradient-to-r from-yellow-500 to-orange-400' : 'bg-gradient-to-r from-green-500 to-green-400'}`}
                        style={{ width: `${(spec.interference / 20) * 100}%` }}
                      />
                    </div>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Handover Tracking */}
        <div className="bg-gradient-to-br from-[#0f172a] to-[#1e293b] border border-cyan-500/20 rounded-lg p-6">
          <h2 className="text-xl font-bold text-cyan-400 mb-4 flex items-center gap-2">
            <Navigation className="w-5 h-5" />
            Real-time Handover Events
          </h2>
          <div className="space-y-2 max-h-80 overflow-y-auto">
            {handoverEvents.slice(0, 8).map(ho => (
              <div key={ho.id} className="bg-black/30 border border-cyan-500/10 rounded p-3">
                <div className="flex items-center justify-between mb-2">
                  <div className="flex items-center gap-2">
                    <ArrowRight className="w-3 h-3 text-cyan-400" />
                    <span className="text-xs font-mono text-gray-300">{ho.ueId}</span>
                  </div>
                  <span className={`px-1.5 py-0.5 rounded text-xs ${ho.success ? 'text-green-400 bg-green-400/10' : 'text-red-400 bg-red-400/10'}`}>
                    {ho.success ? 'Success' : 'Failed'}
                  </span>
                </div>
                <div className="text-xs space-y-1">
                  <div className="flex justify-between">
                    <span className="text-gray-400">Route:</span>
                    <span className="text-gray-200">{ho.sourceCell} → {ho.targetCell}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-gray-400">Reason:</span>
                    <span className="text-purple-400">{ho.reason}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-gray-400">Duration:</span>
                    <span className="text-blue-400">{ho.duration}ms</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-gray-400">Time:</span>
                    <span className="text-gray-500 font-mono text-[10px]">{new Date(ho.timestamp).toLocaleTimeString()}</span>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* MEC Nodes & SBA Interface Monitoring */}
      <div className="grid grid-cols-2 gap-4">
        {/* MEC Nodes */}
        <div className="bg-gradient-to-br from-[#0f172a] to-[#1e293b] border border-cyan-500/20 rounded-lg p-6">
          <h2 className="text-xl font-bold text-cyan-400 mb-4 flex items-center gap-2">
            <Cpu className="w-5 h-5" />
            Multi-Access Edge Computing (MEC)
          </h2>
          <div className="space-y-3">
            {mecNodes.map(node => {
              const Icon = getNodeIcon(node.type);
              return (
                <button
                  key={node.id}
                  onClick={() => handleNodeSelect(node.id)}
                  className={`w-full bg-black/40 border rounded-lg p-4 text-left transition-all ${
                    selectedNode === node.id
                      ? 'border-purple-400 bg-purple-400/10 scale-105'
                      : 'border-purple-500/20 hover:border-purple-400/50'
                  }`}
                >
                  <div className="flex items-center justify-between mb-3">
                    <div className="flex items-center gap-2">
                      <Icon className="w-5 h-5 text-purple-400" />
                      <span className="text-sm font-mono text-gray-200">{node.name}</span>
                    </div>
                    <span className={`px-2 py-1 rounded text-xs border ${getStatusColor(node.status)}`}>
                      {node.status}
                    </span>
                  </div>
                  <div className="grid grid-cols-2 gap-3 text-xs">
                    <div>
                      <div className="text-gray-400">Location</div>
                      <div className="text-gray-200">{node.location}</div>
                    </div>
                    <div>
                      <div className="text-gray-400">Latency</div>
                      <div className="text-green-400 font-mono">{node.latency.toFixed(1)}ms</div>
                    </div>
                    <div>
                      <div className="text-gray-400">Throughput</div>
                      <div className="text-blue-400 font-mono">{node.throughput} Mbps</div>
                    </div>
                    <div>
                      <div className="text-gray-400">Connections</div>
                      <div className="text-cyan-400 font-mono">{node.connections}</div>
                    </div>
                  </div>
                </button>
              );
            })}
          </div>
          <div className="mt-4 pt-4 border-t border-cyan-500/20 grid grid-cols-2 gap-3 text-sm">
            <div className="bg-black/30 rounded p-2">
              <div className="text-gray-400 text-xs">Total MEC Nodes</div>
              <div className="text-xl font-bold text-purple-400">{mecNodes.length}</div>
            </div>
            <div className="bg-black/30 rounded p-2">
              <div className="text-gray-400 text-xs">Avg Edge Latency</div>
              <div className="text-xl font-bold text-green-400">{(mecNodes.reduce((sum, n) => sum + n.latency, 0) / mecNodes.length).toFixed(1)}ms</div>
            </div>
          </div>
        </div>

        {/* SBA Interface Monitoring */}
        <div className="bg-gradient-to-br from-[#0f172a] to-[#1e293b] border border-cyan-500/20 rounded-lg p-6">
          <h2 className="text-xl font-bold text-cyan-400 mb-4 flex items-center gap-2">
            <BarChart3 className="w-5 h-5" />
            SBA Interface Monitoring
          </h2>
          <div className="space-y-2 max-h-80 overflow-y-auto">
            {sbaInterfaces.map(sbi => (
              <div key={sbi.id} className="bg-black/30 border border-cyan-500/10 rounded p-3">
                <div className="flex items-center justify-between mb-2">
                  <div className="text-sm font-semibold text-cyan-400">{sbi.name}</div>
                  <span className={`px-1.5 py-0.5 rounded text-xs border ${getStatusColor(sbi.status)}`}>
                    {sbi.status}
                  </span>
                </div>
                <div className="text-xs space-y-1">
                  <div className="flex justify-between">
                    <span className="text-gray-400">Producer:</span>
                    <span className="text-gray-200 font-mono">{sbi.producer}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-gray-400">Consumer:</span>
                    <span className="text-gray-200 font-mono">{sbi.consumer}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-gray-400">Request Rate:</span>
                    <span className="text-blue-400">{sbi.requestRate} req/s</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-gray-400">Avg Latency:</span>
                    <span className="text-green-400">{sbi.avgLatency.toFixed(1)}ms</span>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Secure Tunnels & QoS Profiles */}
      <div className="grid grid-cols-2 gap-4">
        {/* Encrypted Tunnels */}
        <div className="bg-gradient-to-br from-[#0f172a] to-[#1e293b] border border-cyan-500/20 rounded-lg p-6">
          <h2 className="text-xl font-bold text-cyan-400 mb-4 flex items-center gap-2">
            <Lock className="w-5 h-5" />
            Secure Tunnel Mapping
          </h2>
          <div className="space-y-2 max-h-64 overflow-y-auto">
            {secureTunnels.map(tunnel => {
              const sourceNode = requesters.find(r => r.id === tunnel.source);
              const destNode = requesters.find(r => r.id === tunnel.destination);
              return (
                <div key={tunnel.id} className="bg-black/40 border border-cyan-500/10 rounded p-3">
                  <div className="flex items-center justify-between mb-2">
                    <div className="flex items-center gap-2">
                      <ArrowRight className="w-3 h-3 text-cyan-400" />
                      <span className="text-xs font-mono text-gray-300">{tunnel.id}</span>
                    </div>
                    <span className={`px-1.5 py-0.5 rounded text-xs border ${getStatusColor(tunnel.status)}`}>
                      {tunnel.status}
                    </span>
                  </div>
                  <div className="text-xs space-y-1">
                    <div className="flex justify-between">
                      <span className="text-gray-400">Route:</span>
                      <span className="text-gray-200">{sourceNode?.name} → {destNode?.name}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-gray-400">Protocol:</span>
                      <span className="text-purple-400 font-mono">{tunnel.protocol}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-gray-400">Encryption:</span>
                      <span className="text-green-400 font-mono">{tunnel.encryption}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-gray-400">Throughput:</span>
                      <span className="text-blue-400">{tunnel.throughput} Mbps</span>
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        </div>

        {/* QoS Profile Distribution */}
        <div className="bg-gradient-to-br from-[#0f172a] to-[#1e293b] border border-cyan-500/20 rounded-lg p-6">
          <h2 className="text-xl font-bold text-cyan-400 mb-4 flex items-center gap-2">
            <Gauge className="w-5 h-5" />
            QoS Profile Distribution
          </h2>
          <div className="space-y-4">
            {['Critical', 'High', 'Medium', 'Low'].map(profile => {
              const count = requesters.filter(r => r.qosProfile === profile).length;
              const percentage = (count / requesters.length) * 100;
              const color =
                profile === 'Critical' ? 'from-red-500 to-red-400' :
                profile === 'High' ? 'from-orange-500 to-orange-400' :
                profile === 'Medium' ? 'from-yellow-500 to-yellow-400' :
                'from-green-500 to-green-400';
              const textColor =
                profile === 'Critical' ? 'text-red-400' :
                profile === 'High' ? 'text-orange-400' :
                profile === 'Medium' ? 'text-yellow-400' :
                'text-green-400';

              return (
                <div key={profile}>
                  <div className="flex justify-between text-sm mb-1">
                    <span className={textColor}>{profile} Priority</span>
                    <span className="text-gray-400">{count} nodes ({percentage.toFixed(0)}%)</span>
                  </div>
                  <div className="h-3 bg-black/50 rounded-full overflow-hidden">
                    <div
                      className={`h-full bg-gradient-to-r ${color}`}
                      style={{ width: `${percentage}%` }}
                    />
                  </div>
                </div>
              );
            })}
            <div className="pt-4 border-t border-cyan-500/20 mt-4">
              <h3 className="text-sm font-semibold text-gray-400 mb-3">Requester Type Breakdown</h3>
              <div className="grid grid-cols-2 gap-2 text-xs">
                {['Banking-Terminal', 'ATM-Cluster', 'Mobile-App', 'Core-Service'].map(type => {
                  const count = requesters.filter(r => r.requesterType === type).length;
                  return (
                    <div key={type} className="flex justify-between bg-black/30 rounded p-2">
                      <span className="text-gray-400">{type}:</span>
                      <span className="text-cyan-400 font-mono">{count}</span>
                    </div>
                  );
                })}
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Network Slices */}
      <div className="bg-gradient-to-br from-[#0f172a] to-[#1e293b] border border-cyan-500/20 rounded-lg p-6">
        <h2 className="text-xl font-bold text-cyan-400 mb-4 flex items-center gap-2">
          <Layers className="w-5 h-5" />
          Network Slicing Configuration
        </h2>
        <div className="grid grid-cols-3 gap-4">
          {slices.map(slice => (
            <div key={slice.id} className="bg-black/30 border border-cyan-500/10 rounded-lg p-4">
              <div className="flex items-center justify-between mb-3">
                <div className="font-semibold text-gray-200">{slice.name}</div>
                <span className={`px-2 py-1 rounded text-xs border uppercase ${getStatusColor(slice.status)}`}>
                  {slice.status}
                </span>
              </div>
              <div className="space-y-2 text-sm">
                <div className="flex justify-between">
                  <span className="text-gray-400">Type:</span>
                  <span className="text-cyan-400 font-mono">{slice.type}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-gray-400">Bandwidth:</span>
                  <span className="text-gray-200">{slice.bandwidth}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-gray-400">Latency:</span>
                  <span className="text-green-400">{slice.latency}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-gray-400">Reliability:</span>
                  <span className="text-blue-400">{slice.reliability}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-gray-400">SLA:</span>
                  <span className="text-purple-400 text-xs">{slice.sla}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-gray-400">Encryption:</span>
                  <span className="text-green-400 text-xs font-mono">{slice.encryptionStandard}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-gray-400">Active UEs:</span>
                  <span className="text-orange-400 font-bold">{slice.ueCount}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-gray-400">Orchestration:</span>
                  <span className="text-cyan-400 text-xs">{slice.orchestrationPolicy}</span>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* 5G Topology Visualization */}
      <div className="bg-gradient-to-br from-[#0f172a] to-[#1e293b] border border-cyan-500/20 rounded-lg p-6">
        <h2 className="text-xl font-bold text-cyan-400 mb-6 flex items-center gap-2">
          <Antenna className="w-5 h-5" />
          5G SA Network Topology (3GPP Rel-16)
        </h2>

        <div className="space-y-8">
          {/* User Equipment Layer */}
          <div>
            <div className="text-sm font-semibold text-gray-400 mb-3 flex items-center gap-2">
              <Radio className="w-4 h-4" />
              User Equipment (UE) - Requester Terminals
            </div>
            <div className="grid grid-cols-3 gap-3">
              {ueNodes.map(node => {
                const Icon = getNodeIcon(node.type);
                const isSelected = selectedNode === node.id;
                return (
                  <button
                    key={node.id}
                    onClick={() => handleNodeSelect(node.id)}
                    className={`bg-black/40 border rounded-lg p-3 text-left transition-all ${
                      isSelected
                        ? 'border-cyan-400 bg-cyan-400/10 scale-105'
                        : 'border-cyan-500/20 hover:border-cyan-400/50'
                    }`}
                  >
                    <div className="flex items-center justify-between mb-2">
                      <div className="flex items-center gap-2">
                        <Icon className="w-4 h-4 text-cyan-400" />
                        <span className="text-xs font-mono text-gray-300">{node.requesterType}</span>
                      </div>
                      <span className={`px-1.5 py-0.5 rounded text-xs border ${getStatusColor(node.status)}`}>
                        {node.status}
                      </span>
                    </div>
                    <div className="text-xs text-gray-400 space-y-1">
                      <div className="flex items-center gap-1">
                        <Lock className="w-3 h-3 text-green-400" />
                        <span className="text-green-400">{node.encryption}</span>
                      </div>
                      <div className="flex items-center gap-1">
                        <Gauge className="w-3 h-3 text-purple-400" />
                        <span className="text-purple-400">QoS: {node.qosProfile}</span>
                      </div>
                      <div>Latency: <span className="text-green-400">{node.latency.toFixed(1)}ms</span></div>
                      <div>Throughput: <span className="text-blue-400">{node.throughput.toFixed(0)} Mbps</span></div>
                    </div>
                  </button>
                );
              })}
            </div>
          </div>

          {/* Connection Flow Indicator */}
          <div className="flex items-center justify-center">
            <div className="h-12 w-0.5 bg-gradient-to-b from-cyan-400/50 to-green-400/50"></div>
          </div>

          {/* Radio Access Network Layer */}
          <div>
            <div className="text-sm font-semibold text-gray-400 mb-3 flex items-center gap-2">
              <Antenna className="w-4 h-4" />
              RAN (Radio Access Network) - gNodeB Base Stations
            </div>
            <div className="grid grid-cols-3 gap-3">
              {ranNodes.map(node => {
                const Icon = getNodeIcon(node.type);
                const isSelected = selectedNode === node.id;
                return (
                  <button
                    key={node.id}
                    onClick={() => handleNodeSelect(node.id)}
                    className={`bg-black/40 border rounded-lg p-3 text-left transition-all ${
                      isSelected
                        ? 'border-green-400 bg-green-400/10 scale-105'
                        : 'border-green-500/20 hover:border-green-400/50'
                    }`}
                  >
                    <div className="flex items-center justify-between mb-2">
                      <div className="flex items-center gap-2">
                        <Icon className="w-4 h-4 text-green-400" />
                        <span className="text-xs font-mono text-gray-300">{node.name}</span>
                      </div>
                      <span className={`px-1.5 py-0.5 rounded text-xs border ${getStatusColor(node.status)}`}>
                        {node.status}
                      </span>
                    </div>
                    <div className="text-xs text-gray-400 space-y-1">
                      <div className="flex items-center gap-1">
                        <Key className="w-3 h-3 text-yellow-400" />
                        <span className="text-yellow-400 font-mono text-[10px]">{node.tunnelId}</span>
                      </div>
                      <div>Connections: <span className="text-cyan-400">{node.connections}</span></div>
                      <div>Throughput: <span className="text-blue-400">{node.throughput.toFixed(0)} Mbps</span></div>
                    </div>
                  </button>
                );
              })}
            </div>
          </div>

          {/* Connection Flow Indicator */}
          <div className="flex items-center justify-center">
            <div className="h-12 w-0.5 bg-gradient-to-b from-green-400/50 to-blue-400/50"></div>
          </div>

          {/* 5G Core Network */}
          <div>
            <div className="text-sm font-semibold text-gray-400 mb-3 flex items-center gap-2">
              <Server className="w-4 h-4" />
              5GC (5G Core) Network Functions
            </div>

            {/* Control Plane */}
            <div className="mb-4">
              <div className="text-xs text-gray-500 mb-2">Control Plane (CP)</div>
              <div className="grid grid-cols-2 gap-3">
                {controlPlaneNodes.map(node => {
                  const Icon = getNodeIcon(node.type);
                  const isSelected = selectedNode === node.id;
                  return (
                    <button
                      key={node.id}
                      onClick={() => handleNodeSelect(node.id)}
                      className={`bg-black/40 border rounded-lg p-3 text-left transition-all ${
                        isSelected
                          ? 'border-blue-400 bg-blue-400/10 scale-105'
                          : 'border-blue-500/20 hover:border-blue-400/50'
                      }`}
                    >
                      <div className="flex items-center justify-between mb-2">
                        <div className="flex items-center gap-2">
                          <Icon className="w-4 h-4 text-blue-400" />
                          <span className="text-xs font-mono text-gray-300">{node.name}</span>
                        </div>
                        <span className={`px-1.5 py-0.5 rounded text-xs border ${getStatusColor(node.status)}`}>
                          {node.status}
                        </span>
                      </div>
                      <div className="text-xs text-gray-400">
                        <div>Sessions: <span className="text-cyan-400">{node.connections}</span></div>
                      </div>
                    </button>
                  );
                })}
              </div>
            </div>

            {/* User Plane */}
            <div className="mb-4">
              <div className="text-xs text-gray-500 mb-2">User Plane (UP)</div>
              <div className="grid grid-cols-2 gap-3">
                {userPlaneNodes.map(node => {
                  const Icon = getNodeIcon(node.type);
                  const isSelected = selectedNode === node.id;
                  return (
                    <button
                      key={node.id}
                      onClick={() => handleNodeSelect(node.id)}
                      className={`bg-black/40 border rounded-lg p-3 text-left transition-all ${
                        isSelected
                          ? 'border-purple-400 bg-purple-400/10 scale-105'
                          : 'border-purple-500/20 hover:border-purple-400/50'
                      }`}
                    >
                      <div className="flex items-center justify-between mb-2">
                        <div className="flex items-center gap-2">
                          <Icon className="w-4 h-4 text-purple-400" />
                          <span className="text-xs font-mono text-gray-300">{node.name}</span>
                        </div>
                        <span className={`px-1.5 py-0.5 rounded text-xs border ${getStatusColor(node.status)}`}>
                          {node.status}
                        </span>
                      </div>
                      <div className="text-xs text-gray-400 space-y-1">
                        <div>Throughput: <span className="text-blue-400">{node.throughput.toFixed(0)} Mbps</span></div>
                        <div>Sessions: <span className="text-cyan-400">{node.connections}</span></div>
                      </div>
                    </button>
                  );
                })}
              </div>
            </div>

            {/* Support Functions */}
            <div>
              <div className="text-xs text-gray-500 mb-2">Support Functions (SBA - Service Based Architecture)</div>
              <div className="grid grid-cols-4 gap-3">
                {supportNodes.map(node => {
                  const Icon = getNodeIcon(node.type);
                  const isSelected = selectedNode === node.id;
                  return (
                    <button
                      key={node.id}
                      onClick={() => handleNodeSelect(node.id)}
                      className={`bg-black/40 border rounded-lg p-3 text-left transition-all ${
                        isSelected
                          ? 'border-yellow-400 bg-yellow-400/10 scale-105'
                          : 'border-yellow-500/20 hover:border-yellow-400/50'
                      }`}
                    >
                      <div className="flex items-center gap-2 mb-2">
                        <Icon className="w-4 h-4 text-yellow-400" />
                        <span className="text-xs font-mono text-gray-300">{node.type}</span>
                      </div>
                      <div className="text-xs text-gray-400">
                        <div className={`px-1.5 py-0.5 rounded border ${getStatusColor(node.status)}`}>
                          {node.status}
                        </div>
                      </div>
                    </button>
                  );
                })}
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Certificate Authentication Status */}
      <div className="bg-gradient-to-br from-[#0f172a] to-[#1e293b] border border-cyan-500/20 rounded-lg p-6">
        <h2 className="text-xl font-bold text-cyan-400 mb-4 flex items-center gap-2">
          <Shield className="w-5 h-5" />
          Certificate Authentication & mTLS Status
        </h2>
        <div className="grid grid-cols-2 gap-6">
          <div>
            <div className="text-sm text-gray-400 mb-3">User Equipment & Edge Nodes</div>
            <div className="space-y-2 max-h-64 overflow-y-auto">
              {requesters.filter(r => ['UE', 'gNodeB'].includes(r.type)).map(node => (
                <div key={node.id} className="bg-black/30 border border-cyan-500/10 rounded p-2 flex items-center justify-between">
                  <div className="flex-1">
                    <div className="text-xs font-mono text-gray-300">{node.name}</div>
                    <div className="text-xs text-gray-500 mt-0.5">Cert: {node.certSerial}</div>
                  </div>
                  <div className="flex items-center gap-2">
                    <Shield className="w-3 h-3 text-green-400" />
                    <span className="text-xs text-green-400">Verified</span>
                  </div>
                </div>
              ))}
            </div>
          </div>
          <div>
            <div className="text-sm text-gray-400 mb-3">Core Network Functions</div>
            <div className="space-y-2 max-h-64 overflow-y-auto">
              {requesters.filter(r => !['UE', 'gNodeB'].includes(r.type)).map(node => (
                <div key={node.id} className="bg-black/30 border border-cyan-500/10 rounded p-2 flex items-center justify-between">
                  <div className="flex-1">
                    <div className="text-xs font-mono text-gray-300">{node.name}</div>
                    <div className="text-xs text-gray-500 mt-0.5">Cert: {node.certSerial}</div>
                  </div>
                  <div className="flex items-center gap-2">
                    <Lock className="w-3 h-3 text-green-400" />
                    <span className="text-xs text-green-400">mTLS Active</span>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
        <div className="mt-4 pt-4 border-t border-cyan-500/20 grid grid-cols-4 gap-4">
          <div className="bg-black/30 rounded p-3">
            <div className="text-xs text-gray-400">Total Certificates</div>
            <div className="text-xl font-bold text-cyan-400">{requesters.length}</div>
          </div>
          <div className="bg-black/30 rounded p-3">
            <div className="text-xs text-gray-400">Verified</div>
            <div className="text-xl font-bold text-green-400">{requesters.length}</div>
          </div>
          <div className="bg-black/30 rounded p-3">
            <div className="text-xs text-gray-400">mTLS Sessions</div>
            <div className="text-xl font-bold text-purple-400">{secureTunnels.filter(t => t.protocol === 'mTLS').length}</div>
          </div>
          <div className="bg-black/30 rounded p-3">
            <div className="text-xs text-gray-400">IPsec Tunnels</div>
            <div className="text-xl font-bold text-blue-400">{secureTunnels.filter(t => t.protocol === 'IPsec/IKEv2').length}</div>
          </div>
        </div>
      </div>

      {/* Selected Node Details */}
      {selectedNodeData && (
        <div className="bg-gradient-to-br from-[#0f172a] to-[#1e293b] border border-cyan-500/20 rounded-lg p-6">
          <h2 className="text-xl font-bold text-cyan-400 mb-4 flex items-center gap-2">
            <MapPin className="w-5 h-5" />
            Node Details: {selectedNodeData.name}
          </h2>
          <div className="grid grid-cols-2 gap-6">
            <div className="space-y-3">
              <div className="flex justify-between">
                <span className="text-gray-400">Node ID:</span>
                <span className="text-cyan-400 font-mono">{selectedNodeData.id}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-gray-400">Type:</span>
                <span className="text-gray-200 font-semibold">{selectedNodeData.type}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-gray-400">Status:</span>
                <span className={`px-2 py-1 rounded text-xs border uppercase ${getStatusColor(selectedNodeData.status)}`}>
                  {selectedNodeData.status}
                </span>
              </div>
              <div className="flex justify-between">
                <span className="text-gray-400">IP Address:</span>
                <span className="text-cyan-400 font-mono">{selectedNodeData.ip}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-gray-400">Location:</span>
                <span className="text-gray-200">{selectedNodeData.location}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-gray-400">Frequency Band:</span>
                <span className="text-purple-400 font-mono">{selectedNodeData.band}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-gray-400">Requester Type:</span>
                <span className="text-orange-400 font-semibold">{selectedNodeData.requesterType}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-gray-400">Encryption:</span>
                <span className="text-green-400 font-mono flex items-center gap-1">
                  <Lock className="w-3 h-3" />
                  {selectedNodeData.encryption}
                </span>
              </div>
              <div className="flex justify-between">
                <span className="text-gray-400">QoS Profile:</span>
                <span className={`font-semibold ${
                  selectedNodeData.qosProfile === 'Critical' ? 'text-red-400' :
                  selectedNodeData.qosProfile === 'High' ? 'text-orange-400' :
                  selectedNodeData.qosProfile === 'Medium' ? 'text-yellow-400' :
                  'text-green-400'
                }`}>{selectedNodeData.qosProfile}</span>
              </div>
            </div>
            <div className="space-y-3">
              <div className="flex justify-between">
                <span className="text-gray-400">Latency:</span>
                <span className="text-green-400 font-mono">{selectedNodeData.latency.toFixed(2)} ms</span>
              </div>
              <div className="flex justify-between">
                <span className="text-gray-400">Throughput:</span>
                <span className="text-blue-400 font-mono">{selectedNodeData.throughput.toFixed(0)} Mbps</span>
              </div>
              <div className="flex justify-between">
                <span className="text-gray-400">Active Connections:</span>
                <span className="text-cyan-400 font-mono">{selectedNodeData.connections}</span>
              </div>
              {selectedNodeData.tunnelId && (
                <div className="flex justify-between">
                  <span className="text-gray-400">Tunnel ID:</span>
                  <span className="text-yellow-400 font-mono text-xs">{selectedNodeData.tunnelId}</span>
                </div>
              )}
              {selectedNodeData.certSerial && (
                <div className="flex justify-between">
                  <span className="text-gray-400">Cert Serial:</span>
                  <span className="text-purple-400 font-mono text-xs">{selectedNodeData.certSerial}</span>
                </div>
              )}
              {selectedNodeData.beamId && (
                <div className="flex justify-between">
                  <span className="text-gray-400">Beam ID:</span>
                  <span className="text-cyan-400 font-mono text-xs">{selectedNodeData.beamId}</span>
                </div>
              )}
              {selectedNodeData.spectrumEfficiency !== undefined && selectedNodeData.spectrumEfficiency > 0 && (
                <div className="flex justify-between">
                  <span className="text-gray-400">Spectrum Efficiency:</span>
                  <span className="text-green-400 font-mono">{selectedNodeData.spectrumEfficiency.toFixed(1)} bps/Hz</span>
                </div>
              )}
              {selectedNodeData.handoverCount !== undefined && (
                <div className="flex justify-between">
                  <span className="text-gray-400">Handovers (24h):</span>
                  <span className="text-orange-400 font-mono">{selectedNodeData.handoverCount}</span>
                </div>
              )}
              <div className="mt-4 pt-4 border-t border-cyan-500/20">
                <div className="text-sm text-gray-400 mb-2">Performance Status</div>
                <div className="space-y-2">
                  <div>
                    <div className="flex justify-between text-xs mb-1">
                      <span className="text-gray-500">Latency</span>
                      <span className="text-green-400">{((selectedNodeData.latency / 50) * 100).toFixed(0)}%</span>
                    </div>
                    <div className="h-2 bg-black/50 rounded-full overflow-hidden">
                      <div
                        className="h-full bg-gradient-to-r from-green-500 to-green-400"
                        style={{ width: `${(selectedNodeData.latency / 50) * 100}%` }}
                      />
                    </div>
                  </div>
                  <div>
                    <div className="flex justify-between text-xs mb-1">
                      <span className="text-gray-500">Throughput</span>
                      <span className="text-blue-400">{((selectedNodeData.throughput / 1000) * 100).toFixed(0)}%</span>
                    </div>
                    <div className="h-2 bg-black/50 rounded-full overflow-hidden">
                      <div
                        className="h-full bg-gradient-to-r from-blue-500 to-blue-400"
                        style={{ width: `${(selectedNodeData.throughput / 1000) * 100}%` }}
                      />
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
