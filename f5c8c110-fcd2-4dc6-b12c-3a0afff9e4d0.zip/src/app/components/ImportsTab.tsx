import { useState, useEffect } from "react";
import {
  Package,
  Server,
  Shield,
  Key,
  Lock,
  Cpu,
  HardDrive,
  Network,
  CheckCircle2,
  AlertTriangle,
  Info,
} from "lucide-react";

interface ImportsTabProps {
  secureMode: boolean;
  onAuditLog: (action: string) => void;
}

type BuildType = "normal" | "trusted";
type AlgorithmCategory = "cipher" | "macs" | "kex";

interface Algorithm {
  name: string;
  status: "default" | "available" | "removed";
  build: BuildType[];
  release: string;
  security: "high" | "medium" | "legacy";
}

interface VMHardwareConfig {
  card: number;
  cpuNodes: number;
  cpuCores: number;
  memory: string;
  hugepage: string;
  driver: string;
  optimum: boolean;
}

export function ImportsTab({
  secureMode,
  onAuditLog,
}: ImportsTabProps) {
  const [selectedCategory, setSelectedCategory] = useState<
    "algorithms" | "hardware" | "imports"
  >("algorithms");
  const [buildType, setBuildType] =
    useState<BuildType>("normal");
  const [animatedCount, setAnimatedCount] = useState(0);

  // Semantic enumeration following gold standard
  const algorithmData: Record<AlgorithmCategory, Algorithm[]> =
    {
      cipher: [
        // Release 21.16+ Normal Build - Default
        {
          name: "aes256-ctr",
          status: "default",
          build: ["normal", "trusted"],
          release: "21.16+",
          security: "high",
        },
        {
          name: "aes192-ctr",
          status: "default",
          build: ["normal", "trusted"],
          release: "21.16+",
          security: "high",
        },
        {
          name: "aes128-ctr",
          status: "default",
          build: ["normal", "trusted"],
          release: "21.16+",
          security: "high",
        },
        {
          name: "aes256-gcm@openssh.com",
          status: "default",
          build: ["normal"],
          release: "21.16+",
          security: "high",
        },
        {
          name: "aes128-gcm@openssh.com",
          status: "default",
          build: ["normal"],
          release: "21.16+",
          security: "high",
        },
        {
          name: "chacha20-poly1305@openssh.com",
          status: "default",
          build: ["normal"],
          release: "21.16+",
          security: "high",
        },
        // Available only
        {
          name: "aes128-cbc",
          status: "available",
          build: ["normal"],
          release: "21.16+",
          security: "medium",
        },
        // Legacy (20.x - 21.15)
        {
          name: "blowfish-cbc",
          status: "removed",
          build: ["normal"],
          release: "20.x-21.15",
          security: "legacy",
        },
        {
          name: "3des-cbc",
          status: "removed",
          build: ["normal"],
          release: "20.x-21.15",
          security: "legacy",
        },
      ],
      macs: [
        // Normal Build - Default & Available
        {
          name: "hmac-sha2-512-etm@openssh.com",
          status: "default",
          build: ["normal"],
          release: "21.16+",
          security: "high",
        },
        {
          name: "hmac-sha2-256-etm@openssh.com",
          status: "default",
          build: ["normal"],
          release: "21.16+",
          security: "high",
        },
        {
          name: "hmac-sha1-etm@openssh.com",
          status: "default",
          build: ["normal"],
          release: "21.16+",
          security: "medium",
        },
        {
          name: "hmac-sha2-512",
          status: "default",
          build: ["normal", "trusted"],
          release: "21.16+",
          security: "high",
        },
        {
          name: "hmac-sha2-256",
          status: "default",
          build: ["normal", "trusted"],
          release: "21.16+",
          security: "high",
        },
        {
          name: "hmac-sha1",
          status: "default",
          build: ["normal", "trusted"],
          release: "21.16+",
          security: "medium",
        },
      ],
      kex: [
        // KEX Algorithms (not configurable in StarOS)
        {
          name: "diffie-hellman-group14-sha1",
          status: "available",
          build: ["normal", "trusted"],
          release: "21.16+",
          security: "medium",
        },
        {
          name: "diffie-hellman-group1-sha1",
          status: "removed",
          build: ["normal", "trusted"],
          release: "20.x-21.15",
          security: "legacy",
        },
      ],
    };

  const vmHardwareConfigs: VMHardwareConfig[] = [
    {
      card: 1,
      cpuNodes: 1,
      cpuCores: 8,
      memory: "16384M",
      hugepage: "2048kB",
      driver: "virtio_net",
      optimum: true,
    },
    {
      card: 3,
      cpuNodes: 1,
      cpuCores: 8,
      memory: "16384M",
      hugepage: "2048kB",
      driver: "vmxnet3",
      optimum: true,
    },
    {
      card: 4,
      cpuNodes: 1,
      cpuCores: 24,
      memory: "32768M",
      hugepage: "2048kB",
      driver: "vmxnet3",
      optimum: true,
    },
  ];

  const importModules = [
    {
      name: "React",
      version: "18.3.1",
      type: "Core Framework",
      status: "active",
      source: "npm",
    },
    {
      name: "TypeScript",
      version: "5.6.2",
      type: "Language",
      status: "active",
      source: "npm",
    },
    {
      name: "Tailwind CSS",
      version: "4.1.12",
      type: "Styling",
      status: "active",
      source: "npm",
    },
    {
      name: "Vite",
      version: "6.3.5",
      type: "Build Tool",
      status: "active",
      source: "npm",
    },
    {
      name: "Lucide React",
      version: "0.487.0",
      type: "Icons",
      status: "active",
      source: "npm",
    },
    {
      name: "Motion",
      version: "12.23.24",
      type: "Animation",
      status: "active",
      source: "npm",
    },
    {
      name: "Recharts",
      version: "2.15.2",
      type: "Charts",
      status: "active",
      source: "npm",
    },
    {
      name: "React Hook Form",
      version: "7.55.0",
      type: "Forms",
      status: "active",
      source: "npm",
    },
  ];

  // Animated counter for live updates
  useEffect(() => {
    const interval = setInterval(() => {
      setAnimatedCount((prev) => (prev + 1) % 1000);
    }, 100);

    return () => clearInterval(interval);
  }, []);

  const getSecurityColor = (security: string) => {
    switch (security) {
      case "high":
        return "text-green-400 bg-green-500/10 border-green-500/30";
      case "medium":
        return "text-yellow-400 bg-yellow-500/10 border-yellow-500/30";
      case "legacy":
        return "text-red-400 bg-red-500/10 border-red-500/30";
      default:
        return "text-gray-400 bg-gray-500/10 border-gray-500/30";
    }
  };

  const getStatusIcon = (status: string) => {
    switch (status) {
      case "default":
        return (
          <CheckCircle2 className="w-4 h-4 text-green-400" />
        );
      case "available":
        return <Info className="w-4 h-4 text-blue-400" />;
      case "removed":
        return (
          <AlertTriangle className="w-4 h-4 text-red-400" />
        );
      default:
        return null;
    }
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-2xl font-bold text-white mb-2">
            Import Specifications & Security Algorithms
          </h2>
          <p className="text-gray-400">
            Cisco ASR 5500 / StarOS Release 21.22 - VM Hardware
            & SSH Configuration
          </p>
        </div>
        <div className="flex items-center gap-2 px-4 py-2 bg-cyan-500/10 border border-cyan-500/30 rounded-lg">
          <div className="w-2 h-2 bg-cyan-400 rounded-full animate-pulse"></div>
          <span className="text-xs font-mono text-cyan-400">
            LIVE: {animatedCount}
          </span>
        </div>
      </div>

      {/* Category Selection */}
      <div className="flex gap-3">
        {[
          {
            id: "algorithms" as const,
            label: "SSH Algorithms",
            icon: Key,
          },
          {
            id: "hardware" as const,
            label: "VM Hardware",
            icon: Server,
          },
          {
            id: "imports" as const,
            label: "NPM Imports",
            icon: Package,
          },
        ].map((category) => {
          const Icon = category.icon;
          const isActive = selectedCategory === category.id;
          return (
            <button
              key={category.id}
              onClick={() => {
                setSelectedCategory(category.id);
                onAuditLog(
                  `Switched to ${category.label} view`,
                );
              }}
              className={`flex items-center gap-2 px-6 py-3 rounded-lg border transition-all ${
                isActive
                  ? "bg-cyan-500/20 border-cyan-500/40 text-cyan-400"
                  : "bg-gray-800/40 border-gray-600/40 text-gray-400 hover:border-gray-500/60"
              }`}
            >
              <Icon className="w-5 h-5" />
              <span className="font-semibold">
                {category.label}
              </span>
            </button>
          );
        })}
      </div>

      {/* Maximized Animated Rendering Area */}
      <div className="bg-gradient-to-br from-gray-900/90 to-gray-800/90 border border-cyan-500/20 rounded-lg backdrop-blur-sm">
        {/* SSH Algorithms View */}
        {selectedCategory === "algorithms" && (
          <div className="p-6 space-y-6">
            {/* Build Type Selector */}
            <div className="flex items-center gap-4 mb-4">
              <span className="text-sm text-gray-400 font-semibold">
                Build Type:
              </span>
              {["normal", "trusted"].map((type) => (
                <button
                  key={type}
                  onClick={() =>
                    setBuildType(type as BuildType)
                  }
                  className={`px-4 py-2 rounded-lg border text-sm font-semibold transition-all ${
                    buildType === type
                      ? "bg-purple-500/20 border-purple-500/40 text-purple-400"
                      : "bg-gray-800/40 border-gray-600/40 text-gray-400 hover:border-gray-500/60"
                  }`}
                >
                  {type.toUpperCase()} BUILD
                </button>
              ))}
            </div>

            {/* Algorithm Categories */}
            {Object.entries(algorithmData).map(
              ([category, algorithms]) => (
                <div key={category} className="space-y-4">
                  <div className="flex items-center gap-3 mb-4">
                    {category === "cipher" && (
                      <Lock className="w-6 h-6 text-cyan-400" />
                    )}
                    {category === "macs" && (
                      <Shield className="w-6 h-6 text-purple-400" />
                    )}
                    {category === "kex" && (
                      <Key className="w-6 h-6 text-blue-400" />
                    )}
                    <h3 className="text-xl font-bold text-white uppercase">
                      {category === "cipher"
                        ? "Cipher Algorithms"
                        : category === "macs"
                          ? "MAC Algorithms"
                          : "KEX Algorithms"}
                    </h3>
                    <span className="text-xs text-gray-500 font-mono">
                      (
                      {
                        algorithms.filter((a) =>
                          a.build.includes(buildType),
                        ).length
                      }{" "}
                      algorithms)
                    </span>
                  </div>

                  <div className="grid grid-cols-1 gap-3">
                    {algorithms
                      .filter((algo) =>
                        algo.build.includes(buildType),
                      )
                      .map((algo, idx) => (
                        <div
                          key={idx}
                          className={`flex items-center justify-between p-4 rounded-lg border ${getSecurityColor(algo.security)} transition-all hover:shadow-lg`}
                          style={{
                            animation:
                              "fadeInUp 0.5s ease-out forwards",
                            animationDelay: `${idx * 50}ms`,
                            opacity: 0,
                          }}
                        >
                          <div className="flex items-center gap-4 flex-1">
                            {getStatusIcon(algo.status)}
                            <div>
                              <div className="font-mono text-sm font-semibold">
                                {algo.name}
                              </div>
                              <div className="text-xs opacity-70">
                                Release: {algo.release}
                              </div>
                            </div>
                          </div>

                          <div className="flex items-center gap-3">
                            <span
                              className={`px-3 py-1 rounded text-xs font-bold uppercase ${
                                algo.status === "default"
                                  ? "bg-green-500/20 text-green-400"
                                  : algo.status === "available"
                                    ? "bg-blue-500/20 text-blue-400"
                                    : "bg-red-500/20 text-red-400"
                              }`}
                            >
                              {algo.status}
                            </span>
                            <span
                              className={`px-3 py-1 rounded text-xs font-bold uppercase ${
                                algo.security === "high"
                                  ? "bg-green-500/20 text-green-400"
                                  : algo.security === "medium"
                                    ? "bg-yellow-500/20 text-yellow-400"
                                    : "bg-red-500/20 text-red-400"
                              }`}
                            >
                              {algo.security}
                            </span>
                          </div>
                        </div>
                      ))}
                  </div>
                </div>
              ),
            )}

            {/* Important Notes */}
            <div className="mt-6 p-4 bg-blue-500/10 border border-blue-500/30 rounded-lg">
              <div className="flex items-start gap-3">
                <Info className="w-5 h-5 text-blue-400 flex-shrink-0 mt-0.5" />
                <div className="text-sm text-blue-300 space-y-2">
                  <p className="font-semibold">
                    Important Notes:
                  </p>
                  <ul className="list-disc list-inside space-y-1 text-xs">
                    <li>
                      KEX algorithms are not configurable in
                      StarOS - CLI changes not applicable
                    </li>
                    <li>
                      Trusted builds remove ETM MAC algorithms
                      for enhanced security
                    </li>
                    <li>
                      OpenSSH to CiscoSSH migration completed in
                      Release 21.16+
                    </li>
                    <li>
                      Default algorithms optimized for FIPS
                      140-2 compliance
                    </li>
                  </ul>
                </div>
              </div>
            </div>
          </div>
        )}

        {/* VM Hardware View */}
        {selectedCategory === "hardware" && (
          <div className="p-6 space-y-6">
            <div className="flex items-center gap-3 mb-4">
              <Cpu className="w-6 h-6 text-purple-400" />
              <h3 className="text-xl font-bold text-white">
                VM Hardware Configuration
              </h3>
              <span className="text-xs text-gray-500 font-mono">
                ({vmHardwareConfigs.length} cards)
              </span>
            </div>

            {vmHardwareConfigs.map((config, idx) => (
              <div
                key={idx}
                className="bg-gray-800/50 border border-purple-500/20 rounded-lg p-6"
                style={{
                  animation: "fadeInUp 0.5s ease-out forwards",
                  animationDelay: `${idx * 100}ms`,
                  opacity: 0,
                }}
              >
                <div className="flex items-center justify-between mb-4">
                  <div className="flex items-center gap-3">
                    <Server className="w-6 h-6 text-purple-400" />
                    <h4 className="text-lg font-bold text-white">
                      Card {config.card}
                    </h4>
                  </div>
                  {config.optimum && (
                    <span className="px-3 py-1 bg-green-500/20 border border-green-500/40 text-green-400 rounded text-xs font-bold">
                      OPTIMUM CONFIG
                    </span>
                  )}
                </div>

                <div className="grid grid-cols-3 gap-4">
                  <div className="bg-black/20 rounded p-3 border border-gray-700/40">
                    <div className="text-xs text-gray-400 mb-1">
                      CPU Configuration
                    </div>
                    <div className="font-mono text-sm text-white">
                      {config.cpuNodes} Node / {config.cpuCores}{" "}
                      Cores
                    </div>
                  </div>

                  <div className="bg-black/20 rounded p-3 border border-gray-700/40">
                    <div className="text-xs text-gray-400 mb-1">
                      Memory
                    </div>
                    <div className="font-mono text-sm text-white">
                      {config.memory}
                    </div>
                  </div>

                  <div className="bg-black/20 rounded p-3 border border-gray-700/40">
                    <div className="text-xs text-gray-400 mb-1">
                      Driver
                    </div>
                    <div className="font-mono text-sm text-cyan-400">
                      {config.driver}
                    </div>
                  </div>
                </div>

                <div className="mt-4 flex items-center gap-2 text-xs text-gray-400">
                  <HardDrive className="w-4 h-4" />
                  <span>
                    Hugepage Size:{" "}
                    <span className="text-white font-mono">
                      {config.hugepage}
                    </span>
                  </span>
                </div>
              </div>
            ))}

            {/* Verification Commands */}
            <div className="mt-6 p-4 bg-cyan-500/10 border border-cyan-500/30 rounded-lg">
              <div className="flex items-start gap-3">
                <Info className="w-5 h-5 text-cyan-400 flex-shrink-0 mt-0.5" />
                <div className="text-sm text-cyan-300 space-y-2">
                  <p className="font-semibold">
                    Verification Commands:
                  </p>
                  <div className="space-y-1 text-xs font-mono">
                    <div className="bg-black/30 rounded px-3 py-2">
                      show cloud hardware [card_number]
                    </div>
                    <div className="bg-black/30 rounded px-3 py-2">
                      show hardware optimum
                    </div>
                    <div className="bg-black/30 rounded px-3 py-2">
                      show cloud hardware test [card_number]
                    </div>
                    <div className="bg-black/30 rounded px-3 py-2">
                      show cloud configuration [card_number]
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        )}

        {/* NPM Imports View */}
        {selectedCategory === "imports" && (
          <div className="p-6 space-y-6">
            <div className="flex items-center gap-3 mb-4">
              <Package className="w-6 h-6 text-blue-400" />
              <h3 className="text-xl font-bold text-white">
                NPM Package Imports
              </h3>
              <span className="text-xs text-gray-500 font-mono">
                ({importModules.length} modules)
              </span>
            </div>

            <div className="grid grid-cols-2 gap-4">
              {importModules.map((module, idx) => (
                <div
                  key={idx}
                  className="bg-gray-800/50 border border-blue-500/20 rounded-lg p-4 hover:border-blue-500/40 transition-all"
                  style={{
                    animation:
                      "fadeInUp 0.5s ease-out forwards",
                    animationDelay: `${idx * 50}ms`,
                    opacity: 0,
                  }}
                >
                  <div className="flex items-center justify-between mb-3">
                    <div className="flex items-center gap-2">
                      <Network className="w-5 h-5 text-blue-400" />
                      <h4 className="font-bold text-white">
                        {module.name}
                      </h4>
                    </div>
                    <span className="px-2 py-1 bg-green-500/20 border border-green-500/40 text-green-400 rounded text-xs font-bold">
                      {module.status.toUpperCase()}
                    </span>
                  </div>

                  <div className="space-y-2 text-xs">
                    <div className="flex justify-between">
                      <span className="text-gray-400">
                        Version:
                      </span>
                      <span className="font-mono text-cyan-400">
                        {module.version}
                      </span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-gray-400">
                        Type:
                      </span>
                      <span className="text-white">
                        {module.type}
                      </span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-gray-400">
                        Source:
                      </span>
                      <span className="text-purple-400 font-mono">
                        {module.source}
                      </span>
                    </div>
                  </div>
                </div>
              ))}
            </div>

            {/* Import Statistics */}
            <div className="grid grid-cols-3 gap-4 mt-6">
              <div className="bg-cyan-500/10 border border-cyan-500/30 rounded-lg p-4">
                <div className="text-2xl font-bold text-cyan-400">
                  {importModules.length}
                </div>
                <div className="text-xs text-gray-400 mt-1">
                  Total Packages
                </div>
              </div>
              <div className="bg-green-500/10 border border-green-500/30 rounded-lg p-4">
                <div className="text-2xl font-bold text-green-400">
                  {
                    importModules.filter(
                      (m) => m.status === "active",
                    ).length
                  }
                </div>
                <div className="text-xs text-gray-400 mt-1">
                  Active Imports
                </div>
              </div>
              <div className="bg-purple-500/10 border border-purple-500/30 rounded-lg p-4">
                <div className="text-2xl font-bold text-purple-400">
                  100%
                </div>
                <div className="text-xs text-gray-400 mt-1">
                  Coverage
                </div>
              </div>
            </div>
          </div>
        )}
      </div>

      {/* Compliance Banner */}
      <div className="bg-gradient-to-r from-green-900/20 to-emerald-900/20 border border-green-500/30 rounded-lg p-4">
        <div className="flex items-center gap-3">
          <CheckCircle2 className="w-6 h-6 text-green-400" />
          <div>
            <div className="font-bold text-green-400">
              StarOS Release 21.22 Compliant
            </div>
            <div className="text-xs text-gray-400 mt-1">
              Cisco ASR 5500 / VPC-DI Platform - FIPS 140-2
              Level 3 - All algorithms verified and validated
            </div>
          </div>
        </div>
      </div>

      <style>{`
        @keyframes fadeInUp {
          from {
            opacity: 0;
            transform: translateY(10px);
          }
          to {
            opacity: 1;
            transform: translateY(0);
          }
        }
      `}</style>
    </div>
  );
}