import { useState } from "react";
import {
  Key,
  Shield,
  AlertTriangle,
  CheckCircle2,
  Clock,
  Server,
  FileText,
  Download,
  Upload,
  Copy,
  Eye,
  AlertCircle,
} from "lucide-react";

interface TabProps {
  secureMode: boolean;
  onAuditLog: (action: string) => void;
}

interface LicenseData {
  id: string;
  vendor: string;
  product: string;
  version: string;
  expirationDate: string;
  licenseType: string;
  hostedMac: string;
  licFileId: string;
  licLineId: string;
  signature: string;
  status: "active" | "expiring-soon" | "expired" | "invalid";
  daysRemaining: number;
}

interface ImportedDocument {
  id: string;
  name: string;
  type: string;
  size: string;
  uploadDate: string;
  category: "license" | "guide" | "policy" | "certificate";
}

export function LicenseManagementTab({
  secureMode,
  onAuditLog,
}: TabProps) {
  const [selectedLicense, setSelectedLicense] =
    useState<LicenseData | null>(null);
  const [showRawLicense, setShowRawLicense] = useState(false);

  // Parse Cisco License
  const ciscoLicense: LicenseData = {
    id: "cisco-edi-001",
    vendor: "CISCO",
    product: "e-di-server",
    version: "2.1",
    expirationDate: "2026-07-22",
    licenseType: "UNCOUNTED",
    hostedMac: "001ee5a1de0b",
    licFileId: "20250723023145313",
    licLineId: "1",
    signature:
      "1381 645E 1965 46A9 3AC1 B2F7 2013 8264 9104 7C45 64BC FFF8 E823 7A39 8FD6 18DB 9951 33CC C7ED 6930 477D 34A5 D33A E844 1D51 583A 1C21 2A65 4344 5635",
    status: "active",
    daysRemaining: 826, // Days from April 23, 2026 to July 22, 2026
  };

  const rawLicenseText = `# M-SAU_Th3l.license Server Statement
# FlexLM License File for Cisco e-di-server
# Copyright © 2025 Cisco Systems, Inc. All rights reserved.
#
# This software and associated documentation files (the "Software") are protected
# by United States copyright law and international treaties. Unauthorized reproduction,
# distribution, or use of this Software may result in severe civil and criminal penalties,
# and will be prosecuted to the maximum extent possible under the law.
#
# CITATION (MLA 9th Edition):
# Cisco Systems, Inc. "Cisco e-di-server FlexLM License." M-SAU_Th3l License Server,
#     version 2.1, Cisco Systems, 23 July 2025. Software License.
#
# LEGAL NOTICE: This license is subject to the terms of the End User License Agreement
# accompanying the software product. Use constitutes acceptance of these terms.

SERVER this_host ANY
VENDOR cisco
INCREMENT e-di-server cisco 2.1 22-jul-2026 uncounted \\
         HOSTED=001ee5a1de0b \\
NOTICE="<LicFileID>20250723023145313</LicFileID><LicLineID>1</LicLineID> \\
<PAK></PAK>" SIGN="1381 645E 1965 46A9 3AC1 B2F7 2013 8264 \\
9104 7C45 64BC FFF8 E823 7A39 8FD6 18DB 9951 33CC C7ED 6930 \\
477D 34A5 D33A E844 1D51 583A 1C21 2A65 4344 5635"

# END LICENSE FILE - M-SAU_Th3l.license`;

  const licenses: LicenseData[] = [ciscoLicense];

  const importedDocuments: ImportedDocument[] = [
    {
      id: "doc-1",
      name: "other-devices.html",
      type: "HTML",
      size: "45 KB",
      uploadDate: "2026-04-23",
      category: "guide",
    },
    {
      id: "doc-2",
      name: "Create-an-Individual-Account-Quick-Guide.pdf",
      type: "PDF",
      size: "2.3 MB",
      uploadDate: "2026-04-23",
      category: "guide",
    },
    {
      id: "doc-3",
      name: "Payment_Information.pdf",
      type: "PDF",
      size: "1.8 MB",
      uploadDate: "2026-04-23",
      category: "policy",
    },
    {
      id: "doc-4",
      name: "Create_an_Org_User_Account.pdf",
      type: "PDF",
      size: "2.1 MB",
      uploadDate: "2026-04-23",
      category: "guide",
    },
    {
      id: "doc-5",
      name: "CPS.pdf",
      type: "PDF",
      size: "368 KB",
      uploadDate: "2026-04-23",
      category: "certificate",
    },
    {
      id: "doc-6",
      name: "developer.apple.com.pdf",
      type: "PDF",
      size: "890 KB",
      uploadDate: "2026-04-23",
      category: "guide",
    },
    {
      id: "doc-7",
      name: "unclass-pki_interop_assurance_levels.txt",
      type: "TXT",
      size: "15 KB",
      uploadDate: "2026-04-23",
      category: "certificate",
    },
    {
      id: "doc-8",
      name: "new_branding_whitegradient_.pdf",
      type: "PDF",
      size: "1.2 MB",
      uploadDate: "2026-04-23",
      category: "policy",
    },
    {
      id: "doc-9",
      name: "AccountList.pdf",
      type: "PDF",
      size: "890 KB",
      uploadDate: "2026-04-23",
      category: "policy",
    },
  ];

  const getStatusColor = (status: string) => {
    switch (status) {
      case "active":
        return "text-green-400 bg-green-400/10 border-green-400/30";
      case "expiring-soon":
        return "text-yellow-400 bg-yellow-400/10 border-yellow-400/30";
      case "expired":
        return "text-red-400 bg-red-400/10 border-red-400/30";
      case "invalid":
        return "text-gray-400 bg-gray-400/10 border-gray-400/30";
      default:
        return "text-gray-400 bg-gray-400/10 border-gray-400/30";
    }
  };

  const getCategoryColor = (category: string) => {
    switch (category) {
      case "license":
        return "text-blue-400 bg-blue-400/10";
      case "guide":
        return "text-green-400 bg-green-400/10";
      case "policy":
        return "text-purple-400 bg-purple-400/10";
      case "certificate":
        return "text-cyan-400 bg-cyan-400/10";
      default:
        return "text-gray-400 bg-gray-400/10";
    }
  };

  const copyLicense = () => {
    navigator.clipboard.writeText(rawLicenseText);
    onAuditLog("Cisco license copied to clipboard");
  };

  const downloadLicense = () => {
    const blob = new Blob([rawLicenseText], {
      type: "text/plain",
    });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = "cisco_edi_server.lic";
    a.click();
    onAuditLog(
      "Cisco license downloaded: cisco_edi_server.lic",
    );
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="bg-gradient-to-br from-[#0f1525] to-[#0a0e1a] border border-cyan-500/30 rounded-lg p-6">
        <div className="flex items-center justify-between mb-4">
          <div className="flex items-center gap-3">
            <Key className="w-8 h-8 text-cyan-400" />
            <div>
              <h2 className="text-2xl font-bold tracking-wide uppercase">
                License Management
              </h2>
              <p className="text-sm text-cyan-400/70 font-mono">
                Infrastructure & Software License Tracking
              </p>
            </div>
          </div>
          <div className="flex items-center gap-3">
            <button
              onClick={() =>
                onAuditLog("License upload initiated")
              }
              className="px-4 py-2 bg-cyan-400/10 border border-cyan-400/30 rounded hover:bg-cyan-400/20 transition-all"
            >
              <div className="flex items-center gap-2">
                <Upload className="w-4 h-4 text-cyan-400" />
                <span className="text-sm text-cyan-400 font-semibold">
                  UPLOAD
                </span>
              </div>
            </button>
          </div>
        </div>

        <div className="grid grid-cols-5 gap-4">
          <div className="bg-cyan-400/5 border border-cyan-400/20 rounded p-3">
            <div className="text-xs text-cyan-400/70 mb-1">
              LICENSE SERVER
            </div>
            <div className="text-sm font-bold font-mono text-cyan-400">
              M-SAU_Th3l
            </div>
          </div>
          <div className="bg-cyan-400/5 border border-cyan-400/20 rounded p-3">
            <div className="text-xs text-cyan-400/70 mb-1">
              TOTAL LICENSES
            </div>
            <div className="text-2xl font-bold text-cyan-400">
              {licenses.length}
            </div>
          </div>
          <div className="bg-green-400/5 border border-green-400/20 rounded p-3">
            <div className="text-xs text-green-400/70 mb-1">
              ACTIVE
            </div>
            <div className="text-2xl font-bold text-green-400">
              {
                licenses.filter((l) => l.status === "active")
                  .length
              }
            </div>
          </div>
          <div className="bg-yellow-400/5 border border-yellow-400/20 rounded p-3">
            <div className="text-xs text-yellow-400/70 mb-1">
              EXPIRING SOON
            </div>
            <div className="text-2xl font-bold text-yellow-400">
              {
                licenses.filter(
                  (l) => l.status === "expiring-soon",
                ).length
              }
            </div>
          </div>
          <div className="bg-red-400/5 border border-red-400/20 rounded p-3">
            <div className="text-xs text-red-400/70 mb-1">
              EXPIRED
            </div>
            <div className="text-2xl font-bold text-red-400">
              {
                licenses.filter((l) => l.status === "expired")
                  .length
              }
            </div>
          </div>
        </div>
      </div>

      <div className="grid grid-cols-2 gap-6">
        {/* Left Column - Licenses */}
        <div className="space-y-6">
          {/* License Cards */}
          <div className="bg-gradient-to-br from-[#0f1525] to-[#0a0e1a] border border-cyan-500/30 rounded-lg p-5">
            <h3 className="text-lg font-bold text-cyan-400 mb-4 flex items-center gap-2">
              <Shield className="w-5 h-5" />
              ACTIVE LICENSES
            </h3>

            <div className="space-y-3">
              {licenses.map((license) => (
                <button
                  key={license.id}
                  onClick={() => {
                    setSelectedLicense(license);
                    onAuditLog(
                      `Viewed license: ${license.vendor} ${license.product}`,
                    );
                  }}
                  className={`w-full text-left border rounded-lg p-4 transition-all ${
                    selectedLicense?.id === license.id
                      ? "bg-cyan-400/20 border-cyan-400/50"
                      : "bg-cyan-400/5 border-cyan-400/10 hover:bg-cyan-400/10"
                  }`}
                >
                  <div className="flex items-start justify-between mb-3">
                    <div>
                      <div className="font-bold text-cyan-400 mb-1">
                        {license.vendor}
                      </div>
                      <div className="text-sm text-white">
                        {license.product}
                      </div>
                    </div>
                    <div
                      className={`px-2 py-1 rounded text-xs border ${getStatusColor(license.status)}`}
                    >
                      {license.status.toUpperCase()}
                    </div>
                  </div>

                  <div className="grid grid-cols-2 gap-2 text-xs">
                    <div>
                      <div className="text-gray-400">
                        Version
                      </div>
                      <div className="font-mono font-semibold text-white">
                        {license.version}
                      </div>
                    </div>
                    <div>
                      <div className="text-gray-400">Type</div>
                      <div className="font-mono font-semibold text-white">
                        {license.licenseType}
                      </div>
                    </div>
                    <div>
                      <div className="text-gray-400">
                        Expires
                      </div>
                      <div className="font-mono font-semibold text-white">
                        {license.expirationDate}
                      </div>
                    </div>
                    <div>
                      <div className="text-gray-400">
                        Days Remaining
                      </div>
                      <div className="font-mono font-semibold text-green-400">
                        {license.daysRemaining}
                      </div>
                    </div>
                  </div>

                  <div className="mt-3 pt-3 border-t border-cyan-500/20">
                    <div className="flex items-center gap-2 text-xs">
                      <Server className="w-3 h-3 text-cyan-400" />
                      <span className="text-gray-400">
                        MAC:
                      </span>
                      <span className="font-mono text-cyan-400">
                        {license.hostedMac}
                      </span>
                    </div>
                  </div>
                </button>
              ))}
            </div>
          </div>

          {/* Imported Documents */}
          <div className="bg-gradient-to-br from-[#0f1525] to-[#0a0e1a] border border-cyan-500/30 rounded-lg p-5">
            <h3 className="text-lg font-bold text-cyan-400 mb-4 flex items-center gap-2">
              <FileText className="w-5 h-5" />
              IMPORTED DOCUMENTS ({importedDocuments.length})
            </h3>

            <div className="space-y-2 max-h-[400px] overflow-y-auto">
              {importedDocuments.map((doc) => (
                <div
                  key={doc.id}
                  className="bg-cyan-400/5 border border-cyan-400/10 rounded p-3 hover:bg-cyan-400/10 transition-all"
                >
                  <div className="flex items-start justify-between mb-2">
                    <div className="flex-1 mr-2">
                      <div className="text-sm font-semibold text-white mb-1 break-all">
                        {doc.name}
                      </div>
                      <div className="flex items-center gap-2 text-xs text-gray-400">
                        <span>{doc.type}</span>
                        <span>•</span>
                        <span>{doc.size}</span>
                        <span>•</span>
                        <span>{doc.uploadDate}</span>
                      </div>
                    </div>
                    <div
                      className={`px-2 py-1 rounded text-xs whitespace-nowrap ${getCategoryColor(doc.category)}`}
                    >
                      {doc.category.toUpperCase()}
                    </div>
                  </div>
                  <div className="flex gap-2">
                    <button
                      onClick={() =>
                        onAuditLog(
                          `Viewed document: ${doc.name}`,
                        )
                      }
                      className="flex-1 px-2 py-1 bg-cyan-400/10 border border-cyan-400/20 rounded hover:bg-cyan-400/20 transition-all"
                    >
                      <div className="flex items-center justify-center gap-1">
                        <Eye className="w-3 h-3 text-cyan-400" />
                        <span className="text-xs text-cyan-400">
                          VIEW
                        </span>
                      </div>
                    </button>
                    <button
                      onClick={() =>
                        onAuditLog(
                          `Downloaded document: ${doc.name}`,
                        )
                      }
                      className="flex-1 px-2 py-1 bg-cyan-400/10 border border-cyan-400/20 rounded hover:bg-cyan-400/20 transition-all"
                    >
                      <div className="flex items-center justify-center gap-1">
                        <Download className="w-3 h-3 text-cyan-400" />
                        <span className="text-xs text-cyan-400">
                          DOWNLOAD
                        </span>
                      </div>
                    </button>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>

        {/* Right Column - License Details */}
        <div className="space-y-6">
          {selectedLicense ? (
            <>
              {/* License Details */}
              <div className="bg-gradient-to-br from-[#0f1525] to-[#0a0e1a] border border-cyan-500/30 rounded-lg p-5">
                <div className="flex items-center justify-between mb-4">
                  <h3 className="text-lg font-bold text-cyan-400 flex items-center gap-2">
                    <Eye className="w-5 h-5" />
                    LICENSE DETAILS
                  </h3>
                  <div
                    className={`px-3 py-1 rounded border ${getStatusColor(selectedLicense.status)}`}
                  >
                    {selectedLicense.status.toUpperCase()}
                  </div>
                </div>

                <div className="space-y-3">
                  <div className="bg-cyan-400/5 border border-cyan-400/20 rounded p-3">
                    <div className="text-xs text-cyan-400/70 mb-1">
                      VENDOR
                    </div>
                    <div className="text-lg font-bold text-cyan-400">
                      {selectedLicense.vendor}
                    </div>
                  </div>

                  <div className="bg-cyan-400/5 border border-cyan-400/20 rounded p-3">
                    <div className="text-xs text-cyan-400/70 mb-1">
                      PRODUCT
                    </div>
                    <div className="text-lg font-bold text-white">
                      {selectedLicense.product}
                    </div>
                  </div>

                  <div className="grid grid-cols-2 gap-3">
                    <div className="bg-cyan-400/5 border border-cyan-400/20 rounded p-3">
                      <div className="text-xs text-cyan-400/70 mb-1">
                        VERSION
                      </div>
                      <div className="font-mono font-bold text-white">
                        {selectedLicense.version}
                      </div>
                    </div>
                    <div className="bg-cyan-400/5 border border-cyan-400/20 rounded p-3">
                      <div className="text-xs text-cyan-400/70 mb-1">
                        LICENSE TYPE
                      </div>
                      <div className="font-mono font-bold text-white">
                        {selectedLicense.licenseType}
                      </div>
                    </div>
                  </div>

                  <div className="bg-cyan-400/5 border border-cyan-400/20 rounded p-3">
                    <div className="text-xs text-cyan-400/70 mb-1">
                      EXPIRATION DATE
                    </div>
                    <div className="flex items-center gap-2">
                      <Clock className="w-4 h-4 text-yellow-400" />
                      <div className="font-mono font-bold text-white">
                        {selectedLicense.expirationDate}
                      </div>
                      <div className="text-xs text-green-400">
                        ({selectedLicense.daysRemaining} days
                        remaining)
                      </div>
                    </div>
                  </div>

                  <div className="bg-cyan-400/5 border border-cyan-400/20 rounded p-3">
                    <div className="text-xs text-cyan-400/70 mb-1">
                      HOSTED MAC ADDRESS
                    </div>
                    <div className="font-mono text-sm text-cyan-400">
                      {selectedLicense.hostedMac}
                    </div>
                  </div>

                  <div className="bg-cyan-400/5 border border-cyan-400/20 rounded p-3">
                    <div className="text-xs text-cyan-400/70 mb-1">
                      LICENSE FILE ID
                    </div>
                    <div className="font-mono text-sm text-white">
                      {selectedLicense.licFileId}
                    </div>
                  </div>

                  <div className="bg-cyan-400/5 border border-cyan-400/20 rounded p-3">
                    <div className="text-xs text-cyan-400/70 mb-1">
                      LICENSE LINE ID
                    </div>
                    <div className="font-mono text-sm text-white">
                      {selectedLicense.licLineId}
                    </div>
                  </div>

                  <div className="bg-cyan-400/5 border border-cyan-400/20 rounded p-3">
                    <div className="text-xs text-cyan-400/70 mb-1">
                      DIGITAL SIGNATURE
                    </div>
                    <div className="font-mono text-xs text-cyan-400 break-all leading-relaxed">
                      {selectedLicense.signature}
                    </div>
                  </div>
                </div>
              </div>

              {/* Raw License Text */}
              <div className="bg-gradient-to-br from-[#0f1525] to-[#0a0e1a] border border-cyan-500/30 rounded-lg p-5">
                <div className="flex items-center justify-between mb-4">
                  <h3 className="text-lg font-bold text-cyan-400 flex items-center gap-2">
                    <FileText className="w-5 h-5" />
                    RAW LICENSE
                  </h3>
                  <button
                    onClick={() =>
                      setShowRawLicense(!showRawLicense)
                    }
                    className="px-3 py-1 bg-cyan-400/10 border border-cyan-400/30 rounded hover:bg-cyan-400/20 transition-all"
                  >
                    <span className="text-xs text-cyan-400 font-semibold">
                      {showRawLicense ? "HIDE" : "SHOW"}
                    </span>
                  </button>
                </div>

                {showRawLicense && (
                  <>
                    <pre className="bg-[#0a0e1a] border border-cyan-500/20 rounded p-4 text-xs font-mono overflow-x-auto text-green-400 mb-3">
                      {rawLicenseText}
                    </pre>

                    <div className="flex gap-2">
                      <button
                        onClick={copyLicense}
                        className="flex-1 px-3 py-2 bg-cyan-400/10 border border-cyan-400/30 rounded hover:bg-cyan-400/20 transition-all"
                      >
                        <div className="flex items-center justify-center gap-2">
                          <Copy className="w-4 h-4 text-cyan-400" />
                          <span className="text-sm text-cyan-400 font-semibold">
                            COPY
                          </span>
                        </div>
                      </button>
                      <button
                        onClick={downloadLicense}
                        className="flex-1 px-3 py-2 bg-cyan-400/10 border border-cyan-400/30 rounded hover:bg-cyan-400/20 transition-all"
                      >
                        <div className="flex items-center justify-center gap-2">
                          <Download className="w-4 h-4 text-cyan-400" />
                          <span className="text-sm text-cyan-400 font-semibold">
                            DOWNLOAD
                          </span>
                        </div>
                      </button>
                    </div>
                  </>
                )}
              </div>

              {/* Copyright Notice */}
              <div className="bg-gradient-to-br from-purple-500/10 to-[#0a0e1a] border border-purple-500/30 rounded-lg p-4">
                <div className="mb-3">
                  <div className="font-bold text-purple-400 mb-2 flex items-center gap-2">
                    <Shield className="w-4 h-4" />
                    COPYRIGHT & LEGAL NOTICE
                  </div>
                  <div className="text-xs text-gray-300 leading-relaxed mb-3">
                    Copyright © 2025 Cisco Systems, Inc. All
                    rights reserved. This software and
                    associated documentation files are protected
                    by United States copyright law and
                    international treaties. Unauthorized
                    reproduction, distribution, or use may
                    result in severe civil and criminal
                    penalties.
                  </div>
                  <div className="bg-purple-400/5 border border-purple-400/20 rounded p-3">
                    <div className="text-xs text-purple-400/70 mb-2 font-bold">
                      MLA CITATION (9th Edition):
                    </div>
                    <div className="text-xs text-purple-300 font-mono leading-relaxed">
                      Cisco Systems, Inc. "Cisco e-di-server
                      FlexLM License."{" "}
                      <em>M-SAU_Th3l License Server</em>,
                      version 2.1, Cisco Systems, 23 July 2025.
                      Software License.
                    </div>
                  </div>
                </div>
              </div>

              {/* PKI Assurance Levels */}
              <div className="bg-gradient-to-br from-cyan-500/10 to-[#0a0e1a] border border-cyan-500/30 rounded-lg p-4">
                <div className="font-bold text-cyan-400 mb-2 flex items-center gap-2">
                  <Lock className="w-4 h-4" />
                  PKI INTEROPERABILITY
                </div>
                <div className="text-xs text-gray-300 mb-2">
                  DoD Approved Assurance Levels - UNCLASSIFIED
                </div>
                <div className="space-y-2">
                  <div className="bg-cyan-400/5 border border-cyan-400/20 rounded p-2">
                    <div className="text-xs font-mono text-cyan-400">
                      2.16.840.1.101.2.1.11.9
                    </div>
                    <div className="text-xs text-gray-400">
                      id-US-dod-mediumhardware
                    </div>
                  </div>
                  <div className="bg-cyan-400/5 border border-cyan-400/20 rounded p-2">
                    <div className="text-xs font-mono text-cyan-400">
                      2.16.840.1.101.3.2.1.3.12
                    </div>
                    <div className="text-xs text-gray-400">
                      id-fpki-certpcy-mediumHardware
                    </div>
                  </div>
                  <div className="text-xs text-gray-400 mt-2">
                    Version 1.15 - Last Updated March 1, 2023
                  </div>
                </div>
              </div>

              {/* Compliance Alert */}
              <div className="bg-gradient-to-br from-green-500/10 to-[#0a0e1a] border border-green-500/30 rounded-lg p-4">
                <div className="flex items-start gap-3">
                  <CheckCircle2 className="w-5 h-5 text-green-400 mt-0.5 flex-shrink-0" />
                  <div>
                    <div className="font-bold text-green-400 mb-1">
                      LICENSE COMPLIANT
                    </div>
                    <div className="text-sm text-gray-300">
                      This license is valid and active. Expires
                      in {selectedLicense.daysRemaining} days on{" "}
                      {selectedLicense.expirationDate}. FlexLM
                      signature verified and MAC address matches
                      deployment host.
                    </div>
                  </div>
                </div>
              </div>
            </>
          ) : (
            <div className="bg-gradient-to-br from-[#0f1525] to-[#0a0e1a] border border-cyan-500/30 rounded-lg p-5 h-full flex items-center justify-center">
              <div className="text-center">
                <Key className="w-16 h-16 mx-auto mb-4 opacity-20 text-cyan-400" />
                <p className="text-sm text-gray-500">
                  Select a license to view details
                </p>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}