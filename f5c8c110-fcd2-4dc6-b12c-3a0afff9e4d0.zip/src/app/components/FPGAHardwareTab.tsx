import { useState } from "react";
import {
  Cpu,
  Upload,
  CheckCircle2,
  AlertTriangle,
  Zap,
  Layers,
  HardDrive,
  Shield,
  FileCode,
  Download,
  Lock,
  Activity,
} from "lucide-react";

interface FPGAHardwareTabProps {
  secureMode: boolean;
  onAuditLog: (action: string) => void;
}

interface FPGAComponent {
  partNumber: string;
  family: string;
  logicCells: string;
  blockRAM: string;
  dspSlices: number;
  transceivers: number;
  securityLevel: "Standard" | "Enhanced" | "Maximum";
  status: "Available" | "Deployed" | "Reserved";
}

const FPGA_COMPONENTS: FPGAComponent[] = [
  {
    partNumber: "XCVU3P",
    family: "VIRTEX UltraScale+",
    logicCells: "440K",
    blockRAM: "38.5 Mb",
    dspSlices: 2280,
    transceivers: 32,
    securityLevel: "Enhanced",
    status: "Available",
  },
  {
    partNumber: "XCVU5P",
    family: "VIRTEX UltraScale+",
    logicCells: "728K",
    blockRAM: "51.8 Mb",
    dspSlices: 3840,
    transceivers: 48,
    securityLevel: "Enhanced",
    status: "Deployed",
  },
  {
    partNumber: "XCVU7P",
    family: "VIRTEX UltraScale+",
    logicCells: "912K",
    blockRAM: "75.9 Mb",
    dspSlices: 4560,
    transceivers: 64,
    securityLevel: "Maximum",
    status: "Deployed",
  },
  {
    partNumber: "XCVU9P",
    family: "VIRTEX UltraScale+",
    logicCells: "1.14M",
    blockRAM: "132 Mb",
    dspSlices: 6840,
    transceivers: 64,
    securityLevel: "Maximum",
    status: "Reserved",
  },
  {
    partNumber: "XCVU11P",
    family: "VIRTEX UltraScale+",
    logicCells: "1.28M",
    blockRAM: "132 Mb",
    dspSlices: 9216,
    transceivers: 80,
    securityLevel: "Maximum",
    status: "Available",
  },
  {
    partNumber: "XCVU13P",
    family: "VIRTEX UltraScale+",
    logicCells: "1.73M",
    blockRAM: "176 Mb",
    dspSlices: 12288,
    transceivers: 96,
    securityLevel: "Maximum",
    status: "Available",
  },
  {
    partNumber: "XQVU5P",
    family: "VIRTEX UltraScale+ HBM",
    logicCells: "728K",
    blockRAM: "51.8 Mb",
    dspSlices: 3840,
    transceivers: 48,
    securityLevel: "Maximum",
    status: "Deployed",
  },
  {
    partNumber: "XQVU7P",
    family: "VIRTEX UltraScale+ HBM",
    logicCells: "912K",
    blockRAM: "75.9 Mb",
    dspSlices: 4560,
    transceivers: 64,
    securityLevel: "Maximum",
    status: "Available",
  },
  {
    partNumber: "XQVU9P",
    family: "VIRTEX UltraScale+ HBM",
    logicCells: "1.14M",
    blockRAM: "132 Mb",
    dspSlices: 6840,
    transceivers: 64,
    securityLevel: "Maximum",
    status: "Deployed",
  },
  {
    partNumber: "XQVU11P",
    family: "VIRTEX UltraScale+ HBM",
    logicCells: "1.28M",
    blockRAM: "132 Mb",
    dspSlices: 9216,
    transceivers: 80,
    securityLevel: "Maximum",
    status: "Reserved",
  },
];

export function FPGAHardwareTab({
  secureMode,
  onAuditLog,
}: FPGAHardwareTabProps) {
  const [selectedComponent, setSelectedComponent] =
    useState<FPGAComponent | null>(null);
  const [uploadedFile, setUploadedFile] = useState<File | null>(
    null,
  );
  const [uploadStatus, setUploadStatus] = useState<
    "idle" | "uploading" | "success" | "error"
  >("idle");
  const [designOptimization, setDesignOptimization] = useState<
    "area" | "power" | "performance"
  >("performance");
  const [filterStatus, setFilterStatus] =
    useState<string>("all");

  const handleComponentSelect = (component: FPGAComponent) => {
    setSelectedComponent(component);
    onAuditLog(
      `FPGA component selected: ${component.partNumber} - Security Level: ${component.securityLevel}`,
    );
  };

  const handleFileUpload = (
    event: React.ChangeEvent<HTMLInputElement>,
  ) => {
    const file = event.target.files?.[0];
    if (file) {
      setUploadedFile(file);
      setUploadStatus("uploading");
      onAuditLog(
        `XPF design file upload initiated: ${file.name} (${(file.size / 1024).toFixed(2)} KB)`,
      );

      // Simulate upload process
      setTimeout(() => {
        setUploadStatus("success");
        onAuditLog(
          `XPF design file upload completed: ${file.name} - Design validation passed`,
        );
      }, 2000);
    }
  };

  const handleConfigureComponent = () => {
    if (selectedComponent && secureMode) {
      onAuditLog(
        `FPGA configuration initiated: ${selectedComponent.partNumber} | ` +
          `Optimization: ${designOptimization.toUpperCase()} | ` +
          `Security: ${selectedComponent.securityLevel} | ` +
          `Design File: ${uploadedFile?.name || "None"}`,
      );
    }
  };

  const filteredComponents =
    filterStatus === "all"
      ? FPGA_COMPONENTS
      : FPGA_COMPONENTS.filter(
          (c) => c.status === filterStatus,
        );

  const stats = {
    total: FPGA_COMPONENTS.length,
    available: FPGA_COMPONENTS.filter(
      (c) => c.status === "Available",
    ).length,
    deployed: FPGA_COMPONENTS.filter(
      (c) => c.status === "Deployed",
    ).length,
    reserved: FPGA_COMPONENTS.filter(
      (c) => c.status === "Reserved",
    ).length,
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-4">
          <div className="p-3 rounded-lg bg-cyan-500/10 border border-cyan-500/30">
            <Cpu className="w-6 h-6 text-cyan-400" />
          </div>
          <div>
            <h2 className="text-2xl font-bold text-white tracking-wider">
              FPGA HARDWARE ASSET MANAGEMENT
            </h2>
            <p className="text-sm text-gray-400 font-mono">
              AMD Xilinx VIRTEX UltraScale+ Series • Design
              Optimization & Configuration
            </p>
          </div>
        </div>
      </div>

      {/* Stats Grid */}
      <div className="grid grid-cols-4 gap-4">
        <div className="p-4 rounded-lg bg-gradient-to-br from-cyan-500/10 to-blue-500/10 border border-cyan-500/20">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-xs text-gray-400 font-mono uppercase tracking-wider">
                Total Assets
              </p>
              <p className="text-3xl font-bold text-cyan-400 mt-1">
                {stats.total}
              </p>
            </div>
            <Layers className="w-8 h-8 text-cyan-400/50" />
          </div>
        </div>

        <div className="p-4 rounded-lg bg-gradient-to-br from-green-500/10 to-emerald-500/10 border border-green-500/20">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-xs text-gray-400 font-mono uppercase tracking-wider">
                Available
              </p>
              <p className="text-3xl font-bold text-green-400 mt-1">
                {stats.available}
              </p>
            </div>
            <CheckCircle2 className="w-8 h-8 text-green-400/50" />
          </div>
        </div>

        <div className="p-4 rounded-lg bg-gradient-to-br from-blue-500/10 to-indigo-500/10 border border-blue-500/20">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-xs text-gray-400 font-mono uppercase tracking-wider">
                Deployed
              </p>
              <p className="text-3xl font-bold text-blue-400 mt-1">
                {stats.deployed}
              </p>
            </div>
            <Activity className="w-8 h-8 text-blue-400/50" />
          </div>
        </div>

        <div className="p-4 rounded-lg bg-gradient-to-br from-yellow-500/10 to-amber-500/10 border border-yellow-500/20">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-xs text-gray-400 font-mono uppercase tracking-wider">
                Reserved
              </p>
              <p className="text-3xl font-bold text-yellow-400 mt-1">
                {stats.reserved}
              </p>
            </div>
            <Lock className="w-8 h-8 text-yellow-400/50" />
          </div>
        </div>
      </div>

      {/* Main Content Grid */}
      <div className="grid grid-cols-3 gap-6">
        {/* Component Selector */}
        <div className="col-span-2 space-y-4">
          <div className="flex items-center justify-between">
            <h3 className="text-lg font-bold text-white tracking-wider">
              COMPONENT INVENTORY
            </h3>
            <div className="flex gap-2">
              {["all", "Available", "Deployed", "Reserved"].map(
                (status) => (
                  <button
                    key={status}
                    onClick={() => setFilterStatus(status)}
                    className={`px-3 py-1.5 rounded text-xs font-mono tracking-wider transition-all ${
                      filterStatus === status
                        ? "bg-cyan-500/20 border border-cyan-500/50 text-cyan-400"
                        : "bg-gray-700/20 border border-gray-600/30 text-gray-400 hover:border-cyan-500/30"
                    }`}
                  >
                    {status === "all"
                      ? "ALL"
                      : status.toUpperCase()}
                  </button>
                ),
              )}
            </div>
          </div>

          <div className="space-y-3">
            {filteredComponents.map((component, idx) => (
              <div
                key={component.partNumber}
                onClick={() => handleComponentSelect(component)}
                className={`p-4 rounded-lg border cursor-pointer transition-all ${
                  selectedComponent?.partNumber ===
                  component.partNumber
                    ? "bg-cyan-500/10 border-cyan-500/50 shadow-lg shadow-cyan-500/20"
                    : "bg-[#0f1525]/50 border-cyan-500/20 hover:border-cyan-500/40 hover:bg-cyan-500/5"
                }`}
                style={{
                  animation: "fadeIn 0.3s ease-out",
                  animationDelay: `${idx * 50}ms`,
                }}
              >
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-4">
                    <div className="p-2 rounded bg-cyan-500/10 border border-cyan-500/30">
                      <Cpu className="w-5 h-5 text-cyan-400" />
                    </div>
                    <div>
                      <div className="flex items-center gap-3">
                        <span className="text-white font-bold text-lg font-mono">
                          {component.partNumber}
                        </span>
                        <span className="text-xs text-gray-400 font-mono">
                          {component.family}
                        </span>
                      </div>
                      <div className="flex items-center gap-4 mt-2 text-xs font-mono">
                        <div className="flex items-center gap-1">
                          <Layers className="w-3 h-3 text-cyan-400" />
                          <span className="text-gray-400">
                            Logic:
                          </span>
                          <span className="text-white font-semibold">
                            {component.logicCells}
                          </span>
                        </div>
                        <div className="flex items-center gap-1">
                          <HardDrive className="w-3 h-3 text-cyan-400" />
                          <span className="text-gray-400">
                            RAM:
                          </span>
                          <span className="text-white font-semibold">
                            {component.blockRAM}
                          </span>
                        </div>
                        <div className="flex items-center gap-1">
                          <Zap className="w-3 h-3 text-cyan-400" />
                          <span className="text-gray-400">
                            DSP:
                          </span>
                          <span className="text-white font-semibold">
                            {component.dspSlices}
                          </span>
                        </div>
                        <div className="flex items-center gap-1">
                          <Activity className="w-3 h-3 text-cyan-400" />
                          <span className="text-gray-400">
                            GTY:
                          </span>
                          <span className="text-white font-semibold">
                            {component.transceivers}
                          </span>
                        </div>
                      </div>
                    </div>
                  </div>

                  <div className="flex items-center gap-3">
                    <div
                      className={`px-3 py-1.5 rounded border text-xs font-mono font-semibold ${
                        component.securityLevel === "Maximum"
                          ? "bg-green-500/10 border-green-500/30 text-green-400"
                          : component.securityLevel ===
                              "Enhanced"
                            ? "bg-yellow-500/10 border-yellow-500/30 text-yellow-400"
                            : "bg-gray-500/10 border-gray-500/30 text-gray-400"
                      }`}
                    >
                      <Shield className="w-3 h-3 inline mr-1" />
                      {component.securityLevel}
                    </div>
                    <div
                      className={`px-3 py-1.5 rounded border text-xs font-mono font-semibold ${
                        component.status === "Available"
                          ? "bg-cyan-500/10 border-cyan-500/30 text-cyan-400"
                          : component.status === "Deployed"
                            ? "bg-blue-500/10 border-blue-500/30 text-blue-400"
                            : "bg-yellow-500/10 border-yellow-500/30 text-yellow-400"
                      }`}
                    >
                      {component.status}
                    </div>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Configuration Panel */}
        <div className="space-y-4">
          {/* Design File Upload */}
          <div className="p-4 rounded-lg bg-[#0f1525]/50 border border-cyan-500/20">
            <h3 className="text-sm font-bold text-white tracking-wider mb-3 flex items-center gap-2">
              <FileCode className="w-4 h-4 text-cyan-400" />
              XPF DESIGN FILE
            </h3>

            <label className="block">
              <input
                type="file"
                accept=".xpf,.xdc,.ucf"
                onChange={handleFileUpload}
                disabled={!secureMode}
                className="hidden"
              />
              <div
                className={`p-6 border-2 border-dashed rounded-lg text-center cursor-pointer transition-all ${
                  uploadStatus === "success"
                    ? "border-green-500/50 bg-green-500/5"
                    : "border-cyan-500/30 bg-cyan-500/5 hover:border-cyan-500/50 hover:bg-cyan-500/10"
                } ${!secureMode ? "opacity-50 cursor-not-allowed" : ""}`}
              >
                {uploadStatus === "uploading" ? (
                  <div className="space-y-2">
                    <Upload className="w-8 h-8 text-cyan-400 mx-auto animate-bounce" />
                    <p className="text-sm text-cyan-400 font-mono">
                      Uploading...
                    </p>
                  </div>
                ) : uploadStatus === "success" ? (
                  <div className="space-y-2">
                    <CheckCircle2 className="w-8 h-8 text-green-400 mx-auto" />
                    <p className="text-sm text-green-400 font-mono">
                      {uploadedFile?.name}
                    </p>
                    <p className="text-xs text-gray-400">
                      {(uploadedFile!.size / 1024).toFixed(2)}{" "}
                      KB
                    </p>
                  </div>
                ) : (
                  <div className="space-y-2">
                    <Upload className="w-8 h-8 text-cyan-400 mx-auto" />
                    <p className="text-sm text-cyan-400 font-mono">
                      Upload XPF File
                    </p>
                    <p className="text-xs text-gray-400">
                      Click to select or drag & drop
                    </p>
                  </div>
                )}
              </div>
            </label>
          </div>

          {/* Design Optimization */}
          <div className="p-4 rounded-lg bg-[#0f1525]/50 border border-cyan-500/20">
            <h3 className="text-sm font-bold text-white tracking-wider mb-3">
              OPTIMIZATION STRATEGY
            </h3>
            <div className="space-y-2">
              {[
                {
                  value: "performance",
                  label: "PERFORMANCE",
                  icon: Zap,
                  color: "cyan",
                },
                {
                  value: "power",
                  label: "POWER",
                  icon: Activity,
                  color: "green",
                },
                {
                  value: "area",
                  label: "AREA",
                  icon: Layers,
                  color: "blue",
                },
              ].map((opt) => {
                const Icon = opt.icon;
                const isSelected =
                  designOptimization === opt.value;
                return (
                  <button
                    key={opt.value}
                    onClick={() =>
                      setDesignOptimization(opt.value as any)
                    }
                    disabled={!secureMode}
                    className={`w-full flex items-center gap-3 p-3 rounded border transition-all ${
                      isSelected
                        ? `bg-${opt.color}-500/10 border-${opt.color}-500/50 text-${opt.color}-400`
                        : "bg-gray-700/20 border-gray-600/30 text-gray-400 hover:border-cyan-500/30"
                    } ${!secureMode ? "opacity-50 cursor-not-allowed" : ""}`}
                  >
                    <Icon className="w-4 h-4" />
                    <span className="text-sm font-mono tracking-wider">
                      {opt.label}
                    </span>
                  </button>
                );
              })}
            </div>
          </div>

          {/* Selected Component Info */}
          {selectedComponent && (
            <div className="p-4 rounded-lg bg-gradient-to-br from-cyan-500/10 to-blue-500/10 border border-cyan-500/30">
              <h3 className="text-sm font-bold text-white tracking-wider mb-3">
                SELECTED COMPONENT
              </h3>
              <div className="space-y-2 text-xs font-mono">
                <div className="flex justify-between">
                  <span className="text-gray-400">
                    Part Number:
                  </span>
                  <span className="text-white font-bold">
                    {selectedComponent.partNumber}
                  </span>
                </div>
                <div className="flex justify-between">
                  <span className="text-gray-400">
                    Security:
                  </span>
                  <span className="text-cyan-400 font-bold">
                    {selectedComponent.securityLevel}
                  </span>
                </div>
                <div className="flex justify-between">
                  <span className="text-gray-400">Status:</span>
                  <span className="text-cyan-400 font-bold">
                    {selectedComponent.status}
                  </span>
                </div>
              </div>
            </div>
          )}

          {/* Configure Button */}
          <button
            onClick={handleConfigureComponent}
            disabled={!secureMode || !selectedComponent}
            className="w-full flex items-center justify-center gap-2 px-4 py-3 bg-cyan-500/20 hover:bg-cyan-500/30 border border-cyan-500/50 rounded text-cyan-400 font-mono font-bold tracking-wider transition-all disabled:opacity-50 disabled:cursor-not-allowed"
          >
            <Cpu className="w-4 h-4" />
            CONFIGURE FPGA
          </button>
        </div>
      </div>

      {/* Security Notice */}
      {!secureMode && (
        <div className="p-4 rounded-lg bg-red-500/10 border border-red-500/30 flex items-center gap-3">
          <AlertTriangle className="w-5 h-5 text-red-400" />
          <div>
            <p className="text-sm text-red-400 font-semibold">
              SECURE MODE DISABLED
            </p>
            <p className="text-xs text-gray-400 mt-1">
              FPGA configuration and design file upload require
              RBAC validation. Enable secure mode to proceed.
            </p>
          </div>
        </div>
      )}
    </div>
  );
}