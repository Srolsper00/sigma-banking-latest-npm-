import { useState } from "react";
import {
  Server,
  Eye,
  EyeOff,
  Download,
  Filter,
  CheckCircle2,
  AlertTriangle,
  Clock,
} from "lucide-react";

interface DevicesTabProps {
  secureMode: boolean;
  onAuditLog: (message: string) => void;
}

type Criticality = "Critical" | "High" | "Medium" | "Low";
type Status = "Active" | "Inactive" | "Maintenance";

interface Device {
  id: string;
  name: string;
  criticality: Criticality;
  status: Status;
  location: string;
  ipAddress: string;
  lastMaintenance: string;
  owner: string;
  description: string;
}

const devices: Device[] = [
  {
    id: "DEV-001",
    name: "Core Banking Server Cluster",
    criticality: "Critical",
    status: "Active",
    location: "Primary Data Center - Rack A12",
    ipAddress: "10.50.1.10-15",
    lastMaintenance: "2026-04-10",
    owner: "Infrastructure Team",
    description:
      "Primary processing cluster for all banking transactions and account management",
  },
  {
    id: "DEV-002",
    name: "Payment Gateway Server",
    criticality: "Critical",
    status: "Active",
    location: "Primary Data Center - Rack B04",
    ipAddress: "10.50.2.20",
    lastMaintenance: "2026-04-12",
    owner: "Payment Operations",
    description:
      "Real-time payment processing gateway for ACH, Wire, and RTP transactions",
  },
  {
    id: "DEV-003",
    name: "Tokenization Vault Appliance",
    criticality: "Critical",
    status: "Active",
    location: "Secure Vault Room - HSM-01",
    ipAddress: "10.50.3.50",
    lastMaintenance: "2026-04-08",
    owner: "Security Team",
    description:
      "Hardware security module for DDA tokenization and key management",
  },
  {
    id: "DEV-004",
    name: "ATM Network Controllers",
    criticality: "High",
    status: "Active",
    location: "Network Operations Center",
    ipAddress: "10.60.1.100-105",
    lastMaintenance: "2026-04-05",
    owner: "Network Operations",
    description:
      "Central controllers managing ATM network communications and transactions",
  },
  {
    id: "DEV-005",
    name: "Backup Storage Array",
    criticality: "High",
    status: "Active",
    location: "Secondary Data Center - Storage Bay 3",
    ipAddress: "10.70.5.200",
    lastMaintenance: "2026-04-01",
    owner: "Data Management",
    description:
      "High-capacity storage array for disaster recovery and compliance backups",
  },
  {
    id: "DEV-006",
    name: "Compliance Workstations",
    criticality: "Medium",
    status: "Maintenance",
    location: "Compliance Office - Floor 3",
    ipAddress: "10.80.10.50-60",
    lastMaintenance: "2026-04-14",
    owner: "Compliance Department",
    description:
      "Dedicated workstations for audit reporting and regulatory compliance tasks",
  },
];

const criticalityColors = {
  Critical: {
    bg: "bg-red-500/10",
    border: "border-red-500/50",
    text: "text-red-400",
    badge: "bg-red-500",
  },
  High: {
    bg: "bg-amber-500/10",
    border: "border-amber-500/50",
    text: "text-amber-400",
    badge: "bg-amber-500",
  },
  Medium: {
    bg: "bg-cyan-500/10",
    border: "border-cyan-500/50",
    text: "text-cyan-400",
    badge: "bg-cyan-500",
  },
  Low: {
    bg: "bg-gray-500/10",
    border: "border-gray-500/50",
    text: "text-gray-400",
    badge: "bg-gray-500",
  },
};

const statusIcons = {
  Active: <CheckCircle2 className="w-4 h-4 text-green-400" />,
  Inactive: <AlertTriangle className="w-4 h-4 text-red-400" />,
  Maintenance: <Clock className="w-4 h-4 text-amber-400" />,
};

export function DevicesTab({
  secureMode,
  onAuditLog,
}: DevicesTabProps) {
  const [selectedFilter, setSelectedFilter] = useState<
    "All" | Criticality
  >("All");
  const [showDetails, setShowDetails] = useState(true);

  const filteredDevices =
    selectedFilter === "All"
      ? devices
      : devices.filter((d) => d.criticality === selectedFilter);

  const handleExport = () => {
    if (!secureMode) {
      alert("Export requires Secure Mode to be enabled");
      return;
    }

    const data = JSON.stringify(filteredDevices, null, 2);
    const blob = new Blob([data], { type: "application/json" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = `device-inventory-${new Date().toISOString()}.json`;
    a.click();
    URL.revokeObjectURL(url);

    onAuditLog(
      `Exported device inventory (${filteredDevices.length} devices) - Filter: ${selectedFilter}`,
    );
  };

  const toggleDetails = () => {
    setShowDetails(!showDetails);
    onAuditLog(
      `Device details ${!showDetails ? "shown" : "hidden"}`,
    );
  };

  return (
    <div>
      {/* Controls */}
      <div className="flex flex-wrap items-center justify-between gap-4 mb-6">
        <div className="flex items-center gap-3">
          <Filter className="w-5 h-5 text-cyan-400" />
          <div className="flex gap-2">
            {(
              [
                "All",
                "Critical",
                "High",
                "Medium",
                "Low",
              ] as const
            ).map((filter) => (
              <button
                key={filter}
                onClick={() => {
                  setSelectedFilter(filter);
                  onAuditLog(
                    `Device filter changed to: ${filter}`,
                  );
                }}
                className={`
                  px-4 py-2 rounded-lg text-sm font-semibold uppercase tracking-wide
                  transition-all duration-300
                  ${
                    selectedFilter === filter
                      ? "bg-cyan-500/30 text-cyan-400 border border-cyan-500/50"
                      : "bg-gray-500/10 text-gray-400 border border-gray-500/30 hover:bg-gray-500/20"
                  }
                `}
              >
                {filter}
              </button>
            ))}
          </div>
        </div>

        <div className="flex gap-2">
          <button
            onClick={toggleDetails}
            className="flex items-center gap-2 px-4 py-2 bg-gray-500/10 border border-gray-500/30 rounded-lg text-gray-400 hover:bg-gray-500/20 transition-all duration-300"
          >
            {showDetails ? (
              <EyeOff className="w-4 h-4" />
            ) : (
              <Eye className="w-4 h-4" />
            )}
            <span className="text-sm font-semibold uppercase">
              {showDetails ? "Hide" : "Show"} Details
            </span>
          </button>

          <button
            onClick={handleExport}
            className="flex items-center gap-2 px-4 py-2 bg-cyan-500/10 border border-cyan-500/30 rounded-lg text-cyan-400 hover:bg-cyan-500/20 transition-all duration-300"
          >
            <Download className="w-4 h-4" />
            <span className="text-sm font-semibold uppercase">
              Export
            </span>
          </button>
        </div>
      </div>

      {/* Device Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
        {filteredDevices.map((device, index) => {
          const colors = criticalityColors[device.criticality];

          return (
            <div
              key={device.id}
              className={`
                group relative p-6 rounded-lg border backdrop-blur-sm
                transition-all duration-300 hover:scale-[1.02] hover:shadow-xl
                ${colors.bg} ${colors.border}
              `}
              style={{
                animation: "slideUp 0.5s ease-out forwards",
                animationDelay: `${index * 100}ms`,
                opacity: 0,
              }}
            >
              {/* Criticality Badge */}
              <div className="absolute top-4 right-4">
                <div
                  className={`w-3 h-3 rounded-full ${colors.badge} animate-pulse`}
                />
              </div>

              {/* Header */}
              <div className="flex items-start gap-3 mb-4">
                <div
                  className={`p-3 rounded-lg ${colors.bg} border ${colors.border}`}
                >
                  <Server
                    className={`w-6 h-6 ${colors.text}`}
                  />
                </div>
                <div className="flex-1">
                  <h3 className="text-lg font-bold text-white">
                    {device.name}
                  </h3>
                  <p className="text-sm font-mono text-gray-400">
                    {device.id}
                  </p>
                </div>
              </div>

              {/* Status & Criticality */}
              <div className="flex items-center gap-3 mb-4">
                <div className="flex items-center gap-2 px-3 py-1 bg-black/30 rounded border border-gray-500/30">
                  {statusIcons[device.status]}
                  <span className="text-xs font-semibold uppercase">
                    {device.status}
                  </span>
                </div>
                <div
                  className={`px-3 py-1 rounded border ${colors.border} ${colors.text} text-xs font-bold uppercase`}
                >
                  {device.criticality}
                </div>
              </div>

              {/* Details */}
              {showDetails && (
                <div className="space-y-2 font-mono text-sm">
                  <div className="grid grid-cols-3 gap-2">
                    <div className="text-gray-500">
                      Location:
                    </div>
                    <div className="col-span-2 text-gray-300">
                      {device.location}
                    </div>
                  </div>
                  <div className="grid grid-cols-3 gap-2">
                    <div className="text-gray-500">
                      IP Address:
                    </div>
                    <div className="col-span-2 text-cyan-400">
                      {device.ipAddress}
                    </div>
                  </div>
                  <div className="grid grid-cols-3 gap-2">
                    <div className="text-gray-500">Owner:</div>
                    <div className="col-span-2 text-gray-300">
                      {device.owner}
                    </div>
                  </div>
                  <div className="grid grid-cols-3 gap-2">
                    <div className="text-gray-500">
                      Last Service:
                    </div>
                    <div className="col-span-2 text-gray-300">
                      {device.lastMaintenance}
                    </div>
                  </div>
                  <div className="mt-3 pt-3 border-t border-gray-500/30">
                    <p className="text-xs text-gray-400 leading-relaxed">
                      {device.description}
                    </p>
                  </div>
                </div>
              )}

              {/* Hover Effect */}
              <div className="absolute inset-0 bg-gradient-to-r from-cyan-500/0 via-cyan-500/5 to-cyan-500/0 opacity-0 group-hover:opacity-100 transition-opacity duration-300 rounded-lg pointer-events-none" />
            </div>
          );
        })}
      </div>

      {filteredDevices.length === 0 && (
        <div className="text-center py-12">
          <Server className="w-16 h-16 text-gray-600 mx-auto mb-4" />
          <p className="text-gray-500 text-lg">
            No devices match the selected filter
          </p>
        </div>
      )}

      <style>{`
        @keyframes slideUp {
          to {
            opacity: 1;
            transform: translateY(0);
          }
          from {
            transform: translateY(20px);
          }
        }
      `}</style>
    </div>
  );
}