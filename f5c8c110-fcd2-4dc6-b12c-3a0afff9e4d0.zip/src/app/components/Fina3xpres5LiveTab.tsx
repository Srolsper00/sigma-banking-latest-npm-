import { useState, useEffect } from "react";
import {
  Activity,
  TrendingUp,
  TrendingDown,
  Radio,
  Zap,
  Database,
  GitBranch,
  Hash,
  Clock,
  CheckCircle2,
  AlertTriangle,
  ArrowRight,
  ArrowLeft,
  Cpu,
} from "lucide-react";

interface TabProps {
  secureMode: boolean;
  onAuditLog: (action: string) => void;
}

interface LiveNode {
  nodeId: string;
  status: "active" | "degraded" | "offline";
  upstreamLatency: number;
  txnProcessed: number;
  nonceGenRate: number;
  topographicPosition: number;
  ledgerQueue: {
    incoming: number;
    outgoing: number;
  };
}

interface TimedNonce {
  nonce: string;
  timestamp: string;
  txnId: string;
  validity: number;
  status: "valid" | "expiring" | "expired";
}

interface LedgerTransaction {
  id: string;
  type: "incoming" | "outgoing";
  amount: string;
  nonce: string;
  nodeId: string;
  status: "processing" | "posted" | "failed";
  timestamp: string;
}

export function Fina3xpres5LiveTab({
  secureMode,
  onAuditLog,
}: TabProps) {
  const [liveNodes, setLiveNodes] = useState<LiveNode[]>([
    {
      nodeId: "fina-node-upstream-01",
      status: "active",
      upstreamLatency: 12,
      txnProcessed: 4820,
      nonceGenRate: 850,
      topographicPosition: 1,
      ledgerQueue: { incoming: 142, outgoing: 89 },
    },
    {
      nodeId: "fina-node-upstream-02",
      status: "active",
      upstreamLatency: 18,
      txnProcessed: 4105,
      nonceGenRate: 720,
      topographicPosition: 2,
      ledgerQueue: { incoming: 98, outgoing: 124 },
    },
    {
      nodeId: "fina-node-upstream-03",
      status: "degraded",
      upstreamLatency: 45,
      txnProcessed: 2890,
      nonceGenRate: 480,
      topographicPosition: 3,
      ledgerQueue: { incoming: 215, outgoing: 67 },
    },
    {
      nodeId: "fina-node-upstream-04",
      status: "active",
      upstreamLatency: 9,
      txnProcessed: 5340,
      nonceGenRate: 950,
      topographicPosition: 4,
      ledgerQueue: { incoming: 76, outgoing: 112 },
    },
  ]);

  const [activeNonces, setActiveNonces] = useState<
    TimedNonce[]
  >([
    {
      nonce: "nc_7f8a9b4c2d1e3f5a",
      timestamp: new Date().toISOString(),
      txnId: "txn_incoming_9823",
      validity: 3600,
      status: "valid",
    },
    {
      nonce: "nc_3e5d7c9a1f2b4e6d",
      timestamp: new Date(Date.now() - 3200000).toISOString(),
      txnId: "txn_outgoing_7654",
      validity: 3600,
      status: "expiring",
    },
    {
      nonce: "nc_8b2f4a6e1c9d3b5f",
      timestamp: new Date().toISOString(),
      txnId: "txn_incoming_5421",
      validity: 3600,
      status: "valid",
    },
  ]);

  const [ledgerTransactions, setLedgerTransactions] = useState<
    LedgerTransaction[]
  >([
    {
      id: "ldg_inc_001",
      type: "incoming",
      amount: "125,449.00 USD",
      nonce: "nc_7f8a9b4c2d1e3f5a",
      nodeId: "fina-node-upstream-01",
      status: "posted",
      timestamp: new Date().toISOString(),
    },
    {
      id: "ldg_out_002",
      type: "outgoing",
      amount: "87,230.50 USD",
      nonce: "nc_3e5d7c9a1f2b4e6d",
      nodeId: "fina-node-upstream-02",
      status: "processing",
      timestamp: new Date(Date.now() - 120000).toISOString(),
    },
    {
      id: "ldg_inc_003",
      type: "incoming",
      amount: "203,890.75 USD",
      nonce: "nc_8b2f4a6e1c9d3b5f",
      nodeId: "fina-node-upstream-04",
      status: "posted",
      timestamp: new Date(Date.now() - 60000).toISOString(),
    },
  ]);

  const [currentTime, setCurrentTime] = useState(new Date());

  useEffect(() => {
    const timer = setInterval(() => {
      setCurrentTime(new Date());

      // Simulate live node updates
      setLiveNodes((prev) =>
        prev.map((node) => ({
          ...node,
          txnProcessed:
            node.txnProcessed + Math.floor(Math.random() * 10),
          upstreamLatency: Math.max(
            5,
            node.upstreamLatency + (Math.random() - 0.5) * 3,
          ),
          ledgerQueue: {
            incoming: Math.max(
              0,
              node.ledgerQueue.incoming +
                Math.floor((Math.random() - 0.5) * 20),
            ),
            outgoing: Math.max(
              0,
              node.ledgerQueue.outgoing +
                Math.floor((Math.random() - 0.5) * 15),
            ),
          },
        })),
      );
    }, 2000);

    return () => clearInterval(timer);
  }, []);

  const generateNonce = () => {
    const newNonce: TimedNonce = {
      nonce: `nc_${Math.random().toString(36).substring(2, 18)}`,
      timestamp: new Date().toISOString(),
      txnId: `txn_${Math.random() > 0.5 ? "incoming" : "outgoing"}_${Math.floor(Math.random() * 10000)}`,
      validity: 3600,
      status: "valid",
    };
    setActiveNonces((prev) => [newNonce, ...prev].slice(0, 10));
    onAuditLog(
      `Generated timely nonce: ${newNonce.nonce} for ${newNonce.txnId}`,
    );
  };

  const getNodeStatusColor = (status: string) => {
    switch (status) {
      case "active":
        return "text-green-400 bg-green-400/10 border-green-400/30";
      case "degraded":
        return "text-yellow-400 bg-yellow-400/10 border-yellow-400/30";
      case "offline":
        return "text-red-400 bg-red-400/10 border-red-400/30";
      default:
        return "text-gray-400 bg-gray-400/10 border-gray-400/30";
    }
  };

  const getNonceStatusColor = (status: string) => {
    switch (status) {
      case "valid":
        return "text-green-400 bg-green-400/10";
      case "expiring":
        return "text-yellow-400 bg-yellow-400/10";
      case "expired":
        return "text-red-400 bg-red-400/10";
      default:
        return "text-gray-400 bg-gray-400/10";
    }
  };

  const totalProcessed = liveNodes.reduce(
    (sum, node) => sum + node.txnProcessed,
    0,
  );
  const avgLatency =
    liveNodes.reduce(
      (sum, node) => sum + node.upstreamLatency,
      0,
    ) / liveNodes.length;
  const totalIncoming = liveNodes.reduce(
    (sum, node) => sum + node.ledgerQueue.incoming,
    0,
  );
  const totalOutgoing = liveNodes.reduce(
    (sum, node) => sum + node.ledgerQueue.outgoing,
    0,
  );

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="bg-gradient-to-br from-[#0f1525] to-[#0a0e1a] border border-cyan-500/30 rounded-lg p-6">
        <div className="flex items-center justify-between mb-4">
          <div className="flex items-center gap-3">
            <Zap className="w-8 h-8 text-cyan-400 animate-pulse" />
            <div>
              <h2 className="text-2xl font-bold tracking-wide uppercase">
                Fina_3xpres5 Live Processing
              </h2>
              <p className="text-sm text-cyan-400/70 font-mono">
                Horizontal Upstream Topographic Array |
                Real-Time Nonce Generation
              </p>
            </div>
          </div>
          <div className="flex items-center gap-3">
            <div className="px-4 py-2 bg-cyan-400/10 border border-cyan-400/30 rounded">
              <div className="flex items-center gap-2">
                <Clock className="w-4 h-4 text-cyan-400" />
                <span className="text-sm text-cyan-400 font-mono font-semibold">
                  {currentTime.toLocaleTimeString()}
                </span>
              </div>
            </div>
            <button
              onClick={generateNonce}
              className="px-4 py-2 bg-green-400/10 border border-green-400/30 rounded hover:bg-green-400/20 transition-all"
            >
              <div className="flex items-center gap-2">
                <Hash className="w-4 h-4 text-green-400" />
                <span className="text-sm text-green-400 font-semibold">
                  GENERATE NONCE
                </span>
              </div>
            </button>
          </div>
        </div>

        <div className="grid grid-cols-5 gap-4">
          <div className="bg-cyan-400/5 border border-cyan-400/20 rounded p-3">
            <div className="text-xs text-cyan-400/70 mb-1">
              TOTAL PROCESSED
            </div>
            <div className="text-2xl font-bold text-cyan-400">
              {totalProcessed.toLocaleString()}
            </div>
          </div>
          <div className="bg-green-400/5 border border-green-400/20 rounded p-3">
            <div className="text-xs text-green-400/70 mb-1">
              AVG LATENCY
            </div>
            <div className="text-2xl font-bold text-green-400">
              {avgLatency.toFixed(1)}ms
            </div>
          </div>
          <div className="bg-cyan-400/5 border border-cyan-400/20 rounded p-3">
            <div className="text-xs text-cyan-400/70 mb-1">
              INCOMING QUEUE
            </div>
            <div className="text-2xl font-bold text-blue-400">
              {totalIncoming}
            </div>
          </div>
          <div className="bg-purple-400/5 border border-purple-400/20 rounded p-3">
            <div className="text-xs text-purple-400/70 mb-1">
              OUTGOING QUEUE
            </div>
            <div className="text-2xl font-bold text-purple-400">
              {totalOutgoing}
            </div>
          </div>
          <div className="bg-green-400/5 border border-green-400/20 rounded p-3">
            <div className="text-xs text-green-400/70 mb-1">
              ACTIVE NODES
            </div>
            <div className="text-2xl font-bold text-green-400">
              {
                liveNodes.filter((n) => n.status === "active")
                  .length
              }
              /{liveNodes.length}
            </div>
          </div>
        </div>
      </div>

      {/* Horizontal Upstream Topographic Array */}
      <div className="bg-gradient-to-br from-[#0f1525] to-[#0a0e1a] border border-cyan-500/30 rounded-lg p-5">
        <h3 className="text-lg font-bold text-cyan-400 mb-4 flex items-center gap-2">
          <GitBranch className="w-5 h-5" />
          HORIZONTAL UPSTREAM TOPOGRAPHIC ARRAY
        </h3>

        <div className="space-y-4">
          {liveNodes.map((node, index) => (
            <div key={node.nodeId} className="relative">
              {/* Topographic Position Indicator */}
              <div className="flex items-center gap-4">
                <div className="w-12 h-12 rounded-full border-2 border-cyan-400 bg-cyan-400/10 flex items-center justify-center">
                  <span className="text-cyan-400 font-bold">
                    {node.topographicPosition}
                  </span>
                </div>

                {/* Node Card */}
                <div
                  className={`flex-1 border rounded-lg p-4 ${getNodeStatusColor(node.status)}`}
                >
                  <div className="flex items-center justify-between mb-3">
                    <div className="flex items-center gap-2">
                      <Radio className="w-4 h-4" />
                      <span className="font-mono font-bold">
                        {node.nodeId}
                      </span>
                    </div>
                    <div
                      className={`px-2 py-1 rounded text-xs uppercase ${getNodeStatusColor(node.status)}`}
                    >
                      {node.status}
                    </div>
                  </div>

                  <div className="grid grid-cols-5 gap-3 text-xs">
                    <div>
                      <div className="text-gray-400 mb-1">
                        Upstream Latency
                      </div>
                      <div className="font-mono font-bold">
                        {node.upstreamLatency.toFixed(1)}ms
                      </div>
                    </div>
                    <div>
                      <div className="text-gray-400 mb-1">
                        TXN Processed
                      </div>
                      <div className="font-mono font-bold">
                        {node.txnProcessed.toLocaleString()}
                      </div>
                    </div>
                    <div>
                      <div className="text-gray-400 mb-1">
                        Nonce Gen Rate
                      </div>
                      <div className="font-mono font-bold">
                        {node.nonceGenRate}/s
                      </div>
                    </div>
                    <div>
                      <div className="text-gray-400 mb-1 flex items-center gap-1">
                        <ArrowLeft className="w-3 h-3" />
                        Incoming
                      </div>
                      <div className="font-mono font-bold text-blue-400">
                        {node.ledgerQueue.incoming}
                      </div>
                    </div>
                    <div>
                      <div className="text-gray-400 mb-1 flex items-center gap-1">
                        <ArrowRight className="w-3 h-3" />
                        Outgoing
                      </div>
                      <div className="font-mono font-bold text-purple-400">
                        {node.ledgerQueue.outgoing}
                      </div>
                    </div>
                  </div>

                  {/* Live Activity Bar */}
                  <div className="mt-3">
                    <div className="h-1 bg-gray-700 rounded-full overflow-hidden">
                      <div
                        className="h-full bg-gradient-to-r from-cyan-500 to-green-500 rounded-full transition-all duration-500"
                        style={{
                          width: `${(node.txnProcessed / totalProcessed) * 100}%`,
                        }}
                      />
                    </div>
                  </div>
                </div>

                {/* Upstream Flow Indicator */}
                {index < liveNodes.length - 1 && (
                  <div className="absolute left-6 top-full h-4 w-0.5 bg-cyan-400/30" />
                )}
              </div>
            </div>
          ))}
        </div>
      </div>

      <div className="grid grid-cols-2 gap-6">
        {/* Timely Nonce Generation */}
        <div className="bg-gradient-to-br from-[#0f1525] to-[#0a0e1a] border border-cyan-500/30 rounded-lg p-5">
          <h3 className="text-lg font-bold text-cyan-400 mb-4 flex items-center gap-2">
            <Hash className="w-5 h-5" />
            TIMELY NONCE GENERATION
          </h3>

          <div className="space-y-3 max-h-[400px] overflow-y-auto">
            {activeNonces.map((nonce, index) => (
              <div
                key={index}
                className={`border rounded-lg p-3 ${getNonceStatusColor(nonce.status)}`}
              >
                <div className="flex items-center justify-between mb-2">
                  <div className="font-mono text-sm font-bold">
                    {nonce.nonce}
                  </div>
                  <div
                    className={`px-2 py-0.5 rounded text-xs uppercase ${getNonceStatusColor(nonce.status)}`}
                  >
                    {nonce.status}
                  </div>
                </div>
                <div className="grid grid-cols-2 gap-2 text-xs">
                  <div>
                    <div className="text-gray-400">
                      Transaction ID
                    </div>
                    <div className="font-mono">
                      {nonce.txnId}
                    </div>
                  </div>
                  <div>
                    <div className="text-gray-400">
                      Validity
                    </div>
                    <div className="font-mono">
                      {nonce.validity}s
                    </div>
                  </div>
                </div>
                <div className="mt-2 text-xs text-gray-400">
                  Generated:{" "}
                  {new Date(nonce.timestamp).toLocaleString()}
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Incoming/Outgoing Ledger Post Process */}
        <div className="bg-gradient-to-br from-[#0f1525] to-[#0a0e1a] border border-cyan-500/30 rounded-lg p-5">
          <h3 className="text-lg font-bold text-cyan-400 mb-4 flex items-center gap-2">
            <Database className="w-5 h-5" />
            INCOMING/OUTGOING LEDGER POST PROCESS
          </h3>

          <div className="space-y-3 max-h-[400px] overflow-y-auto">
            {ledgerTransactions.map((txn) => (
              <div
                key={txn.id}
                className={`border rounded-lg p-3 ${
                  txn.type === "incoming"
                    ? "bg-blue-400/5 border-blue-400/20"
                    : "bg-purple-400/5 border-purple-400/20"
                }`}
              >
                <div className="flex items-center justify-between mb-2">
                  <div className="flex items-center gap-2">
                    {txn.type === "incoming" ? (
                      <TrendingDown className="w-4 h-4 text-blue-400" />
                    ) : (
                      <TrendingUp className="w-4 h-4 text-purple-400" />
                    )}
                    <span className="font-mono text-sm font-bold uppercase">
                      {txn.type}
                    </span>
                  </div>
                  <div
                    className={`px-2 py-0.5 rounded text-xs ${
                      txn.status === "posted"
                        ? "bg-green-400/20 text-green-400"
                        : txn.status === "processing"
                          ? "bg-yellow-400/20 text-yellow-400"
                          : "bg-red-400/20 text-red-400"
                    }`}
                  >
                    {txn.status.toUpperCase()}
                  </div>
                </div>

                <div className="text-lg font-bold mb-2">
                  {txn.amount}
                </div>

                <div className="grid grid-cols-2 gap-2 text-xs">
                  <div>
                    <div className="text-gray-400">
                      Ledger ID
                    </div>
                    <div className="font-mono">{txn.id}</div>
                  </div>
                  <div>
                    <div className="text-gray-400">Node ID</div>
                    <div className="font-mono text-cyan-400">
                      {txn.nodeId.split("-").pop()}
                    </div>
                  </div>
                </div>

                <div className="mt-2 bg-gray-900/50 rounded p-2">
                  <div className="text-xs text-gray-400 mb-1">
                    Nonce
                  </div>
                  <div className="font-mono text-xs text-green-400">
                    {txn.nonce}
                  </div>
                </div>

                <div className="mt-2 text-xs text-gray-400">
                  {new Date(txn.timestamp).toLocaleString()}
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Active Array Status */}
      <div className="bg-gradient-to-br from-green-500/10 to-[#0a0e1a] border border-green-500/30 rounded-lg p-4">
        <div className="flex items-start gap-3">
          <Activity className="w-5 h-5 text-green-400 mt-0.5 flex-shrink-0 animate-pulse" />
          <div>
            <div className="font-bold text-green-400 mb-1">
              ACTIVE ARRAY OPERATIONAL
            </div>
            <div className="text-sm text-gray-300">
              {
                liveNodes.filter((n) => n.status === "active")
                  .length
              }{" "}
              upstream nodes active with real-time nonce
              generation at{" "}
              {liveNodes.reduce(
                (sum, n) => sum + n.nonceGenRate,
                0,
              )}{" "}
              nonces/sec. Processing {totalIncoming} incoming
              and {totalOutgoing} outgoing ledger transactions
              across horizontal topographic array positions.
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}