import { useState } from "react";
import {
  Building2,
  Link2,
  Target,
  Network,
  CheckCircle2,
} from "lucide-react";

interface BusinessTabProps {
  secureMode: boolean;
  onAuditLog: (message: string) => void;
}

interface BusinessControl {
  id: string;
  code: string;
  title: string;
  description: string;
  context: string;
  details: string[];
  icon: any;
  color: {
    bg: string;
    text: string;
    border: string;
    badge: string;
  };
}

const controls: BusinessControl[] = [
  {
    id: "BE-001",
    code: "ID.BE-1",
    title: "Supply Chain Role Identification",
    description:
      "Organization's role in the supply chain is identified and communicated",
    context: "Financial Services Ecosystem Position",
    details: [
      "Core Banking Partner: UMB Bank NA integration for account services",
      "Payment Network Integrator: FedNow, RTP, and ACH network connectivity",
      "Technology Provider: HashiCorp Vault tokenization services",
      "Blockchain Participant: NULS network integration for distributed ledger",
      "Cloud Infrastructure Consumer: AWS for scalable compute and storage",
    ],
    icon: Link2,
    color: {
      bg: "bg-cyan-500/10",
      text: "text-cyan-400",
      border: "border-cyan-500/50",
      badge: "bg-cyan-500",
    },
  },
  {
    id: "BE-002",
    code: "ID.BE-2",
    title: "Critical Infrastructure Sector",
    description:
      "Organization's place in critical infrastructure is identified and communicated",
    context: "Financial Services Sector - FFIEC Oversight",
    details: [
      "Sector: Financial Services (Banking & Credit)",
      "Regulatory Framework: FFIEC (Federal Financial Institutions Examination Council)",
      "Critical Function: Payment processing and settlement infrastructure",
      "National Security Impact: Part of U.S. financial system resilience",
      "Interdependency: Federal Reserve, ACH network, payment rails ecosystem",
    ],
    icon: Building2,
    color: {
      bg: "bg-purple-500/10",
      text: "text-purple-400",
      border: "border-purple-500/50",
      badge: "bg-purple-500",
    },
  },
  {
    id: "BE-003",
    code: "ID.BE-3",
    title: "Organizational Mission & Objectives",
    description:
      "Priorities for organizational mission, objectives, and activities are established",
    context: "VOM Banking Platform Strategic Vision",
    details: [
      "Mission: Deliver secure, compliant, and innovative banking services",
      "Objective 1: Real-time payment processing with 99.99% uptime",
      "Objective 2: Zero-trust security architecture with tokenization",
      "Objective 3: Regulatory compliance across all banking frameworks",
      "Objective 4: Blockchain integration for transparency and auditability",
    ],
    icon: Target,
    color: {
      bg: "bg-green-500/10",
      text: "text-green-400",
      border: "border-green-500/50",
      badge: "bg-green-500",
    },
  },
  {
    id: "BE-004",
    code: "ID.BE-4",
    title: "Dependencies & Critical Functions",
    description:
      "Dependencies and critical functions for delivery of critical services are established",
    context: "System Dependencies & Service Continuity",
    details: [
      "Core Dependency: UMB Bank NA core banking system (99.99% SLA)",
      "Payment Infrastructure: FedNow (99.95%) and RTP (99.98%) networks",
      "Security Foundation: HashiCorp Vault tokenization (hot standby)",
      "Cloud Infrastructure: AWS Direct Connect for primary compute",
      "Audit Trail: MongoDB Atlas immutable ledger and NULS blockchain",
    ],
    icon: Network,
    color: {
      bg: "bg-amber-500/10",
      text: "text-amber-400",
      border: "border-amber-500/50",
      badge: "bg-amber-500",
    },
  },
];

export function BusinessTab({
  secureMode,
  onAuditLog,
}: BusinessTabProps) {
  const [expandedControl, setExpandedControl] = useState<
    string | null
  >(null);

  const toggleControl = (controlId: string) => {
    const newExpanded =
      expandedControl === controlId ? null : controlId;
    setExpandedControl(newExpanded);
    onAuditLog(
      `${newExpanded ? "Expanded" : "Collapsed"} business control: ${controlId}`,
    );
  };

  return (
    <div>
      {/* Header */}
      <div className="mb-6">
        <h2 className="text-2xl font-bold text-white uppercase tracking-wide">
          Business Environment Controls
        </h2>
        <p className="text-cyan-400 font-mono text-sm mt-1">
          ID.BE Compliance Framework
        </p>
      </div>

      {/* Info Banner */}
      <div className="mb-6 p-4 bg-cyan-500/10 border border-cyan-500/30 rounded-lg">
        <div className="flex items-start gap-3">
          <Building2 className="w-5 h-5 text-cyan-400 flex-shrink-0 mt-0.5" />
          <div>
            <h3 className="font-bold text-white mb-1">
              VOM Banking Platform Business Context
            </h3>
            <p className="text-sm text-gray-300 leading-relaxed">
              Financial services organization operating within
              the critical infrastructure sector, partnered with
              UMB Bank NA, integrating real-time payment
              networks (FedNow, RTP), and leveraging blockchain
              technology for enhanced security and compliance.
            </p>
          </div>
        </div>
      </div>

      {/* Business Controls */}
      <div className="space-y-4">
        {controls.map((control, index) => {
          const Icon = control.icon;
          const isExpanded = expandedControl === control.id;

          return (
            <div
              key={control.id}
              className="group"
              style={{
                animation:
                  "controlAppear 0.5s ease-out forwards",
                animationDelay: `${index * 80}ms`,
                opacity: 0,
              }}
            >
              <div
                onClick={() => toggleControl(control.id)}
                className={`
                  relative p-6 rounded-lg border backdrop-blur-sm cursor-pointer
                  transition-all duration-300
                  ${
                    isExpanded
                      ? `${control.color.bg} ${control.color.border} shadow-xl`
                      : "bg-gray-500/5 border-gray-500/30 hover:bg-gray-500/10"
                  }
                `}
              >
                {/* Header */}
                <div className="flex items-start gap-4 mb-4">
                  <div
                    className={`p-3 rounded-lg border ${isExpanded ? `${control.color.bg} ${control.color.border}` : "bg-gray-500/10 border-gray-500/30"}`}
                  >
                    <Icon
                      className={`w-6 h-6 ${isExpanded ? control.color.text : "text-gray-400"}`}
                    />
                  </div>

                  <div className="flex-1">
                    <div className="flex items-center gap-3 mb-2">
                      <h3 className="text-lg font-bold text-white">
                        {control.title}
                      </h3>
                      <span
                        className={`px-2 py-1 rounded text-xs font-mono font-bold ${control.color.badge} text-white`}
                      >
                        {control.code}
                      </span>
                    </div>
                    <p className="text-sm text-gray-400 mb-2">
                      {control.description}
                    </p>
                    <div
                      className={`inline-flex items-center gap-2 px-3 py-1 rounded border ${control.color.bg} ${control.color.border}`}
                    >
                      <CheckCircle2
                        className={`w-3 h-3 ${control.color.text}`}
                      />
                      <span
                        className={`text-xs font-semibold ${control.color.text}`}
                      >
                        {control.context}
                      </span>
                    </div>
                  </div>
                </div>

                {/* Expanded Details */}
                {isExpanded && (
                  <div
                    className="pt-4 border-t border-gray-500/30"
                    style={{
                      animation: "expandDetails 0.3s ease-out",
                    }}
                  >
                    <div className="space-y-3">
                      {control.details.map((detail, idx) => {
                        const parts = detail.split(":");
                        const label = parts[0];
                        const value = parts
                          .slice(1)
                          .join(":")
                          .trim();

                        return (
                          <div
                            key={idx}
                            className="flex items-start gap-3 p-3 bg-black/30 rounded border border-gray-500/30"
                            style={{
                              animation:
                                "slideUp 0.3s ease-out forwards",
                              animationDelay: `${idx * 50}ms`,
                              opacity: 0,
                            }}
                          >
                            <div
                              className={`w-1.5 h-1.5 rounded-full ${control.color.badge} mt-2 flex-shrink-0`}
                            />
                            <div className="flex-1">
                              <div
                                className={`text-sm font-bold ${control.color.text} mb-1`}
                              >
                                {label}
                              </div>
                              {value && (
                                <div className="text-sm text-gray-300">
                                  {value}
                                </div>
                              )}
                            </div>
                          </div>
                        );
                      })}
                    </div>
                  </div>
                )}

                {/* Status Indicator */}
                <div className="absolute top-6 right-6">
                  <div
                    className={`w-2 h-2 rounded-full ${control.color.badge} ${isExpanded ? "animate-pulse" : ""}`}
                  />
                </div>
              </div>
            </div>
          );
        })}
      </div>

      {/* Footer Summary */}
      <div className="mt-8 p-6 bg-gradient-to-r from-cyan-500/10 via-purple-500/10 to-green-500/10 border border-gray-500/30 rounded-lg">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
          <div className="text-center">
            <div className="text-3xl font-bold text-cyan-400 mb-1">
              4/4
            </div>
            <div className="text-xs text-gray-400 uppercase">
              Controls Implemented
            </div>
          </div>
          <div className="text-center">
            <div className="text-3xl font-bold text-green-400 mb-1">
              100%
            </div>
            <div className="text-xs text-gray-400 uppercase">
              Compliance Rate
            </div>
          </div>
          <div className="text-center">
            <div className="text-3xl font-bold text-purple-400 mb-1">
              FFIEC
            </div>
            <div className="text-xs text-gray-400 uppercase">
              Regulatory Framework
            </div>
          </div>
          <div className="text-center">
            <div className="text-3xl font-bold text-amber-400 mb-1">
              Financial
            </div>
            <div className="text-xs text-gray-400 uppercase">
              Critical Sector
            </div>
          </div>
        </div>
      </div>

      <style>{`
        @keyframes controlAppear {
          from {
            opacity: 0;
            transform: translateY(20px);
          }
          to {
            opacity: 1;
            transform: translateY(0);
          }
        }

        @keyframes expandDetails {
          from {
            opacity: 0;
            transform: translateY(-10px);
          }
          to {
            opacity: 1;
            transform: translateY(0);
          }
        }

        @keyframes slideUp {
          from {
            opacity: 0;
            transform: translateY(10px);
          }
          to {
            opacity: 1;
            transform: translateY(0);
          }
        }
      `}</style>
    </div>
  );
}