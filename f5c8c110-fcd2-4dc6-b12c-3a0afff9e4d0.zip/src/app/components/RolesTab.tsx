import { useState } from 'react';
import { Users, Shield, Activity, Lock, FileCheck, ChevronDown, ChevronUp } from 'lucide-react';

interface RolesTabProps {
  secureMode: boolean;
  onAuditLog: (message: string) => void;
}

interface Role {
  id: string;
  title: string;
  department: string;
  position: string;
  responsibilities: string[];
  frameworks: string[];
  icon: any;
  color: { bg: string; text: string; border: string; badge: string };
}

const roles: Role[] = [
  {
    id: 'ROLE-001',
    title: 'Chief Information Security Officer',
    department: 'Executive Leadership',
    position: 'C-Level Executive',
    responsibilities: [
      'Overall cybersecurity strategy and risk management',
      'Board-level reporting on security posture and incidents',
      'Budget allocation for security tools and personnel',
      'Compliance oversight across all regulatory frameworks',
      'Executive decision-making for security investments'
    ],
    frameworks: ['NIST CSF', 'ISO 27001', 'COBIT 5', 'CIS CSC'],
    icon: Shield,
    color: { bg: 'bg-purple-500/10', text: 'text-purple-400', border: 'border-purple-500/50', badge: 'bg-purple-500' }
  },
  {
    id: 'ROLE-002',
    title: 'Security Operations Center Team',
    department: 'Security Department',
    position: 'SOC Analysts & Lead',
    responsibilities: [
      '24/7 security monitoring and incident detection',
      'Threat hunting and anomaly detection',
      'Incident response and forensic analysis',
      'SIEM management and log correlation',
      'Security alert triage and escalation'
    ],
    frameworks: ['NIST SP 800-53', 'ISO 27001', 'CIS CSC'],
    icon: Activity,
    color: { bg: 'bg-cyan-500/10', text: 'text-cyan-400', border: 'border-cyan-500/50', badge: 'bg-cyan-500' }
  },
  {
    id: 'ROLE-003',
    title: 'Vault Administrator',
    department: 'Infrastructure Security',
    position: 'Senior Security Engineer',
    responsibilities: [
      'HashiCorp Vault configuration and maintenance',
      'Cryptographic key lifecycle management',
      'HSM administration and security',
      'Secret rotation and access policy enforcement',
      'Tokenization service uptime and monitoring'
    ],
    frameworks: ['NIST SP 800-53', 'ISO 27001', 'PCI DSS'],
    icon: Lock,
    color: { bg: 'bg-green-500/10', text: 'text-green-400', border: 'border-green-500/50', badge: 'bg-green-500' }
  },
  {
    id: 'ROLE-004',
    title: 'Third-Party Risk Manager',
    department: 'Compliance',
    position: 'Risk Management Lead',
    responsibilities: [
      'Vendor security assessment and due diligence',
      'Third-party contract security terms negotiation',
      'Ongoing vendor compliance monitoring',
      'Supply chain risk assessment',
      'Vendor incident response coordination'
    ],
    frameworks: ['NIST CSF', 'ISO 27001', 'COBIT 5', 'ISA 62443'],
    icon: FileCheck,
    color: { bg: 'bg-amber-500/10', text: 'text-amber-400', border: 'border-amber-500/50', badge: 'bg-amber-500' }
  },
  {
    id: 'ROLE-005',
    title: 'DDA Service Owner',
    department: 'Banking Operations',
    position: 'Operations Manager',
    responsibilities: [
      'Demand deposit account service availability',
      'Tokenization service integration oversight',
      'Business continuity for DDA operations',
      'User access management for DDA systems',
      'Change management for DDA platform updates'
    ],
    frameworks: ['NIST CSF', 'COBIT 5', 'ISO 27001'],
    icon: Users,
    color: { bg: 'bg-blue-500/10', text: 'text-blue-400', border: 'border-blue-500/50', badge: 'bg-blue-500' }
  }
];

export function RolesTab({ secureMode, onAuditLog }: RolesTabProps) {
  const [expandedRole, setExpandedRole] = useState<string | null>(null);

  const toggleRole = (roleId: string) => {
    const newExpanded = expandedRole === roleId ? null : roleId;
    setExpandedRole(newExpanded);
    onAuditLog(`${newExpanded ? 'Expanded' : 'Collapsed'} role details: ${roleId}`);
  };

  return (
    <div>
      {/* Header */}
      <div className="mb-6">
        <h2 className="text-2xl font-bold text-white uppercase tracking-wide">Cybersecurity Roles & Responsibilities</h2>
        <p className="text-cyan-400 font-mono text-sm mt-1">ID.AM-6 Compliance - Position-Based Structure</p>
      </div>

      {/* Roles Grid */}
      <div className="space-y-4">
        {roles.map((role, index) => {
          const Icon = role.icon;
          const isExpanded = expandedRole === role.id;

          return (
            <div
              key={role.id}
              className="group"
              style={{
                animation: 'roleSlide 0.5s ease-out forwards',
                animationDelay: `${index * 70}ms`,
                opacity: 0
              }}
            >
              <div
                className={`
                  relative p-6 rounded-lg border backdrop-blur-sm cursor-pointer
                  transition-all duration-300
                  ${isExpanded
                    ? `${role.color.bg} ${role.color.border} shadow-xl`
                    : 'bg-gray-500/5 border-gray-500/30 hover:bg-gray-500/10'
                  }
                `}
                onClick={() => toggleRole(role.id)}
              >
                {/* Header */}
                <div className="flex items-start justify-between">
                  <div className="flex items-start gap-4 flex-1">
                    {/* Icon */}
                    <div className={`p-3 rounded-lg border ${isExpanded ? `${role.color.bg} ${role.color.border}` : 'bg-gray-500/10 border-gray-500/30'}`}>
                      <Icon className={`w-6 h-6 ${isExpanded ? role.color.text : 'text-gray-400'}`} />
                    </div>

                    {/* Title & Info */}
                    <div className="flex-1">
                      <h3 className="text-lg font-bold text-white mb-1">{role.title}</h3>
                      <div className="flex flex-wrap items-center gap-3 text-sm mb-3">
                        <span className="font-mono text-gray-400">{role.id}</span>
                        <span className="text-gray-500">•</span>
                        <span className="text-gray-400">{role.department}</span>
                        <span className="text-gray-500">•</span>
                        <span className={`font-semibold ${role.color.text}`}>{role.position}</span>
                      </div>

                      {/* Framework Badges */}
                      {!isExpanded && (
                        <div className="flex flex-wrap gap-2">
                          {role.frameworks.map((framework) => (
                            <span
                              key={framework}
                              className="px-2 py-1 bg-black/30 border border-gray-500/30 rounded text-xs font-mono text-gray-400"
                            >
                              {framework}
                            </span>
                          ))}
                        </div>
                      )}
                    </div>
                  </div>

                  {/* Expand Button */}
                  <button
                    className={`p-2 rounded-lg transition-all duration-300 ${
                      isExpanded
                        ? `${role.color.bg} ${role.color.border} ${role.color.text}`
                        : 'bg-gray-500/10 border-gray-500/30 text-gray-400 hover:bg-gray-500/20'
                    } border`}
                  >
                    {isExpanded ? (
                      <ChevronUp className="w-5 h-5" />
                    ) : (
                      <ChevronDown className="w-5 h-5" />
                    )}
                  </button>
                </div>

                {/* Expanded Content */}
                {isExpanded && (
                  <div
                    className="mt-6 space-y-4"
                    style={{ animation: 'expandContent 0.3s ease-out' }}
                  >
                    {/* Responsibilities */}
                    <div>
                      <div className="flex items-center gap-2 mb-3">
                        <div className={`w-1 h-6 rounded ${role.color.badge}`} />
                        <h4 className="text-sm font-bold text-white uppercase tracking-wide">Key Responsibilities</h4>
                      </div>
                      <ul className="space-y-2 ml-4">
                        {role.responsibilities.map((resp, idx) => (
                          <li
                            key={idx}
                            className="flex items-start gap-3 text-sm text-gray-300"
                            style={{
                              animation: 'fadeIn 0.3s ease-out forwards',
                              animationDelay: `${idx * 50}ms`,
                              opacity: 0
                            }}
                          >
                            <div className={`w-1.5 h-1.5 rounded-full ${role.color.badge} mt-2 flex-shrink-0`} />
                            <span>{resp}</span>
                          </li>
                        ))}
                      </ul>
                    </div>

                    {/* Framework Compliance */}
                    <div className="pt-4 border-t border-gray-500/30">
                      <div className="flex items-center gap-2 mb-3">
                        <Shield className={`w-4 h-4 ${role.color.text}`} />
                        <h4 className="text-sm font-bold text-white uppercase tracking-wide">Framework Compliance</h4>
                      </div>
                      <div className="grid grid-cols-2 md:grid-cols-4 gap-2">
                        {role.frameworks.map((framework, idx) => (
                          <div
                            key={framework}
                            className={`px-3 py-2 rounded border ${role.color.bg} ${role.color.border} text-center`}
                            style={{
                              animation: 'scaleIn 0.3s ease-out forwards',
                              animationDelay: `${idx * 50}ms`,
                              opacity: 0
                            }}
                          >
                            <div className={`text-xs font-mono font-bold ${role.color.text}`}>{framework}</div>
                          </div>
                        ))}
                      </div>
                    </div>
                  </div>
                )}

                {/* Status Indicator */}
                <div className="absolute top-6 right-6">
                  <div className={`w-2 h-2 rounded-full ${role.color.badge} ${isExpanded ? 'animate-pulse' : ''}`} />
                </div>
              </div>
            </div>
          );
        })}
      </div>

      <style>{`
        @keyframes roleSlide {
          from {
            opacity: 0;
            transform: translateX(-20px);
          }
          to {
            opacity: 1;
            transform: translateX(0);
          }
        }

        @keyframes expandContent {
          from {
            opacity: 0;
            transform: translateY(-10px);
          }
          to {
            opacity: 1;
            transform: translateY(0);
          }
        }

        @keyframes fadeIn {
          to {
            opacity: 1;
          }
        }

        @keyframes scaleIn {
          from {
            opacity: 0;
            transform: scale(0.9);
          }
          to {
            opacity: 1;
            transform: scale(1);
          }
        }
      `}</style>
    </div>
  );
}
