import { useState } from "react";
import {
  Cloud,
  Download,
  Wifi,
  Building2,
  TrendingUp,
} from "lucide-react";

interface ExternalSystemsTabProps {
  secureMode: boolean;
  onAuditLog: (message: string) => void;
}

interface ExternalSystem {
  id: string;
  name: string;
  provider: string;
  sla: string;
  connectionType: string;
  purpose: string;
  criticality: string;
  endpoint: string;
  status: "Connected" | "Degraded" | "Offline";
}

const externalSystems: ExternalSystem[] = [
  {
    id: "EXT-001",
    name: "UMB Bank NA Core System",
    provider: "UMB Financial Corporation",
    sla: "99.99%",
    connectionType: "Direct API / Leased Line",
    purpose:
      "Core banking partner system for account services and transaction processing",
    criticality: "Critical",
    endpoint: "https://core.umb.com/api/v2",
    status: "Connected",
  },
  {
    id: "EXT-002",
    name: "Federal Reserve FedNow",
    provider: "Federal Reserve Banks",
    sla: "99.95%",
    connectionType: "FedLine Network",
    purpose:
      "Instant payment service for 24/7/365 real-time payment processing",
    criticality: "Critical",
    endpoint: "https://fednow.frb.gov/gateway",
    status: "Connected",
  },
  {
    id: "EXT-003",
    name: "The Clearing House RTP",
    provider: "The Clearing House",
    sla: "99.98%",
    connectionType: "Secure VPN",
    purpose:
      "Real-time payment network for instant fund transfers and payment confirmations",
    criticality: "Critical",
    endpoint: "https://rtp.theclearinghouse.org/v3",
    status: "Connected",
  },
  {
    id: "EXT-004",
    name: "NULS Blockchain Network",
    provider: "NULS Foundation",
    sla: "Best Effort",
    connectionType: "P2P Nodes",
    purpose:
      "Distributed ledger for smart contracts, immutable audit trails, and DeFi integration",
    criticality: "High",
    endpoint: "https://api.nuls.io/mainnet",
    status: "Connected",
  },
  {
    id: "EXT-005",
    name: "AWS Infrastructure",
    provider: "Amazon Web Services",
    sla: "99.99%",
    connectionType: "Cloud Direct Connect",
    purpose:
      "Cloud infrastructure for scalable compute, storage, and disaster recovery services",
    criticality: "Critical",
    endpoint: "https://us-east-1.aws.amazon.com",
    status: "Connected",
  },
];

const statusColors = {
  Connected: {
    bg: "bg-green-500/10",
    text: "text-green-400",
    border: "border-green-500/50",
    dot: "bg-green-400",
  },
  Degraded: {
    bg: "bg-amber-500/10",
    text: "text-amber-400",
    border: "border-amber-500/50",
    dot: "bg-amber-400",
  },
  Offline: {
    bg: "bg-red-500/10",
    text: "text-red-400",
    border: "border-red-500/50",
    dot: "bg-red-400",
  },
};

export function ExternalSystemsTab({
  secureMode,
  onAuditLog,
}: ExternalSystemsTabProps) {
  const [expandedSystem, setExpandedSystem] = useState<
    string | null
  >(null);

  const handleExport = () => {
    if (!secureMode) {
      alert("Export requires Secure Mode to be enabled");
      return;
    }

    const data = JSON.stringify(externalSystems, null, 2);
    const blob = new Blob([data], { type: "application/json" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = `external-systems-${new Date().toISOString()}.json`;
    a.click();
    URL.revokeObjectURL(url);

    onAuditLog(
      `Exported external systems catalog (${externalSystems.length} systems)`,
    );
  };

  const toggleExpanded = (systemId: string) => {
    setExpandedSystem(
      expandedSystem === systemId ? null : systemId,
    );
    onAuditLog(
      `Viewed details for external system: ${systemId}`,
    );
  };

  return (
    <div>
      {/* Header */}
      <div className="flex items-center justify-between mb-6">
        <div>
          <h2 className="text-2xl font-bold text-white uppercase tracking-wide">
            External Information Systems
          </h2>
          <p className="text-cyan-400 font-mono text-sm mt-1">
            ID.AM-4 Compliance
          </p>
        </div>

        <button
          onClick={handleExport}
          className="flex items-center gap-2 px-4 py-2 bg-cyan-500/10 border border-cyan-500/30 rounded-lg text-cyan-400 hover:bg-cyan-500/20 transition-all duration-300"
        >
          <Download className="w-4 h-4" />
          <span className="text-sm font-semibold uppercase">
            Export Catalog
          </span>
        </button>
      </div>

      {/* Systems Grid */}
      <div className="space-y-4">
        {externalSystems.map((system, index) => {
          const statusStyle = statusColors[system.status];
          const isExpanded = expandedSystem === system.id;

          return (
            <div
              key={system.id}
              onClick={() => toggleExpanded(system.id)}
              className="group cursor-pointer"
              style={{
                animation:
                  "systemSlideIn 0.5s ease-out forwards",
                animationDelay: `${index * 80}ms`,
                opacity: 0,
              }}
            >
              <div
                className={`
                relative p-6 rounded-lg border backdrop-blur-sm
                transition-all duration-300
                ${
                  isExpanded
                    ? "bg-cyan-500/10 border-cyan-500/50 shadow-xl shadow-cyan-500/20"
                    : "bg-gray-500/5 border-gray-500/30 hover:bg-gray-500/10"
                }
              `}
              >
                {/* Header Row */}
                <div className="flex items-start justify-between gap-4">
                  {/* Left: Icon & Name */}
                  <div className="flex items-start gap-4 flex-1">
                    <div
                      className={`p-3 rounded-lg ${isExpanded ? "bg-cyan-500/20 border-cyan-500/50" : "bg-purple-500/10 border-purple-500/30"} border`}
                    >
                      <Cloud
                        className={`w-6 h-6 ${isExpanded ? "text-cyan-400" : "text-purple-400"}`}
                      />
                    </div>

                    <div className="flex-1">
                      <h3 className="text-lg font-bold text-white mb-1">
                        {system.name}
                      </h3>
                      <div className="flex items-center gap-3 text-sm mb-2">
                        <span className="font-mono text-gray-400">
                          {system.id}
                        </span>
                        <span className="text-gray-500">•</span>
                        <div className="flex items-center gap-2">
                          <Building2 className="w-4 h-4 text-gray-500" />
                          <span className="text-gray-400">
                            {system.provider}
                          </span>
                        </div>
                      </div>

                      {/* Quick Stats */}
                      <div className="flex flex-wrap items-center gap-3">
                        {/* Connection Type */}
                        <div className="flex items-center gap-2 px-3 py-1 bg-black/30 rounded border border-gray-500/30">
                          <Wifi className="w-3 h-3 text-cyan-400" />
                          <span className="text-xs font-mono text-gray-300">
                            {system.connectionType}
                          </span>
                        </div>

                        {/* SLA */}
                        <div className="flex items-center gap-2 px-3 py-1 bg-green-500/10 rounded border border-green-500/30">
                          <TrendingUp className="w-3 h-3 text-green-400" />
                          <span className="text-xs font-semibold text-green-400">
                            SLA: {system.sla}
                          </span>
                        </div>

                        {/* Criticality */}
                        <div
                          className={`px-3 py-1 rounded border ${
                            system.criticality === "Critical"
                              ? "bg-red-500/10 border-red-500/30 text-red-400"
                              : "bg-amber-500/10 border-amber-500/30 text-amber-400"
                          } text-xs font-bold uppercase`}
                        >
                          {system.criticality}
                        </div>
                      </div>
                    </div>
                  </div>

                  {/* Right: Status */}
                  <div
                    className={`px-4 py-2 rounded-lg border ${statusStyle.bg} ${statusStyle.border}`}
                  >
                    <div className="flex items-center gap-2">
                      <div
                        className={`w-2 h-2 rounded-full ${statusStyle.dot} animate-pulse`}
                      />
                      <span
                        className={`text-sm font-bold uppercase ${statusStyle.text}`}
                      >
                        {system.status}
                      </span>
                    </div>
                  </div>
                </div>

                {/* Expanded Details */}
                {isExpanded && (
                  <div
                    className="mt-6 pt-6 border-t border-gray-500/30 space-y-4"
                    style={{
                      animation: "fadeInDown 0.3s ease-out",
                    }}
                  >
                    {/* Purpose */}
                    <div>
                      <div className="text-xs text-gray-500 uppercase mb-2">
                        Purpose
                      </div>
                      <p className="text-sm text-gray-300 leading-relaxed">
                        {system.purpose}
                      </p>
                    </div>

                    {/* Endpoint */}
                    <div>
                      <div className="text-xs text-gray-500 uppercase mb-2">
                        API Endpoint
                      </div>
                      <div className="px-4 py-2 bg-black/50 border border-cyan-500/30 rounded font-mono text-sm text-cyan-400 overflow-x-auto">
                        {system.endpoint}
                      </div>
                    </div>

                    {/* Metrics */}
                    <div className="grid grid-cols-3 gap-3">
                      <div className="p-3 bg-black/30 rounded border border-gray-500/30 text-center">
                        <div className="text-2xl font-bold text-green-400">
                          {parseFloat(system.sla) > 99
                            ? "✓"
                            : "~"}
                        </div>
                        <div className="text-xs text-gray-500 mt-1">
                          Reliability
                        </div>
                      </div>
                      <div className="p-3 bg-black/30 rounded border border-gray-500/30 text-center">
                        <div className="text-2xl font-bold text-cyan-400">
                          {system.criticality === "Critical"
                            ? "P1"
                            : "P2"}
                        </div>
                        <div className="text-xs text-gray-500 mt-1">
                          Priority
                        </div>
                      </div>
                      <div className="p-3 bg-black/30 rounded border border-gray-500/30 text-center">
                        <div className="text-2xl font-bold text-purple-400">
                          24/7
                        </div>
                        <div className="text-xs text-gray-500 mt-1">
                          Monitoring
                        </div>
                      </div>
                    </div>
                  </div>
                )}

                {/* Expand Indicator */}
                {isExpanded && (
                  <div className="absolute bottom-0 left-0 right-0 h-1 bg-gradient-to-r from-transparent via-cyan-400 to-transparent rounded-b-lg" />
                )}
              </div>
            </div>
          );
        })}
      </div>

      <style>{`
        @keyframes systemSlideIn {
          from {
            opacity: 0;
            transform: translateX(-30px);
          }
          to {
            opacity: 1;
            transform: translateX(0);
          }
        }

        @keyframes fadeInDown {
          from {
            opacity: 0;
            transform: translateY(-10px);
          }
          to {
            opacity: 1;
            transform: translateY(0);
          }
        }
      `}</style>
    </div>
  );
}