import { useState } from 'react';
import { TrendingUp, Clock, DollarSign, AlertCircle, Info } from 'lucide-react';

interface ResourcesTabProps {
  secureMode: boolean;
  onAuditLog: (message: string) => void;
}

interface Resource {
  id: string;
  name: string;
  tier: 'Tier-1 Critical' | 'Tier-2 High';
  rto: string;
  rpoMinutes: number;
  rpo: string;
  businessValue: string;
  dependencies: string[];
  recoveryProcedure: string;
}

const resources: Resource[] = [
  {
    id: 'RES-001',
    name: 'Core Banking Platform',
    tier: 'Tier-1 Critical',
    rto: '1 hour',
    rpoMinutes: 15,
    rpo: '15 min',
    businessValue: '$10B+ daily transaction volume',
    dependencies: ['UMB Core System', 'Tokenization Vault', 'MongoDB Ledger'],
    recoveryProcedure: 'Hot standby failover with automated health checks every 30 seconds'
  },
  {
    id: 'RES-002',
    name: 'Tokenization Vault',
    tier: 'Tier-1 Critical',
    rto: '30 min',
    rpoMinutes: 0,
    rpo: '0 (hot standby)',
    businessValue: 'Security cornerstone - no acceptable downtime',
    dependencies: ['HSM Cluster', 'Key Management Service'],
    recoveryProcedure: 'Immediate failover to secondary HSM with real-time replication'
  },
  {
    id: 'RES-003',
    name: 'Payment Rails',
    tier: 'Tier-1 Critical',
    rto: '2 hours',
    rpoMinutes: 30,
    rpo: '30 min',
    businessValue: '$5B+ daily settlements',
    dependencies: ['FedNow', 'RTP Network', 'ACH Gateway'],
    recoveryProcedure: 'Restore from incremental backups with transaction replay capability'
  },
  {
    id: 'RES-004',
    name: 'Fraud Detection',
    tier: 'Tier-2 High',
    rto: '4 hours',
    rpoMinutes: 60,
    rpo: '1 hour',
    businessValue: 'Risk mitigation - delayed start acceptable',
    dependencies: ['Transaction Stream', 'ML Model Repository'],
    recoveryProcedure: 'Deploy containerized service to backup cluster with last checkpoint'
  },
  {
    id: 'RES-005',
    name: 'Compliance Reporting',
    tier: 'Tier-2 High',
    rto: '8 hours',
    rpoMinutes: 240,
    rpo: '4 hours',
    businessValue: 'Regulatory reporting - daily/weekly cycles',
    dependencies: ['Audit Ledger', 'Data Warehouse'],
    recoveryProcedure: 'Restore from nightly backups with manual validation before reporting'
  },
  {
    id: 'RES-006',
    name: 'Customer Portal',
    tier: 'Tier-2 High',
    rto: '4 hours',
    rpoMinutes: 120,
    rpo: '2 hours',
    businessValue: 'Customer experience - degraded mode available',
    dependencies: ['Core Banking', 'Authentication Service'],
    recoveryProcedure: 'Spin up read-only mode while restoring full functionality'
  }
];

export function ResourcesTab({ secureMode, onAuditLog }: ResourcesTabProps) {
  const [selectedTier, setSelectedTier] = useState<'All' | 'Tier-1 Critical' | 'Tier-2 High'>('All');
  const [showLegend, setShowLegend] = useState(true);

  const filteredResources = selectedTier === 'All'
    ? resources
    : resources.filter(r => r.tier === selectedTier);

  const tierColors = {
    'Tier-1 Critical': { bg: 'bg-red-500/10', border: 'border-red-500/50', text: 'text-red-400', badge: 'bg-red-500' },
    'Tier-2 High': { bg: 'bg-amber-500/10', border: 'border-amber-500/50', text: 'text-amber-400', badge: 'bg-amber-500' }
  };

  const getRTOColor = (rto: string) => {
    const hours = parseInt(rto);
    if (hours <= 1) return 'text-green-400 bg-green-500/10 border-green-500/30';
    if (hours <= 4) return 'text-amber-400 bg-amber-500/10 border-amber-500/30';
    return 'text-red-400 bg-red-500/10 border-red-500/30';
  };

  const getRPOWidth = (minutes: number) => {
    const maxMinutes = 240;
    return Math.min((minutes / maxMinutes) * 100, 100);
  };

  return (
    <div>
      {/* Header */}
      <div className="mb-6">
        <h2 className="text-2xl font-bold text-white uppercase tracking-wide">Resource Prioritization</h2>
        <p className="text-cyan-400 font-mono text-sm mt-1">ID.AM-5 Compliance - Recovery Objectives</p>
      </div>

      {/* Tier Filter */}
      <div className="flex items-center justify-between mb-6">
        <div className="flex gap-2">
          {(['All', 'Tier-1 Critical', 'Tier-2 High'] as const).map((tier) => (
            <button
              key={tier}
              onClick={() => {
                setSelectedTier(tier);
                onAuditLog(`Resource filter changed to: ${tier}`);
              }}
              className={`
                px-4 py-2 rounded-lg text-sm font-semibold uppercase tracking-wide
                transition-all duration-300
                ${selectedTier === tier
                  ? 'bg-cyan-500/30 text-cyan-400 border border-cyan-500/50'
                  : 'bg-gray-500/10 text-gray-400 border border-gray-500/30 hover:bg-gray-500/20'
                }
              `}
            >
              {tier}
            </button>
          ))}
        </div>

        <button
          onClick={() => setShowLegend(!showLegend)}
          className="flex items-center gap-2 px-4 py-2 bg-gray-500/10 border border-gray-500/30 rounded-lg text-gray-400 hover:bg-gray-500/20 transition-all duration-300"
        >
          <Info className="w-4 h-4" />
          <span className="text-sm font-semibold uppercase">{showLegend ? 'Hide' : 'Show'} Legend</span>
        </button>
      </div>

      {/* Legend */}
      {showLegend && (
        <div className="mb-6 p-4 bg-gray-500/5 border border-gray-500/30 rounded-lg" style={{ animation: 'fadeIn 0.3s ease-out' }}>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4 text-sm">
            <div>
              <div className="flex items-center gap-2 mb-2">
                <Clock className="w-4 h-4 text-cyan-400" />
                <span className="font-bold text-white uppercase">RTO</span>
              </div>
              <p className="text-gray-400 text-xs">Recovery Time Objective - Maximum acceptable downtime</p>
            </div>
            <div>
              <div className="flex items-center gap-2 mb-2">
                <AlertCircle className="w-4 h-4 text-purple-400" />
                <span className="font-bold text-white uppercase">RPO</span>
              </div>
              <p className="text-gray-400 text-xs">Recovery Point Objective - Maximum acceptable data loss</p>
            </div>
            <div>
              <div className="flex items-center gap-2 mb-2">
                <DollarSign className="w-4 h-4 text-green-400" />
                <span className="font-bold text-white uppercase">Business Value</span>
              </div>
              <p className="text-gray-400 text-xs">Financial or operational impact of downtime</p>
            </div>
          </div>
        </div>
      )}

      {/* Resources Table */}
      <div className="space-y-3">
        {filteredResources.map((resource, index) => {
          const colors = tierColors[resource.tier];

          return (
            <div
              key={resource.id}
              className={`
                group relative p-5 rounded-lg border backdrop-blur-sm
                transition-all duration-300 hover:scale-[1.01] hover:shadow-lg
                ${colors.bg} ${colors.border}
              `}
              style={{
                animation: 'slideIn 0.5s ease-out forwards',
                animationDelay: `${index * 60}ms`,
                opacity: 0
              }}
            >
              {/* Header */}
              <div className="flex items-start justify-between mb-4">
                <div className="flex-1">
                  <div className="flex items-center gap-3 mb-2">
                    <h3 className="text-lg font-bold text-white">{resource.name}</h3>
                    <span className={`px-2 py-1 rounded text-xs font-bold uppercase ${colors.badge} text-white`}>
                      {resource.tier}
                    </span>
                  </div>
                  <p className="text-sm font-mono text-gray-400">{resource.id}</p>
                </div>

                <div className="flex items-center gap-2 text-green-400">
                  <DollarSign className="w-5 h-5" />
                  <span className="text-sm font-semibold">{resource.businessValue}</span>
                </div>
              </div>

              {/* RTO & RPO Metrics */}
              <div className="grid grid-cols-2 gap-4 mb-4">
                {/* RTO */}
                <div className={`p-4 rounded-lg border ${getRTOColor(resource.rto)}`}>
                  <div className="flex items-center gap-2 mb-2">
                    <Clock className="w-5 h-5" />
                    <span className="text-xs font-bold uppercase opacity-70">Recovery Time</span>
                  </div>
                  <div className="text-2xl font-bold">{resource.rto}</div>
                  <div className="text-xs opacity-70 mt-1">Maximum Downtime</div>
                </div>

                {/* RPO */}
                <div className="p-4 bg-purple-500/10 border border-purple-500/30 rounded-lg">
                  <div className="flex items-center gap-2 mb-2">
                    <AlertCircle className="w-5 h-5 text-purple-400" />
                    <span className="text-xs font-bold uppercase text-purple-400 opacity-70">Recovery Point</span>
                  </div>
                  <div className="text-2xl font-bold text-purple-400">{resource.rpo}</div>
                  <div className="text-xs text-purple-400 opacity-70 mt-1">Maximum Data Loss</div>

                  {/* RPO Visual Bar */}
                  <div className="mt-3 h-2 bg-black/30 rounded-full overflow-hidden">
                    <div
                      className="h-full bg-gradient-to-r from-purple-500 to-purple-400 transition-all duration-500"
                      style={{ width: `${getRPOWidth(resource.rpoMinutes)}%` }}
                    />
                  </div>
                </div>
              </div>

              {/* Dependencies */}
              <div className="mb-4">
                <div className="text-xs text-gray-500 uppercase mb-2">Dependencies</div>
                <div className="flex flex-wrap gap-2">
                  {resource.dependencies.map((dep) => (
                    <span
                      key={dep}
                      className="px-3 py-1 bg-black/30 border border-cyan-500/30 rounded text-xs font-mono text-cyan-400"
                    >
                      {dep}
                    </span>
                  ))}
                </div>
              </div>

              {/* Recovery Procedure */}
              <div className="pt-4 border-t border-gray-500/30">
                <div className="text-xs text-gray-500 uppercase mb-2">Recovery Procedure</div>
                <p className="text-sm text-gray-300 leading-relaxed">{resource.recoveryProcedure}</p>
              </div>

              {/* Tier Badge Indicator */}
              <div className="absolute top-4 right-4">
                <div className={`w-3 h-3 rounded-full ${colors.badge} animate-pulse`} />
              </div>
            </div>
          );
        })}
      </div>

      <style>{`
        @keyframes slideIn {
          from {
            opacity: 0;
            transform: translateY(20px);
          }
          to {
            opacity: 1;
            transform: translateY(0);
          }
        }

        @keyframes fadeIn {
          from {
            opacity: 0;
          }
          to {
            opacity: 1;
          }
        }
      `}</style>
    </div>
  );
}
