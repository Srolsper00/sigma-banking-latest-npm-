import { useState, useEffect } from "react";
import {
  FileKey,
  Lock,
  CheckCircle2,
  AlertTriangle,
  TrendingUp,
  Zap,
  Database,
  Shield,
  Clock,
  Activity,
  Info,
  ArrowRight,
} from "lucide-react";

interface CertificateTransactionTabProps {
  secureMode: boolean;
  onAuditLog: (message: string) => void;
}

export function CertificateTransactionTab({
  secureMode,
  onAuditLog,
}: CertificateTransactionTabProps) {
  const [selectedView, setSelectedView] = useState<
    | "lifecycle"
    | "transactions"
    | "suggestions"
    | "pki-integration"
  >("lifecycle");

  const handleViewChange = (view: typeof selectedView) => {
    setSelectedView(view);
    onAuditLog(
      `Switched to ${view} view in Certificates & Transactions`,
    );
  };

  return (
    <div>
      {/* Header */}
      <div className="mb-6">
        <h2 className="text-2xl font-bold text-white uppercase tracking-wide">
          Certificate Lifecycle & Critical Transactions
        </h2>
        <p className="text-cyan-400 font-mono text-sm mt-1">
          ACT2 SUDI CA - FIPS 140-2 Level 3 Compliance
        </p>
      </div>

      {/* View Selector */}
      <div className="flex gap-2 mb-6 overflow-x-auto scrollbar-hide">
        {[
          {
            id: "lifecycle",
            label: "Certificate Lifecycle",
            icon: FileKey,
          },
          {
            id: "transactions",
            label: "Critical Cluster Transactions",
            icon: Database,
          },
          {
            id: "pki-integration",
            label: "PKI System Integration",
            icon: Activity,
          },
          {
            id: "suggestions",
            label: "Optimization Suggestions",
            icon: TrendingUp,
          },
        ].map((view) => {
          const Icon = view.icon;
          return (
            <button
              key={view.id}
              onClick={() =>
                handleViewChange(view.id as typeof selectedView)
              }
              className={`
                flex items-center gap-2 px-4 py-2 rounded-lg text-sm font-semibold uppercase tracking-wide whitespace-nowrap
                transition-all duration-300
                ${
                  selectedView === view.id
                    ? "bg-cyan-500/30 text-cyan-400 border border-cyan-500/50"
                    : "bg-gray-500/10 text-gray-400 border border-gray-500/30 hover:bg-gray-500/20"
                }
              `}
            >
              <Icon className="w-4 h-4" />
              {view.label}
            </button>
          );
        })}
      </div>

      {/* Content */}
      <div style={{ animation: "fadeIn 0.3s ease-out" }}>
        {selectedView === "lifecycle" && (
          <CertificateLifecycleContent
            secureMode={secureMode}
            onAuditLog={onAuditLog}
          />
        )}
        {selectedView === "transactions" && (
          <ClusterTransactionsContent
            secureMode={secureMode}
            onAuditLog={onAuditLog}
          />
        )}
        {selectedView === "pki-integration" && (
          <PKIIntegrationContent
            secureMode={secureMode}
            onAuditLog={onAuditLog}
          />
        )}
        {selectedView === "suggestions" && (
          <SuggestionsContent
            secureMode={secureMode}
            onAuditLog={onAuditLog}
          />
        )}
      </div>

      <style>{`
        @keyframes fadeIn {
          from { opacity: 0; }
          to { opacity: 1; }
        }
        .scrollbar-hide::-webkit-scrollbar {
          display: none;
        }
        .scrollbar-hide {
          -ms-overflow-style: none;
          scrollbar-width: none;
        }
      `}</style>
    </div>
  );
}

function CertificateLifecycleContent({
  secureMode,
  onAuditLog,
}: {
  secureMode: boolean;
  onAuditLog: (msg: string) => void;
}) {
  const lifecycleStages = [
    {
      stage: "4.1 Certificate Application",
      substages: [
        {
          id: "4.1.1",
          name: "Subscriber Validation",
          status: "active",
          description:
            "ACT2 chip serial number validation against pre-registered chips",
        },
        {
          id: "4.1.2",
          name: "Enrollment Process",
          status: "active",
          description:
            "Encrypted communications and protected information storage",
        },
      ],
    },
    {
      stage: "4.2 Application Processing",
      substages: [
        {
          id: "4.2.1",
          name: "Authentication",
          status: "active",
          description:
            "Serial number, PID validation, and signature verification",
        },
        {
          id: "4.2.2",
          name: "Approval/Rejection",
          status: "active",
          description:
            "Automated decision with success/error code transmission",
        },
        {
          id: "4.2.3",
          name: "Processing Time",
          status: "optimal",
          description: "Prompt rendering, no specific SLA",
        },
      ],
    },
    {
      stage: "4.3 Certificate Issuance",
      substages: [
        {
          id: "4.3.1",
          name: "CA Actions",
          status: "active",
          description:
            "TLS mutual certificate authentication channel",
        },
        {
          id: "4.3.2",
          name: "Notification",
          status: "active",
          description:
            "Certificate receipt constitutes notification",
        },
      ],
    },
    {
      stage: "4.4 Certificate Acceptance",
      substages: [
        {
          id: "4.4.1",
          name: "Acceptance",
          status: "active",
          description:
            "Successful reception over authenticated channel",
        },
        {
          id: "4.4.2",
          name: "Publication",
          status: "disabled",
          description: "No public repository publication",
        },
      ],
    },
    {
      stage: "4.5 Key Pair & Certificate Usage",
      substages: [
        {
          id: "4.5.1",
          name: "Private Key Usage",
          status: "secured",
          description:
            "FIPS 140-2 Level 3 hardware chip storage",
        },
        {
          id: "4.5.2",
          name: "Public Key Usage",
          status: "active",
          description:
            "Authentication, encryption, digital signatures",
        },
      ],
    },
  ];

  const statusColors: Record<
    string,
    { bg: string; text: string; border: string }
  > = {
    active: {
      bg: "bg-green-500/10",
      text: "text-green-400",
      border: "border-green-500/30",
    },
    optimal: {
      bg: "bg-cyan-500/10",
      text: "text-cyan-400",
      border: "border-cyan-500/30",
    },
    secured: {
      bg: "bg-purple-500/10",
      text: "text-purple-400",
      border: "border-purple-500/30",
    },
    disabled: {
      bg: "bg-gray-500/10",
      text: "text-gray-400",
      border: "border-gray-500/30",
    },
  };

  return (
    <div className="space-y-6">
      {/* FIPS Compliance Banner */}
      <div className="p-6 bg-purple-500/10 border border-purple-500/50 rounded-lg">
        <div className="flex items-start gap-4">
          <div className="p-3 bg-purple-500/20 border border-purple-500/50 rounded-lg">
            <Shield className="w-6 h-6 text-purple-400" />
          </div>
          <div className="flex-1">
            <div className="flex items-center gap-3 mb-2">
              <h3 className="text-xl font-bold text-white">
                ACT2 SUDI CA Certificate Practice Statement
              </h3>
              <div className="px-2 py-1 bg-purple-500 text-white text-xs font-bold rounded uppercase">
                FIPS 140-2 L3
              </div>
            </div>
            <p className="text-gray-300 mb-3">
              Hardware-based certificate lifecycle for Cisco
              ACT2 Subscribing Products with FIPS 140-2 Level 3
              certified secure storage
            </p>
            <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
              <div className="p-3 bg-black/30 rounded border border-purple-500/30 text-center">
                <div className="text-xl font-bold text-purple-400">
                  TLS 1.3
                </div>
                <div className="text-xs text-gray-500">
                  Mutual Auth
                </div>
              </div>
              <div className="p-3 bg-black/30 rounded border border-purple-500/30 text-center">
                <div className="text-xl font-bold text-green-400">
                  X.509
                </div>
                <div className="text-xs text-gray-500">
                  RFC 5280
                </div>
              </div>
              <div className="p-3 bg-black/30 rounded border border-purple-500/30 text-center">
                <div className="text-xl font-bold text-cyan-400">
                  Encrypted
                </div>
                <div className="text-xs text-gray-500">
                  End-to-End
                </div>
              </div>
              <div className="p-3 bg-black/30 rounded border border-purple-500/30 text-center">
                <div className="text-xl font-bold text-amber-400">
                  Auto
                </div>
                <div className="text-xs text-gray-500">
                  Processing
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Lifecycle Stages */}
      <div className="space-y-4">
        {lifecycleStages.map((stage, stageIdx) => (
          <div
            key={stage.stage}
            className="p-5 bg-gray-500/5 border border-gray-500/30 rounded-lg"
            style={{
              animation: "slideIn 0.4s ease-out forwards",
              animationDelay: `${stageIdx * 100}ms`,
              opacity: 0,
            }}
          >
            <h4 className="text-lg font-bold text-white mb-4 flex items-center gap-2">
              <FileKey className="w-5 h-5 text-cyan-400" />
              {stage.stage}
            </h4>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
              {stage.substages.map((substage, subIdx) => {
                const colors = statusColors[substage.status];
                return (
                  <div
                    key={substage.id}
                    className={`p-4 rounded border ${colors.bg} ${colors.border}`}
                    style={{
                      animation:
                        "scaleIn 0.3s ease-out forwards",
                      animationDelay: `${stageIdx * 100 + subIdx * 50}ms`,
                      opacity: 0,
                    }}
                  >
                    <div className="flex items-center justify-between mb-2">
                      <span className="font-mono text-xs text-gray-400">
                        {substage.id}
                      </span>
                      <div
                        className={`px-2 py-1 rounded text-xs font-bold uppercase ${colors.text}`}
                      >
                        {substage.status}
                      </div>
                    </div>
                    <h5 className="font-bold text-white mb-1">
                      {substage.name}
                    </h5>
                    <p className="text-sm text-gray-400">
                      {substage.description}
                    </p>
                  </div>
                );
              })}
            </div>
          </div>
        ))}
      </div>

      <style>{`
        @keyframes slideIn {
          from { opacity: 0; transform: translateY(20px); }
          to { opacity: 1; transform: translateY(0); }
        }
        @keyframes scaleIn {
          from { opacity: 0; transform: scale(0.95); }
          to { opacity: 1; transform: scale(1); }
        }
      `}</style>
    </div>
  );
}

function ClusterTransactionsContent({
  secureMode,
  onAuditLog,
}: {
  secureMode: boolean;
  onAuditLog: (msg: string) => void;
}) {
  const clusterNodes = [
    {
      id: "CLUSTER-01",
      name: "Core Banking Primary",
      transactions: 15847,
      tps: 2341,
      latency: 12,
      status: "optimal",
      health: 98,
      load: 72,
    },
    {
      id: "CLUSTER-02",
      name: "Payment Gateway Node",
      transactions: 8923,
      tps: 1847,
      latency: 8,
      status: "optimal",
      health: 99,
      load: 58,
    },
    {
      id: "CLUSTER-03",
      name: "Tokenization Vault",
      transactions: 12456,
      tps: 2156,
      latency: 5,
      status: "optimal",
      health: 100,
      load: 45,
    },
    {
      id: "CLUSTER-04",
      name: "Settlement Processor",
      transactions: 6234,
      tps: 987,
      latency: 15,
      status: "warning",
      health: 89,
      load: 94,
    },
    {
      id: "CLUSTER-05",
      name: "Ledger Replication",
      transactions: 9876,
      tps: 1234,
      latency: 22,
      status: "warning",
      health: 85,
      load: 88,
    },
  ];

  const getStatusColor = (status: string) => {
    return status === "optimal"
      ? {
          bg: "bg-green-500/10",
          text: "text-green-400",
          border: "border-green-500/50",
          badge: "bg-green-500",
        }
      : {
          bg: "bg-amber-500/10",
          text: "text-amber-400",
          border: "border-amber-500/50",
          badge: "bg-amber-500",
        };
  };

  return (
    <div className="space-y-6">
      {/* Overview Metrics */}
      <div className="grid grid-cols-2 md:grid-cols-5 gap-4">
        {[
          {
            label: "Total Transactions",
            value: "53.3K",
            subtext: "Last Hour",
            color: "cyan",
          },
          {
            label: "Avg TPS",
            value: "1,713",
            subtext: "Transactions/sec",
            color: "green",
          },
          {
            label: "Avg Latency",
            value: "12.4ms",
            subtext: "Response Time",
            color: "purple",
          },
          {
            label: "Cluster Health",
            value: "94%",
            subtext: "All Nodes",
            color: "green",
          },
          {
            label: "Critical Alerts",
            value: "2",
            subtext: "High Load Nodes",
            color: "amber",
          },
        ].map((metric, idx) => (
          <div
            key={metric.label}
            className={`p-4 bg-${metric.color}-500/10 border border-${metric.color}-500/30 rounded-lg`}
            style={{
              animation: "scaleIn 0.4s ease-out forwards",
              animationDelay: `${idx * 80}ms`,
              opacity: 0,
            }}
          >
            <div
              className={`text-2xl font-bold text-${metric.color}-400 mb-1`}
            >
              {metric.value}
            </div>
            <div className="text-xs text-gray-400 uppercase mb-1">
              {metric.label}
            </div>
            <div className="text-xs text-gray-500">
              {metric.subtext}
            </div>
          </div>
        ))}
      </div>

      {/* Cluster Nodes */}
      <div className="space-y-3">
        {clusterNodes.map((node, idx) => {
          const colors = getStatusColor(node.status);

          return (
            <div
              key={node.id}
              className={`p-5 rounded-lg border backdrop-blur-sm ${colors.bg} ${colors.border}`}
              style={{
                animation: "slideUp 0.4s ease-out forwards",
                animationDelay: `${idx * 100}ms`,
                opacity: 0,
              }}
            >
              <div className="flex items-start justify-between mb-4">
                <div className="flex items-start gap-4">
                  <div
                    className={`p-3 rounded-lg border ${colors.bg} ${colors.border}`}
                  >
                    <Database
                      className={`w-6 h-6 ${colors.text}`}
                    />
                  </div>
                  <div>
                    <h3 className="text-lg font-bold text-white mb-1">
                      {node.name}
                    </h3>
                    <div className="flex items-center gap-3 text-sm">
                      <span className="font-mono text-gray-400">
                        {node.id}
                      </span>
                      <span className="text-gray-500">•</span>
                      <span
                        className={`font-semibold uppercase ${colors.text}`}
                      >
                        {node.status}
                      </span>
                    </div>
                  </div>
                </div>

                <div
                  className={`px-3 py-2 rounded border ${colors.border} ${colors.bg}`}
                >
                  <div className="flex items-center gap-2">
                    <div
                      className={`w-2 h-2 rounded-full ${colors.badge} animate-pulse`}
                    />
                    <span
                      className={`text-sm font-bold ${colors.text}`}
                    >
                      Health: {node.health}%
                    </span>
                  </div>
                </div>
              </div>

              {/* Metrics Grid */}
              <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
                <div className="p-3 bg-black/30 rounded border border-gray-500/30">
                  <div className="text-xs text-gray-500 uppercase mb-1">
                    Transactions
                  </div>
                  <div className="text-lg font-bold text-white">
                    {node.transactions.toLocaleString()}
                  </div>
                </div>
                <div className="p-3 bg-black/30 rounded border border-gray-500/30">
                  <div className="text-xs text-gray-500 uppercase mb-1">
                    TPS
                  </div>
                  <div className="text-lg font-bold text-cyan-400">
                    {node.tps.toLocaleString()}
                  </div>
                </div>
                <div className="p-3 bg-black/30 rounded border border-gray-500/30">
                  <div className="text-xs text-gray-500 uppercase mb-1">
                    Latency
                  </div>
                  <div className="text-lg font-bold text-purple-400">
                    {node.latency}ms
                  </div>
                </div>
                <div className="p-3 bg-black/30 rounded border border-gray-500/30">
                  <div className="text-xs text-gray-500 uppercase mb-1">
                    Load
                  </div>
                  <div
                    className={`text-lg font-bold ${node.load > 85 ? "text-red-400" : "text-green-400"}`}
                  >
                    {node.load}%
                  </div>
                </div>
              </div>

              {/* Load Bar */}
              <div className="mt-3">
                <div className="h-2 bg-black/30 rounded-full overflow-hidden">
                  <div
                    className={`h-full ${node.load > 85 ? "bg-gradient-to-r from-red-500 to-amber-500" : "bg-gradient-to-r from-green-500 to-cyan-500"}`}
                    style={{
                      width: `${node.load}%`,
                      animation: "expandBar 1s ease-out",
                    }}
                  />
                </div>
              </div>
            </div>
          );
        })}
      </div>

      <style>{`
        @keyframes scaleIn {
          from { opacity: 0; transform: scale(0.95); }
          to { opacity: 1; transform: scale(1); }
        }
        @keyframes slideUp {
          from { opacity: 0; transform: translateY(20px); }
          to { opacity: 1; transform: translateY(0); }
        }
        @keyframes expandBar {
          from { width: 0; }
        }
      `}</style>
    </div>
  );
}

function SuggestionsContent({
  secureMode,
  onAuditLog,
}: {
  secureMode: boolean;
  onAuditLog: (msg: string) => void;
}) {
  const suggestions = [
    {
      id: "SUGG-001",
      category: "Performance Optimization",
      priority: "high",
      title:
        "Implement Transaction Sharding for Settlement Processor",
      description:
        "CLUSTER-04 Settlement Processor is experiencing 94% load. Implement horizontal sharding to distribute transactions across multiple nodes.",
      impact:
        "Reduce latency by 40%, increase throughput by 3x",
      implementation: [
        "Deploy 2 additional settlement processor nodes",
        "Configure consistent hashing for transaction distribution",
        "Implement sticky sessions for in-flight transactions",
        "Update load balancer with weighted round-robin",
      ],
      estimatedTime: "4 hours",
      cost: "Medium",
    },
    {
      id: "SUGG-002",
      category: "Certificate Management",
      priority: "critical",
      title: "Automate Certificate Rotation for ACT2 Chips",
      description:
        "Current manual certificate renewal process poses security risk. Implement automated rotation with zero-downtime deployment.",
      impact:
        "Eliminate manual intervention, reduce cert expiry risk",
      implementation: [
        "Deploy cert-manager with ACT2 SUDI CA integration",
        "Configure 30-day pre-expiry renewal triggers",
        "Implement blue-green rotation for active certificates",
        "Enable automatic rollback on validation failure",
      ],
      estimatedTime: "8 hours",
      cost: "Low",
    },
    {
      id: "SUGG-003",
      category: "Data Archival",
      priority: "medium",
      title:
        "Increase S3 Express Archival to 75% for Historical Ledger Data",
      description:
        "Current 62% archival rate can be optimized. Archive ledger entries older than 90 days to S3 Express for cost savings.",
      impact: "90% cost reduction, maintain <100ms retrieval",
      implementation: [
        "Identify ledger entries with last_access > 90 days",
        "Configure S3 Lifecycle policies for auto-archival",
        "Implement transparent retrieval layer in Ledger Service",
        "Monitor query performance post-migration",
      ],
      estimatedTime: "6 hours",
      cost: "Very Low",
    },
    {
      id: "SUGG-004",
      category: "Transaction Processing",
      priority: "high",
      title: "Enable Connection Pooling for Ledger Replication",
      description:
        "CLUSTER-05 Ledger Replication shows 22ms latency. Implement connection pooling to reduce TCP handshake overhead.",
      impact:
        "Reduce latency to <10ms, improve throughput by 60%",
      implementation: [
        "Configure PgBouncer for Postgres connection pooling",
        "Set pool size to 100 connections per node",
        "Enable transaction-level pooling mode",
        "Implement connection health checks every 30s",
      ],
      estimatedTime: "2 hours",
      cost: "Low",
    },
    {
      id: "SUGG-005",
      category: "Security Enhancement",
      priority: "critical",
      title:
        "Implement TLS Session Resumption for Certificate Validation",
      description:
        "Reduce TLS handshake latency for ACT2 SUDI certificate validation by enabling session tickets and resumption.",
      impact:
        "Reduce cert validation time by 80%, save CPU cycles",
      implementation: [
        "Enable TLS session tickets on all ACT2 SubCAs",
        "Configure 24-hour ticket lifetime",
        "Implement session cache with Redis backing",
        "Monitor resumption rate (target: >90%)",
      ],
      estimatedTime: "3 hours",
      cost: "Low",
    },
  ];

  const priorityColors = {
    critical: {
      bg: "bg-red-500/10",
      text: "text-red-400",
      border: "border-red-500/50",
      badge: "bg-red-500",
    },
    high: {
      bg: "bg-amber-500/10",
      text: "text-amber-400",
      border: "border-amber-500/50",
      badge: "bg-amber-500",
    },
    medium: {
      bg: "bg-cyan-500/10",
      text: "text-cyan-400",
      border: "border-cyan-500/50",
      badge: "bg-cyan-500",
    },
  };

  return (
    <div className="space-y-4">
      {/* Summary Banner */}
      <div className="p-6 bg-gradient-to-r from-cyan-500/10 via-purple-500/10 to-green-500/10 border border-gray-500/30 rounded-lg">
        <div className="flex items-center justify-between">
          <div>
            <h3 className="text-xl font-bold text-white mb-2">
              AI-Powered Optimization Recommendations
            </h3>
            <p className="text-sm text-gray-400">
              Based on real-time cluster analysis and
              certificate lifecycle monitoring
            </p>
          </div>
          <div className="flex gap-3">
            <div className="text-center">
              <div className="text-3xl font-bold text-red-400">
                2
              </div>
              <div className="text-xs text-gray-500 uppercase">
                Critical
              </div>
            </div>
            <div className="text-center">
              <div className="text-3xl font-bold text-amber-400">
                2
              </div>
              <div className="text-xs text-gray-500 uppercase">
                High
              </div>
            </div>
            <div className="text-center">
              <div className="text-3xl font-bold text-cyan-400">
                1
              </div>
              <div className="text-xs text-gray-500 uppercase">
                Medium
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Suggestions */}
      {suggestions.map((suggestion, idx) => {
        const colors =
          priorityColors[
            suggestion.priority as keyof typeof priorityColors
          ];

        return (
          <div
            key={suggestion.id}
            className={`p-6 rounded-lg border backdrop-blur-sm ${colors.bg} ${colors.border}`}
            style={{
              animation: "slideIn 0.4s ease-out forwards",
              animationDelay: `${idx * 80}ms`,
              opacity: 0,
            }}
          >
            {/* Header */}
            <div className="flex items-start justify-between mb-4">
              <div className="flex-1">
                <div className="flex items-center gap-3 mb-2">
                  <span
                    className={`px-3 py-1 rounded text-xs font-bold uppercase ${colors.badge} text-white`}
                  >
                    {suggestion.priority}
                  </span>
                  <span className="font-mono text-sm text-gray-400">
                    {suggestion.id}
                  </span>
                  <span className="text-sm text-gray-500">
                    {suggestion.category}
                  </span>
                </div>
                <h4 className="text-lg font-bold text-white mb-2">
                  {suggestion.title}
                </h4>
                <p className="text-sm text-gray-300 mb-3">
                  {suggestion.description}
                </p>

                {/* Impact */}
                <div
                  className={`inline-flex items-center gap-2 px-3 py-1 rounded border ${colors.border} ${colors.bg}`}
                >
                  <TrendingUp
                    className={`w-4 h-4 ${colors.text}`}
                  />
                  <span
                    className={`text-sm font-semibold ${colors.text}`}
                  >
                    Impact: {suggestion.impact}
                  </span>
                </div>
              </div>

              <div className="flex flex-col gap-2 ml-4">
                <div className="px-3 py-2 bg-black/30 rounded border border-gray-500/30 text-center">
                  <div className="text-xs text-gray-500 uppercase mb-1">
                    Est. Time
                  </div>
                  <div className="text-sm font-bold text-white">
                    {suggestion.estimatedTime}
                  </div>
                </div>
                <div className="px-3 py-2 bg-black/30 rounded border border-gray-500/30 text-center">
                  <div className="text-xs text-gray-500 uppercase mb-1">
                    Cost
                  </div>
                  <div className="text-sm font-bold text-green-400">
                    {suggestion.cost}
                  </div>
                </div>
              </div>
            </div>

            {/* Implementation Steps */}
            <div className="mt-4 pt-4 border-t border-gray-500/30">
              <div className="flex items-center gap-2 mb-3">
                <Zap className="w-4 h-4 text-cyan-400" />
                <h5 className="text-sm font-bold text-white uppercase">
                  Implementation Steps
                </h5>
              </div>
              <div className="space-y-2">
                {suggestion.implementation.map(
                  (step, stepIdx) => (
                    <div
                      key={stepIdx}
                      className="flex items-start gap-3 text-sm text-gray-300"
                    >
                      <div className="flex items-center justify-center w-6 h-6 rounded-full bg-cyan-500/20 border border-cyan-500/30 flex-shrink-0 mt-0.5">
                        <span className="text-xs font-bold text-cyan-400">
                          {stepIdx + 1}
                        </span>
                      </div>
                      <span>{step}</span>
                    </div>
                  ),
                )}
              </div>
            </div>
          </div>
        );
      })}

      <style>{`
        @keyframes slideIn {
          from { opacity: 0; transform: translateX(-20px); }
          to { opacity: 1; transform: translateX(0); }
        }
      `}</style>
    </div>
  );
}

function PKIIntegrationContent({
  secureMode,
  onAuditLog,
}: {
  secureMode: boolean;
  onAuditLog: (msg: string) => void;
}) {
  const [lastUpdate, setLastUpdate] = useState(
    new Date().toISOString(),
  );
  const [autoUpdateEnabled, setAutoUpdateEnabled] =
    useState(true);
  const [nextScheduledUpdate, setNextScheduledUpdate] =
    useState(new Date(Date.now() + 86400000).toISOString());
  const [systemIntegrations, setSystemIntegrations] = useState([
    {
      id: "PKI-INT-001",
      name: "Citi Bank Statement Initiation API",
      endpoint: "tts.sandbox.apib2b.citi.com",
      protocol: "mTLS + OAuth",
      certificateStatus: "valid",
      certificateExpiry: new Date(
        Date.now() + 86400000 * 45,
      ).toISOString(),
      lastRotation: new Date(
        Date.now() - 86400000 * 30,
      ).toISOString(),
      nextRotation: new Date(
        Date.now() + 86400000 * 30,
      ).toISOString(),
      tokenRefresh: "every-15-min",
      encryptionStandard: "ISO-20022 pain.002.001.03",
      format: "SWIFT-MT940",
      status: "operational",
      dailyUpdateStatus: "completed",
      lastUpdate: new Date(Date.now() - 3600000).toISOString(),
      checksumValidation: "N/A",
      complianceFramework: "SOX, PCI-DSS",
    },
    {
      id: "PKI-INT-002",
      name: "Federal Reserve Bank Services",
      endpoint: "frbservices.org",
      protocol: "X.509 + TLS 1.3",
      certificateStatus: "valid",
      certificateExpiry: new Date(
        Date.now() + 86400000 * 60,
      ).toISOString(),
      lastRotation: new Date(
        Date.now() - 86400000 * 15,
      ).toISOString(),
      nextRotation: new Date(
        Date.now() + 86400000 * 45,
      ).toISOString(),
      tokenRefresh: "N/A",
      encryptionStandard: "AES-256-GCM",
      format: "FedWire XML",
      status: "operational",
      dailyUpdateStatus: "completed",
      lastUpdate: new Date(Date.now() - 1800000).toISOString(),
      checksumValidation: "N/A",
      complianceFramework: "Federal Reserve Regulation, FinCEN",
    },
    {
      id: "PKI-INT-003",
      name: "ID.me Identity Verification",
      endpoint: "developers.id.me",
      protocol: "OAuth 2.0 + OIDC",
      certificateStatus: "valid",
      certificateExpiry: new Date(
        Date.now() + 86400000 * 90,
      ).toISOString(),
      lastRotation: new Date(
        Date.now() - 86400000 * 10,
      ).toISOString(),
      nextRotation: new Date(
        Date.now() + 86400000 * 80,
      ).toISOString(),
      tokenRefresh: "every-60-min",
      encryptionStandard: "NIST-800-63-3",
      format: "JWT + OpenID",
      status: "operational",
      dailyUpdateStatus: "completed",
      lastUpdate: new Date(Date.now() - 7200000).toISOString(),
      checksumValidation: "N/A",
      complianceFramework: "NIST-800-63, SOC-2",
    },
    {
      id: "PKI-INT-004",
      name: "Oracle Database Cloud",
      endpoint: "www.oracle.com",
      protocol: "mTLS + Wallet Auth",
      certificateStatus: "valid",
      certificateExpiry: new Date(
        Date.now() + 86400000 * 120,
      ).toISOString(),
      lastRotation: new Date(
        Date.now() - 86400000 * 5,
      ).toISOString(),
      nextRotation: new Date(
        Date.now() + 86400000 * 115,
      ).toISOString(),
      tokenRefresh: "N/A",
      encryptionStandard: "TDE + AES-256",
      format: "SQL*Net",
      status: "operational",
      dailyUpdateStatus: "completed",
      lastUpdate: new Date(Date.now() - 5400000).toISOString(),
      checksumValidation: "N/A",
      complianceFramework: "HIPAA, SOX, GDPR",
    },
    {
      id: "PKI-INT-005",
      name: "Stripe Payment Gateway",
      endpoint: "api.stripe.com",
      protocol: "Bearer Token + TLS 1.3",
      certificateStatus: "valid",
      certificateExpiry: new Date(
        Date.now() + 86400000 * 75,
      ).toISOString(),
      lastRotation: new Date(
        Date.now() - 86400000 * 20,
      ).toISOString(),
      nextRotation: new Date(
        Date.now() + 86400000 * 55,
      ).toISOString(),
      tokenRefresh: "never",
      encryptionStandard: "PCI-DSS Level 1",
      format: "REST-JSON",
      status: "operational",
      dailyUpdateStatus: "completed",
      lastUpdate: new Date(Date.now() - 1200000).toISOString(),
      checksumValidation: "SHA-256",
      complianceFramework: "PCI-DSS, SOC-1, SOC-2",
    },
  ]);

  const handleManualUpdate = (integrationId: string) => {
    if (!secureMode) {
      onAuditLog(
        `PKI update failed for ${integrationId} - secure mode required`,
      );
      return;
    }

    setSystemIntegrations((prev) =>
      prev.map((int) =>
        int.id === integrationId
          ? {
              ...int,
              dailyUpdateStatus: "in-progress",
              lastUpdate: new Date().toISOString(),
            }
          : int,
      ),
    );

    onAuditLog(
      `Manual PKI update initiated for ${integrationId}`,
    );

    setTimeout(() => {
      setSystemIntegrations((prev) =>
        prev.map((int) =>
          int.id === integrationId
            ? { ...int, dailyUpdateStatus: "completed" }
            : int,
        ),
      );
      onAuditLog(`PKI update completed for ${integrationId}`);
    }, 2000);
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case "operational":
        return {
          bg: "bg-green-500/10",
          text: "text-green-400",
          border: "border-green-500/30",
        };
      case "warning":
        return {
          bg: "bg-yellow-500/10",
          text: "text-yellow-400",
          border: "border-yellow-500/30",
        };
      case "critical":
        return {
          bg: "bg-red-500/10",
          text: "text-red-400",
          border: "border-red-500/30",
        };
      default:
        return {
          bg: "bg-gray-500/10",
          text: "text-gray-400",
          border: "border-gray-500/30",
        };
    }
  };

  const getDaysUntilExpiry = (expiry: string) => {
    return Math.floor(
      (new Date(expiry).getTime() - Date.now()) /
        (1000 * 60 * 60 * 24),
    );
  };

  const handleAutomatedDailyUpdate = () => {
    if (!autoUpdateEnabled) return;

    const randomIntegration =
      systemIntegrations[
        Math.floor(Math.random() * systemIntegrations.length)
      ];

    setSystemIntegrations((prev) =>
      prev.map((int) =>
        int.id === randomIntegration.id
          ? {
              ...int,
              dailyUpdateStatus: "in-progress",
              lastUpdate: new Date().toISOString(),
            }
          : int,
      ),
    );

    onAuditLog(
      `Automated PKI daily update started for ${randomIntegration.name}`,
    );

    setTimeout(() => {
      setSystemIntegrations((prev) =>
        prev.map((int) =>
          int.id === randomIntegration.id
            ? {
                ...int,
                dailyUpdateStatus: "completed",
                lastRotation: new Date().toISOString(),
                certificateStatus: "valid",
              }
            : int,
        ),
      );
      setLastUpdate(new Date().toISOString());
      setNextScheduledUpdate(
        new Date(Date.now() + 86400000).toISOString(),
      );
      onAuditLog(
        `Automated PKI update completed for ${randomIntegration.name} - Certificate rotated successfully`,
      );
    }, 3000);
  };

  const handleUpdateAll = () => {
    if (!secureMode) {
      onAuditLog(
        "Bulk PKI update failed - secure mode required",
      );
      return;
    }

    setSystemIntegrations((prev) =>
      prev.map((int) => ({
        ...int,
        dailyUpdateStatus: "in-progress",
        lastUpdate: new Date().toISOString(),
      })),
    );

    onAuditLog(
      `Bulk PKI update initiated for all ${systemIntegrations.length} system integrations`,
    );

    setTimeout(() => {
      setSystemIntegrations((prev) =>
        prev.map((int) => ({
          ...int,
          dailyUpdateStatus: "completed",
          lastRotation: new Date().toISOString(),
          certificateStatus: "valid",
        })),
      );
      setLastUpdate(new Date().toISOString());
      setNextScheduledUpdate(
        new Date(Date.now() + 86400000).toISOString(),
      );
      onAuditLog(
        `Bulk PKI update completed - All ${systemIntegrations.length} integrations updated successfully`,
      );
    }, 5000);
  };

  // Automated daily PKI updates - runs every 10 seconds for demo (in production: every 24 hours)
  useEffect(() => {
    if (!autoUpdateEnabled) return;

    const interval = setInterval(() => {
      handleAutomatedDailyUpdate();
    }, 10000); // 10 seconds for demo; use 86400000 for 24 hours in production

    return () => clearInterval(interval);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [autoUpdateEnabled]);

  return (
    <div className="space-y-6">
      {/* PKI Integration Header */}
      <div className="p-6 bg-gradient-to-r from-indigo-900/20 via-purple-900/20 to-indigo-900/20 border border-indigo-500/30 rounded-lg">
        <div className="flex items-center justify-between mb-4">
          <div>
            <h3 className="text-2xl font-bold text-white mb-2">
              Daily PKI System Integration Updates
            </h3>
            <p className="text-sm text-gray-400">
              Automated certificate rotation, token refresh, and
              compliance validation
            </p>
          </div>
          <div className="flex items-center gap-2">
            <Clock className="w-5 h-5 text-cyan-400" />
            <div className="text-right">
              <div className="text-xs text-gray-400">
                Last System-Wide Update
              </div>
              <div className="text-sm font-mono text-cyan-400">
                {new Date(lastUpdate).toLocaleString()}
              </div>
            </div>
          </div>
        </div>

        {/* Summary Stats */}
        <div className="grid grid-cols-5 gap-3">
          <div className="bg-black/40 border border-green-500/20 rounded-lg p-3 text-center">
            <div className="text-2xl font-bold text-green-400">
              {
                systemIntegrations.filter(
                  (s) => s.status === "operational",
                ).length
              }
            </div>
            <div className="text-xs text-gray-400 mt-1">
              Operational
            </div>
          </div>
          <div className="bg-black/40 border border-cyan-500/20 rounded-lg p-3 text-center">
            <div className="text-2xl font-bold text-cyan-400">
              {
                systemIntegrations.filter(
                  (s) => s.dailyUpdateStatus === "completed",
                ).length
              }
            </div>
            <div className="text-xs text-gray-400 mt-1">
              Updated Today
            </div>
          </div>
          <div className="bg-black/40 border border-purple-500/20 rounded-lg p-3 text-center">
            <div className="text-2xl font-bold text-purple-400">
              {
                systemIntegrations.filter((s) =>
                  s.protocol.includes("mTLS"),
                ).length
              }
            </div>
            <div className="text-xs text-gray-400 mt-1">
              mTLS Enabled
            </div>
          </div>
          <div className="bg-black/40 border border-orange-500/20 rounded-lg p-3 text-center">
            <div className="text-2xl font-bold text-orange-400">
              {
                systemIntegrations.filter(
                  (s) =>
                    s.tokenRefresh !== "N/A" &&
                    s.tokenRefresh !== "never",
                ).length
              }
            </div>
            <div className="text-xs text-gray-400 mt-1">
              Token Refresh Active
            </div>
          </div>
          <div className="bg-black/40 border border-red-500/20 rounded-lg p-3 text-center">
            <div className="text-2xl font-bold text-red-400">
              {
                systemIntegrations.filter(
                  (s) =>
                    getDaysUntilExpiry(s.certificateExpiry) <
                    30,
                ).length
              }
            </div>
            <div className="text-xs text-gray-400 mt-1">
              Expiring Soon
            </div>
          </div>
        </div>
      </div>

      {/* Automation Controls */}
      <div className="p-6 bg-gradient-to-r from-cyan-900/20 via-blue-900/20 to-cyan-900/20 border border-cyan-500/30 rounded-lg">
        <div className="flex items-center justify-between mb-4">
          <div className="flex items-center gap-4">
            <div className="flex items-center gap-3">
              <Activity className="w-6 h-6 text-cyan-400" />
              <div>
                <h4 className="text-lg font-bold text-white">
                  Automated Daily PKI Updates
                </h4>
                <p className="text-xs text-gray-400">
                  Scheduled certificate rotation and validation
                </p>
              </div>
            </div>
            <button
              onClick={() => {
                setAutoUpdateEnabled(!autoUpdateEnabled);
                onAuditLog(
                  `Automated PKI updates ${!autoUpdateEnabled ? "ENABLED" : "DISABLED"}`,
                );
              }}
              className={`px-4 py-2 rounded-lg text-sm font-semibold transition-all ${
                autoUpdateEnabled
                  ? "bg-green-600 text-white hover:bg-green-500"
                  : "bg-gray-700 text-gray-400 hover:bg-gray-600"
              }`}
            >
              {autoUpdateEnabled
                ? "✓ Auto-Update ON"
                : "Auto-Update OFF"}
            </button>
          </div>
          <button
            onClick={handleUpdateAll}
            disabled={!secureMode}
            className={`px-6 py-2 rounded-lg text-sm font-semibold transition-all ${
              secureMode
                ? "bg-gradient-to-r from-purple-600 to-indigo-600 text-white hover:from-purple-500 hover:to-indigo-500"
                : "bg-gray-700 text-gray-500 cursor-not-allowed"
            }`}
          >
            Update All Systems Now
          </button>
        </div>

        <div className="grid grid-cols-3 gap-4">
          <div className="bg-black/40 border border-cyan-500/20 rounded-lg p-4">
            <div className="flex items-center gap-2 mb-2">
              <Clock className="w-4 h-4 text-cyan-400" />
              <div className="text-xs text-gray-400">
                Next Scheduled Update
              </div>
            </div>
            <div className="text-sm font-mono text-cyan-400">
              {new Date(nextScheduledUpdate).toLocaleString()}
            </div>
            <div className="text-xs text-gray-500 mt-1">
              {Math.floor(
                (new Date(nextScheduledUpdate).getTime() -
                  Date.now()) /
                  (1000 * 60 * 60),
              )}{" "}
              hours remaining
            </div>
          </div>
          <div className="bg-black/40 border border-green-500/20 rounded-lg p-4">
            <div className="flex items-center gap-2 mb-2">
              <CheckCircle2 className="w-4 h-4 text-green-400" />
              <div className="text-xs text-gray-400">
                Automation Status
              </div>
            </div>
            <div
              className={`text-sm font-semibold ${autoUpdateEnabled ? "text-green-400" : "text-gray-400"}`}
            >
              {autoUpdateEnabled ? "ACTIVE" : "INACTIVE"}
            </div>
            <div className="text-xs text-gray-500 mt-1">
              {autoUpdateEnabled
                ? "Daily rotation enabled"
                : "Manual updates only"}
            </div>
          </div>
          <div className="bg-black/40 border border-purple-500/20 rounded-lg p-4">
            <div className="flex items-center gap-2 mb-2">
              <Shield className="w-4 h-4 text-purple-400" />
              <div className="text-xs text-gray-400">
                Rotation Policy
              </div>
            </div>
            <div className="text-sm font-semibold text-purple-400">
              24-Hour Cycle
            </div>
            <div className="text-xs text-gray-500 mt-1">
              Zero-downtime deployment
            </div>
          </div>
        </div>
      </div>

      {/* System Integrations */}
      <div className="space-y-4">
        {systemIntegrations.map((integration, idx) => {
          const colors = getStatusColor(integration.status);
          const daysUntilExpiry = getDaysUntilExpiry(
            integration.certificateExpiry,
          );
          const expiryWarning = daysUntilExpiry < 30;

          return (
            <div
              key={integration.id}
              className={`p-6 rounded-lg border backdrop-blur-sm ${colors.bg} ${colors.border}`}
              style={{
                animation: "slideIn 0.4s ease-out forwards",
                animationDelay: `${idx * 80}ms`,
                opacity: 0,
              }}
            >
              {/* Header */}
              <div className="flex items-start justify-between mb-4">
                <div className="flex-1">
                  <div className="flex items-center gap-3 mb-2">
                    <h4 className="text-lg font-bold text-white">
                      {integration.name}
                    </h4>
                    <span
                      className={`px-2 py-1 rounded text-xs font-bold uppercase ${colors.text} ${colors.bg} border ${colors.border}`}
                    >
                      {integration.status}
                    </span>
                    {integration.dailyUpdateStatus ===
                      "completed" && (
                      <span className="px-2 py-1 rounded text-xs font-bold bg-green-500/20 text-green-400 border border-green-500/30">
                        ✓ Updated
                      </span>
                    )}
                    {integration.dailyUpdateStatus ===
                      "in-progress" && (
                      <span className="px-2 py-1 rounded text-xs font-bold bg-cyan-500/20 text-cyan-400 border border-cyan-500/30 animate-pulse">
                        Updating...
                      </span>
                    )}
                  </div>
                  <div className="flex items-center gap-2 text-sm text-gray-400 mb-3">
                    <span className="font-mono">
                      {integration.id}
                    </span>
                    <span>•</span>
                    <span>{integration.endpoint}</span>
                  </div>
                </div>

                <button
                  onClick={() =>
                    handleManualUpdate(integration.id)
                  }
                  disabled={
                    !secureMode ||
                    integration.dailyUpdateStatus ===
                      "in-progress"
                  }
                  className={`px-4 py-2 rounded-lg text-sm font-semibold transition-all ${
                    secureMode &&
                    integration.dailyUpdateStatus !==
                      "in-progress"
                      ? "bg-cyan-600 text-white hover:bg-cyan-500"
                      : "bg-gray-700 text-gray-500 cursor-not-allowed"
                  }`}
                >
                  Manual Update
                </button>
              </div>

              {/* Details Grid */}
              <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-4">
                <div className="bg-black/30 rounded border border-gray-500/20 p-3">
                  <div className="text-xs text-gray-400 mb-1">
                    Protocol
                  </div>
                  <div className="text-sm font-semibold text-purple-400">
                    {integration.protocol}
                  </div>
                </div>
                <div className="bg-black/30 rounded border border-gray-500/20 p-3">
                  <div className="text-xs text-gray-400 mb-1">
                    Encryption
                  </div>
                  <div className="text-sm font-semibold text-cyan-400">
                    {integration.encryptionStandard}
                  </div>
                </div>
                <div className="bg-black/30 rounded border border-gray-500/20 p-3">
                  <div className="text-xs text-gray-400 mb-1">
                    Format
                  </div>
                  <div className="text-sm font-semibold text-blue-400">
                    {integration.format}
                  </div>
                </div>
                <div className="bg-black/30 rounded border border-gray-500/20 p-3">
                  <div className="text-xs text-gray-400 mb-1">
                    Token Refresh
                  </div>
                  <div className="text-sm font-semibold text-orange-400">
                    {integration.tokenRefresh}
                  </div>
                </div>
              </div>

              {/* Certificate Information */}
              <div className="grid grid-cols-2 md:grid-cols-3 gap-4 mb-4">
                <div className="bg-black/30 rounded border border-gray-500/20 p-3">
                  <div className="text-xs text-gray-400 mb-1">
                    Certificate Status
                  </div>
                  <div
                    className={`text-sm font-semibold ${integration.certificateStatus === "valid" ? "text-green-400" : "text-red-400"}`}
                  >
                    {integration.certificateStatus.toUpperCase()}
                  </div>
                </div>
                <div
                  className={`bg-black/30 rounded border p-3 ${expiryWarning ? "border-red-500/50 bg-red-500/10" : "border-gray-500/20"}`}
                >
                  <div className="text-xs text-gray-400 mb-1">
                    Expires In
                  </div>
                  <div
                    className={`text-sm font-semibold ${expiryWarning ? "text-red-400" : "text-cyan-400"}`}
                  >
                    {daysUntilExpiry} days
                    {expiryWarning && " ⚠️"}
                  </div>
                </div>
                <div className="bg-black/30 rounded border border-gray-500/20 p-3">
                  <div className="text-xs text-gray-400 mb-1">
                    Last Rotation
                  </div>
                  <div className="text-sm font-semibold text-gray-300">
                    {new Date(
                      integration.lastRotation,
                    ).toLocaleDateString()}
                  </div>
                </div>
              </div>

              {/* Compliance & Updates */}
              <div className="flex items-center justify-between pt-4 border-t border-gray-500/20">
                <div>
                  <div className="text-xs text-gray-400 mb-1">
                    Compliance Framework
                  </div>
                  <div className="text-sm font-semibold text-green-400">
                    {integration.complianceFramework}
                  </div>
                </div>
                <div className="text-right">
                  <div className="text-xs text-gray-400 mb-1">
                    Last PKI Update
                  </div>
                  <div className="text-sm font-mono text-gray-300">
                    {new Date(
                      integration.lastUpdate,
                    ).toLocaleString()}
                  </div>
                </div>
                {integration.checksumValidation !== "N/A" && (
                  <div className="text-right">
                    <div className="text-xs text-gray-400 mb-1">
                      Checksum
                    </div>
                    <div className="text-sm font-mono text-cyan-400">
                      {integration.checksumValidation}
                    </div>
                  </div>
                )}
              </div>
            </div>
          );
        })}
      </div>

      {/* Stripe Checksum Validation */}
      <div className="p-6 bg-gradient-to-r from-purple-900/20 via-indigo-900/20 to-purple-900/20 border border-purple-500/30 rounded-lg">
        <div className="flex items-center gap-3 mb-4">
          <Shield className="w-6 h-6 text-purple-400" />
          <h3 className="text-xl font-bold text-white">
            Stripe Binary Checksum Validation
          </h3>
        </div>
        <div className="grid grid-cols-2 gap-4">
          <div className="bg-black/40 border border-purple-500/20 rounded-lg p-4">
            <div className="text-xs text-gray-400 mb-2">
              macOS x86_64 SHA-256
            </div>
            <div className="font-mono text-xs text-cyan-400 break-all">
              738142cd8fac55e821e89cc147adcc958ba32909f65cdfb531852d0e1a25f742
            </div>
            <div className="mt-2 text-xs text-green-400">
              ✓ Verified
            </div>
          </div>
          <div className="bg-black/40 border border-purple-500/20 rounded-lg p-4">
            <div className="text-xs text-gray-400 mb-2">
              macOS ARM64 SHA-256
            </div>
            <div className="font-mono text-xs text-cyan-400 break-all">
              fda1ca85948a1b95d44965e23ac58045956748b4458d30d627626bedf5bd148a
            </div>
            <div className="mt-2 text-xs text-green-400">
              ✓ Verified
            </div>
          </div>
        </div>
      </div>

      <style>{`
        @keyframes slideIn {
          from { opacity: 0; transform: translateY(20px); }
          to { opacity: 1; transform: translateY(0); }
        }
      `}</style>
    </div>
  );
}