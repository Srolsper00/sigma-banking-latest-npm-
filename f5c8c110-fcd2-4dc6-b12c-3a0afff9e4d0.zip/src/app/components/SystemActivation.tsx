import { useState, useEffect } from "react";
import {
  CheckCircle2,
  Zap,
  Shield,
  Database,
  Network,
  Cpu,
  Radio,
  FileKey,
  DollarSign,
  Activity,
} from "lucide-react";

interface SystemModule {
  id: string;
  name: string;
  icon: any;
  status: "initializing" | "active" | "ready";
  description: string;
}

interface SystemActivationProps {
  onActivationComplete: () => void;
}

export function SystemActivation({
  onActivationComplete,
}: SystemActivationProps) {
  const [currentStep, setCurrentStep] = useState(0);
  const [showActivation, setShowActivation] = useState(true);
  const [systemModules, setSystemModules] = useState<
    SystemModule[]
  >([
    {
      id: "security",
      name: "Security Framework",
      icon: Shield,
      status: "initializing",
      description: "RBAC • Encryption • Audit Logging",
    },
    {
      id: "devices",
      name: "Asset Management",
      icon: Database,
      status: "initializing",
      description: "NIST CSF • Device Inventory",
    },
    {
      id: "network",
      name: "5G Telecom Infrastructure",
      icon: Radio,
      status: "initializing",
      description: "3GPP R16 • URLLC • Edge Computing",
    },
    {
      id: "certificates",
      name: "PKI System",
      icon: FileKey,
      status: "initializing",
      description: "ACT2 SUDI • Daily Updates • mTLS",
    },
    {
      id: "financial",
      name: "Fina_3xpres5 Live",
      icon: Zap,
      status: "initializing",
      description: "Real-time Processing • Blockchain",
    },
    {
      id: "transactions",
      name: "Transaction Pipeline",
      icon: DollarSign,
      status: "initializing",
      description: "Banking Integration • Compliance",
    },
    {
      id: "monitoring",
      name: "Detection & Response",
      icon: Activity,
      status: "initializing",
      description: "Real-time Monitoring • Threat Detection",
    },
    {
      id: "compliance",
      name: "Regulatory Compliance",
      icon: CheckCircle2,
      status: "initializing",
      description: "NIST-800-171 • FDIC • Basel-III",
    },
  ]);

  useEffect(() => {
    const activationSequence = async () => {
      // Step 1: Initialize all modules
      await new Promise((resolve) => setTimeout(resolve, 800));
      setCurrentStep(1);

      // Step 2-9: Activate each module sequentially
      for (let i = 0; i < systemModules.length; i++) {
        await new Promise((resolve) =>
          setTimeout(resolve, 400),
        );
        setSystemModules((prev) =>
          prev.map((module, idx) =>
            idx === i
              ? { ...module, status: "active" }
              : module,
          ),
        );
        setCurrentStep(i + 2);
      }

      // Step 10: All systems ready
      await new Promise((resolve) => setTimeout(resolve, 500));
      setSystemModules((prev) =>
        prev.map((module) => ({ ...module, status: "ready" })),
      );
      setCurrentStep(systemModules.length + 2);

      // Step 11: Complete activation
      await new Promise((resolve) => setTimeout(resolve, 1500));
      setShowActivation(false);
      onActivationComplete();
    };

    activationSequence();
  }, []);

  if (!showActivation) return null;

  const progress =
    (currentStep / (systemModules.length + 2)) * 100;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-[#0a0e1a] overflow-hidden">
      {/* Animated Background */}
      <div className="absolute inset-0">
        <div className="absolute inset-0 bg-gradient-to-br from-cyan-500/5 via-purple-500/5 to-blue-500/5" />
        <div className="absolute inset-0">
          {[...Array(20)].map((_, i) => (
            <div
              key={i}
              className="absolute w-1 h-1 bg-cyan-400/30 rounded-full"
              style={{
                left: `${Math.random() * 100}%`,
                top: `${Math.random() * 100}%`,
                animation: `pulse ${2 + Math.random() * 3}s infinite`,
                animationDelay: `${Math.random() * 2}s`,
              }}
            />
          ))}
        </div>
      </div>

      {/* Main Activation Panel */}
      <div className="relative z-10 w-full max-w-4xl mx-auto px-6">
        {/* Header */}
        <div className="text-center mb-8">
          <div className="flex items-center justify-center gap-4 mb-4">
            <div className="relative">
              <Shield className="w-20 h-20 text-cyan-400" />
              <div className="absolute inset-0 animate-ping">
                <Shield className="w-20 h-20 text-cyan-400/30" />
              </div>
            </div>
          </div>
          <h1
            className="text-5xl font-bold text-white mb-3 tracking-tight"
            style={{ fontFamily: "var(--font-rajdhani)" }}
          >
            VOM BANKING PLATFORM
          </h1>
          <p className="text-xl text-cyan-400 font-semibold mb-2">
            System Activation Sequence
          </p>
          <p className="text-sm text-gray-400">
            Initializing secure banking infrastructure...
          </p>
        </div>

        {/* Progress Bar */}
        <div className="mb-8">
          <div className="h-2 bg-gray-800 rounded-full overflow-hidden border border-cyan-500/20">
            <div
              className="h-full bg-gradient-to-r from-cyan-500 via-blue-500 to-purple-500 transition-all duration-500 ease-out"
              style={{ width: `${progress}%` }}
            />
          </div>
          <div className="flex justify-between mt-2">
            <span className="text-xs text-gray-500">
              Initializing
            </span>
            <span className="text-xs font-mono text-cyan-400">
              {Math.round(progress)}%
            </span>
            <span className="text-xs text-gray-500">Ready</span>
          </div>
        </div>

        {/* System Modules Grid */}
        <div className="grid grid-cols-2 gap-4 mb-8">
          {systemModules.map((module, idx) => {
            const Icon = module.icon;
            const isActive =
              module.status === "active" ||
              module.status === "ready";
            const isReady = module.status === "ready";

            return (
              <div
                key={module.id}
                className={`p-4 rounded-lg border transition-all duration-500 ${
                  isReady
                    ? "bg-green-500/10 border-green-500/50"
                    : isActive
                      ? "bg-cyan-500/10 border-cyan-500/50 animate-pulse"
                      : "bg-gray-500/5 border-gray-500/20"
                }`}
                style={{
                  animation: isActive
                    ? "glow 2s ease-in-out infinite"
                    : "none",
                  animationDelay: `${idx * 100}ms`,
                }}
              >
                <div className="flex items-center gap-3 mb-2">
                  <Icon
                    className={`w-6 h-6 ${
                      isReady
                        ? "text-green-400"
                        : isActive
                          ? "text-cyan-400"
                          : "text-gray-600"
                    }`}
                  />
                  <div className="flex-1">
                    <h3
                      className={`text-sm font-bold ${
                        isReady
                          ? "text-green-400"
                          : isActive
                            ? "text-cyan-400"
                            : "text-gray-500"
                      }`}
                    >
                      {module.name}
                    </h3>
                    <p className="text-xs text-gray-500">
                      {module.description}
                    </p>
                  </div>
                  {isReady && (
                    <CheckCircle2 className="w-5 h-5 text-green-400" />
                  )}
                  {isActive && !isReady && (
                    <div className="w-5 h-5 border-2 border-cyan-400 border-t-transparent rounded-full animate-spin" />
                  )}
                </div>
                <div
                  className={`text-xs font-mono uppercase tracking-wide ${
                    isReady
                      ? "text-green-400"
                      : isActive
                        ? "text-cyan-400"
                        : "text-gray-600"
                  }`}
                >
                  {isReady
                    ? "✓ READY"
                    : isActive
                      ? "ACTIVATING..."
                      : "STANDBY"}
                </div>
              </div>
            );
          })}
        </div>

        {/* Status Messages */}
        <div className="bg-black/40 border border-cyan-500/20 rounded-lg p-6">
          <div className="space-y-2">
            {currentStep >= 1 && (
              <div className="flex items-center gap-3 text-sm">
                <CheckCircle2 className="w-4 h-4 text-green-400" />
                <span className="text-gray-300">
                  Security protocols initialized
                </span>
              </div>
            )}
            {currentStep >= 3 && (
              <div className="flex items-center gap-3 text-sm">
                <CheckCircle2 className="w-4 h-4 text-green-400" />
                <span className="text-gray-300">
                  Asset management systems online
                </span>
              </div>
            )}
            {currentStep >= 5 && (
              <div className="flex items-center gap-3 text-sm">
                <CheckCircle2 className="w-4 h-4 text-green-400" />
                <span className="text-gray-300">
                  PKI infrastructure activated
                </span>
              </div>
            )}
            {currentStep >= 7 && (
              <div className="flex items-center gap-3 text-sm">
                <CheckCircle2 className="w-4 h-4 text-green-400" />
                <span className="text-gray-300">
                  Financial processing engines ready
                </span>
              </div>
            )}
            {currentStep >= 9 && (
              <div className="flex items-center gap-3 text-sm">
                <CheckCircle2 className="w-4 h-4 text-green-400" />
                <span className="text-gray-300">
                  Regulatory compliance verified
                </span>
              </div>
            )}
            {currentStep >= systemModules.length + 2 && (
              <div className="flex items-center gap-3 text-sm mt-4 pt-4 border-t border-cyan-500/20">
                <Zap className="w-5 h-5 text-cyan-400 animate-pulse" />
                <span className="text-cyan-400 font-bold text-lg">
                  SYSTEM ACTIVATED - LIVE PLATFORM READY
                </span>
              </div>
            )}
          </div>
        </div>

        {/* Live Indicator */}
        {currentStep >= systemModules.length + 2 && (
          <div className="mt-6 text-center">
            <div className="inline-flex items-center gap-3 px-6 py-3 bg-gradient-to-r from-green-600 to-green-500 rounded-lg border border-green-400/50">
              <div className="w-3 h-3 bg-green-300 rounded-full animate-pulse" />
              <span className="text-white font-bold uppercase tracking-wide">
                LIVE • REAL-TIME APPLICATION ACTIVE
              </span>
              <div className="w-3 h-3 bg-green-300 rounded-full animate-pulse" />
            </div>
          </div>
        )}
      </div>

      <style>{`
        @keyframes glow {
          0%, 100% { box-shadow: 0 0 10px rgba(34, 211, 238, 0.3); }
          50% { box-shadow: 0 0 20px rgba(34, 211, 238, 0.6); }
        }
        @keyframes pulse {
          0%, 100% { opacity: 0.3; transform: scale(1); }
          50% { opacity: 1; transform: scale(1.5); }
        }
      `}</style>
    </div>
  );
}