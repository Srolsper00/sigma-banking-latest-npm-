import {
  AlertTriangle,
  Ban,
  DollarSign,
  Shield,
  Clock,
  Fingerprint,
} from "lucide-react";

type ExceptionType =
  | "FRAUD_DETECTED"
  | "AML_VIOLATION"
  | "SANCTIONS_MATCH"
  | "DUPLICATE_TRANSACTION"
  | "INSUFFICIENT_FUNDS"
  | "VELOCITY_LIMIT"
  | "GEOLOCATION_RISK"
  | "UNAUTHORIZED_COUNTERPARTY";

interface ExceptionBadgeProps {
  exception: ExceptionType;
}

const exceptionConfig: Record<
  ExceptionType,
  {
    label: string;
    color: string;
    bgColor: string;
    borderColor: string;
    icon: any;
  }
> = {
  FRAUD_DETECTED: {
    label: "FRAUD DETECTED",
    color: "#dc2626",
    bgColor: "rgba(220, 38, 38, 0.15)",
    borderColor: "rgba(220, 38, 38, 0.5)",
    icon: AlertTriangle,
  },
  AML_VIOLATION: {
    label: "AML VIOLATION",
    color: "#ef4444",
    bgColor: "rgba(239, 68, 68, 0.15)",
    borderColor: "rgba(239, 68, 68, 0.5)",
    icon: Shield,
  },
  SANCTIONS_MATCH: {
    label: "SANCTIONS",
    color: "#b91c1c",
    bgColor: "rgba(185, 28, 28, 0.15)",
    borderColor: "rgba(185, 28, 28, 0.5)",
    icon: Ban,
  },
  DUPLICATE_TRANSACTION: {
    label: "DUPLICATE",
    color: "#f97316",
    bgColor: "rgba(249, 115, 22, 0.15)",
    borderColor: "rgba(249, 115, 22, 0.5)",
    icon: Fingerprint,
  },
  INSUFFICIENT_FUNDS: {
    label: "INSUF. FUNDS",
    color: "#f59e0b",
    bgColor: "rgba(245, 158, 11, 0.15)",
    borderColor: "rgba(245, 158, 11, 0.5)",
    icon: DollarSign,
  },
  VELOCITY_LIMIT: {
    label: "VELOCITY",
    color: "#f97316",
    bgColor: "rgba(249, 115, 22, 0.15)",
    borderColor: "rgba(249, 115, 22, 0.5)",
    icon: Clock,
  },
  GEOLOCATION_RISK: {
    label: "GEO RISK",
    color: "#ea580c",
    bgColor: "rgba(234, 88, 12, 0.15)",
    borderColor: "rgba(234, 88, 12, 0.5)",
    icon: AlertTriangle,
  },
  UNAUTHORIZED_COUNTERPARTY: {
    label: "UNAUTH PARTY",
    color: "#dc2626",
    bgColor: "rgba(220, 38, 38, 0.15)",
    borderColor: "rgba(220, 38, 38, 0.5)",
    icon: Ban,
  },
};

export function ExceptionBadge({
  exception,
}: ExceptionBadgeProps) {
  const config = exceptionConfig[exception];
  const Icon = config.icon;

  return (
    <div className="relative inline-flex">
      <div
        className="flex items-center gap-2 px-3 py-1.5 rounded border font-mono text-xs tracking-wider animate-pulse"
        style={{
          color: config.color,
          backgroundColor: config.bgColor,
          borderColor: config.borderColor,
          boxShadow: `0 0 15px ${config.bgColor}, inset 0 0 10px ${config.bgColor}`,
        }}
      >
        <Icon className="w-3.5 h-3.5" />
        <span className="font-bold">{config.label}</span>
      </div>

      {/* Alert glow effect */}
      <div
        className="absolute -inset-1 rounded blur-sm opacity-50"
        style={{
          backgroundColor: config.borderColor,
          animation:
            "pulse 2s cubic-bezier(0.4, 0, 0.6, 1) infinite",
        }}
      />
    </div>
  );
}