import { useState } from "react";
import {
  Network,
  ArrowRight,
  Download,
  Lock,
  Shield,
  AlertCircle,
} from "lucide-react";

interface DataFlowsTabProps {
  secureMode: boolean;
  onAuditLog: (message: string) => void;
}

interface DataFlow {
  id: string;
  source: string;
  destination: string;
  protocol: string;
  encryption: string;
  sensitivity: string;
  dataType: string;
  description: string;
}

const dataFlows: DataFlow[] = [
  {
    id: "DF-001",
    source: "Customer Portal",
    destination: "Core Banking",
    protocol: "HTTPS/TLS 1.3",
    encryption: "AES-256-GCM",
    sensitivity: "Highly Sensitive",
    dataType: "PII/PCI",
    description:
      "Secure customer transactions and account data transmission from web portal to core banking system",
  },
  {
    id: "DF-002",
    source: "DDA Service",
    destination: "Tokenization Vault",
    protocol: "mTLS",
    encryption: "RSA-4096 + AES-256",
    sensitivity: "Highly Sensitive",
    dataType: "Financial Data",
    description:
      "Mutual TLS encrypted channel for demand deposit account tokenization and key exchange",
  },
  {
    id: "DF-003",
    source: "Payment Gateway",
    destination: "ACH Network",
    protocol: "SFTP/TLS",
    encryption: "AES-256-CBC",
    sensitivity: "Sensitive",
    dataType: "PCI",
    description:
      "Secure file transfer for ACH batch processing and payment settlements",
  },
  {
    id: "DF-004",
    source: "Audit System",
    destination: "Immutable Ledger",
    protocol: "HTTPS",
    encryption: "TLS 1.3",
    sensitivity: "Compliance",
    dataType: "Audit Logs",
    description:
      "Real-time audit trail logging to blockchain-based immutable ledger for regulatory compliance",
  },
  {
    id: "DF-005",
    source: "NULS Blockchain",
    destination: "Architecture Nodes",
    protocol: "P2P Encrypted",
    encryption: "ECDSA + AES",
    sensitivity: "Sensitive",
    dataType: "Blockchain Data",
    description:
      "Peer-to-peer encrypted blockchain consensus and smart contract data synchronization",
  },
];

const sensitivityColors: Record<
  string,
  { bg: string; text: string; border: string; glow: string }
> = {
  "Highly Sensitive": {
    bg: "bg-red-500/10",
    text: "text-red-400",
    border: "border-red-500/50",
    glow: "shadow-red-500/20",
  },
  Sensitive: {
    bg: "bg-amber-500/10",
    text: "text-amber-400",
    border: "border-amber-500/50",
    glow: "shadow-amber-500/20",
  },
  Compliance: {
    bg: "bg-cyan-500/10",
    text: "text-cyan-400",
    border: "border-cyan-500/50",
    glow: "shadow-cyan-500/20",
  },
};

export function DataFlowsTab({
  secureMode,
  onAuditLog,
}: DataFlowsTabProps) {
  const [selectedFlow, setSelectedFlow] = useState<
    string | null
  >(null);

  const handleExport = () => {
    if (!secureMode) {
      alert("Export requires Secure Mode to be enabled");
      return;
    }

    const data = JSON.stringify(dataFlows, null, 2);
    const blob = new Blob([data], { type: "application/json" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = `data-flows-${new Date().toISOString()}.json`;
    a.click();
    URL.revokeObjectURL(url);

    onAuditLog(
      `Exported data flow map (${dataFlows.length} flows)`,
    );
  };

  const handleFlowClick = (flowId: string) => {
    setSelectedFlow(selectedFlow === flowId ? null : flowId);
    onAuditLog(`Inspected data flow: ${flowId}`);
  };

  return (
    <div>
      {/* Header */}
      <div className="flex items-center justify-between mb-6">
        <div>
          <h2 className="text-2xl font-bold text-white uppercase tracking-wide">
            Communication & Data Flow Mapping
          </h2>
          <p className="text-cyan-400 font-mono text-sm mt-1">
            ID.AM-3 Compliance
          </p>
        </div>

        <button
          onClick={handleExport}
          className="flex items-center gap-2 px-4 py-2 bg-cyan-500/10 border border-cyan-500/30 rounded-lg text-cyan-400 hover:bg-cyan-500/20 transition-all duration-300"
        >
          <Download className="w-4 h-4" />
          <span className="text-sm font-semibold uppercase">
            Export Map
          </span>
        </button>
      </div>

      {/* Data Flows */}
      <div className="space-y-4">
        {dataFlows.map((flow, index) => {
          const sensitivity =
            sensitivityColors[flow.sensitivity];
          const isSelected = selectedFlow === flow.id;

          return (
            <div
              key={flow.id}
              onClick={() => handleFlowClick(flow.id)}
              className={`
                group relative cursor-pointer
                transition-all duration-300
                ${isSelected ? "scale-[1.01]" : "hover:scale-[1.005]"}
              `}
              style={{
                animation: "flowAppear 0.5s ease-out forwards",
                animationDelay: `${index * 100}ms`,
                opacity: 0,
              }}
            >
              {/* Flow Container */}
              <div
                className={`
                relative p-6 rounded-lg border backdrop-blur-sm
                ${
                  isSelected
                    ? `${sensitivity.bg} ${sensitivity.border} shadow-xl ${sensitivity.glow}`
                    : "bg-gray-500/5 border-gray-500/30 hover:bg-gray-500/10"
                }
              `}
              >
                {/* Flow Visualization */}
                <div className="flex items-center gap-4 mb-4">
                  {/* Source */}
                  <div className="flex-1 text-center">
                    <div
                      className={`
                      p-4 rounded-lg border backdrop-blur-sm
                      ${isSelected ? `${sensitivity.bg} ${sensitivity.border}` : "bg-cyan-500/10 border-cyan-500/30"}
                    `}
                    >
                      <Network
                        className={`w-6 h-6 mx-auto mb-2 ${isSelected ? sensitivity.text : "text-cyan-400"}`}
                      />
                      <div className="font-bold text-white text-sm">
                        {flow.source}
                      </div>
                    </div>
                  </div>

                  {/* Arrow with Protocol */}
                  <div className="flex flex-col items-center gap-2">
                    <div className="flex items-center gap-2">
                      <div className="h-px w-12 bg-gradient-to-r from-cyan-500/50 to-cyan-500 relative">
                        <div className="absolute right-0 top-1/2 -translate-y-1/2">
                          <ArrowRight className="w-5 h-5 text-cyan-400" />
                        </div>
                      </div>
                    </div>
                    <div className="px-3 py-1 bg-black/50 border border-cyan-500/30 rounded text-xs font-mono text-cyan-400">
                      {flow.protocol}
                    </div>
                  </div>

                  {/* Destination */}
                  <div className="flex-1 text-center">
                    <div
                      className={`
                      p-4 rounded-lg border backdrop-blur-sm
                      ${isSelected ? `${sensitivity.bg} ${sensitivity.border}` : "bg-purple-500/10 border-purple-500/30"}
                    `}
                    >
                      <Shield
                        className={`w-6 h-6 mx-auto mb-2 ${isSelected ? sensitivity.text : "text-purple-400"}`}
                      />
                      <div className="font-bold text-white text-sm">
                        {flow.destination}
                      </div>
                    </div>
                  </div>
                </div>

                {/* Flow Details */}
                <div className="grid grid-cols-2 md:grid-cols-4 gap-3 mb-4">
                  <div className="text-center p-3 bg-black/30 rounded border border-gray-500/30">
                    <div className="text-xs text-gray-500 uppercase mb-1">
                      Encryption
                    </div>
                    <div className="text-sm font-mono text-green-400 flex items-center justify-center gap-1">
                      <Lock className="w-3 h-3" />
                      {flow.encryption}
                    </div>
                  </div>

                  <div
                    className={`text-center p-3 rounded border ${sensitivity.bg} ${sensitivity.border}`}
                  >
                    <div className="text-xs text-gray-500 uppercase mb-1">
                      Sensitivity
                    </div>
                    <div
                      className={`text-sm font-bold ${sensitivity.text} flex items-center justify-center gap-1`}
                    >
                      <AlertCircle className="w-3 h-3" />
                      {flow.sensitivity}
                    </div>
                  </div>

                  <div className="text-center p-3 bg-black/30 rounded border border-gray-500/30">
                    <div className="text-xs text-gray-500 uppercase mb-1">
                      Data Type
                    </div>
                    <div className="text-sm font-semibold text-amber-400">
                      {flow.dataType}
                    </div>
                  </div>

                  <div className="text-center p-3 bg-black/30 rounded border border-gray-500/30">
                    <div className="text-xs text-gray-500 uppercase mb-1">
                      Flow ID
                    </div>
                    <div className="text-sm font-mono text-gray-300">
                      {flow.id}
                    </div>
                  </div>
                </div>

                {/* Expandable Description */}
                {isSelected && (
                  <div
                    className="pt-4 border-t border-gray-500/30"
                    style={{
                      animation: "expandDown 0.3s ease-out",
                    }}
                  >
                    <p className="text-sm text-gray-400 leading-relaxed">
                      {flow.description}
                    </p>
                  </div>
                )}

                {/* Selection Indicator */}
                {isSelected && (
                  <div className="absolute top-0 left-0 right-0 h-1 bg-gradient-to-r from-transparent via-cyan-400 to-transparent rounded-t-lg" />
                )}
              </div>
            </div>
          );
        })}
      </div>

      <style>{`
        @keyframes flowAppear {
          from {
            opacity: 0;
            transform: translateX(-20px);
          }
          to {
            opacity: 1;
            transform: translateX(0);
          }
        }

        @keyframes expandDown {
          from {
            opacity: 0;
            max-height: 0;
          }
          to {
            opacity: 1;
            max-height: 200px;
          }
        }
      `}</style>
    </div>
  );
}