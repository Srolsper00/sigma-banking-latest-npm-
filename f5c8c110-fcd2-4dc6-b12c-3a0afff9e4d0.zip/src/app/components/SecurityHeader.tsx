import { useState, useEffect } from 'react';
import { Shield, Lock, EyeOff, Activity, Info } from 'lucide-react';
import { SystemOverview } from './SystemOverview';

interface SecurityHeaderProps {
  secureMode: boolean;
  onToggleSecure: () => void;
  onAuditLog: (message: string) => void;
}

const frameworks = [
  'CIS CSC',
  'COBIT 5',
  'ISA 62443',
  'ISO/IEC 27001:2013',
  'NIST SP 800-53 Rev. 4'
];

export function SecurityHeader({ secureMode, onToggleSecure, onAuditLog }: SecurityHeaderProps) {
  const [currentTime, setCurrentTime] = useState(new Date());
  const [showOverview, setShowOverview] = useState(false);

  useEffect(() => {
    const timer = setInterval(() => {
      setCurrentTime(new Date());
    }, 1000);

    return () => clearInterval(timer);
  }, []);

  return (
    <div className="border-b border-cyan-500/20 bg-gradient-to-r from-[#0a0e1a]/95 via-[#0f1525]/95 to-[#0a0e1a]/95 backdrop-blur-xl">
      <div className="max-w-7xl mx-auto px-6 py-6">
        <div className="flex items-center justify-between">
          {/* Logo & Title */}
          <div className="flex items-center gap-4">
            <div className="relative">
              <Shield className="w-10 h-10 text-cyan-400" />
              <div className="absolute inset-0 bg-cyan-400/20 blur-xl" />
            </div>
            <div>
              <h1 className="text-2xl font-bold tracking-tight text-white uppercase">
                VOM Banking Platform
              </h1>
              <div className="flex items-center gap-3">
                <p className="text-sm text-cyan-400/80 font-mono">Asset Management & Business Environment</p>
                <div className="flex items-center gap-2 px-2 py-1 bg-green-500/20 border border-green-500/50 rounded">
                  <div className="w-2 h-2 bg-green-400 rounded-full animate-pulse" />
                  <span className="text-xs font-bold text-green-400 uppercase">LIVE</span>
                </div>
                <div className="text-xs font-mono text-gray-400">
                  {currentTime.toLocaleTimeString()}
                </div>
              </div>
            </div>
          </div>

          {/* Security Status & Controls */}
          <div className="flex items-center gap-6">
            {/* System Overview Button */}
            <button
              onClick={() => {
                setShowOverview(true);
                onAuditLog('System Overview accessed');
              }}
              className="px-4 py-2 bg-cyan-500/10 border border-cyan-500/30 rounded-lg text-cyan-400 hover:bg-cyan-500/20 transition-all flex items-center gap-2"
            >
              <Info className="w-4 h-4" />
              <span className="text-sm font-semibold">System Overview</span>
            </button>

            {/* Framework Compliance */}
            <div className="hidden lg:flex items-center gap-2">
              <Activity className="w-4 h-4 text-green-400" />
              <div className="text-xs">
                <div className="text-gray-400 font-mono">COMPLIANCE</div>
                <div className="text-green-400 font-semibold">{frameworks.length}/10 Active</div>
              </div>
            </div>

            {/* Secure Mode Toggle */}
            <button
              onClick={onToggleSecure}
              className={`
                group relative px-6 py-3 rounded-lg font-semibold text-sm tracking-wide uppercase
                transition-all duration-300 overflow-hidden
                ${secureMode
                  ? 'bg-gradient-to-r from-green-500/20 to-emerald-500/20 text-green-400 border border-green-500/50'
                  : 'bg-gradient-to-r from-red-500/20 to-rose-500/20 text-red-400 border border-red-500/50'
                }
              `}
            >
              <div className="relative z-10 flex items-center gap-2">
                {secureMode ? (
                  <>
                    <Lock className="w-4 h-4" />
                    <span>Secure Mode</span>
                  </>
                ) : (
                  <>
                    <EyeOff className="w-4 h-4" />
                    <span>Public Mode</span>
                  </>
                )}
              </div>

              <div
                className={`
                  absolute inset-0 opacity-0 group-hover:opacity-100 transition-opacity duration-300
                  ${secureMode ? 'bg-green-400/10' : 'bg-red-400/10'}
                `}
              />

              {secureMode && (
                <div className="absolute top-0 right-0 w-2 h-2 bg-green-400 rounded-full animate-pulse" />
              )}
            </button>

            {/* Status Indicator */}
            <div className={`flex items-center gap-2 px-4 py-2 rounded-lg border ${
              secureMode
                ? 'border-green-500/30 bg-green-500/10'
                : 'border-red-500/30 bg-red-500/10'
            }`}>
              <div className={`w-2 h-2 rounded-full ${
                secureMode ? 'bg-green-400' : 'bg-red-400'
              } animate-pulse`} />
              <span className={`text-xs font-mono font-semibold ${
                secureMode ? 'text-green-400' : 'text-red-400'
              }`}>
                {secureMode ? 'RBAC ACTIVE' : 'RBAC SUSPENDED'}
              </span>
            </div>
          </div>
        </div>

        {/* Framework Tags */}
        <div className="flex flex-wrap gap-2 mt-4">
          {frameworks.map((framework, index) => (
            <div
              key={framework}
              className="px-3 py-1 bg-cyan-500/10 border border-cyan-500/30 rounded text-xs font-mono text-cyan-400"
              style={{
                animation: 'fadeIn 0.5s ease-out forwards',
                animationDelay: `${index * 50}ms`,
                opacity: 0
              }}
            >
              {framework}
            </div>
          ))}
        </div>
      </div>

      {/* System Overview Modal */}
      {showOverview && <SystemOverview onClose={() => setShowOverview(false)} />}

      <style>{`
        @keyframes fadeIn {
          to {
            opacity: 1;
          }
        }
      `}</style>
    </div>
  );
}
