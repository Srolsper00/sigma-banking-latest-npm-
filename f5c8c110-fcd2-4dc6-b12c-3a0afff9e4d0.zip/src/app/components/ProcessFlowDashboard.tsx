import { useState, useEffect } from "react";
import {
  Zap,
  Shield,
  FileKey,
  Radio,
  Database,
  Activity,
  TrendingUp,
  Cpu,
  Lock,
} from "lucide-react";

interface ProcessStep {
  id: number;
  name: string;
  status: "completed" | "active" | "pending";
  time: string;
  description: string;
}

interface Process {
  id: string;
  name: string;
  icon: any;
  color: string;
  totalTime: string;
  successRate: string;
  steps: ProcessStep[];
}

interface ProcessFlowDashboardProps {
  secureMode: boolean;
  onAuditLog: (action: string) => void;
}

export function ProcessFlowDashboard({
  secureMode,
  onAuditLog,
}: ProcessFlowDashboardProps) {
  const [selectedProcess, setSelectedProcess] =
    useState<string>("transaction");
  const [liveMetrics, setLiveMetrics] = useState({
    totalProcessed: 45789,
    successRate: 99.7,
    avgProcessingTime: 247,
    currentLoad: 68,
  });
  const [plotData, setPlotData] = useState<number[]>([]);
  const [encryptionMode, setEncryptionMode] = useState(false);

  // MATLAB-style 24k resolution plot data generation
  useEffect(() => {
    const generatePlotData = () => {
      const data: number[] = [];
      for (let i = 0; i < 24000; i++) {
        const t = i / 1000;
        const signal =
          Math.sin(2 * Math.PI * t * 0.5) * 50 +
          Math.cos(2 * Math.PI * t * 0.3) * 30 +
          Math.sin(2 * Math.PI * t * 1.2) * 20 +
          (Math.random() - 0.5) * 10;
        data.push(50 + signal);
      }
      setPlotData(data);
    };

    generatePlotData();
    const interval = setInterval(generatePlotData, 5000);
    return () => clearInterval(interval);
  }, []);

  // Live metrics update
  useEffect(() => {
    const interval = setInterval(() => {
      setLiveMetrics((prev) => ({
        totalProcessed:
          prev.totalProcessed +
          Math.floor(Math.random() * 50 + 20),
        successRate: 99.5 + Math.random() * 0.4,
        avgProcessingTime: 240 + Math.random() * 20,
        currentLoad: 60 + Math.random() * 20,
      }));
    }, 2000);

    return () => clearInterval(interval);
  }, []);

  const processes: Process[] = [
    {
      id: "transaction",
      name: "Transaction Processing",
      icon: Zap,
      color: "cyan",
      totalTime: "~248ms",
      successRate: "99.7%",
      steps: [
        {
          id: 1,
          name: "Initiation",
          status: "completed",
          time: "10ms",
          description:
            "Transaction request received and validated",
        },
        {
          id: 2,
          name: "Nonce Generation",
          status: "completed",
          time: "5ms",
          description:
            "Cryptographic nonce generated from pool",
        },
        {
          id: 3,
          name: "RBAC Validation",
          status: "completed",
          time: "15ms",
          description: "Role-based access control verification",
        },
        {
          id: 4,
          name: "Ledger Write",
          status: "completed",
          time: "45ms",
          description:
            "Transaction written to distributed ledger",
        },
        {
          id: 5,
          name: "Merkle Hash",
          status: "active",
          time: "20ms",
          description: "SHA-256 Merkle tree hash generation",
        },
        {
          id: 6,
          name: "Blockchain Anchor",
          status: "pending",
          time: "80ms",
          description: "Ethereum blockchain anchoring",
        },
        {
          id: 7,
          name: "Verification",
          status: "pending",
          time: "30ms",
          description: "Multi-node consensus verification",
        },
        {
          id: 8,
          name: "State Update",
          status: "pending",
          time: "18ms",
          description: "Transaction state propagation",
        },
        {
          id: 9,
          name: "Notification",
          status: "pending",
          time: "12ms",
          description: "Stakeholder notification dispatch",
        },
        {
          id: 10,
          name: "Completion",
          status: "pending",
          time: "13ms",
          description: "Final state committed and logged",
        },
      ],
    },
    {
      id: "pki",
      name: "PKI Certificate Rotation",
      icon: Shield,
      color: "purple",
      totalTime: "~868ms",
      successRate: "100%",
      steps: [
        {
          id: 1,
          name: "Schedule Trigger",
          status: "completed",
          time: "5ms",
          description: "Daily automated scheduler activation",
        },
        {
          id: 2,
          name: "Integration Select",
          status: "completed",
          time: "10ms",
          description: "Target system identification",
        },
        {
          id: 3,
          name: "CSR Generation",
          status: "completed",
          time: "120ms",
          description: "Certificate Signing Request creation",
        },
        {
          id: 4,
          name: "ACT2 SUDI Validation",
          status: "completed",
          time: "85ms",
          description: "Cisco ACT2 chip validation",
        },
        {
          id: 5,
          name: "CA Authentication",
          status: "active",
          time: "150ms",
          description: "Certificate Authority mutual auth",
        },
        {
          id: 6,
          name: "Certificate Issue",
          status: "pending",
          time: "200ms",
          description: "X.509 certificate issuance",
        },
        {
          id: 7,
          name: "Zero-Downtime Deploy",
          status: "pending",
          time: "180ms",
          description: "Hot-swap certificate installation",
        },
        {
          id: 8,
          name: "Validation Test",
          status: "pending",
          time: "45ms",
          description: "TLS handshake verification",
        },
        {
          id: 9,
          name: "Expiry Update",
          status: "pending",
          time: "25ms",
          description: "Certificate lifecycle tracking",
        },
        {
          id: 10,
          name: "Audit Log",
          status: "pending",
          time: "48ms",
          description: "Immutable audit trail entry",
        },
      ],
    },
    {
      id: "banking",
      name: "Banking Statement Generation",
      icon: FileKey,
      color: "green",
      totalTime: "~418ms",
      successRate: "99.9%",
      steps: [
        {
          id: 1,
          name: "Account Validation",
          status: "completed",
          time: "25ms",
          description: "Sutton Bank / Capital One auth",
        },
        {
          id: 2,
          name: "Transaction Retrieval",
          status: "completed",
          time: "65ms",
          description: "Period transaction aggregation",
        },
        {
          id: 3,
          name: "Balance Calculation",
          status: "completed",
          time: "35ms",
          description: "Opening/closing balance computation",
        },
        {
          id: 4,
          name: "Methodology Apply",
          status: "completed",
          time: "45ms",
          description: "GAAP/IFRS/Basel-III/FDIC-Reg",
        },
        {
          id: 5,
          name: "Compliance Check",
          status: "active",
          time: "55ms",
          description: "FDIC/OCC/CFPB/Fed/FinCEN validation",
        },
        {
          id: 6,
          name: "5G URLLC Delivery",
          status: "pending",
          time: "12ms",
          description: "Ultra-low latency transmission",
        },
        {
          id: 7,
          name: "SWIFT Formatting",
          status: "pending",
          time: "40ms",
          description: "MT940 message construction",
        },
        {
          id: 8,
          name: "Merkle Hash",
          status: "pending",
          time: "28ms",
          description: "Statement integrity verification",
        },
        {
          id: 9,
          name: "S3 Storage",
          status: "pending",
          time: "75ms",
          description: "Encrypted archive to S3",
        },
        {
          id: 10,
          name: "Delivery",
          status: "pending",
          time: "38ms",
          description: "Statement distribution",
        },
      ],
    },
    {
      id: "5g-slice",
      name: "5G Network Slice Management",
      icon: Radio,
      color: "blue",
      totalTime: "~390ms",
      successRate: "99.99%",
      steps: [
        {
          id: 1,
          name: "UE Connection",
          status: "completed",
          time: "15ms",
          description: "User equipment attachment",
        },
        {
          id: 2,
          name: "gNodeB Handshake",
          status: "completed",
          time: "22ms",
          description: "5G base station registration",
        },
        {
          id: 3,
          name: "AMF Authentication",
          status: "completed",
          time: "45ms",
          description: "Access & Mobility Management",
        },
        {
          id: 4,
          name: "SMF Session Setup",
          status: "completed",
          time: "38ms",
          description: "Session Management Function",
        },
        {
          id: 5,
          name: "UPF Routing",
          status: "active",
          time: "55ms",
          description: "User Plane Function data path",
        },
        {
          id: 6,
          name: "URLLC Slice Alloc",
          status: "pending",
          time: "35ms",
          description: "Ultra-reliable low-latency slice",
        },
        {
          id: 7,
          name: "QoS Policy Apply",
          status: "pending",
          time: "42ms",
          description: "Quality of Service enforcement",
        },
        {
          id: 8,
          name: "Spectrum Allocation",
          status: "pending",
          time: "48ms",
          description: "Dynamic spectrum assignment",
        },
        {
          id: 9,
          name: "MEC Integration",
          status: "pending",
          time: "55ms",
          description: "Multi-access Edge Computing",
        },
        {
          id: 10,
          name: "Monitoring Active",
          status: "pending",
          time: "35ms",
          description: "Real-time slice monitoring",
        },
      ],
    },
    {
      id: "document",
      name: "Document Export Workflow",
      icon: Database,
      color: "orange",
      totalTime: "~630ms",
      successRate: "99.8%",
      steps: [
        {
          id: 1,
          name: "Document Selection",
          status: "completed",
          time: "15ms",
          description: "User pool aggregation",
        },
        {
          id: 2,
          name: "Type Validation",
          status: "completed",
          time: "20ms",
          description: "Format compatibility check",
        },
        {
          id: 3,
          name: "Module Aggregation",
          status: "completed",
          time: "65ms",
          description: "Cross-module document gather",
        },
        {
          id: 4,
          name: "Format Conversion",
          status: "completed",
          time: "120ms",
          description: "PDF/CSV/JSON/XML/TXT conversion",
        },
        {
          id: 5,
          name: "Merkle Hashing",
          status: "active",
          time: "85ms",
          description: "Document integrity hash",
        },
        {
          id: 6,
          name: "Blockchain Anchor",
          status: "pending",
          time: "95ms",
          description: "Ethereum anchoring for proof",
        },
        {
          id: 7,
          name: "ZIP Compression",
          status: "pending",
          time: "110ms",
          description: "Archive creation",
        },
        {
          id: 8,
          name: "S3 Upload",
          status: "pending",
          time: "75ms",
          description: "Encrypted S3 storage",
        },
        {
          id: 9,
          name: "Link Generation",
          status: "pending",
          time: "25ms",
          description: "Signed URL creation",
        },
        {
          id: 10,
          name: "Notification",
          status: "pending",
          time: "20ms",
          description: "Download notification",
        },
      ],
    },
    {
      id: "system-init",
      name: "System Initialization",
      icon: Activity,
      color: "indigo",
      totalTime: "~5.9s",
      successRate: "100%",
      steps: [
        {
          id: 1,
          name: "Security Validation",
          status: "completed",
          time: "250ms",
          description: "FIPS 140-2 L3 hardware check",
        },
        {
          id: 2,
          name: "Encryption Init",
          status: "completed",
          time: "450ms",
          description: "AES-256-GCM initialization",
        },
        {
          id: 3,
          name: "Database Connect",
          status: "completed",
          time: "680ms",
          description: "MongoDB + Redis connection pool",
        },
        {
          id: 4,
          name: "Vault Integration",
          status: "completed",
          time: "520ms",
          description: "HashiCorp Vault authentication",
        },
        {
          id: 5,
          name: "PKI Bootstrap",
          status: "active",
          time: "890ms",
          description: "Certificate authority setup",
        },
        {
          id: 6,
          name: "External Systems",
          status: "pending",
          time: "1200ms",
          description: "Citi/Fed/ID.me/Oracle/Stripe",
        },
        {
          id: 7,
          name: "5G Network Attach",
          status: "pending",
          time: "750ms",
          description: "5G SA core registration",
        },
        {
          id: 8,
          name: "Compliance Load",
          status: "pending",
          time: "420ms",
          description: "NIST/ISO/PCI/FFIEC policies",
        },
        {
          id: 9,
          name: "Module Activation",
          status: "pending",
          time: "580ms",
          description: "All 19 modules online",
        },
        {
          id: 10,
          name: "Platform LIVE",
          status: "pending",
          time: "160ms",
          description: "System operational",
        },
      ],
    },
  ];

  const selectedProcessData =
    processes.find((p) => p.id === selectedProcess) ||
    processes[0];

  const getColorClasses = (color: string) => {
    const colors: Record<
      string,
      { bg: string; border: string; text: string; glow: string }
    > = {
      cyan: {
        bg: "bg-cyan-500/10",
        border: "border-cyan-500/30",
        text: "text-cyan-400",
        glow: "shadow-cyan-500/20",
      },
      purple: {
        bg: "bg-purple-500/10",
        border: "border-purple-500/30",
        text: "text-purple-400",
        glow: "shadow-purple-500/20",
      },
      green: {
        bg: "bg-green-500/10",
        border: "border-green-500/30",
        text: "text-green-400",
        glow: "shadow-green-500/20",
      },
      blue: {
        bg: "bg-blue-500/10",
        border: "border-blue-500/30",
        text: "text-blue-400",
        glow: "shadow-blue-500/20",
      },
      orange: {
        bg: "bg-orange-500/10",
        border: "border-orange-500/30",
        text: "text-orange-400",
        glow: "shadow-orange-500/20",
      },
      indigo: {
        bg: "bg-indigo-500/10",
        border: "border-indigo-500/30",
        text: "text-indigo-400",
        glow: "shadow-indigo-500/20",
      },
    };
    return colors[color] || colors.cyan;
  };

  const toggleEncryptionMode = () => {
    setEncryptionMode(!encryptionMode);
    onAuditLog(
      `Encryption execution mode ${!encryptionMode ? "ENABLED" : "DISABLED"} - AES-256-GCM active`,
    );
  };

  const sampledPlotData = plotData.filter(
    (_, i) => i % 20 === 0,
  );

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-2xl font-bold text-white mb-2">
            Process Flow Dashboard
          </h2>
          <p className="text-gray-400">
            Real-time workflow visualization with 24k resolution
            analytics
          </p>
        </div>
        <button
          onClick={toggleEncryptionMode}
          className={`flex items-center gap-2 px-4 py-2 rounded-lg transition-all ${
            encryptionMode
              ? "bg-gradient-to-r from-green-500/20 to-emerald-500/20 border border-green-500/40 text-green-400"
              : "bg-gray-800/40 border border-gray-600/40 text-gray-400 hover:border-green-500/40"
          }`}
        >
          <Lock className="w-4 h-4" />
          <span className="font-semibold text-sm">
            ENCRYPTION EXEC {encryptionMode ? "ON" : "OFF"}
          </span>
        </button>
      </div>

      {/* Live Metrics */}
      <div className="grid grid-cols-4 gap-4">
        {[
          {
            label: "Total Processed",
            value: liveMetrics.totalProcessed.toLocaleString(),
            icon: TrendingUp,
            color: "cyan",
          },
          {
            label: "Success Rate",
            value: `${liveMetrics.successRate.toFixed(2)}%`,
            icon: Shield,
            color: "green",
          },
          {
            label: "Avg Processing Time",
            value: `${Math.round(liveMetrics.avgProcessingTime)}ms`,
            icon: Zap,
            color: "purple",
          },
          {
            label: "Current Load",
            value: `${Math.round(liveMetrics.currentLoad)}%`,
            icon: Cpu,
            color: "orange",
          },
        ].map((metric, idx) => {
          const Icon = metric.icon;
          const colors = getColorClasses(metric.color);
          return (
            <div
              key={idx}
              className={`${colors.bg} border ${colors.border} rounded-lg p-4 backdrop-blur-sm`}
            >
              <div className="flex items-center gap-2 mb-2">
                <Icon className={`w-4 h-4 ${colors.text}`} />
                <span className="text-xs text-gray-400 uppercase tracking-wide">
                  {metric.label}
                </span>
              </div>
              <div
                className={`text-2xl font-bold ${colors.text}`}
              >
                {metric.value}
              </div>
            </div>
          );
        })}
      </div>

      {/* MATLAB Plot */}
      <div className="bg-gradient-to-br from-gray-900/90 to-gray-800/90 border border-cyan-500/20 rounded-lg p-6 backdrop-blur-sm">
        <div className="flex items-center justify-between mb-4">
          <h3 className="text-lg font-semibold text-white">
            MATLAB-Style 24k Signal Processing
          </h3>
          <div className="flex items-center gap-3">
            <span className="text-xs text-gray-400">
              24,000 samples @ 1kHz
            </span>
            <div className="flex items-center gap-1">
              <div className="w-2 h-2 bg-cyan-400 rounded-full animate-pulse"></div>
              <span className="text-xs text-cyan-400">
                LIVE
              </span>
            </div>
          </div>
        </div>
        <div className="bg-black/40 rounded border border-gray-700/40 p-4">
          <svg
            width="100%"
            height="200"
            className="text-cyan-400"
          >
            <defs>
              <linearGradient
                id="plotGradient"
                x1="0%"
                y1="0%"
                x2="0%"
                y2="100%"
              >
                <stop
                  offset="0%"
                  style={{
                    stopColor: "rgb(34, 211, 238)",
                    stopOpacity: 0.3,
                  }}
                />
                <stop
                  offset="100%"
                  style={{
                    stopColor: "rgb(34, 211, 238)",
                    stopOpacity: 0,
                  }}
                />
              </linearGradient>
            </defs>
            <g>
              {[0, 50, 100, 150, 200].map((y) => (
                <line
                  key={y}
                  x1="0"
                  y1={y}
                  x2="100%"
                  y2={y}
                  stroke="#1f2937"
                  strokeWidth="1"
                  opacity="0.3"
                />
              ))}
              <polyline
                fill="none"
                stroke="rgb(34, 211, 238)"
                strokeWidth="2"
                points={sampledPlotData
                  .map((val, idx) => {
                    const x =
                      (idx / sampledPlotData.length) * 1000;
                    const y = 200 - (val / 100) * 200;
                    return `${x},${y}`;
                  })
                  .join(" ")}
              />
              <polygon
                fill="url(#plotGradient)"
                points={
                  `0,200 ` +
                  sampledPlotData
                    .map((val, idx) => {
                      const x =
                        (idx / sampledPlotData.length) * 1000;
                      const y = 200 - (val / 100) * 200;
                      return `${x},${y}`;
                    })
                    .join(" ") +
                  ` 1000,200`
                }
              />
            </g>
          </svg>
          <div className="flex items-center justify-between mt-2 text-xs text-gray-500">
            <span>0s</span>
            <span>12s</span>
            <span>24s</span>
          </div>
        </div>
      </div>

      {/* Process Selection */}
      <div className="grid grid-cols-6 gap-3">
        {processes.map((process) => {
          const Icon = process.icon;
          const colors = getColorClasses(process.color);
          const isSelected = selectedProcess === process.id;

          return (
            <button
              key={process.id}
              onClick={() => {
                setSelectedProcess(process.id);
                onAuditLog(
                  `Process view changed to ${process.name}`,
                );
              }}
              className={`p-4 rounded-lg border transition-all ${
                isSelected
                  ? `${colors.bg} ${colors.border} shadow-lg ${colors.glow}`
                  : "bg-gray-800/40 border-gray-700/40 hover:border-gray-600/60"
              }`}
            >
              <Icon
                className={`w-6 h-6 mx-auto mb-2 ${isSelected ? colors.text : "text-gray-400"}`}
              />
              <div
                className={`text-xs font-medium text-center ${isSelected ? colors.text : "text-gray-400"}`}
              >
                {process.name}
              </div>
              <div className="text-xs text-gray-500 text-center mt-1">
                {process.totalTime}
              </div>
            </button>
          );
        })}
      </div>

      {/* Process Steps */}
      <div className="bg-gradient-to-br from-gray-900/90 to-gray-800/90 border border-cyan-500/20 rounded-lg p-6 backdrop-blur-sm">
        <div className="flex items-center justify-between mb-6">
          <div>
            <h3 className="text-xl font-bold text-white">
              {selectedProcessData.name}
            </h3>
            <div className="flex items-center gap-4 mt-2">
              <span className="text-sm text-gray-400">
                Total Time:{" "}
                <span className="text-cyan-400 font-semibold">
                  {selectedProcessData.totalTime}
                </span>
              </span>
              <span className="text-sm text-gray-400">
                Success Rate:{" "}
                <span className="text-green-400 font-semibold">
                  {selectedProcessData.successRate}
                </span>
              </span>
            </div>
          </div>
        </div>

        <div className="space-y-3">
          {selectedProcessData.steps.map((step, idx) => {
            const isLast =
              idx === selectedProcessData.steps.length - 1;
            const statusColors = {
              completed:
                "bg-green-500/20 border-green-500/40 text-green-400",
              active:
                "bg-cyan-500/20 border-cyan-500/40 text-cyan-400",
              pending:
                "bg-gray-700/20 border-gray-600/40 text-gray-400",
            };

            return (
              <div key={step.id} className="relative">
                <div
                  className={`flex items-center gap-4 p-4 rounded-lg border ${statusColors[step.status]} transition-all`}
                >
                  <div className="flex-shrink-0">
                    <div
                      className={`w-8 h-8 rounded-full flex items-center justify-center font-bold text-sm ${
                        step.status === "completed"
                          ? "bg-green-500/30"
                          : step.status === "active"
                            ? "bg-cyan-500/30 animate-pulse"
                            : "bg-gray-600/30"
                      }`}
                    >
                      {step.id}
                    </div>
                  </div>
                  <div className="flex-1">
                    <div className="flex items-center justify-between mb-1">
                      <span className="font-semibold">
                        {step.name}
                      </span>
                      <span className="text-xs opacity-70">
                        {step.time}
                      </span>
                    </div>
                    <p className="text-xs opacity-70">
                      {step.description}
                    </p>
                  </div>
                  <div className="flex-shrink-0">
                    {step.status === "completed" && (
                      <div className="text-green-400">✓</div>
                    )}
                    {step.status === "active" && (
                      <div className="w-4 h-4 border-2 border-cyan-400 border-t-transparent rounded-full animate-spin"></div>
                    )}
                    {step.status === "pending" && (
                      <div className="text-gray-600">○</div>
                    )}
                  </div>
                </div>
                {!isLast && (
                  <div className="absolute left-7 top-16 w-0.5 h-3 bg-gradient-to-b from-cyan-500/40 to-transparent"></div>
                )}
              </div>
            );
          })}
        </div>
      </div>

      {/* Hardware/Software Specs */}
      <div className="grid grid-cols-2 gap-6">
        <div className="bg-gradient-to-br from-gray-900/90 to-gray-800/90 border border-purple-500/20 rounded-lg p-6 backdrop-blur-sm">
          <h3 className="text-lg font-bold text-white mb-4 flex items-center gap-2">
            <Cpu className="w-5 h-5 text-purple-400" />
            Hardware Architecture
          </h3>
          <div className="space-y-3 text-sm">
            {[
              {
                label: "Processing Nodes:",
                value: "18-Node Horizontal Topology",
              },
              {
                label: "Cryptographic Module:",
                value: "FIPS 140-2 Level 3",
              },
              {
                label: "FPGA Acceleration:",
                value: "Xilinx Virtex UltraScale+",
              },
              {
                label: "Network Interface:",
                value: "5G SA URLLC (<1ms latency)",
              },
              {
                label: "Storage Backend:",
                value: "S3 Express One Zone + Redis",
              },
            ].map((item, idx) => (
              <div key={idx} className="flex justify-between">
                <span className="text-gray-400">
                  {item.label}
                </span>
                <span className="text-white font-semibold">
                  {item.value}
                </span>
              </div>
            ))}
          </div>
        </div>

        <div className="bg-gradient-to-br from-gray-900/90 to-gray-800/90 border border-blue-500/20 rounded-lg p-6 backdrop-blur-sm">
          <h3 className="text-lg font-bold text-white mb-4 flex items-center gap-2">
            <Database className="w-5 h-5 text-blue-400" />
            Software Stack
          </h3>
          <div className="space-y-3 text-sm">
            {[
              {
                label: "Core Framework:",
                value: "React 18.3.1 + TypeScript",
              },
              {
                label: "Encryption:",
                value: "AES-256-GCM + RSA-4096",
              },
              {
                label: "Vault:",
                value: "HashiCorp Vault 1.15.x",
              },
              {
                label: "Database:",
                value: "MongoDB Atlas + DynamoDB",
              },
              {
                label: "Blockchain:",
                value: "Ethereum (Merkle anchoring)",
              },
            ].map((item, idx) => (
              <div key={idx} className="flex justify-between">
                <span className="text-gray-400">
                  {item.label}
                </span>
                <span className="text-white font-semibold">
                  {item.value}
                </span>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Platform Description */}
      <div className="bg-gradient-to-br from-cyan-900/20 to-blue-900/20 border border-cyan-500/30 rounded-lg p-6 backdrop-blur-sm">
        <h3 className="text-xl font-bold text-cyan-400 mb-3">
          VOM Banking Platform - Enterprise-Grade Financial
          Infrastructure
        </h3>
        <p className="text-gray-300 leading-relaxed mb-4">
          The VOM Banking Platform is a comprehensive,
          production-ready financial operations system designed
          for mission-critical banking infrastructure. Featuring
          19 integrated modules, real-time transaction
          processing with 99.7% success rate, and military-grade
          encryption.
        </p>
        <div className="grid grid-cols-3 gap-4 mt-4">
          {[
            {
              value: "248ms",
              label: "Average Transaction Time",
            },
            {
              value: "99.99%",
              label: "5G Network Reliability",
            },
            { value: "24h", label: "Automated PKI Rotation" },
          ].map((stat, idx) => (
            <div
              key={idx}
              className="bg-black/20 rounded p-3 border border-cyan-500/20"
            >
              <div className="text-2xl font-bold text-cyan-400">
                {stat.value}
              </div>
              <div className="text-xs text-gray-400 mt-1">
                {stat.label}
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}