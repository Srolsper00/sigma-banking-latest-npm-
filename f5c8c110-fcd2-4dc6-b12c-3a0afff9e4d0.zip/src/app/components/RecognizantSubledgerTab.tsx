import { useState, useEffect } from 'react';
import {
  Shield,
  FileText,
  Database,
  Lock,
  ChevronRight,
  ChevronDown,
  Eye,
  Download,
  Calendar,
  CheckCircle2,
  AlertTriangle,
  FileKey,
  Building2,
  Scale,
  UserCheck,
  Layers
} from 'lucide-react';

interface RecognizantSubledgerProps {
  secureMode: boolean;
  onAuditLog: (action: string) => void;
}

interface SubledgerEntry {
  id: string;
  category: string;
  subcategory: string;
  reference: string;
  antecedent: string;
  truncatedSummary: string;
  effectiveDate: string;
  status: 'active' | 'superseded' | 'pending';
  hierarchyLevel: number;
  parentId?: string;
}

interface AntecedentDocument {
  id: string;
  title: string;
  type: 'privacy-act' | 'fpki-ecosystem' | 'policy' | 'regulation';
  effectiveDate: string;
  truncatedContent: string[];
  hierarchicalReferences: string[];
}

export function RecognizantSubledgerTab({ secureMode, onAuditLog }: RecognizantSubledgerProps) {
  const [selectedCategory, setSelectedCategory] = useState<string>('all');
  const [expandedEntries, setExpandedEntries] = useState<Set<string>>(new Set());
  const [selectedDocument, setSelectedDocument] = useState<string | null>(null);

  useEffect(() => {
    onAuditLog('Accessed Recognizant Subledger - Hierarchical antecedents loaded');
  }, []);

  // Privacy Act of 1974 System of Records - Truncated Antecedents
  const privacyActAntecedents: AntecedentDocument[] = [
    {
      id: 'PA-SOR-001',
      title: 'Privacy Act of 1974 - System of Records Notice (SORN)',
      type: 'privacy-act',
      effectiveDate: '2021-11-02',
      truncatedContent: [
        'SYSTEM NAME: Treasury Federal PKI Certification Authority (FPKI CA) System of Records',
        'SECURITY CLASSIFICATION: Unclassified',
        'SYSTEM LOCATION: Bureau of the Fiscal Service, Parkersburg, WV',
        'AUTHORITY: 5 U.S.C. § 552a (Privacy Act), 44 U.S.C. § 3541 (Federal Information Security)',
        'PURPOSE: Maintain records of individuals who receive digital certificates for authentication',
        'CATEGORIES OF INDIVIDUALS: Federal employees, contractors, state/local government personnel',
        'CATEGORIES OF RECORDS: Name, SSN, email, organizational affiliation, certificate serial numbers',
        'ROUTINE USES: Law enforcement, congressional inquiries, NARA archival, court proceedings',
        'RETENTION: Active certificates: Duration of validity + 7 years; Revoked: 20 years',
        'SAFEGUARDS: FIPS 140-2 encryption, multi-factor authentication, audit logging, access controls'
      ],
      hierarchicalReferences: [
        'Treasury Directive 81-08 (Information Security)',
        'OMB Circular A-130 (Federal Information Resources Management)',
        'NIST SP 800-53 Rev. 5 (Security and Privacy Controls)',
        'Federal PKI Policy Authority (FPKIPA) Certificate Policy'
      ]
    },
    {
      id: 'PA-SOR-002',
      title: 'Privacy Act - Disclosure and Exemptions',
      type: 'privacy-act',
      effectiveDate: '2021-11-02',
      truncatedContent: [
        'DISCLOSURE RESTRICTIONS: No disclosure without written consent except routine uses',
        'EXEMPTIONS CLAIMED: None - Full Privacy Act protections apply',
        'INDIVIDUAL ACCESS: Subject can request records via FOIA/Privacy Act request',
        'AMENDMENT PROCEDURES: Submit written request with supporting documentation',
        'DISPUTE RESOLUTION: Appeals to Treasury FOIA/Privacy Act Officer',
        'NOTIFICATION: Annual Federal Register publication of system updates'
      ],
      hierarchicalReferences: [
        '5 U.S.C. § 552a(b) (Disclosure Conditions)',
        '5 U.S.C. § 552a(d) (Access to Records)',
        '5 U.S.C. § 552a(j)-(k) (Exemptions)',
        '31 CFR Part 1 (Privacy Act Regulations)'
      ]
    }
  ];

  // FPKI Ecosystem Changes - Truncated Antecedents
  const fpkiEcosystemAntecedents: AntecedentDocument[] = [
    {
      id: 'FPKI-ECO-001',
      title: 'FPKI Ecosystem Changes - Trust Infrastructure Migration',
      type: 'fpki-ecosystem',
      effectiveDate: '2024-06-01',
      truncatedContent: [
        'FEDERAL COMMON POLICY CA (FCPCA) ROOT MIGRATION: Transition to FCPCA G2',
        'LEGACY ROOT DEPRECATION: SHA-1 FCPCA root sunset by December 2024',
        'NEW ROOT SPECIFICATIONS: RSA-4096, SHA-256, 20-year validity',
        'CROSS-CERTIFICATION CHANGES: Removal of SHA-1 cross-certificates',
        'BRIDGE CA UPDATES: Federal Bridge CA G4 operational',
        'OCSP RESPONDER MIGRATION: New infrastructure at http://ocsp.fpki.gov',
        'CRL DISTRIBUTION POINTS: Consolidated at http://repo.fpki.gov',
        'PIV-I CHANGES: Personal Identity Verification Interoperable certification updates'
      ],
      hierarchicalReferences: [
        'X.509 Certificate Policy for FCPCA (CP) v2.0',
        'FPKI Certificate Profile (RFC 5280 Profile)',
        'NIST SP 800-217 (Guidelines for PIV Federation)',
        'Federal Bridge CA Certificate Policy v3.2'
      ]
    },
    {
      id: 'FPKI-ECO-002',
      title: 'FPKI Ecosystem - Certificate Policy Hierarchy',
      type: 'fpki-ecosystem',
      effectiveDate: '2024-06-01',
      truncatedContent: [
        'TIER 1: Federal Common Policy CA (FCPCA) - Root of Trust',
        'TIER 2: Shared Service Providers (SSP) - Intermediate CAs (DigiCert, Entrust, etc.)',
        'TIER 3: Agency-Specific CAs - Department/Bureau level issuance',
        'TIER 4: Issuing CAs - Direct certificate issuance to end entities',
        'ASSURANCE LEVELS: High (PIV), Medium (PIV-I), Low (basic authentication)',
        'KEY MANAGEMENT: FIPS 140-2 Level 3 HSMs mandatory for Tier 1-2',
        'CERTIFICATE TYPES: PIV Authentication, Digital Signature, Key Management, Card Auth',
        'VALIDITY PERIODS: Max 3 years (end-entity), 6 years (issuing CA), 20 years (root)'
      ],
      hierarchicalReferences: [
        'HSPD-12 (Policy for Common ID Standard)',
        'FIPS 201-3 (PIV Standard)',
        'OMB M-19-17 (PIV Authentication)',
        'FPKI Trust Framework v1.5'
      ]
    },
    {
      id: 'FPKI-ECO-003',
      title: 'FPKI Ecosystem - Compliance and Audit Requirements',
      type: 'fpki-ecosystem',
      effectiveDate: '2024-06-01',
      truncatedContent: [
        'ANNUAL AUDITS: WebTrust for Certification Authorities by licensed CPA firms',
        'COMPLIANCE MONITORING: FPKI Policy Authority (FPKIPA) quarterly reviews',
        'INCIDENT REPORTING: 24-hour notification for CA compromise or policy violations',
        'CERTIFICATE PROFILE VALIDATION: Automated scanning against RFC 5280 requirements',
        'REVOCATION TIMELINESS: CRL updates every 6 hours, OCSP real-time',
        'KEY CEREMONY PROCEDURES: Multi-party control (M-of-N) for root key operations',
        'DISASTER RECOVERY: Annual DR testing, RTO <4 hours, RPO <15 minutes',
        'SECURITY CONTROLS: NIST SP 800-53 Rev. 5 High baseline + FPKI overlays'
      ],
      hierarchicalReferences: [
        'WebTrust Principles and Criteria for CAs v2.2',
        'FPKI Audit Letter of Compliance (LOC) Template',
        'NIST SP 800-53 Rev. 5 (Security Controls)',
        'FPKI Annual Review Requirements (ARR) v4.0'
      ]
    }
  ];

  // Hierarchical Subledger Entries
  const subledgerEntries: SubledgerEntry[] = [
    // Level 1: Privacy Act Hierarchy
    {
      id: 'SL-PA-L1-001',
      category: 'Privacy Act Compliance',
      subcategory: 'System of Records',
      reference: 'PA-SOR-001',
      antecedent: 'Privacy Act of 1974 § 552a',
      truncatedSummary: 'Treasury FPKI CA maintains SORN for certificate holder records. Retention: 7-20 years.',
      effectiveDate: '2021-11-02',
      status: 'active',
      hierarchyLevel: 1
    },
    {
      id: 'SL-PA-L2-001',
      category: 'Privacy Act Compliance',
      subcategory: 'Record Categories',
      reference: 'PA-SOR-001',
      antecedent: '5 U.S.C. § 552a(e)(1)',
      truncatedSummary: 'PII collected: Name, SSN, Email, Org. Purpose: Digital certificate issuance/revocation.',
      effectiveDate: '2021-11-02',
      status: 'active',
      hierarchyLevel: 2,
      parentId: 'SL-PA-L1-001'
    },
    {
      id: 'SL-PA-L2-002',
      category: 'Privacy Act Compliance',
      subcategory: 'Routine Uses',
      reference: 'PA-SOR-001',
      antecedent: '5 U.S.C. § 552a(b)(3)',
      truncatedSummary: 'Authorized disclosures: Law enforcement, NARA, congressional, judicial proceedings only.',
      effectiveDate: '2021-11-02',
      status: 'active',
      hierarchyLevel: 2,
      parentId: 'SL-PA-L1-001'
    },
    {
      id: 'SL-PA-L3-001',
      category: 'Privacy Act Compliance',
      subcategory: 'Safeguards',
      reference: 'PA-SOR-001',
      antecedent: 'NIST SP 800-53 Rev. 5',
      truncatedSummary: 'Technical controls: FIPS 140-2 encryption, MFA, audit logs. Administrative: Access controls.',
      effectiveDate: '2021-11-02',
      status: 'active',
      hierarchyLevel: 3,
      parentId: 'SL-PA-L2-001'
    },

    // Level 1: FPKI Ecosystem Hierarchy
    {
      id: 'SL-FPKI-L1-001',
      category: 'FPKI Ecosystem',
      subcategory: 'Trust Infrastructure',
      reference: 'FPKI-ECO-001',
      antecedent: 'FCPCA G2 Root Migration',
      truncatedSummary: 'Migrate to FCPCA G2 (RSA-4096/SHA-256). Sunset SHA-1 legacy root by Dec 2024.',
      effectiveDate: '2024-06-01',
      status: 'active',
      hierarchyLevel: 1
    },
    {
      id: 'SL-FPKI-L2-001',
      category: 'FPKI Ecosystem',
      subcategory: 'Certificate Policy',
      reference: 'FPKI-ECO-002',
      antecedent: 'FPKI 4-Tier Hierarchy',
      truncatedSummary: 'Tier 1: FCPCA Root → Tier 2: SSP CAs → Tier 3: Agency CAs → Tier 4: Issuing CAs.',
      effectiveDate: '2024-06-01',
      status: 'active',
      hierarchyLevel: 2,
      parentId: 'SL-FPKI-L1-001'
    },
    {
      id: 'SL-FPKI-L2-002',
      category: 'FPKI Ecosystem',
      subcategory: 'Assurance Levels',
      reference: 'FPKI-ECO-002',
      antecedent: 'FIPS 201-3 PIV Standard',
      truncatedSummary: 'High (PIV), Medium (PIV-I), Low (basic). HSM required for High/Medium assurance.',
      effectiveDate: '2024-06-01',
      status: 'active',
      hierarchyLevel: 2,
      parentId: 'SL-FPKI-L1-001'
    },
    {
      id: 'SL-FPKI-L3-001',
      category: 'FPKI Ecosystem',
      subcategory: 'Audit & Compliance',
      reference: 'FPKI-ECO-003',
      antecedent: 'WebTrust for CAs v2.2',
      truncatedSummary: 'Annual WebTrust audits required. FPKIPA quarterly reviews. 24hr incident reporting.',
      effectiveDate: '2024-06-01',
      status: 'active',
      hierarchyLevel: 3,
      parentId: 'SL-FPKI-L2-001'
    },
    {
      id: 'SL-FPKI-L3-002',
      category: 'FPKI Ecosystem',
      subcategory: 'Revocation Services',
      reference: 'FPKI-ECO-001',
      antecedent: 'RFC 5280 + FPKI Profile',
      truncatedSummary: 'CRL: 6hr updates at repo.fpki.gov. OCSP: Real-time at ocsp.fpki.gov.',
      effectiveDate: '2024-06-01',
      status: 'active',
      hierarchyLevel: 3,
      parentId: 'SL-FPKI-L2-001'
    },

    // Cross-Reference: Privacy Act ↔ FPKI
    {
      id: 'SL-XREF-001',
      category: 'Cross-Reference',
      subcategory: 'Privacy Act ↔ FPKI Integration',
      reference: 'PA-SOR-001 + FPKI-ECO-002',
      antecedent: 'HSPD-12 + Privacy Act § 552a',
      truncatedSummary: 'PIV certificate records subject to Privacy Act SORN. FPKI CA operates under dual framework.',
      effectiveDate: '2024-06-01',
      status: 'active',
      hierarchyLevel: 1
    },
    {
      id: 'SL-XREF-002',
      category: 'Cross-Reference',
      subcategory: 'Audit Trail Requirements',
      reference: 'PA-SOR-002 + FPKI-ECO-003',
      antecedent: 'Privacy Act § 552a(e)(4) + WebTrust',
      truncatedSummary: 'Certificate operations logged per Privacy Act. WebTrust audit validates compliance.',
      effectiveDate: '2024-06-01',
      status: 'active',
      hierarchyLevel: 2,
      parentId: 'SL-XREF-001'
    },

    // VOM Platform Integration
    {
      id: 'SL-VOM-L1-001',
      category: 'VOM Platform Integration',
      subcategory: 'ACT2-SUDI Compliance',
      reference: 'FPKI-ECO-002',
      antecedent: 'Cisco ACT2 SUDI + FPKI CP',
      truncatedSummary: 'ACT2-SUDI certificates align with FPKI Tier 4 issuing CA requirements. 24hr rotation.',
      effectiveDate: '2024-06-01',
      status: 'active',
      hierarchyLevel: 1
    },
    {
      id: 'SL-VOM-L2-001',
      category: 'VOM Platform Integration',
      subcategory: 'Privacy Act Implementation',
      reference: 'PA-SOR-001',
      antecedent: 'VOM Banking Platform SORN',
      truncatedSummary: 'Device certificates include limited PII (device ID, org). Retention: 20 years post-revocation.',
      effectiveDate: '2024-06-01',
      status: 'active',
      hierarchyLevel: 2,
      parentId: 'SL-VOM-L1-001'
    },
    {
      id: 'SL-VOM-L2-002',
      category: 'VOM Platform Integration',
      subcategory: 'FPKI Bridge Integration',
      reference: 'FPKI-ECO-001',
      antecedent: 'Federal Bridge CA G4',
      truncatedSummary: 'VOM PKI cross-certified with FBCA G4. Enables trust with federal agencies.',
      effectiveDate: '2024-06-01',
      status: 'active',
      hierarchyLevel: 2,
      parentId: 'SL-VOM-L1-001'
    }
  ];

  const categories = ['all', 'Privacy Act Compliance', 'FPKI Ecosystem', 'Cross-Reference', 'VOM Platform Integration'];

  const toggleExpanded = (id: string) => {
    const newExpanded = new Set(expandedEntries);
    if (newExpanded.has(id)) {
      newExpanded.delete(id);
    } else {
      newExpanded.add(id);
    }
    setExpandedEntries(newExpanded);
    onAuditLog(`Toggled subledger entry ${id}`);
  };

  const getChildEntries = (parentId: string) => {
    return subledgerEntries.filter(entry => entry.parentId === parentId);
  };

  const filteredEntries = selectedCategory === 'all'
    ? subledgerEntries.filter(e => !e.parentId)
    : subledgerEntries.filter(e => e.category === selectedCategory && !e.parentId);

  const allDocuments = [...privacyActAntecedents, ...fpkiEcosystemAntecedents];

  const renderSubledgerEntry = (entry: SubledgerEntry, depth: number = 0) => {
    const isExpanded = expandedEntries.has(entry.id);
    const hasChildren = getChildEntries(entry.id).length > 0;
    const indentClass = `ml-${depth * 6}`;

    return (
      <div key={entry.id} className="mb-2">
        <div
          className={`${indentClass} bg-gradient-to-r from-slate-800/50 to-slate-900/50 border border-cyan-500/20 rounded-lg p-4 hover:border-cyan-400/40 transition-all cursor-pointer`}
          onClick={() => hasChildren && toggleExpanded(entry.id)}
        >
          <div className="flex items-start justify-between">
            <div className="flex-1">
              <div className="flex items-center gap-3 mb-2">
                {hasChildren && (
                  isExpanded ? <ChevronDown className="w-4 h-4 text-cyan-400" /> : <ChevronRight className="w-4 h-4 text-cyan-400" />
                )}
                <Layers className="w-5 h-5 text-cyan-400" />
                <span className="text-xs font-mono text-cyan-400">Level {entry.hierarchyLevel}</span>
                <span className="text-xs font-mono text-gray-500">{entry.id}</span>
                <span className={`text-xs px-2 py-0.5 rounded ${
                  entry.status === 'active' ? 'bg-green-500/20 text-green-400' :
                  entry.status === 'superseded' ? 'bg-yellow-500/20 text-yellow-400' :
                  'bg-blue-500/20 text-blue-400'
                }`}>
                  {entry.status.toUpperCase()}
                </span>
              </div>

              <h3 className="font-semibold text-white mb-1">{entry.subcategory}</h3>
              <p className="text-sm text-gray-300 mb-2">{entry.truncatedSummary}</p>

              <div className="grid grid-cols-2 gap-4 text-xs">
                <div>
                  <span className="text-gray-500">Antecedent:</span>
                  <span className="ml-2 text-cyan-400 font-mono">{entry.antecedent}</span>
                </div>
                <div>
                  <span className="text-gray-500">Reference:</span>
                  <span className="ml-2 text-purple-400 font-mono">{entry.reference}</span>
                </div>
                <div>
                  <span className="text-gray-500">Effective Date:</span>
                  <span className="ml-2 text-gray-300">{entry.effectiveDate}</span>
                </div>
                <div>
                  <span className="text-gray-500">Category:</span>
                  <span className="ml-2 text-gray-300">{entry.category}</span>
                </div>
              </div>
            </div>

            <button
              onClick={(e) => {
                e.stopPropagation();
                setSelectedDocument(entry.reference);
                onAuditLog(`Viewed antecedent document ${entry.reference}`);
              }}
              className="ml-4 p-2 bg-cyan-500/20 hover:bg-cyan-500/30 rounded transition-colors"
            >
              <Eye className="w-4 h-4 text-cyan-400" />
            </button>
          </div>
        </div>

        {isExpanded && hasChildren && (
          <div className="mt-2">
            {getChildEntries(entry.id).map(child => renderSubledgerEntry(child, depth + 1))}
          </div>
        )}
      </div>
    );
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-2xl font-bold text-transparent bg-clip-text bg-gradient-to-r from-cyan-400 to-blue-500">
            Recognizant Hierarchical Subledger
          </h2>
          <p className="text-gray-400 mt-1">
            Truncated antecedents for Privacy Act & FPKI ecosystem compliance
          </p>
        </div>
        <div className="flex items-center gap-2">
          <Shield className={`w-6 h-6 ${secureMode ? 'text-green-400' : 'text-yellow-400'}`} />
          <span className="text-sm font-mono text-gray-400">
            {secureMode ? 'SECURE MODE' : 'AUDIT MODE'}
          </span>
        </div>
      </div>

      {/* Statistics */}
      <div className="grid grid-cols-4 gap-4">
        <div className="bg-gradient-to-br from-cyan-500/10 to-blue-500/10 border border-cyan-500/30 rounded-lg p-4">
          <div className="flex items-center gap-3">
            <Database className="w-8 h-8 text-cyan-400" />
            <div>
              <div className="text-2xl font-bold text-white">{subledgerEntries.length}</div>
              <div className="text-sm text-gray-400">Total Entries</div>
            </div>
          </div>
        </div>

        <div className="bg-gradient-to-br from-purple-500/10 to-pink-500/10 border border-purple-500/30 rounded-lg p-4">
          <div className="flex items-center gap-3">
            <FileText className="w-8 h-8 text-purple-400" />
            <div>
              <div className="text-2xl font-bold text-white">{allDocuments.length}</div>
              <div className="text-sm text-gray-400">Antecedent Docs</div>
            </div>
          </div>
        </div>

        <div className="bg-gradient-to-br from-green-500/10 to-emerald-500/10 border border-green-500/30 rounded-lg p-4">
          <div className="flex items-center gap-3">
            <CheckCircle2 className="w-8 h-8 text-green-400" />
            <div>
              <div className="text-2xl font-bold text-white">
                {subledgerEntries.filter(e => e.status === 'active').length}
              </div>
              <div className="text-sm text-gray-400">Active</div>
            </div>
          </div>
        </div>

        <div className="bg-gradient-to-br from-yellow-500/10 to-orange-500/10 border border-yellow-500/30 rounded-lg p-4">
          <div className="flex items-center gap-3">
            <Layers className="w-8 h-8 text-yellow-400" />
            <div>
              <div className="text-2xl font-bold text-white">
                {Math.max(...subledgerEntries.map(e => e.hierarchyLevel))}
              </div>
              <div className="text-sm text-gray-400">Max Depth</div>
            </div>
          </div>
        </div>
      </div>

      {/* Category Filter */}
      <div className="flex gap-2 overflow-x-auto pb-2">
        {categories.map(cat => (
          <button
            key={cat}
            onClick={() => {
              setSelectedCategory(cat);
              onAuditLog(`Filtered subledger by category: ${cat}`);
            }}
            className={`px-4 py-2 rounded-lg font-medium text-sm whitespace-nowrap transition-all ${
              selectedCategory === cat
                ? 'bg-cyan-500 text-white'
                : 'bg-slate-800 text-gray-400 hover:bg-slate-700'
            }`}
          >
            {cat === 'all' ? 'All Categories' : cat}
          </button>
        ))}
      </div>

      {/* Subledger Entries */}
      <div className="space-y-2">
        <h3 className="text-lg font-semibold text-white flex items-center gap-2">
          <Database className="w-5 h-5 text-cyan-400" />
          Hierarchical Subledger Entries
        </h3>
        {filteredEntries.map(entry => renderSubledgerEntry(entry, 0))}
      </div>

      {/* Document Viewer Modal */}
      {selectedDocument && (
        <div className="fixed inset-0 bg-black/80 backdrop-blur-sm z-50 flex items-center justify-center p-6">
          <div className="bg-slate-900 border border-cyan-500/30 rounded-xl max-w-4xl w-full max-h-[90vh] overflow-hidden flex flex-col">
            <div className="flex items-center justify-between p-6 border-b border-cyan-500/20">
              <h3 className="text-xl font-bold text-white flex items-center gap-2">
                <FileKey className="w-6 h-6 text-cyan-400" />
                Antecedent Document: {selectedDocument}
              </h3>
              <button
                onClick={() => setSelectedDocument(null)}
                className="text-gray-400 hover:text-white transition-colors"
              >
                ✕
              </button>
            </div>

            <div className="p-6 overflow-y-auto flex-1">
              {allDocuments
                .filter(doc => doc.id === selectedDocument)
                .map(doc => (
                  <div key={doc.id} className="space-y-4">
                    <div className="bg-slate-800/50 border border-cyan-500/20 rounded-lg p-4">
                      <div className="grid grid-cols-2 gap-4 text-sm">
                        <div>
                          <span className="text-gray-500">Document Type:</span>
                          <span className="ml-2 text-cyan-400 uppercase">{doc.type.replace('-', ' ')}</span>
                        </div>
                        <div>
                          <span className="text-gray-500">Effective Date:</span>
                          <span className="ml-2 text-gray-300">{doc.effectiveDate}</span>
                        </div>
                      </div>
                    </div>

                    <div>
                      <h4 className="text-lg font-semibold text-white mb-3">Truncated Content</h4>
                      <div className="space-y-2">
                        {doc.truncatedContent.map((item, idx) => (
                          <div key={idx} className="bg-slate-800/30 border-l-2 border-cyan-500/50 pl-4 py-2">
                            <p className="text-sm text-gray-300 font-mono">{item}</p>
                          </div>
                        ))}
                      </div>
                    </div>

                    <div>
                      <h4 className="text-lg font-semibold text-white mb-3">Hierarchical References</h4>
                      <div className="grid grid-cols-1 gap-2">
                        {doc.hierarchicalReferences.map((ref, idx) => (
                          <div key={idx} className="bg-purple-500/10 border border-purple-500/30 rounded px-3 py-2">
                            <p className="text-sm text-purple-300 font-mono">{ref}</p>
                          </div>
                        ))}
                      </div>
                    </div>
                  </div>
                ))}
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
