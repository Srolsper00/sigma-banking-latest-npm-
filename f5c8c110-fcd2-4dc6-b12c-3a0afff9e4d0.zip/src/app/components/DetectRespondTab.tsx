import { useState } from "react";
import {
  Activity,
  Shield,
  Database,
  TrendingUp,
  Zap,
  HardDrive,
  CheckCircle2,
  AlertTriangle,
  Info,
} from "lucide-react";

interface DetectRespondTabProps {
  secureMode: boolean;
  onAuditLog: (message: string) => void;
}

const frameworks = [
  "CIS CSC 4, 7, 8, 12",
  "COBIT 5 DSS05.01",
  "ISA 62443-2-1:2009 4.3.4.3.8",
  "ISA 62443-3-3:2013 SR 3.2",
  "ISO/IEC 27001:2013 A.12.2.1",
  "NIST SP 800-53 Rev. 4 SI-3, SI-8",
];

export function DetectRespondTab({
  secureMode,
  onAuditLog,
}: DetectRespondTabProps) {
  const [selectedView, setSelectedView] = useState<
    "overview" | "glschema" | "topology" | "treasury"
  >("overview");

  const handleViewChange = (view: typeof selectedView) => {
    setSelectedView(view);
    onAuditLog(`Switched to ${view} view in Detect & Respond`);
  };

  return (
    <div>
      {/* Header */}
      <div className="mb-6">
        <h2 className="text-2xl font-bold text-white uppercase tracking-wide">
          Detect & Respond Operations
        </h2>
        <p className="text-cyan-400 font-mono text-sm mt-1">
          DE.CM-4: Malicious Code Detection & Performance
          Optimization
        </p>
      </div>

      {/* View Selector */}
      <div className="flex gap-2 mb-6 overflow-x-auto scrollbar-hide">
        {[
          {
            id: "overview",
            label: "Performance & Detection",
            icon: Activity,
          },
          {
            id: "glschema",
            label: "GL Schema - Clearing M-11",
            icon: Database,
          },
          {
            id: "topology",
            label: "MCP Microservice Topology",
            icon: Zap,
          },
          {
            id: "treasury",
            label: "Treasury Operations",
            icon: TrendingUp,
          },
        ].map((view) => {
          const Icon = view.icon;
          return (
            <button
              key={view.id}
              onClick={() =>
                handleViewChange(view.id as typeof selectedView)
              }
              className={`
                flex items-center gap-2 px-4 py-2 rounded-lg text-sm font-semibold uppercase tracking-wide whitespace-nowrap
                transition-all duration-300
                ${
                  selectedView === view.id
                    ? "bg-cyan-500/30 text-cyan-400 border border-cyan-500/50"
                    : "bg-gray-500/10 text-gray-400 border border-gray-500/30 hover:bg-gray-500/20"
                }
              `}
            >
              <Icon className="w-4 h-4" />
              {view.label}
            </button>
          );
        })}
      </div>

      {/* Content */}
      <div style={{ animation: "fadeIn 0.3s ease-out" }}>
        {selectedView === "overview" && (
          <OverviewContent
            secureMode={secureMode}
            onAuditLog={onAuditLog}
          />
        )}
        {selectedView === "glschema" && <GLSchemaContent />}
        {selectedView === "topology" && <TopologyContent />}
        {selectedView === "treasury" && <TreasuryContent />}
      </div>

      <style>{`
        @keyframes fadeIn {
          from { opacity: 0; }
          to { opacity: 1; }
        }
      `}</style>
    </div>
  );
}

function OverviewContent({
  secureMode,
  onAuditLog,
}: {
  secureMode: boolean;
  onAuditLog: (msg: string) => void;
}) {
  const frameworks = [
    "CIS CSC 4, 7, 8, 12",
    "COBIT 5 DSS05.01",
    "ISA 62443-2-1:2009 4.3.4.3.8",
    "ISA 62443-3-3:2013 SR 3.2",
    "ISO/IEC 27001:2013 A.12.2.1",
    "NIST SP 800-53 Rev. 4 SI-3, SI-8",
  ];

  return (
    <div className="space-y-6">
      {/* DE.CM-4 Control */}
      <div className="p-6 bg-red-500/10 border border-red-500/50 rounded-lg">
        <div className="flex items-start gap-4 mb-4">
          <div className="p-3 bg-red-500/20 border border-red-500/50 rounded-lg">
            <Shield className="w-6 h-6 text-red-400" />
          </div>
          <div className="flex-1">
            <div className="flex items-center gap-3 mb-2">
              <h3 className="text-xl font-bold text-white">
                DE.CM-4: Malicious Code Detection
              </h3>
              <div className="px-2 py-1 bg-green-500 text-white text-xs font-bold rounded uppercase">
                Active
              </div>
            </div>
            <p className="text-gray-300 mb-4">
              Real-time malicious code detection across all
              critical banking infrastructure with multi-layer
              security controls
            </p>

            {/* Framework Compliance */}
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-2">
              {frameworks.map((framework, idx) => (
                <div
                  key={framework}
                  className="px-3 py-2 bg-black/30 border border-red-500/30 rounded text-xs font-mono text-red-400"
                  style={{
                    animation: "slideIn 0.4s ease-out forwards",
                    animationDelay: `${idx * 50}ms`,
                    opacity: 0,
                  }}
                >
                  {framework}
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>

      {/* Performance Optimization - S3 Express */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
        {/* S3 Express Archival */}
        <div className="p-6 bg-cyan-500/10 border border-cyan-500/50 rounded-lg">
          <div className="flex items-center gap-3 mb-4">
            <HardDrive className="w-6 h-6 text-cyan-400" />
            <h3 className="text-lg font-bold text-white">
              S3 Express One Zone Archival
            </h3>
          </div>

          <div className="space-y-4">
            {/* Primary Active Data */}
            <div>
              <div className="flex items-center justify-between mb-2">
                <span className="text-sm text-gray-400">
                  Primary Active Data
                </span>
                <span className="text-sm font-bold text-white">
                  38%
                </span>
              </div>
              <div className="h-3 bg-black/30 rounded-full overflow-hidden">
                <div
                  className="h-full bg-gradient-to-r from-green-500 to-green-400 w-[38%]"
                  style={{ animation: "expandBar 1s ease-out" }}
                />
              </div>
              <p className="text-xs text-gray-500 mt-1">
                Hot storage - Core Banking Cluster
              </p>
            </div>

            {/* Archived to S3 Express */}
            <div>
              <div className="flex items-center justify-between mb-2">
                <span className="text-sm text-gray-400">
                  Archived to S3 Express
                </span>
                <span className="text-sm font-bold text-cyan-400">
                  62%
                </span>
              </div>
              <div className="h-3 bg-black/30 rounded-full overflow-hidden">
                <div
                  className="h-full bg-gradient-to-r from-cyan-500 to-cyan-400 w-[62%]"
                  style={{
                    animation: "expandBar 1.2s ease-out",
                  }}
                />
              </div>
              <p className="text-xs text-gray-500 mt-1">
                S3 Express One Zone - 10x faster retrieval
              </p>
            </div>

            {/* Stats */}
            <div className="grid grid-cols-3 gap-2 pt-4 border-t border-cyan-500/30">
              <div className="text-center">
                <div className="text-xl font-bold text-cyan-400">
                  10x
                </div>
                <div className="text-xs text-gray-500">
                  Faster Access
                </div>
              </div>
              <div className="text-center">
                <div className="text-xl font-bold text-green-400">
                  85%
                </div>
                <div className="text-xs text-gray-500">
                  Cost Reduction
                </div>
              </div>
              <div className="text-center">
                <div className="text-xl font-bold text-purple-400">
                  99.99%
                </div>
                <div className="text-xs text-gray-500">
                  Availability
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* Node Processing Performance */}
        <div className="p-6 bg-purple-500/10 border border-purple-500/50 rounded-lg">
          <div className="flex items-center gap-3 mb-4">
            <Zap className="w-6 h-6 text-purple-400" />
            <h3 className="text-lg font-bold text-white">
              Critical Node Processing
            </h3>
          </div>

          <div className="space-y-3">
            {[
              {
                node: "Core Banking Cluster",
                load: 89,
                status: "optimal",
                color: "green",
              },
              {
                node: "Payment Gateway",
                load: 72,
                status: "optimal",
                color: "green",
              },
              {
                node: "Tokenization Vault",
                load: 45,
                status: "optimal",
                color: "green",
              },
              {
                node: "MCP Orchestrator",
                load: 94,
                status: "high",
                color: "amber",
              },
              {
                node: "Settlement Listener",
                load: 38,
                status: "optimal",
                color: "green",
              },
            ].map((node, idx) => (
              <div
                key={node.node}
                className="p-3 bg-black/30 border border-gray-500/30 rounded"
                style={{
                  animation: "slideUp 0.4s ease-out forwards",
                  animationDelay: `${idx * 100}ms`,
                  opacity: 0,
                }}
              >
                <div className="flex items-center justify-between mb-2">
                  <span className="text-sm font-semibold text-white">
                    {node.node}
                  </span>
                  <span
                    className={`text-xs font-bold uppercase ${
                      node.color === "green"
                        ? "text-green-400"
                        : "text-amber-400"
                    }`}
                  >
                    {node.status}
                  </span>
                </div>
                <div className="h-2 bg-black/50 rounded-full overflow-hidden">
                  <div
                    className={`h-full ${
                      node.color === "green"
                        ? "bg-gradient-to-r from-green-500 to-green-400"
                        : "bg-gradient-to-r from-amber-500 to-amber-400"
                    }`}
                    style={{
                      width: `${node.load}%`,
                      animation: "expandBar 1s ease-out",
                    }}
                  />
                </div>
                <div className="text-xs text-gray-500 mt-1">
                  Load: {node.load}%
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Detection Metrics */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        {[
          {
            label: "Threats Detected",
            value: "0",
            status: "success",
            icon: CheckCircle2,
          },
          {
            label: "Active Scans",
            value: "24/7",
            status: "active",
            icon: Activity,
          },
          {
            label: "Last Scan",
            value: "2m ago",
            status: "recent",
            icon: Info,
          },
          {
            label: "Protection Level",
            value: "Maximum",
            status: "protected",
            icon: Shield,
          },
        ].map((metric, idx) => {
          const Icon = metric.icon;
          return (
            <div
              key={metric.label}
              className="p-4 bg-gray-500/5 border border-gray-500/30 rounded-lg"
              style={{
                animation: "scaleIn 0.4s ease-out forwards",
                animationDelay: `${idx * 100}ms`,
                opacity: 0,
              }}
            >
              <div className="flex items-center gap-2 mb-2">
                <Icon
                  className={`w-4 h-4 ${
                    metric.status === "success"
                      ? "text-green-400"
                      : metric.status === "active"
                        ? "text-cyan-400"
                        : metric.status === "protected"
                          ? "text-purple-400"
                          : "text-gray-400"
                  }`}
                />
                <span className="text-xs text-gray-500 uppercase">
                  {metric.label}
                </span>
              </div>
              <div
                className={`text-2xl font-bold ${
                  metric.status === "success"
                    ? "text-green-400"
                    : metric.status === "active"
                      ? "text-cyan-400"
                      : metric.status === "protected"
                        ? "text-purple-400"
                        : "text-white"
                }`}
              >
                {metric.value}
              </div>
            </div>
          );
        })}
      </div>

      <style>{`
        @keyframes expandBar {
          from { width: 0; }
        }
        @keyframes slideIn {
          from { opacity: 0; transform: translateX(-10px); }
          to { opacity: 1; transform: translateX(0); }
        }
        @keyframes slideUp {
          from { opacity: 0; transform: translateY(10px); }
          to { opacity: 1; transform: translateY(0); }
        }
        @keyframes scaleIn {
          from { opacity: 0; transform: scale(0.95); }
          to { opacity: 1; transform: scale(1); }
        }
      `}</style>
    </div>
  );
}

function GLSchemaContent() {
  return (
    <div className="space-y-6">
      <div className="p-6 bg-gray-500/5 border border-gray-500/30 rounded-lg">
        <h3 className="text-xl font-bold text-white mb-2">
          GL Schema - Clearing M-11 Ledger
        </h3>
        <p className="text-sm text-gray-400 mb-6">
          General ledger clearing accounts for ACH processing
          and settlement operations
        </p>

        {/* Flowchart */}
        <div className="bg-black/30 border border-cyan-500/30 rounded-lg p-8 overflow-x-auto">
          <svg
            viewBox="0 0 800 600"
            className="w-full"
            style={{ maxWidth: "800px", margin: "0 auto" }}
          >
            {/* Definitions */}
            <defs>
              <linearGradient
                id="nodeGrad"
                x1="0%"
                y1="0%"
                x2="100%"
                y2="100%"
              >
                <stop
                  offset="0%"
                  style={{
                    stopColor: "#00d4ff",
                    stopOpacity: 0.2,
                  }}
                />
                <stop
                  offset="100%"
                  style={{
                    stopColor: "#00d4ff",
                    stopOpacity: 0.1,
                  }}
                />
              </linearGradient>
              <filter id="glow">
                <feGaussianBlur
                  stdDeviation="2"
                  result="coloredBlur"
                />
                <feMerge>
                  <feMergeNode in="coloredBlur" />
                  <feMergeNode in="SourceGraphic" />
                </feMerge>
              </filter>
            </defs>

            {/* Main Flow */}
            {/* GL Accounts */}
            <rect
              x="300"
              y="20"
              width="200"
              height="60"
              rx="8"
              fill="url(#nodeGrad)"
              stroke="#00d4ff"
              strokeWidth="2"
              filter="url(#glow)"
            />
            <text
              x="400"
              y="55"
              textAnchor="middle"
              fill="#00d4ff"
              fontSize="16"
              fontWeight="bold"
            >
              GL Accounts
            </text>

            {/* Arrow to Journal Entries */}
            <path
              d="M 400 80 L 400 120"
              stroke="#00d4ff"
              strokeWidth="2"
              markerEnd="url(#arrowhead)"
            />

            {/* Journal Entries */}
            <rect
              x="300"
              y="120"
              width="200"
              height="60"
              rx="8"
              fill="url(#nodeGrad)"
              stroke="#00d4ff"
              strokeWidth="2"
            />
            <text
              x="400"
              y="155"
              textAnchor="middle"
              fill="#00d4ff"
              fontSize="16"
              fontWeight="bold"
            >
              Journal Entries
            </text>

            {/* Arrow to Transactions */}
            <path
              d="M 400 180 L 400 220"
              stroke="#00d4ff"
              strokeWidth="2"
              markerEnd="url(#arrowhead)"
            />

            {/* Transactions */}
            <rect
              x="300"
              y="220"
              width="200"
              height="60"
              rx="8"
              fill="url(#nodeGrad)"
              stroke="#00d4ff"
              strokeWidth="2"
            />
            <text
              x="400"
              y="255"
              textAnchor="middle"
              fill="#00d4ff"
              fontSize="16"
              fontWeight="bold"
            >
              Transactions
            </text>

            {/* Arrow to ACH Batches */}
            <path
              d="M 400 280 L 400 320"
              stroke="#00d4ff"
              strokeWidth="2"
              markerEnd="url(#arrowhead)"
            />

            {/* ACH Batches */}
            <rect
              x="300"
              y="320"
              width="200"
              height="60"
              rx="8"
              fill="url(#nodeGrad)"
              stroke="#00d4ff"
              strokeWidth="2"
            />
            <text
              x="400"
              y="355"
              textAnchor="middle"
              fill="#00d4ff"
              fontSize="16"
              fontWeight="bold"
            >
              ACH Batches
            </text>

            {/* Arrow to Settlements */}
            <path
              d="M 400 380 L 400 420"
              stroke="#00d4ff"
              strokeWidth="2"
              markerEnd="url(#arrowhead)"
            />

            {/* Settlements */}
            <rect
              x="300"
              y="420"
              width="200"
              height="60"
              rx="8"
              fill="url(#nodeGrad)"
              stroke="#00d4ff"
              strokeWidth="2"
            />
            <text
              x="400"
              y="455"
              textAnchor="middle"
              fill="#00d4ff"
              fontSize="16"
              fontWeight="bold"
            >
              Settlements
            </text>

            {/* Arrow to Reconciliation */}
            <path
              d="M 400 480 L 400 520"
              stroke="#00d4ff"
              strokeWidth="2"
              markerEnd="url(#arrowhead)"
            />

            {/* Reconciliation */}
            <rect
              x="300"
              y="520"
              width="200"
              height="60"
              rx="8"
              fill="url(#nodeGrad)"
              stroke="#a855f7"
              strokeWidth="2"
            />
            <text
              x="400"
              y="555"
              textAnchor="middle"
              fill="#a855f7"
              fontSize="16"
              fontWeight="bold"
            >
              Reconciliation
            </text>

            {/* Clearing Accounts (Right Side) */}
            <rect
              x="560"
              y="20"
              width="220"
              height="40"
              rx="6"
              fill="#10b981"
              fillOpacity="0.1"
              stroke="#10b981"
              strokeWidth="1.5"
            />
            <text
              x="670"
              y="45"
              textAnchor="middle"
              fill="#10b981"
              fontSize="13"
            >
              Payroll Clearing
            </text>

            <rect
              x="560"
              y="70"
              width="220"
              height="40"
              rx="6"
              fill="#10b981"
              fillOpacity="0.1"
              stroke="#10b981"
              strokeWidth="1.5"
            />
            <text
              x="670"
              y="95"
              textAnchor="middle"
              fill="#10b981"
              fontSize="13"
            >
              ACH In Process
            </text>

            <rect
              x="560"
              y="120"
              width="220"
              height="40"
              rx="6"
              fill="#10b981"
              fillOpacity="0.1"
              stroke="#10b981"
              strokeWidth="1.5"
            />
            <text
              x="670"
              y="145"
              textAnchor="middle"
              fill="#10b981"
              fontSize="13"
            >
              ACH Unsettled
            </text>

            <rect
              x="560"
              y="170"
              width="220"
              height="40"
              rx="6"
              fill="#10b981"
              fillOpacity="0.1"
              stroke="#10b981"
              strokeWidth="1.5"
            />
            <text
              x="670"
              y="195"
              textAnchor="middle"
              fill="#10b981"
              fontSize="13"
            >
              Originator Settlement
            </text>

            <rect
              x="560"
              y="220"
              width="220"
              height="40"
              rx="6"
              fill="#10b981"
              fillOpacity="0.1"
              stroke="#10b981"
              strokeWidth="1.5"
            />
            <text
              x="670"
              y="245"
              textAnchor="middle"
              fill="#10b981"
              fontSize="13"
            >
              Federal Reserve Settlement
            </text>

            {/* Connections from GL Accounts */}
            <path
              d="M 500 50 L 560 40"
              stroke="#10b981"
              strokeWidth="1.5"
              strokeDasharray="4,4"
              opacity="0.5"
            />
            <path
              d="M 500 50 L 560 90"
              stroke="#10b981"
              strokeWidth="1.5"
              strokeDasharray="4,4"
              opacity="0.5"
            />
            <path
              d="M 500 50 L 560 140"
              stroke="#10b981"
              strokeWidth="1.5"
              strokeDasharray="4,4"
              opacity="0.5"
            />
            <path
              d="M 500 50 L 560 190"
              stroke="#10b981"
              strokeWidth="1.5"
              strokeDasharray="4,4"
              opacity="0.5"
            />
            <path
              d="M 500 50 L 560 240"
              stroke="#10b981"
              strokeWidth="1.5"
              strokeDasharray="4,4"
              opacity="0.5"
            />

            {/* Journal Entry Details (Left Side) */}
            <rect
              x="20"
              y="120"
              width="160"
              height="35"
              rx="6"
              fill="#f59e0b"
              fillOpacity="0.1"
              stroke="#f59e0b"
              strokeWidth="1.5"
            />
            <text
              x="100"
              y="143"
              textAnchor="middle"
              fill="#f59e0b"
              fontSize="12"
            >
              Debit Account
            </text>

            <rect
              x="20"
              y="165"
              width="160"
              height="35"
              rx="6"
              fill="#f59e0b"
              fillOpacity="0.1"
              stroke="#f59e0b"
              strokeWidth="1.5"
            />
            <text
              x="100"
              y="188"
              textAnchor="middle"
              fill="#f59e0b"
              fontSize="12"
            >
              Credit Account
            </text>

            <rect
              x="20"
              y="210"
              width="160"
              height="35"
              rx="6"
              fill="#f59e0b"
              fillOpacity="0.1"
              stroke="#f59e0b"
              strokeWidth="1.5"
            />
            <text
              x="100"
              y="233"
              textAnchor="middle"
              fill="#f59e0b"
              fontSize="12"
            >
              Amount
            </text>

            <rect
              x="20"
              y="255"
              width="160"
              height="35"
              rx="6"
              fill="#f59e0b"
              fillOpacity="0.1"
              stroke="#f59e0b"
              strokeWidth="1.5"
            />
            <text
              x="100"
              y="278"
              textAnchor="middle"
              fill="#f59e0b"
              fontSize="12"
            >
              Timestamp
            </text>

            {/* Connections from Journal Entries */}
            <path
              d="M 300 150 L 180 138"
              stroke="#f59e0b"
              strokeWidth="1.5"
              strokeDasharray="4,4"
              opacity="0.5"
            />
            <path
              d="M 300 150 L 180 183"
              stroke="#f59e0b"
              strokeWidth="1.5"
              strokeDasharray="4,4"
              opacity="0.5"
            />
            <path
              d="M 300 150 L 180 228"
              stroke="#f59e0b"
              strokeWidth="1.5"
              strokeDasharray="4,4"
              opacity="0.5"
            />
            <path
              d="M 300 150 L 180 273"
              stroke="#f59e0b"
              strokeWidth="1.5"
              strokeDasharray="4,4"
              opacity="0.5"
            />

            {/* Arrow marker */}
            <defs>
              <marker
                id="arrowhead"
                markerWidth="10"
                markerHeight="10"
                refX="9"
                refY="3"
                orient="auto"
              >
                <polygon
                  points="0 0, 10 3, 0 6"
                  fill="#00d4ff"
                />
              </marker>
            </defs>
          </svg>
        </div>

        {/* Legend */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mt-6">
          <div className="p-3 bg-cyan-500/10 border border-cyan-500/30 rounded">
            <div className="text-sm font-bold text-cyan-400 mb-1">
              Main Flow
            </div>
            <div className="text-xs text-gray-400">
              Core ledger processing pipeline
            </div>
          </div>
          <div className="p-3 bg-green-500/10 border border-green-500/30 rounded">
            <div className="text-sm font-bold text-green-400 mb-1">
              Clearing Accounts
            </div>
            <div className="text-xs text-gray-400">
              M-11 clearing account types
            </div>
          </div>
          <div className="p-3 bg-amber-500/10 border border-amber-500/30 rounded">
            <div className="text-sm font-bold text-amber-400 mb-1">
              Journal Components
            </div>
            <div className="text-xs text-gray-400">
              Entry transaction details
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

function TopologyContent() {
  return (
    <div className="space-y-6">
      <div className="p-6 bg-gray-500/5 border border-gray-500/30 rounded-lg">
        <h3 className="text-xl font-bold text-white mb-2">
          Production MCP Microservice Topology
        </h3>
        <p className="text-sm text-gray-400 mb-6">
          Real-time payment processing microservice architecture
          with Federal Reserve integration
        </p>

        <div className="bg-black/30 border border-purple-500/30 rounded-lg p-8 overflow-x-auto">
          <svg
            viewBox="0 0 900 500"
            className="w-full"
            style={{ maxWidth: "900px", margin: "0 auto" }}
          >
            <defs>
              <linearGradient
                id="serviceGrad"
                x1="0%"
                y1="0%"
                x2="100%"
                y2="100%"
              >
                <stop
                  offset="0%"
                  style={{
                    stopColor: "#a855f7",
                    stopOpacity: 0.2,
                  }}
                />
                <stop
                  offset="100%"
                  style={{
                    stopColor: "#a855f7",
                    stopOpacity: 0.1,
                  }}
                />
              </linearGradient>
              <linearGradient
                id="dbGrad"
                x1="0%"
                y1="0%"
                x2="100%"
                y2="100%"
              >
                <stop
                  offset="0%"
                  style={{
                    stopColor: "#10b981",
                    stopOpacity: 0.2,
                  }}
                />
                <stop
                  offset="100%"
                  style={{
                    stopColor: "#10b981",
                    stopOpacity: 0.1,
                  }}
                />
              </linearGradient>
            </defs>

            {/* API Gateway */}
            <rect
              x="20"
              y="200"
              width="140"
              height="70"
              rx="8"
              fill="url(#serviceGrad)"
              stroke="#a855f7"
              strokeWidth="2"
            />
            <text
              x="90"
              y="230"
              textAnchor="middle"
              fill="#a855f7"
              fontSize="14"
              fontWeight="bold"
            >
              API Gateway
            </text>
            <text
              x="90"
              y="250"
              textAnchor="middle"
              fill="#a855f7"
              fontSize="10"
            >
              Port 8443
            </text>

            {/* MCP Orchestrator */}
            <rect
              x="220"
              y="200"
              width="150"
              height="70"
              rx="8"
              fill="url(#serviceGrad)"
              stroke="#00d4ff"
              strokeWidth="2"
            />
            <text
              x="295"
              y="225"
              textAnchor="middle"
              fill="#00d4ff"
              fontSize="14"
              fontWeight="bold"
            >
              MCP
            </text>
            <text
              x="295"
              y="245"
              textAnchor="middle"
              fill="#00d4ff"
              fontSize="14"
              fontWeight="bold"
            >
              Orchestrator
            </text>

            {/* Ledger Service */}
            <rect
              x="420"
              y="50"
              width="150"
              height="70"
              rx="8"
              fill="url(#serviceGrad)"
              stroke="#00d4ff"
              strokeWidth="2"
            />
            <text
              x="495"
              y="80"
              textAnchor="middle"
              fill="#00d4ff"
              fontSize="14"
              fontWeight="bold"
            >
              Ledger Service
            </text>

            {/* ACH Batch Builder */}
            <rect
              x="420"
              y="150"
              width="150"
              height="70"
              rx="8"
              fill="url(#serviceGrad)"
              stroke="#00d4ff"
              strokeWidth="2"
            />
            <text
              x="495"
              y="175"
              textAnchor="middle"
              fill="#00d4ff"
              fontSize="14"
              fontWeight="bold"
            >
              ACH Batch
            </text>
            <text
              x="495"
              y="195"
              textAnchor="middle"
              fill="#00d4ff"
              fontSize="14"
              fontWeight="bold"
            >
              Builder
            </text>

            {/* Liquidity Engine */}
            <rect
              x="420"
              y="250"
              width="150"
              height="70"
              rx="8"
              fill="url(#serviceGrad)"
              stroke="#00d4ff"
              strokeWidth="2"
            />
            <text
              x="495"
              y="275"
              textAnchor="middle"
              fill="#00d4ff"
              fontSize="14"
              fontWeight="bold"
            >
              Liquidity
            </text>
            <text
              x="495"
              y="295"
              textAnchor="middle"
              fill="#00d4ff"
              fontSize="14"
              fontWeight="bold"
            >
              Engine
            </text>

            {/* Settlement Listener */}
            <rect
              x="420"
              y="350"
              width="150"
              height="70"
              rx="8"
              fill="url(#serviceGrad)"
              stroke="#00d4ff"
              strokeWidth="2"
            />
            <text
              x="495"
              y="375"
              textAnchor="middle"
              fill="#00d4ff"
              fontSize="14"
              fontWeight="bold"
            >
              Settlement
            </text>
            <text
              x="495"
              y="395"
              textAnchor="middle"
              fill="#00d4ff"
              fontSize="14"
              fontWeight="bold"
            >
              Listener
            </text>

            {/* Postgres Ledger DB */}
            <rect
              x="620"
              y="50"
              width="140"
              height="70"
              rx="8"
              fill="url(#dbGrad)"
              stroke="#10b981"
              strokeWidth="2"
            />
            <text
              x="690"
              y="80"
              textAnchor="middle"
              fill="#10b981"
              fontSize="13"
              fontWeight="bold"
            >
              Postgres
            </text>
            <text
              x="690"
              y="100"
              textAnchor="middle"
              fill="#10b981"
              fontSize="13"
              fontWeight="bold"
            >
              Ledger DB
            </text>

            {/* Redis Cache */}
            <rect
              x="620"
              y="250"
              width="140"
              height="70"
              rx="8"
              fill="url(#dbGrad)"
              stroke="#f59e0b"
              strokeWidth="2"
            />
            <text
              x="690"
              y="280"
              textAnchor="middle"
              fill="#f59e0b"
              fontSize="13"
              fontWeight="bold"
            >
              Redis Cache
            </text>

            {/* Secure Transmission Gateway */}
            <rect
              x="620"
              y="150"
              width="160"
              height="70"
              rx="8"
              fill="url(#serviceGrad)"
              stroke="#ef4444"
              strokeWidth="2"
            />
            <text
              x="700"
              y="175"
              textAnchor="middle"
              fill="#ef4444"
              fontSize="12"
              fontWeight="bold"
            >
              Secure
            </text>
            <text
              x="700"
              y="195"
              textAnchor="middle"
              fill="#ef4444"
              fontSize="12"
              fontWeight="bold"
            >
              Transmission
            </text>
            <text
              x="700"
              y="210"
              textAnchor="middle"
              fill="#ef4444"
              fontSize="12"
              fontWeight="bold"
            >
              Gateway
            </text>

            {/* Federal Reserve ACH */}
            <rect
              x="820"
              y="150"
              width="140"
              height="70"
              rx="8"
              fill="#ef4444"
              fillOpacity="0.2"
              stroke="#ef4444"
              strokeWidth="3"
            />
            <text
              x="890"
              y="175"
              textAnchor="middle"
              fill="#ef4444"
              fontSize="12"
              fontWeight="bold"
            >
              Federal
            </text>
            <text
              x="890"
              y="195"
              textAnchor="middle"
              fill="#ef4444"
              fontSize="12"
              fontWeight="bold"
            >
              Reserve ACH
            </text>

            {/* Connections */}
            <path
              d="M 160 235 L 220 235"
              stroke="#a855f7"
              strokeWidth="2"
              markerEnd="url(#arrow2)"
            />
            <path
              d="M 295 200 L 495 120"
              stroke="#00d4ff"
              strokeWidth="2"
              markerEnd="url(#arrow2)"
            />
            <path
              d="M 295 200 L 495 185"
              stroke="#00d4ff"
              strokeWidth="2"
              markerEnd="url(#arrow2)"
            />
            <path
              d="M 370 235 L 420 285"
              stroke="#00d4ff"
              strokeWidth="2"
              markerEnd="url(#arrow2)"
            />
            <path
              d="M 370 235 L 420 385"
              stroke="#00d4ff"
              strokeWidth="2"
              markerEnd="url(#arrow2)"
            />
            <path
              d="M 570 85 L 620 85"
              stroke="#10b981"
              strokeWidth="2"
              markerEnd="url(#arrow3)"
            />
            <path
              d="M 570 285 L 620 285"
              stroke="#f59e0b"
              strokeWidth="2"
              markerEnd="url(#arrow4)"
            />
            <path
              d="M 570 185 L 620 185"
              stroke="#ef4444"
              strokeWidth="2"
              markerEnd="url(#arrow5)"
            />
            <path
              d="M 780 185 L 820 185"
              stroke="#ef4444"
              strokeWidth="3"
              markerEnd="url(#arrow5)"
            />

            <defs>
              <marker
                id="arrow2"
                markerWidth="10"
                markerHeight="10"
                refX="9"
                refY="3"
                orient="auto"
              >
                <polygon
                  points="0 0, 10 3, 0 6"
                  fill="#00d4ff"
                />
              </marker>
              <marker
                id="arrow3"
                markerWidth="10"
                markerHeight="10"
                refX="9"
                refY="3"
                orient="auto"
              >
                <polygon
                  points="0 0, 10 3, 0 6"
                  fill="#10b981"
                />
              </marker>
              <marker
                id="arrow4"
                markerWidth="10"
                markerHeight="10"
                refX="9"
                refY="3"
                orient="auto"
              >
                <polygon
                  points="0 0, 10 3, 0 6"
                  fill="#f59e0b"
                />
              </marker>
              <marker
                id="arrow5"
                markerWidth="10"
                markerHeight="10"
                refX="9"
                refY="3"
                orient="auto"
              >
                <polygon
                  points="0 0, 10 3, 0 6"
                  fill="#ef4444"
                />
              </marker>
            </defs>
          </svg>
        </div>

        <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mt-6">
          <div className="p-3 bg-purple-500/10 border border-purple-500/30 rounded text-center">
            <div className="text-xs text-gray-500 mb-1">
              Gateway
            </div>
            <div className="text-sm font-bold text-purple-400">
              API Entry
            </div>
          </div>
          <div className="p-3 bg-cyan-500/10 border border-cyan-500/30 rounded text-center">
            <div className="text-xs text-gray-500 mb-1">
              Services
            </div>
            <div className="text-sm font-bold text-cyan-400">
              5 Microservices
            </div>
          </div>
          <div className="p-3 bg-green-500/10 border border-green-500/30 rounded text-center">
            <div className="text-xs text-gray-500 mb-1">
              Databases
            </div>
            <div className="text-sm font-bold text-green-400">
              Postgres + Redis
            </div>
          </div>
          <div className="p-3 bg-red-500/10 border border-red-500/30 rounded text-center">
            <div className="text-xs text-gray-500 mb-1">
              External
            </div>
            <div className="text-sm font-bold text-red-400">
              Fed ACH
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

function TreasuryContent() {
  return (
    <div className="space-y-6">
      <div className="p-6 bg-gray-500/5 border border-gray-500/30 rounded-lg">
        <h3 className="text-xl font-bold text-white mb-2">
          Treasury Clearing Operations Dashboard
        </h3>
        <p className="text-sm text-gray-400 mb-6">
          Real-time payment stream monitoring with ACH batch
          tracking and settlement reconciliation
        </p>

        <div className="bg-black/30 border border-green-500/30 rounded-lg p-8 overflow-x-auto">
          <svg
            viewBox="0 0 850 450"
            className="w-full"
            style={{ maxWidth: "850px", margin: "0 auto" }}
          >
            <defs>
              <linearGradient
                id="treasuryGrad"
                x1="0%"
                y1="0%"
                x2="100%"
                y2="100%"
              >
                <stop
                  offset="0%"
                  style={{
                    stopColor: "#10b981",
                    stopOpacity: 0.3,
                  }}
                />
                <stop
                  offset="100%"
                  style={{
                    stopColor: "#10b981",
                    stopOpacity: 0.1,
                  }}
                />
              </linearGradient>
            </defs>

            {/* Real-Time Payment Stream */}
            <rect
              x="30"
              y="30"
              width="180"
              height="80"
              rx="8"
              fill="url(#treasuryGrad)"
              stroke="#10b981"
              strokeWidth="2"
            />
            <text
              x="120"
              y="60"
              textAnchor="middle"
              fill="#10b981"
              fontSize="14"
              fontWeight="bold"
            >
              Real-Time
            </text>
            <text
              x="120"
              y="80"
              textAnchor="middle"
              fill="#10b981"
              fontSize="14"
              fontWeight="bold"
            >
              Payment Stream
            </text>

            {/* ACH Batch Tracker */}
            <rect
              x="30"
              y="150"
              width="180"
              height="80"
              rx="8"
              fill="url(#treasuryGrad)"
              stroke="#10b981"
              strokeWidth="2"
            />
            <text
              x="120"
              y="180"
              textAnchor="middle"
              fill="#10b981"
              fontSize="14"
              fontWeight="bold"
            >
              ACH Batch
            </text>
            <text
              x="120"
              y="200"
              textAnchor="middle"
              fill="#10b981"
              fontSize="14"
              fontWeight="bold"
            >
              Tracker
            </text>

            {/* Liquidity Risk Gauges */}
            <rect
              x="30"
              y="270"
              width="180"
              height="80"
              rx="8"
              fill="url(#treasuryGrad)"
              stroke="#10b981"
              strokeWidth="2"
            />
            <text
              x="120"
              y="300"
              textAnchor="middle"
              fill="#10b981"
              fontSize="14"
              fontWeight="bold"
            >
              Liquidity Risk
            </text>
            <text
              x="120"
              y="320"
              textAnchor="middle"
              fill="#10b981"
              fontSize="14"
              fontWeight="bold"
            >
              Gauges
            </text>

            {/* Settlement Monitor */}
            <rect
              x="250"
              y="150"
              width="180"
              height="80"
              rx="8"
              fill="url(#treasuryGrad)"
              stroke="#00d4ff"
              strokeWidth="2"
            />
            <text
              x="340"
              y="180"
              textAnchor="middle"
              fill="#00d4ff"
              fontSize="14"
              fontWeight="bold"
            >
              Settlement
            </text>
            <text
              x="340"
              y="200"
              textAnchor="middle"
              fill="#00d4ff"
              fontSize="14"
              fontWeight="bold"
            >
              Monitor
            </text>

            {/* Reconciliation Status */}
            <rect
              x="470"
              y="150"
              width="180"
              height="80"
              rx="8"
              fill="url(#treasuryGrad)"
              stroke="#a855f7"
              strokeWidth="2"
            />
            <text
              x="560"
              y="180"
              textAnchor="middle"
              fill="#a855f7"
              fontSize="14"
              fontWeight="bold"
            >
              Reconciliation
            </text>
            <text
              x="560"
              y="200"
              textAnchor="middle"
              fill="#a855f7"
              fontSize="14"
              fontWeight="bold"
            >
              Status
            </text>

            {/* Arrows */}
            <path
              d="M 120 110 L 120 150"
              stroke="#10b981"
              strokeWidth="2"
              markerEnd="url(#arrow6)"
            />
            <path
              d="M 120 230 L 120 270"
              stroke="#10b981"
              strokeWidth="2"
              markerEnd="url(#arrow6)"
            />
            <path
              d="M 210 190 L 250 190"
              stroke="#00d4ff"
              strokeWidth="2"
              markerEnd="url(#arrow7)"
            />
            <path
              d="M 430 190 L 470 190"
              stroke="#a855f7"
              strokeWidth="2"
              markerEnd="url(#arrow8)"
            />

            {/* Monitoring Metrics (Right side) */}
            <g transform="translate(680, 30)">
              <rect
                x="0"
                y="0"
                width="150"
                height="50"
                rx="6"
                fill="#ef4444"
                fillOpacity="0.1"
                stroke="#ef4444"
                strokeWidth="1.5"
              />
              <text
                x="75"
                y="25"
                textAnchor="middle"
                fill="#ef4444"
                fontSize="11"
                fontWeight="bold"
              >
                Batch Status
              </text>
              <text
                x="75"
                y="40"
                textAnchor="middle"
                fill="#ef4444"
                fontSize="10"
              >
                Real-time
              </text>
            </g>

            <g transform="translate(680, 90)">
              <rect
                x="0"
                y="0"
                width="150"
                height="50"
                rx="6"
                fill="#f59e0b"
                fillOpacity="0.1"
                stroke="#f59e0b"
                strokeWidth="1.5"
              />
              <text
                x="75"
                y="25"
                textAnchor="middle"
                fill="#f59e0b"
                fontSize="11"
                fontWeight="bold"
              >
                Risk Level
              </text>
              <text
                x="75"
                y="40"
                textAnchor="middle"
                fill="#f59e0b"
                fontSize="10"
              >
                Low (2.3%)
              </text>
            </g>

            <g transform="translate(680, 150)">
              <rect
                x="0"
                y="0"
                width="150"
                height="50"
                rx="6"
                fill="#10b981"
                fillOpacity="0.1"
                stroke="#10b981"
                strokeWidth="1.5"
              />
              <text
                x="75"
                y="25"
                textAnchor="middle"
                fill="#10b981"
                fontSize="11"
                fontWeight="bold"
              >
                Settlement
              </text>
              <text
                x="75"
                y="40"
                textAnchor="middle"
                fill="#10b981"
                fontSize="10"
              >
                On Schedule
              </text>
            </g>

            <g transform="translate(680, 210)">
              <rect
                x="0"
                y="0"
                width="150"
                height="50"
                rx="6"
                fill="#00d4ff"
                fillOpacity="0.1"
                stroke="#00d4ff"
                strokeWidth="1.5"
              />
              <text
                x="75"
                y="25"
                textAnchor="middle"
                fill="#00d4ff"
                fontSize="11"
                fontWeight="bold"
              >
                Reconciliation
              </text>
              <text
                x="75"
                y="40"
                textAnchor="middle"
                fill="#00d4ff"
                fontSize="10"
              >
                99.98% Match
              </text>
            </g>

            <defs>
              <marker
                id="arrow6"
                markerWidth="10"
                markerHeight="10"
                refX="9"
                refY="3"
                orient="auto"
              >
                <polygon
                  points="0 0, 10 3, 0 6"
                  fill="#10b981"
                />
              </marker>
              <marker
                id="arrow7"
                markerWidth="10"
                markerHeight="10"
                refX="9"
                refY="3"
                orient="auto"
              >
                <polygon
                  points="0 0, 10 3, 0 6"
                  fill="#00d4ff"
                />
              </marker>
              <marker
                id="arrow8"
                markerWidth="10"
                markerHeight="10"
                refX="9"
                refY="3"
                orient="auto"
              >
                <polygon
                  points="0 0, 10 3, 0 6"
                  fill="#a855f7"
                />
              </marker>
            </defs>
          </svg>
        </div>

        <div className="grid grid-cols-2 md:grid-cols-5 gap-3 mt-6">
          <div className="p-3 bg-green-500/10 border border-green-500/30 rounded text-center">
            <div className="text-2xl font-bold text-green-400">
              $127M
            </div>
            <div className="text-xs text-gray-500">
              Daily Volume
            </div>
          </div>
          <div className="p-3 bg-cyan-500/10 border border-cyan-500/30 rounded text-center">
            <div className="text-2xl font-bold text-cyan-400">
              1,847
            </div>
            <div className="text-xs text-gray-500">
              Transactions
            </div>
          </div>
          <div className="p-3 bg-purple-500/10 border border-purple-500/30 rounded text-center">
            <div className="text-2xl font-bold text-purple-400">
              99.98%
            </div>
            <div className="text-xs text-gray-500">
              Reconciled
            </div>
          </div>
          <div className="p-3 bg-amber-500/10 border border-amber-500/30 rounded text-center">
            <div className="text-2xl font-bold text-amber-400">
              2.3%
            </div>
            <div className="text-xs text-gray-500">
              Risk Level
            </div>
          </div>
          <div className="p-3 bg-red-500/10 border border-red-500/30 rounded text-center">
            <div className="text-2xl font-bold text-red-400">
              0
            </div>
            <div className="text-xs text-gray-500">
              Failed Batches
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}