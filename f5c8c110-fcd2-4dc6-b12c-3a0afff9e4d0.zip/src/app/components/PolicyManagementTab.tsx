import { useState } from "react";
import {
  Shield,
  Lock,
  FileText,
  CheckCircle2,
  AlertTriangle,
  Users,
  HardDrive,
  Eye,
  Download,
  Filter,
  Search,
  ChevronRight,
  Settings,
} from "lucide-react";

interface TabProps {
  secureMode: boolean;
  onAuditLog: (action: string) => void;
}

interface PolicyRequirement {
  id: string;
  category: string;
  type: "Basic" | "Derived";
  nistId: string;
  code: string;
  requirement: string;
  guidance: string;
  complianceStatus:
    | "compliant"
    | "partial"
    | "non-compliant"
    | "not-applicable";
}

const policyRequirements: PolicyRequirement[] = [
  {
    id: "mp-1",
    category: "Media Protection",
    type: "Basic",
    nistId: "3.8.1",
    code: "03.08.01",
    requirement:
      "Protect (i.e., physically control and securely store) system media containing CUI, both paper and digital.",
    guidance:
      "System media includes digital and non-digital media. Digital media includes diskettes, magnetic tapes, external and removable hard disk drives, flash drives, compact disks, and digital video disks. Protecting digital media includes limiting access to design specifications stored on compact disks or flash drives in the media library.",
    complianceStatus: "compliant",
  },
  {
    id: "mp-2",
    category: "Media Protection",
    type: "Basic",
    nistId: "3.8.2",
    code: "03.08.02",
    requirement:
      "Limit access to CUI on system media to authorized users",
    guidance:
      "Access can be limited by physically controlling system media and secure storage areas. Physically controlling system media includes conducting inventories, ensuring procedures are in place to allow individuals to check out and return system media to the media library.",
    complianceStatus: "compliant",
  },
  {
    id: "mp-3",
    category: "Media Protection",
    type: "Basic",
    nistId: "3.8.3",
    code: "03.08.03",
    requirement:
      "Sanitize or destroy system media containing CUI before disposal or release for reuse.",
    guidance:
      "Sanitization techniques, including clearing, purging, cryptographic erase, and destruction, prevent the disclosure of information to unauthorized individuals when such media is released for reuse or disposal.",
    complianceStatus: "compliant",
  },
  {
    id: "mp-4",
    category: "Media Protection",
    type: "Derived",
    nistId: "3.8.4",
    code: "03.08.04",
    requirement:
      "Mark media with necessary CUI markings and distribution limitations.",
    guidance:
      "System media includes digital and non-digital media. Marking of system media reflects applicable federal laws, Executive Orders, directives, policies, and regulations.",
    complianceStatus: "compliant",
  },
  {
    id: "mp-5",
    category: "Media Protection",
    type: "Derived",
    nistId: "3.8.5",
    code: "03.08.05",
    requirement:
      "Control access to media containing CUI and maintain accountability for media during transport outside of controlled areas.",
    guidance:
      "Controls to maintain accountability for media during transport include locked containers and cryptography. Cryptographic mechanisms can provide confidentiality and integrity protections.",
    complianceStatus: "compliant",
  },
  {
    id: "mp-6",
    category: "Media Protection",
    type: "Derived",
    nistId: "3.8.6",
    code: "03.08.06",
    requirement:
      "Implement cryptographic mechanisms to protect the confidentiality of CUI stored on digital media during transport.",
    guidance:
      "This requirement applies to portable storage devices (e.g., USB memory sticks, digital video disks, compact disks, external or removable hard disk drives).",
    complianceStatus: "compliant",
  },
  {
    id: "mp-7",
    category: "Media Protection",
    type: "Derived",
    nistId: "3.8.7",
    code: "03.08.07",
    requirement:
      "Control the use of removable media on system components.",
    guidance:
      "Organizations can employ technical and nontechnical controls (e.g., policies, procedures, and rules of behavior) to control the use of system media. Organizations may control the use of portable storage devices to only approved devices.",
    complianceStatus: "compliant",
  },
  {
    id: "mp-8",
    category: "Media Protection",
    type: "Derived",
    nistId: "3.8.8",
    code: "03.08.08",
    requirement:
      "Prohibit the use of portable storage devices when such devices have no identifiable owner.",
    guidance:
      "Requiring identifiable owners (e.g., individuals, organizations, or projects) for portable storage devices reduces the overall risk of using such technologies.",
    complianceStatus: "compliant",
  },
  {
    id: "mp-9",
    category: "Media Protection",
    type: "Derived",
    nistId: "3.8.9",
    code: "03.08.09",
    requirement:
      "Protect the confidentiality of backup CUI at storage locations.",
    guidance:
      "Organizations can employ cryptographic mechanisms or alternative physical controls to protect the confidentiality of backup information at designated storage locations.",
    complianceStatus: "compliant",
  },
  {
    id: "ps-1",
    category: "Personnel Security",
    type: "Basic",
    nistId: "3.9.1",
    code: "03.09.01",
    requirement:
      "Screen individuals prior to authorizing access to organizational systems containing CUI.",
    guidance:
      "Personnel security screening activities involve evaluation of conduct, integrity, judgment, loyalty, reliability, and stability prior to authorizing access to organizational systems containing CUI.",
    complianceStatus: "compliant",
  },
  {
    id: "ps-2",
    category: "Personnel Security",
    type: "Basic",
    nistId: "3.9.2",
    code: "03.09.02",
    requirement:
      "Ensure that organizational systems containing CUI are protected during and after personnel actions such as terminations and transfers.",
    guidance:
      "Protecting CUI during and after personnel actions may include returning system-related property and conducting exit interviews. System-related property includes hardware authentication tokens, identification cards, and building passes.",
    complianceStatus: "compliant",
  },
  {
    id: "pp-1",
    category: "Physical Protection",
    type: "Basic",
    nistId: "3.10.1",
    code: "03.10.01",
    requirement:
      "Limit physical access to organizational systems, equipment, and the respective operating environments to authorized individuals.",
    guidance:
      "This requirement applies to employees and visitors. Authorized individuals have credentials that include badges, identification cards, and smart cards.",
    complianceStatus: "compliant",
  },
  {
    id: "pp-2",
    category: "Physical Protection",
    type: "Basic",
    nistId: "3.10.2",
    code: "03.10.02",
    requirement:
      "Protect and monitor the physical facility and support infrastructure for organizational systems.",
    guidance:
      "Monitoring of physical access includes publicly accessible areas within organizational facilities. This can be accomplished by the employment of guards, sensor devices, or video surveillance equipment.",
    complianceStatus: "compliant",
  },
  {
    id: "pp-3",
    category: "Physical Protection",
    type: "Derived",
    nistId: "3.10.3",
    code: "03.10.03",
    requirement:
      "Escort visitors and monitor visitor activity.",
    guidance:
      "Individuals with permanent physical access authorization credentials are not considered visitors. Audit logs can be used to monitor visitor activity.",
    complianceStatus: "compliant",
  },
  {
    id: "pp-4",
    category: "Physical Protection",
    type: "Derived",
    nistId: "3.10.4",
    code: "03.10.04",
    requirement: "Maintain audit logs of physical access.",
    guidance:
      "Audit logs can be procedural, automated, or combination thereof. Physical access points can include facility access points or interior access points to systems requiring supplemental access controls.",
    complianceStatus: "compliant",
  },
  {
    id: "ra-1",
    category: "Risk Assessment",
    type: "Basic",
    nistId: "3.11.1",
    code: "03.11.01",
    requirement:
      "Periodically assess the risk to organizational operations, assets, and individuals.",
    guidance:
      "Risk assessments consider threats, vulnerabilities, likelihood, and impact to organizational operations, organizational assets, and individuals based on the operation and use of organizational systems.",
    complianceStatus: "compliant",
  },
  {
    id: "ra-2",
    category: "Risk Assessment",
    type: "Derived",
    nistId: "3.11.2",
    code: "03.11.02",
    requirement:
      "Scan for vulnerabilities in organizational systems and applications periodically and when new vulnerabilities are identified.",
    guidance:
      "Vulnerability scanning includes scanning for patch levels, functions, ports, protocols, and services that should not be accessible to users or devices.",
    complianceStatus: "compliant",
  },
  {
    id: "ra-3",
    category: "Risk Assessment",
    type: "Derived",
    nistId: "3.11.3",
    code: "03.11.03",
    requirement:
      "Remediate vulnerabilities in accordance with risk assessments.",
    guidance:
      "Consideration of risk influences the prioritization of remediation efforts and the level of effort to be expended in the remediation for specific vulnerabilities.",
    complianceStatus: "compliant",
  },
  {
    id: "mt-1",
    category: "Maintenance",
    type: "Derived",
    nistId: "3.7.4",
    code: "03.07.04",
    requirement:
      "Check media containing diagnostic and test programs for malicious code before use.",
    guidance:
      "If media containing maintenance diagnostic and test programs contain malicious code, the incident is handled consistent with incident handling policies and procedures.",
    complianceStatus: "compliant",
  },
  {
    id: "mt-2",
    category: "Maintenance",
    type: "Derived",
    nistId: "3.7.5",
    code: "03.07.05",
    requirement:
      "Require multifactor authentication to establish nonlocal maintenance sessions via external network connections.",
    guidance:
      "Nonlocal maintenance activities are conducted by individuals communicating through an external network. Authentication techniques reflect network access requirements.",
    complianceStatus: "compliant",
  },
];

export function PolicyManagementTab({
  secureMode,
  onAuditLog,
}: TabProps) {
  const [selectedCategory, setSelectedCategory] =
    useState<string>("all");
  const [searchTerm, setSearchTerm] = useState("");
  const [selectedPolicy, setSelectedPolicy] =
    useState<PolicyRequirement | null>(null);

  const categories = [
    "all",
    "Media Protection",
    "Personnel Security",
    "Physical Protection",
    "Risk Assessment",
    "Maintenance",
  ];

  const filteredPolicies = policyRequirements.filter(
    (policy) => {
      const matchesCategory =
        selectedCategory === "all" ||
        policy.category === selectedCategory;
      const matchesSearch =
        searchTerm === "" ||
        policy.requirement
          .toLowerCase()
          .includes(searchTerm.toLowerCase()) ||
        policy.nistId
          .toLowerCase()
          .includes(searchTerm.toLowerCase()) ||
        policy.code
          .toLowerCase()
          .includes(searchTerm.toLowerCase());
      return matchesCategory && matchesSearch;
    },
  );

  const getComplianceColor = (status: string) => {
    switch (status) {
      case "compliant":
        return "text-green-400 bg-green-400/10 border-green-400/30";
      case "partial":
        return "text-yellow-400 bg-yellow-400/10 border-yellow-400/30";
      case "non-compliant":
        return "text-red-400 bg-red-400/10 border-red-400/30";
      case "not-applicable":
        return "text-gray-400 bg-gray-400/10 border-gray-400/30";
      default:
        return "text-gray-400 bg-gray-400/10 border-gray-400/30";
    }
  };

  const getCategoryIcon = (category: string) => {
    switch (category) {
      case "Media Protection":
        return HardDrive;
      case "Personnel Security":
        return Users;
      case "Physical Protection":
        return Lock;
      case "Risk Assessment":
        return AlertTriangle;
      case "Maintenance":
        return Settings;
      default:
        return Shield;
    }
  };

  const complianceStats = {
    total: policyRequirements.length,
    compliant: policyRequirements.filter(
      (p) => p.complianceStatus === "compliant",
    ).length,
    partial: policyRequirements.filter(
      (p) => p.complianceStatus === "partial",
    ).length,
    nonCompliant: policyRequirements.filter(
      (p) => p.complianceStatus === "non-compliant",
    ).length,
  };

  const compliancePercentage = (
    (complianceStats.compliant / complianceStats.total) *
    100
  ).toFixed(1);

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="bg-gradient-to-br from-[#0f1525] to-[#0a0e1a] border border-cyan-500/30 rounded-lg p-6">
        <div className="flex items-center justify-between mb-4">
          <div className="flex items-center gap-3">
            <Shield className="w-8 h-8 text-cyan-400" />
            <div>
              <h2 className="text-2xl font-bold tracking-wide uppercase">
                Policy Management
              </h2>
              <p className="text-sm text-cyan-400/70 font-mono">
                NIST 800-171 Compliance Framework
              </p>
            </div>
          </div>
          <div className="flex items-center gap-3">
            <button
              onClick={() =>
                onAuditLog("Policy export initiated")
              }
              className="px-4 py-2 bg-cyan-400/10 border border-cyan-400/30 rounded hover:bg-cyan-400/20 transition-all"
            >
              <div className="flex items-center gap-2">
                <Download className="w-4 h-4 text-cyan-400" />
                <span className="text-sm text-cyan-400 font-semibold">
                  EXPORT
                </span>
              </div>
            </button>
          </div>
        </div>

        {/* Compliance Statistics */}
        <div className="grid grid-cols-5 gap-4">
          <div className="bg-cyan-400/5 border border-cyan-400/20 rounded p-3">
            <div className="text-xs text-cyan-400/70 mb-1">
              TOTAL POLICIES
            </div>
            <div className="text-2xl font-bold text-cyan-400">
              {complianceStats.total}
            </div>
          </div>
          <div className="bg-green-400/5 border border-green-400/20 rounded p-3">
            <div className="text-xs text-green-400/70 mb-1">
              COMPLIANT
            </div>
            <div className="text-2xl font-bold text-green-400">
              {complianceStats.compliant}
            </div>
          </div>
          <div className="bg-yellow-400/5 border border-yellow-400/20 rounded p-3">
            <div className="text-xs text-yellow-400/70 mb-1">
              PARTIAL
            </div>
            <div className="text-2xl font-bold text-yellow-400">
              {complianceStats.partial}
            </div>
          </div>
          <div className="bg-red-400/5 border border-red-400/20 rounded p-3">
            <div className="text-xs text-red-400/70 mb-1">
              NON-COMPLIANT
            </div>
            <div className="text-2xl font-bold text-red-400">
              {complianceStats.nonCompliant}
            </div>
          </div>
          <div className="bg-cyan-400/5 border border-cyan-400/20 rounded p-3">
            <div className="text-xs text-cyan-400/70 mb-1">
              COMPLIANCE %
            </div>
            <div className="text-2xl font-bold text-green-400">
              {compliancePercentage}%
            </div>
          </div>
        </div>
      </div>

      <div className="grid grid-cols-3 gap-6">
        {/* Left Panel - Category Filter & Search */}
        <div className="col-span-1 space-y-6">
          {/* Search */}
          <div className="bg-gradient-to-br from-[#0f1525] to-[#0a0e1a] border border-cyan-500/30 rounded-lg p-5">
            <h3 className="text-lg font-bold text-cyan-400 mb-4 flex items-center gap-2">
              <Search className="w-5 h-5" />
              SEARCH
            </h3>
            <input
              type="text"
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              placeholder="Search policies..."
              className="w-full bg-[#0a0e1a] border border-cyan-500/30 rounded px-3 py-2 text-sm text-white focus:outline-none focus:border-cyan-400"
            />
          </div>

          {/* Category Filter */}
          <div className="bg-gradient-to-br from-[#0f1525] to-[#0a0e1a] border border-cyan-500/30 rounded-lg p-5">
            <h3 className="text-lg font-bold text-cyan-400 mb-4 flex items-center gap-2">
              <Filter className="w-5 h-5" />
              CATEGORIES
            </h3>
            <div className="space-y-2">
              {categories.map((category) => {
                const Icon = getCategoryIcon(category);
                const count =
                  category === "all"
                    ? policyRequirements.length
                    : policyRequirements.filter(
                        (p) => p.category === category,
                      ).length;

                return (
                  <button
                    key={category}
                    onClick={() => {
                      setSelectedCategory(category);
                      onAuditLog(
                        `Filtered policies by category: ${category}`,
                      );
                    }}
                    className={`w-full flex items-center justify-between px-3 py-2 rounded transition-all ${
                      selectedCategory === category
                        ? "bg-cyan-400/20 border border-cyan-400/50 text-cyan-400"
                        : "bg-cyan-400/5 border border-cyan-400/10 text-gray-400 hover:bg-cyan-400/10"
                    }`}
                  >
                    <div className="flex items-center gap-2">
                      <Icon className="w-4 h-4" />
                      <span className="text-sm uppercase">
                        {category}
                      </span>
                    </div>
                    <span className="text-xs font-mono bg-cyan-400/10 px-2 py-0.5 rounded">
                      {count}
                    </span>
                  </button>
                );
              })}
            </div>
          </div>
        </div>

        {/* Middle Panel - Policy List */}
        <div className="col-span-1">
          <div className="bg-gradient-to-br from-[#0f1525] to-[#0a0e1a] border border-cyan-500/30 rounded-lg p-5">
            <h3 className="text-lg font-bold text-cyan-400 mb-4 flex items-center gap-2">
              <FileText className="w-5 h-5" />
              POLICIES ({filteredPolicies.length})
            </h3>
            <div className="space-y-2 max-h-[600px] overflow-y-auto">
              {filteredPolicies.map((policy) => {
                const Icon = getCategoryIcon(policy.category);
                return (
                  <button
                    key={policy.id}
                    onClick={() => {
                      setSelectedPolicy(policy);
                      onAuditLog(
                        `Viewed policy: ${policy.nistId} - ${policy.code}`,
                      );
                    }}
                    className={`w-full text-left border rounded-lg p-3 transition-all ${
                      selectedPolicy?.id === policy.id
                        ? "bg-cyan-400/20 border-cyan-400/50"
                        : "bg-cyan-400/5 border-cyan-400/10 hover:bg-cyan-400/10"
                    }`}
                  >
                    <div className="flex items-start justify-between mb-2">
                      <div className="flex items-center gap-2">
                        <Icon className="w-4 h-4 text-cyan-400" />
                        <span className="text-sm font-mono font-bold text-cyan-400">
                          {policy.nistId}
                        </span>
                      </div>
                      <div
                        className={`px-2 py-0.5 rounded text-xs border ${getComplianceColor(policy.complianceStatus)}`}
                      >
                        {policy.complianceStatus.toUpperCase()}
                      </div>
                    </div>
                    <div className="text-xs text-gray-400 mb-1 font-mono">
                      {policy.code}
                    </div>
                    <div className="text-sm text-gray-300 line-clamp-2">
                      {policy.requirement}
                    </div>
                    <div className="flex items-center justify-between mt-2">
                      <span className="text-xs text-cyan-400/70">
                        {policy.category}
                      </span>
                      <span
                        className={`text-xs px-2 py-0.5 rounded ${
                          policy.type === "Basic"
                            ? "bg-blue-400/20 text-blue-400"
                            : "bg-purple-400/20 text-purple-400"
                        }`}
                      >
                        {policy.type}
                      </span>
                    </div>
                  </button>
                );
              })}
            </div>
          </div>
        </div>

        {/* Right Panel - Policy Details */}
        <div className="col-span-1">
          <div className="bg-gradient-to-br from-[#0f1525] to-[#0a0e1a] border border-cyan-500/30 rounded-lg p-5 h-full">
            {selectedPolicy ? (
              <>
                <div className="flex items-center justify-between mb-4">
                  <h3 className="text-lg font-bold text-cyan-400 flex items-center gap-2">
                    <Eye className="w-5 h-5" />
                    POLICY DETAILS
                  </h3>
                  <div
                    className={`px-3 py-1 rounded border ${getComplianceColor(selectedPolicy.complianceStatus)}`}
                  >
                    {selectedPolicy.complianceStatus.toUpperCase()}
                  </div>
                </div>

                <div className="space-y-4">
                  <div className="bg-cyan-400/5 border border-cyan-400/20 rounded p-3">
                    <div className="text-xs text-cyan-400/70 mb-1">
                      NIST ID
                    </div>
                    <div className="text-lg font-bold font-mono text-cyan-400">
                      {selectedPolicy.nistId}
                    </div>
                  </div>

                  <div className="bg-cyan-400/5 border border-cyan-400/20 rounded p-3">
                    <div className="text-xs text-cyan-400/70 mb-1">
                      CODE
                    </div>
                    <div className="text-lg font-bold font-mono text-cyan-400">
                      {selectedPolicy.code}
                    </div>
                  </div>

                  <div className="bg-cyan-400/5 border border-cyan-400/20 rounded p-3">
                    <div className="text-xs text-cyan-400/70 mb-1">
                      CATEGORY
                    </div>
                    <div className="text-sm font-semibold text-white">
                      {selectedPolicy.category}
                    </div>
                  </div>

                  <div className="bg-cyan-400/5 border border-cyan-400/20 rounded p-3">
                    <div className="text-xs text-cyan-400/70 mb-1">
                      TYPE
                    </div>
                    <div
                      className={`inline-block px-2 py-1 rounded text-sm ${
                        selectedPolicy.type === "Basic"
                          ? "bg-blue-400/20 text-blue-400"
                          : "bg-purple-400/20 text-purple-400"
                      }`}
                    >
                      {selectedPolicy.type}
                    </div>
                  </div>

                  <div className="bg-cyan-400/5 border border-cyan-400/20 rounded p-3">
                    <div className="text-xs text-cyan-400/70 mb-2">
                      REQUIREMENT
                    </div>
                    <div className="text-sm text-white leading-relaxed">
                      {selectedPolicy.requirement}
                    </div>
                  </div>

                  <div className="bg-cyan-400/5 border border-cyan-400/20 rounded p-3">
                    <div className="text-xs text-cyan-400/70 mb-2">
                      GUIDANCE
                    </div>
                    <div className="text-sm text-gray-300 leading-relaxed">
                      {selectedPolicy.guidance}
                    </div>
                  </div>

                  <div className="flex gap-2">
                    <button
                      onClick={() =>
                        onAuditLog(
                          `Policy evidence uploaded: ${selectedPolicy.nistId}`,
                        )
                      }
                      className="flex-1 px-3 py-2 bg-green-400/10 border border-green-400/30 rounded hover:bg-green-400/20 transition-all"
                    >
                      <div className="flex items-center justify-center gap-2">
                        <CheckCircle2 className="w-4 h-4 text-green-400" />
                        <span className="text-sm text-green-400 font-semibold">
                          VERIFY
                        </span>
                      </div>
                    </button>
                    <button
                      onClick={() =>
                        onAuditLog(
                          `Policy documentation downloaded: ${selectedPolicy.nistId}`,
                        )
                      }
                      className="flex-1 px-3 py-2 bg-cyan-400/10 border border-cyan-400/30 rounded hover:bg-cyan-400/20 transition-all"
                    >
                      <div className="flex items-center justify-center gap-2">
                        <Download className="w-4 h-4 text-cyan-400" />
                        <span className="text-sm text-cyan-400 font-semibold">
                          EXPORT
                        </span>
                      </div>
                    </button>
                  </div>
                </div>
              </>
            ) : (
              <div className="h-full flex items-center justify-center text-gray-500">
                <div className="text-center">
                  <Shield className="w-16 h-16 mx-auto mb-4 opacity-20" />
                  <p className="text-sm">
                    Select a policy to view details
                  </p>
                </div>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}