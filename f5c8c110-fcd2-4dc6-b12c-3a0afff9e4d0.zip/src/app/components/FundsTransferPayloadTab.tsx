import { useState } from "react";
import {
  Send,
  Hash,
  Shield,
  AlertTriangle,
  CheckCircle2,
  Cpu,
  Activity,
  Database,
  Copy,
  Download,
  RefreshCw,
} from "lucide-react";

interface TabProps {
  secureMode: boolean;
  onAuditLog: (action: string) => void;
}

interface PayloadData {
  // Amount
  currency: string;
  units: string;
  nanos: string;
  // Originator
  origInst: string;
  origRtn: string;
  origAcctToken: string;
  // Beneficiary
  benInst: string;
  benRtn: string;
  benAcctToken: string;
  // Metadata
  source: string;
  idempotencyKey: string;
  hash: string;
  signature: string;
  // Payload Details
  type: string;
  version: string;
  txnId: string;
  ledgerEffect: string;
  eventTs: string;
  ingestTs: string;
}

interface MLNodeMetrics {
  nodeId: string;
  cpuLoad: number;
  latencyMs: number;
  queueDepth: number;
  txnRate: number;
  status: "optimal" | "warning" | "critical";
}

export function FundsTransferPayloadTab({
  secureMode,
  onAuditLog,
}: TabProps) {
  const [payloadData, setPayloadData] = useState<PayloadData>({
    currency: "USD",
    units: "105449",
    nanos: "0",
    origInst: "origInst",
    origRtn: "origRtn",
    origAcctToken: "tok_orig_92af...",
    benInst: "benInst",
    benRtn: "benRtn",
    benAcctToken: "tok_ben_77bc...",
    source: "api-gateway",
    idempotencyKey: "idem_7caa...",
    hash: "sha256:abc123...",
    signature: "ed25519:signature...",
    type: "FUNDS_TRANSFER",
    version: "1.0",
    txnId: "txn_9f3a88c2",
    ledgerEffect: "DEBIT_CREDIT",
    eventTs: new Date().toISOString(),
    ingestTs: new Date().toISOString(),
  });

  const [mlNodes, setMlNodes] = useState<MLNodeMetrics[]>([
    {
      nodeId: "cluster-04-node-1",
      cpuLoad: 0.87,
      latencyMs: 145,
      queueDepth: 980,
      txnRate: 2800,
      status: "warning",
    },
    {
      nodeId: "cluster-04-node-2",
      cpuLoad: 0.94,
      latencyMs: 182,
      queueDepth: 1240,
      txnRate: 3200,
      status: "critical",
    },
    {
      nodeId: "cluster-04-node-3",
      cpuLoad: 0.91,
      latencyMs: 168,
      queueDepth: 1100,
      txnRate: 3050,
      status: "critical",
    },
    {
      nodeId: "cluster-04-node-4",
      cpuLoad: 0.56,
      latencyMs: 98,
      queueDepth: 420,
      txnRate: 1900,
      status: "optimal",
    },
    {
      nodeId: "cluster-04-node-5",
      cpuLoad: 0.62,
      latencyMs: 112,
      queueDepth: 580,
      txnRate: 2100,
      status: "optimal",
    },
  ]);

  const [generatedPayload, setGeneratedPayload] =
    useState<string>("");
  const [shardingEnabled, setShardingEnabled] = useState(false);

  const handleInputChange = (
    field: keyof PayloadData,
    value: string,
  ) => {
    setPayloadData((prev) => ({ ...prev, [field]: value }));
  };

  const generatePayload = () => {
    const payload = {
      type: payloadData.type,
      version: payloadData.version,
      txnId: payloadData.txnId,
      ledgerEffect: payloadData.ledgerEffect,
      eventTs: payloadData.eventTs,
      ingestTs: payloadData.ingestTs,
      amount: {
        currency: payloadData.currency,
        units: payloadData.units,
        nanos: parseInt(payloadData.nanos),
      },
      originator: {
        institution: payloadData.origInst,
        routingNumber: payloadData.origRtn,
        accountToken: payloadData.origAcctToken,
      },
      beneficiary: {
        institution: payloadData.benInst,
        routingNumber: payloadData.benRtn,
        accountToken: payloadData.benAcctToken,
      },
      metadata: {
        source: payloadData.source,
        idempotencyKey: payloadData.idempotencyKey,
        hash: payloadData.hash,
        signature: payloadData.signature,
      },
    };

    const jsonPayload = JSON.stringify(payload, null, 2);
    setGeneratedPayload(jsonPayload);
    onAuditLog(
      `Generated FUNDS_TRANSFER payload: ${payloadData.txnId} - Amount: ${payloadData.currency} ${payloadData.units}`,
    );
  };

  const copyPayload = () => {
    navigator.clipboard.writeText(generatedPayload);
    onAuditLog("Payload copied to clipboard");
  };

  const downloadPayload = () => {
    const blob = new Blob([generatedPayload], {
      type: "application/json",
    });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = `payload_${payloadData.txnId}.json`;
    a.click();
    onAuditLog(
      `Payload downloaded: payload_${payloadData.txnId}.json`,
    );
  };

  const toggleSharding = () => {
    const newState = !shardingEnabled;
    setShardingEnabled(newState);
    onAuditLog(
      `Horizontal sharding ${newState ? "ENABLED" : "DISABLED"} - Consistent hashing active`,
    );

    if (newState) {
      //  load redistribution
      setTimeout(() => {
        setMlNodes((prev) =>
          prev.map((node) => {
            if (node.cpuLoad > 0.85) {
              return {
                ...node,
                cpuLoad: node.cpuLoad * 0.6,
                latencyMs: Math.floor(node.latencyMs * 0.6),
                queueDepth: Math.floor(node.queueDepth * 0.5),
                status: "optimal",
              };
            }
            return node;
          }),
        );
      }, 1000);
    }
  };

  const getNodeStatusColor = (status: string) => {
    switch (status) {
      case "optimal":
        return "text-green-400 bg-green-400/10 border-green-400/30";
      case "warning":
        return "text-yellow-400 bg-yellow-400/10 border-yellow-400/30";
      case "critical":
        return "text-red-400 bg-red-400/10 border-red-400/30";
      default:
        return "text-gray-400 bg-gray-400/10 border-gray-400/30";
    }
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="bg-gradient-to-br from-[#0f1525] to-[#0a0e1a] border border-cyan-500/30 rounded-lg p-6">
        <div className="flex items-center justify-between mb-4">
          <div className="flex items-center gap-3">
            <Send className="w-8 h-8 text-cyan-400" />
            <div>
              <h2 className="text-2xl font-bold tracking-wide uppercase">
                Funds Transfer Payload Builder
              </h2>
              <p className="text-sm text-cyan-400/70 font-mono">
                Production Payload Construction Engine v1.0
              </p>
            </div>
          </div>
          <div className="flex items-center gap-3">
            <button
              onClick={toggleSharding}
              className={`px-4 py-2 rounded border transition-all ${
                shardingEnabled
                  ? "bg-green-400/20 border-green-400/50 text-green-400"
                  : "bg-cyan-400/10 border-cyan-400/30 text-cyan-400 hover:bg-cyan-400/20"
              }`}
            >
              <div className="flex items-center gap-2">
                <Database className="w-4 h-4" />
                <span className="text-sm font-semibold">
                  {shardingEnabled
                    ? "SHARDING ACTIVE"
                    : "ENABLE SHARDING"}
                </span>
              </div>
            </button>
          </div>
        </div>

        <div className="grid grid-cols-4 gap-4 mt-4">
          <div className="bg-cyan-400/5 border border-cyan-400/20 rounded p-3">
            <div className="text-xs text-cyan-400/70 mb-1">
              PCI-DSS
            </div>
            <div className="text-sm font-semibold text-cyan-400">
              TOKENIZED
            </div>
          </div>
          <div className="bg-cyan-400/5 border border-cyan-400/20 rounded p-3">
            <div className="text-xs text-cyan-400/70 mb-1">
              SIGNATURE
            </div>
            <div className="text-sm font-semibold text-cyan-400">
              ED25519
            </div>
          </div>
          <div className="bg-cyan-400/5 border border-cyan-400/20 rounded p-3">
            <div className="text-xs text-cyan-400/70 mb-1">
              HASH
            </div>
            <div className="text-sm font-semibold text-cyan-400">
              SHA-256
            </div>
          </div>
          <div className="bg-cyan-400/5 border border-cyan-400/20 rounded p-3">
            <div className="text-xs text-cyan-400/70 mb-1">
              SEMANTICS
            </div>
            <div className="text-sm font-semibold text-cyan-400">
              IDEMPOTENT
            </div>
          </div>
        </div>
      </div>

      <div className="grid grid-cols-2 gap-6">
        {/* Payload Builder Form */}
        <div className="space-y-6">
          {/* Amount Section */}
          <div className="bg-gradient-to-br from-[#0f1525] to-[#0a0e1a] border border-cyan-500/30 rounded-lg p-5">
            <h3 className="text-lg font-bold text-cyan-400 mb-4 flex items-center gap-2">
              <Hash className="w-5 h-5" />
              AMOUNT
            </h3>
            <div className="space-y-3">
              <div>
                <label className="block text-xs text-cyan-400/70 mb-1 font-mono">
                  Currency
                </label>
                <input
                  type="text"
                  value={payloadData.currency}
                  onChange={(e) =>
                    handleInputChange(
                      "currency",
                      e.target.value,
                    )
                  }
                  className="w-full bg-[#0a0e1a] border border-cyan-500/30 rounded px-3 py-2 text-sm text-white font-mono focus:outline-none focus:border-cyan-400"
                />
              </div>
              <div>
                <label className="block text-xs text-cyan-400/70 mb-1 font-mono">
                  Units
                </label>
                <input
                  type="text"
                  value={payloadData.units}
                  onChange={(e) =>
                    handleInputChange("units", e.target.value)
                  }
                  className="w-full bg-[#0a0e1a] border border-cyan-500/30 rounded px-3 py-2 text-sm text-white font-mono focus:outline-none focus:border-cyan-400"
                />
              </div>
              <div>
                <label className="block text-xs text-cyan-400/70 mb-1 font-mono">
                  Nanos
                </label>
                <input
                  type="text"
                  value={payloadData.nanos}
                  onChange={(e) =>
                    handleInputChange("nanos", e.target.value)
                  }
                  className="w-full bg-[#0a0e1a] border border-cyan-500/30 rounded px-3 py-2 text-sm text-white font-mono focus:outline-none focus:border-cyan-400"
                />
              </div>
            </div>
          </div>

          {/* Originator Section */}
          <div className="bg-gradient-to-br from-[#0f1525] to-[#0a0e1a] border border-cyan-500/30 rounded-lg p-5">
            <h3 className="text-lg font-bold text-cyan-400 mb-4 flex items-center gap-2">
              <Shield className="w-5 h-5" />
              ORIGINATOR ACCOUNT
            </h3>
            <div className="space-y-3">
              <div>
                <label className="block text-xs text-cyan-400/70 mb-1 font-mono">
                  Institution
                </label>
                <input
                  type="text"
                  value={payloadData.origInst}
                  onChange={(e) =>
                    handleInputChange(
                      "origInst",
                      e.target.value,
                    )
                  }
                  className="w-full bg-[#0a0e1a] border border-cyan-500/30 rounded px-3 py-2 text-sm text-white font-mono focus:outline-none focus:border-cyan-400"
                />
              </div>
              <div>
                <label className="block text-xs text-cyan-400/70 mb-1 font-mono">
                  Routing Number
                </label>
                <input
                  type="text"
                  value={payloadData.origRtn}
                  onChange={(e) =>
                    handleInputChange("origRtn", e.target.value)
                  }
                  className="w-full bg-[#0a0e1a] border border-cyan-500/30 rounded px-3 py-2 text-sm text-white font-mono focus:outline-none focus:border-cyan-400"
                />
              </div>
              <div>
                <label className="block text-xs text-cyan-400/70 mb-1 font-mono">
                  Account Token
                </label>
                <input
                  type="text"
                  value={payloadData.origAcctToken}
                  onChange={(e) =>
                    handleInputChange(
                      "origAcctToken",
                      e.target.value,
                    )
                  }
                  className="w-full bg-[#0a0e1a] border border-cyan-500/30 rounded px-3 py-2 text-sm text-white font-mono focus:outline-none focus:border-cyan-400"
                />
              </div>
            </div>
          </div>

          {/* Beneficiary Section */}
          <div className="bg-gradient-to-br from-[#0f1525] to-[#0a0e1a] border border-cyan-500/30 rounded-lg p-5">
            <h3 className="text-lg font-bold text-cyan-400 mb-4 flex items-center gap-2">
              <Shield className="w-5 h-5" />
              BENEFICIARY ACCOUNT
            </h3>
            <div className="space-y-3">
              <div>
                <label className="block text-xs text-cyan-400/70 mb-1 font-mono">
                  Institution
                </label>
                <input
                  type="text"
                  value={payloadData.benInst}
                  onChange={(e) =>
                    handleInputChange("benInst", e.target.value)
                  }
                  className="w-full bg-[#0a0e1a] border border-cyan-500/30 rounded px-3 py-2 text-sm text-white font-mono focus:outline-none focus:border-cyan-400"
                />
              </div>
              <div>
                <label className="block text-xs text-cyan-400/70 mb-1 font-mono">
                  Routing Number
                </label>
                <input
                  type="text"
                  value={payloadData.benRtn}
                  onChange={(e) =>
                    handleInputChange("benRtn", e.target.value)
                  }
                  className="w-full bg-[#0a0e1a] border border-cyan-500/30 rounded px-3 py-2 text-sm text-white font-mono focus:outline-none focus:border-cyan-400"
                />
              </div>
              <div>
                <label className="block text-xs text-cyan-400/70 mb-1 font-mono">
                  Account Token
                </label>
                <input
                  type="text"
                  value={payloadData.benAcctToken}
                  onChange={(e) =>
                    handleInputChange(
                      "benAcctToken",
                      e.target.value,
                    )
                  }
                  className="w-full bg-[#0a0e1a] border border-cyan-500/30 rounded px-3 py-2 text-sm text-white font-mono focus:outline-none focus:border-cyan-400"
                />
              </div>
            </div>
          </div>

          {/* Metadata Section */}
          <div className="bg-gradient-to-br from-[#0f1525] to-[#0a0e1a] border border-cyan-500/30 rounded-lg p-5">
            <h3 className="text-lg font-bold text-cyan-400 mb-4 flex items-center gap-2">
              <Hash className="w-5 h-5" />
              METADATA
            </h3>
            <div className="space-y-3">
              <div>
                <label className="block text-xs text-cyan-400/70 mb-1 font-mono">
                  Source
                </label>
                <input
                  type="text"
                  value={payloadData.source}
                  onChange={(e) =>
                    handleInputChange("source", e.target.value)
                  }
                  className="w-full bg-[#0a0e1a] border border-cyan-500/30 rounded px-3 py-2 text-sm text-white font-mono focus:outline-none focus:border-cyan-400"
                />
              </div>
              <div>
                <label className="block text-xs text-cyan-400/70 mb-1 font-mono">
                  Idempotency Key
                </label>
                <input
                  type="text"
                  value={payloadData.idempotencyKey}
                  onChange={(e) =>
                    handleInputChange(
                      "idempotencyKey",
                      e.target.value,
                    )
                  }
                  className="w-full bg-[#0a0e1a] border border-cyan-500/30 rounded px-3 py-2 text-sm text-white font-mono focus:outline-none focus:border-cyan-400"
                />
              </div>
              <div>
                <label className="block text-xs text-cyan-400/70 mb-1 font-mono">
                  Hash
                </label>
                <input
                  type="text"
                  value={payloadData.hash}
                  onChange={(e) =>
                    handleInputChange("hash", e.target.value)
                  }
                  className="w-full bg-[#0a0e1a] border border-cyan-500/30 rounded px-3 py-2 text-sm text-white font-mono focus:outline-none focus:border-cyan-400"
                />
              </div>
              <div>
                <label className="block text-xs text-cyan-400/70 mb-1 font-mono">
                  Signature
                </label>
                <input
                  type="text"
                  value={payloadData.signature}
                  onChange={(e) =>
                    handleInputChange(
                      "signature",
                      e.target.value,
                    )
                  }
                  className="w-full bg-[#0a0e1a] border border-cyan-500/30 rounded px-3 py-2 text-sm text-white font-mono focus:outline-none focus:border-cyan-400"
                />
              </div>
            </div>
          </div>

          {/* Payload Details Section */}
          <div className="bg-gradient-to-br from-[#0f1525] to-[#0a0e1a] border border-cyan-500/30 rounded-lg p-5">
            <h3 className="text-lg font-bold text-cyan-400 mb-4 flex items-center gap-2">
              <Activity className="w-5 h-5" />
              PAYLOAD DETAILS
            </h3>
            <div className="space-y-3">
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs text-cyan-400/70 mb-1 font-mono">
                    Type
                  </label>
                  <input
                    type="text"
                    value={payloadData.type}
                    onChange={(e) =>
                      handleInputChange("type", e.target.value)
                    }
                    className="w-full bg-[#0a0e1a] border border-cyan-500/30 rounded px-3 py-2 text-sm text-white font-mono focus:outline-none focus:border-cyan-400"
                  />
                </div>
                <div>
                  <label className="block text-xs text-cyan-400/70 mb-1 font-mono">
                    Version
                  </label>
                  <input
                    type="text"
                    value={payloadData.version}
                    onChange={(e) =>
                      handleInputChange(
                        "version",
                        e.target.value,
                      )
                    }
                    className="w-full bg-[#0a0e1a] border border-cyan-500/30 rounded px-3 py-2 text-sm text-white font-mono focus:outline-none focus:border-cyan-400"
                  />
                </div>
              </div>
              <div>
                <label className="block text-xs text-cyan-400/70 mb-1 font-mono">
                  Transaction ID
                </label>
                <input
                  type="text"
                  value={payloadData.txnId}
                  onChange={(e) =>
                    handleInputChange("txnId", e.target.value)
                  }
                  className="w-full bg-[#0a0e1a] border border-cyan-500/30 rounded px-3 py-2 text-sm text-white font-mono focus:outline-none focus:border-cyan-400"
                />
              </div>
              <div>
                <label className="block text-xs text-cyan-400/70 mb-1 font-mono">
                  Ledger Effect
                </label>
                <input
                  type="text"
                  value={payloadData.ledgerEffect}
                  onChange={(e) =>
                    handleInputChange(
                      "ledgerEffect",
                      e.target.value,
                    )
                  }
                  className="w-full bg-[#0a0e1a] border border-cyan-500/30 rounded px-3 py-2 text-sm text-white font-mono focus:outline-none focus:border-cyan-400"
                />
              </div>
            </div>
          </div>

          {/* Generate Button */}
          <button
            onClick={generatePayload}
            className="w-full bg-gradient-to-r from-cyan-500 to-blue-500 hover:from-cyan-400 hover:to-blue-400 text-white font-bold py-4 rounded-lg transition-all transform hover:scale-[1.02] shadow-lg shadow-cyan-500/20"
          >
            <div className="flex items-center justify-center gap-2">
              <Send className="w-5 h-5" />
              <span className="uppercase tracking-wide">
                Generate Payload
              </span>
            </div>
          </button>
        </div>

        {/* Right Column */}
        <div className="space-y-6">
          {/* ML Node Expressions Array - TensorFlow v0.1.2.39 */}
          <div className="bg-gradient-to-br from-[#0f1525] to-[#0a0e1a] border border-cyan-500/30 rounded-lg p-5">
            <div className="flex items-center justify-between mb-4">
              <h3 className="text-lg font-bold text-cyan-400 flex items-center gap-2">
                <Cpu className="w-5 h-5" />
                ML NODE EXPRESSIONS v0.1.2.39
              </h3>
              <div className="text-xs text-cyan-400/70 font-mono">
                TensorFlow Semantic Processing
              </div>
            </div>

            <div className="space-y-3">
              {mlNodes.map((node) => (
                <div
                  key={node.nodeId}
                  className={`border rounded-lg p-4 ${getNodeStatusColor(node.status)}`}
                >
                  <div className="flex items-center justify-between mb-3">
                    <div className="font-mono text-sm font-bold">
                      {node.nodeId}
                    </div>
                    <div
                      className={`px-2 py-1 rounded text-xs font-bold uppercase ${
                        node.status === "optimal"
                          ? "bg-green-400/20"
                          : node.status === "warning"
                            ? "bg-yellow-400/20"
                            : "bg-red-400/20"
                      }`}
                    >
                      {node.status}
                    </div>
                  </div>
                  <div className="grid grid-cols-2 gap-2 text-xs">
                    <div>
                      <div className="text-gray-400">
                        CPU Load
                      </div>
                      <div className="font-mono font-bold">
                        {(node.cpuLoad * 100).toFixed(1)}%
                      </div>
                    </div>
                    <div>
                      <div className="text-gray-400">
                        Latency
                      </div>
                      <div className="font-mono font-bold">
                        {node.latencyMs}ms
                      </div>
                    </div>
                    <div>
                      <div className="text-gray-400">
                        Queue Depth
                      </div>
                      <div className="font-mono font-bold">
                        {node.queueDepth}
                      </div>
                    </div>
                    <div>
                      <div className="text-gray-400">
                        TXN Rate
                      </div>
                      <div className="font-mono font-bold">
                        {node.txnRate}/s
                      </div>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Cluster Sharding Implementation */}
          <div className="bg-gradient-to-br from-[#0f1525] to-[#0a0e1a] border border-cyan-500/30 rounded-lg p-5">
            <h3 className="text-lg font-bold text-cyan-400 mb-4 flex items-center gap-2">
              <Database className="w-5 h-5" />
              CLUSTER-04 SHARDING
            </h3>
            <div className="space-y-3">
              <div className="bg-cyan-400/5 border border-cyan-400/20 rounded p-3">
                <div className="text-xs text-cyan-400/70 mb-2">
                  DESCRIPTION
                </div>
                <div className="text-sm">
                  CLUSTER-04 Settlement Processor experiencing
                  94% load. Horizontal sharding distributes
                  transactions across multiple nodes.
                </div>
              </div>
              <div className="bg-cyan-400/5 border border-cyan-400/20 rounded p-3">
                <div className="text-xs text-cyan-400/70 mb-2">
                  IMPACT
                </div>
                <div className="text-sm font-semibold text-green-400">
                  Reduce latency by 40%, increase throughput by
                  3x
                </div>
              </div>
              <div className="bg-cyan-400/5 border border-cyan-400/20 rounded p-3">
                <div className="text-xs text-cyan-400/70 mb-2">
                  IMPLEMENTATION
                </div>
                <ul className="text-xs space-y-1">
                  <li className="flex items-start gap-2">
                    <CheckCircle2 className="w-3 h-3 text-green-400 mt-0.5 flex-shrink-0" />
                    <span>
                      Deploy 2 additional settlement processor
                      nodes
                    </span>
                  </li>
                  <li className="flex items-start gap-2">
                    <CheckCircle2 className="w-3 h-3 text-green-400 mt-0.5 flex-shrink-0" />
                    <span>
                      Configure consistent hashing for
                      transaction distribution
                    </span>
                  </li>
                  <li className="flex items-start gap-2">
                    <CheckCircle2 className="w-3 h-3 text-green-400 mt-0.5 flex-shrink-0" />
                    <span>
                      Implement sticky sessions for in-flight
                      transactions
                    </span>
                  </li>
                  <li className="flex items-start gap-2">
                    <CheckCircle2 className="w-3 h-3 text-green-400 mt-0.5 flex-shrink-0" />
                    <span>
                      Update load balancer with weighted
                      round-robin v0.2.039.01
                    </span>
                  </li>
                </ul>
              </div>
            </div>
          </div>

          {/* Generated Payload Output */}
          {generatedPayload && (
            <div className="bg-gradient-to-br from-[#0f1525] to-[#0a0e1a] border border-cyan-500/30 rounded-lg p-5">
              <div className="flex items-center justify-between mb-4">
                <h3 className="text-lg font-bold text-cyan-400 flex items-center gap-2">
                  <Hash className="w-5 h-5" />
                  GENERATED PAYLOAD
                </h3>
                <div className="flex gap-2">
                  <button
                    onClick={copyPayload}
                    className="px-3 py-1 bg-cyan-400/10 border border-cyan-400/30 rounded hover:bg-cyan-400/20 transition-all"
                  >
                    <Copy className="w-4 h-4 text-cyan-400" />
                  </button>
                  <button
                    onClick={downloadPayload}
                    className="px-3 py-1 bg-cyan-400/10 border border-cyan-400/30 rounded hover:bg-cyan-400/20 transition-all"
                  >
                    <Download className="w-4 h-4 text-cyan-400" />
                  </button>
                </div>
              </div>
              <pre className="bg-[#0a0e1a] border border-cyan-500/20 rounded p-4 text-xs font-mono overflow-x-auto text-cyan-300">
                {generatedPayload}
              </pre>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}