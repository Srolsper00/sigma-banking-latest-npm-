/**
 * Unified Animation System for VOM Banking Platform
 * Ensures consistent animations across all 19 modules
 * Eliminates code duplication and provides production-ready transitions
 */

// Standard animation delays for staggered reveals
export const STAGGER_DELAY = 50; // ms per item
export const FADE_DURATION = 500; // ms
export const SLIDE_DURATION = 300; // ms

// Animation class generators
export const getStaggerStyle = (index: number) => ({
  animation: `fadeInUp ${FADE_DURATION}ms ease-out forwards`,
  animationDelay: `${index * STAGGER_DELAY}ms`,
  opacity: 0
});

export const getSlideInStyle = (delay = 0) => ({
  animation: `slideIn ${SLIDE_DURATION}ms ease-out forwards`,
  animationDelay: `${delay}ms`
});

export const getPulseStyle = () => ({
  animation: 'pulse 2s ease-in-out infinite'
});

// CSS keyframes as a string for inline injection
export const ANIMATION_KEYFRAMES = `
  @keyframes fadeInUp {
    from {
      opacity: 0;
      transform: translateY(10px);
    }
    to {
      opacity: 1;
      transform: translateY(0);
    }
  }

  @keyframes slideIn {
    from {
      opacity: 0;
      transform: translateX(-20px);
    }
    to {
      opacity: 1;
      transform: translateX(0);
    }
  }

  @keyframes fadeIn {
    from {
      opacity: 0;
    }
    to {
      opacity: 1;
    }
  }

  @keyframes pulse {
    0%, 100% {
      opacity: 1;
    }
    50% {
      opacity: 0.5;
    }
  }

  @keyframes slideDown {
    from {
      opacity: 0;
      transform: translateY(-10px);
    }
    to {
      opacity: 1;
      transform: translateY(0);
    }
  }

  @keyframes expandWidth {
    from {
      transform: scaleX(0);
    }
    to {
      transform: scaleX(1);
    }
  }

  @keyframes shimmer {
    0% {
      background-position: -1000px 0;
    }
    100% {
      background-position: 1000px 0;
    }
  }

  @keyframes spin {
    from {
      transform: rotate(0deg);
    }
    to {
      transform: rotate(360deg);
    }
  }

  @keyframes bounce {
    0%, 100% {
      transform: translateY(0);
    }
    50% {
      transform: translateY(-10px);
    }
  }
`;

// Reusable animation classes
export const ANIMATION_CLASSES = {
  fadeIn: 'animate-[fadeIn_0.5s_ease-out]',
  fadeInUp: 'animate-[fadeInUp_0.5s_ease-out]',
  slideIn: 'animate-[slideIn_0.3s_ease-out]',
  slideDown: 'animate-[slideDown_0.5s_ease-out]',
  pulse: 'animate-pulse',
  spin: 'animate-spin',
  bounce: 'animate-bounce'
};

// Color theme constants for consistency
export const COLOR_THEMES = {
  cyan: {
    bg: 'bg-cyan-500/10',
    border: 'border-cyan-500/30',
    text: 'text-cyan-400',
    glow: 'shadow-cyan-500/20'
  },
  purple: {
    bg: 'bg-purple-500/10',
    border: 'border-purple-500/30',
    text: 'text-purple-400',
    glow: 'shadow-purple-500/20'
  },
  green: {
    bg: 'bg-green-500/10',
    border: 'border-green-500/30',
    text: 'text-green-400',
    glow: 'shadow-green-500/20'
  },
  blue: {
    bg: 'bg-blue-500/10',
    border: 'border-blue-500/30',
    text: 'text-blue-400',
    glow: 'shadow-blue-500/20'
  },
  orange: {
    bg: 'bg-orange-500/10',
    border: 'border-orange-500/30',
    text: 'text-orange-400',
    glow: 'shadow-orange-500/20'
  },
  indigo: {
    bg: 'bg-indigo-500/10',
    border: 'border-indigo-500/30',
    text: 'text-indigo-400',
    glow: 'shadow-indigo-500/20'
  },
  red: {
    bg: 'bg-red-500/10',
    border: 'border-red-500/30',
    text: 'text-red-400',
    glow: 'shadow-red-500/20'
  },
  yellow: {
    bg: 'bg-yellow-500/10',
    border: 'border-yellow-500/30',
    text: 'text-yellow-400',
    glow: 'shadow-yellow-500/20'
  }
};

// Helper to get color theme classes
export const getColorTheme = (color: keyof typeof COLOR_THEMES) => {
  return COLOR_THEMES[color] || COLOR_THEMES.cyan;
};

// Real-time update intervals (in milliseconds)
export const UPDATE_INTERVALS = {
  DEVICE_ADDITION: 5000,      // 5 seconds
  TRANSACTION_LIVE: 2000,     // 2 seconds
  MATLAB_PLOT: 5000,          // 5 seconds
  DOCUMENT_GEN: 3000,         // 3 seconds
  EXHIBIT_CREATE: 8000,       // 8 seconds
  BANKING_STATEMENT: 2000,    // 2 seconds
  PKI_DEMO: 10000,            // 10 seconds (demo)
  PKI_PRODUCTION: 86400000,   // 24 hours (production)
  METRICS_REFRESH: 2000,      // 2 seconds
  NETWORK_5G: 2000,           // 2 seconds
  CLOCK_UPDATE: 1000          // 1 second
};

// Production-ready error handling
export const handleError = (error: Error, context: string) => {
  console.error(`[${context}]`, error);
  // In production, send to error tracking service
  // Example: Sentry.captureException(error, { tags: { context } });
};

// Performance monitoring wrapper
export const measurePerformance = async <T,>(
  fn: () => Promise<T>,
  label: string
): Promise<T> => {
  const start = performance.now();
  try {
    const result = await fn();
    const duration = performance.now() - start;
    console.log(`[Performance] ${label}: ${duration.toFixed(2)}ms`);
    return result;
  } catch (error) {
    handleError(error as Error, label);
    throw error;
  }
};

// Debounce helper for performance
export const debounce = <T extends (...args: any[]) => any>(
  func: T,
  wait: number
): ((...args: Parameters<T>) => void) => {
  let timeout: NodeJS.Timeout;
  return (...args: Parameters<T>) => {
    clearTimeout(timeout);
    timeout = setTimeout(() => func(...args), wait);
  };
};

// Throttle helper for real-time updates
export const throttle = <T extends (...args: any[]) => any>(
  func: T,
  limit: number
): ((...args: Parameters<T>) => void) => {
  let inThrottle: boolean;
  return (...args: Parameters<T>) => {
    if (!inThrottle) {
      func(...args);
      inThrottle = true;
      setTimeout(() => (inThrottle = false), limit);
    }
  };
};
