# VOM Banking Platform - Security Architecture

## 🔒 Comprehensive Security Implementation

This document describes the encrypted build configuration, syntax protection firewall, and defensible parameterization following Cisco ACT2 SUDI CA guidelines and FIPS 140-2 Level 3 compliance.

---

## 📋 Table of Contents

1. [Security Enumerations](#security-enumerations)
2. [Encrypted Configuration](#encrypted-configuration)
3. [Syntax Protection Firewall](#syntax-protection-firewall)
4. [Transaction Security](#transaction-security)
5. [Certificate Lifecycle Security](#certificate-lifecycle-security)
6. [Compliance Frameworks](#compliance-frameworks)
7. [Usage Examples](#usage-examples)

---

## 🔐 Security Enumerations

All security parameters are defined as TypeScript enums for type safety and defensible parameterization.

### Location
`src/app/types/security-enums.ts`

### Key Enumerations

#### Certificate Lifecycle
- `CertificateLifecycleStage` - 8 stages from APPLICATION to EXPIRATION
- `CertificateApplicationStatus` - 7 validation states
- `CertificateIssuanceResult` - 7 result codes
- `TLSAuthenticationLevel` - 4 TLS/mTLS configurations
- `KeyStorageSecurityLevel` - FIPS 140-2 Level 2/3, HSM
- `CertificateUsagePurpose` - 6 usage types

#### Transaction Processing
- `TransactionPayloadType` - 6 payment types (FUNDS_TRANSFER, ACH, Wire, RTP, FedNow)
- `LedgerEffectType` - DEBIT, CREDIT, HOLD, RELEASE
- `TransactionStatus` - 7 processing states
- `CurrencyCode` - ISO 4217 currency codes

#### Cryptography
- `EncryptionAlgorithm` - AES-256-GCM/CBC, RSA-4096/2048, ECDSA
- `HashAlgorithm` - SHA-256/384/512, SHA3-256

#### Security Operations
- `SecurityClassification` - TOP_SECRET to PUBLIC
- `DataSensitivityLevel` - 4 levels
- `AuditEventType` - 11 event types
- `RBACPermissionLevel` - 5 access levels
- `FirewallRuleAction` - ALLOW, DENY, LOG, RATE_LIMIT, QUARANTINE

---

## 🛡️ Encrypted Configuration

### Location
`src/app/config/security-config.ts`

### Configuration Sections

#### 1. Certificate Management (ACT2 SUDI CA)
```typescript
certificate: {
  ca: {
    name: 'ACT2_SUDI_CA',
    version: '2.1',
    tlsLevel: TLSAuthenticationLevel.TLS_1_3_MUTUAL_AUTH,
    keyStorage: KeyStorageSecurityLevel.FIPS_140_2_LEVEL_3,
    autoRenewal: true,
    renewalThresholdDays: 30
  }
}
```

**Features:**
- FIPS 140-2 Level 3 hardware-backed key storage
- TLS 1.3 mutual authentication
- Automated renewal 30 days before expiration
- Serial number and PID validation
- Signature verification required

#### 2. Encryption Settings
```typescript
encryption: {
  atRest: {
    algorithm: EncryptionAlgorithm.AES_256_GCM,
    keyRotationDays: 90
  },
  inTransit: {
    algorithm: EncryptionAlgorithm.AES_256_GCM,
    tlsMinVersion: '1.3',
    requireMutualAuth: true
  }
}
```

**Ciphers Allowed:**
- TLS_AES_256_GCM_SHA384
- TLS_CHACHA20_POLY1305_SHA256
- TLS_AES_128_GCM_SHA256

#### 3. Transaction Security
```typescript
transaction: {
  validation: {
    requireSignature: true,
    requireIdempotencyKey: true,
    requireHashVerification: true,
    maxTransactionSize: 10485760 // 10MB
  },
  limits: {
    maxAmountUSD: 10000000,      // $10M
    dailyLimitUSD: 100000000,    // $100M
    requireDualApprovalAbove: 1000000 // $1M
  }
}
```

#### 4. RBAC & Access Control
```typescript
accessControl: {
  rbac: {
    requireMFA: true,
    sessionTimeoutMinutes: 30,
    maxFailedAttempts: 3,
    lockoutDurationMinutes: 15
  }
}
```

---

## 🔥 Syntax Protection Firewall

### Overview
The Syntax Firewall provides real-time protection against injection attacks and malicious input patterns.

### Firewall Rules

#### 1. SQL Injection Protection
```typescript
{
  name: 'BLOCK_SQL_INJECTION',
  pattern: /(\bUNION\b|\bSELECT\b|\bDROP\b|\bINSERT\b|\bUPDATE\b|\bDELETE\b)/i,
  action: FirewallRuleAction.DENY,
  severity: 'CRITICAL'
}
```

#### 2. XSS Protection
```typescript
{
  name: 'BLOCK_XSS',
  pattern: /<script|javascript:|onerror=|onload=/i,
  action: FirewallRuleAction.DENY,
  severity: 'CRITICAL'
}
```

#### 3. Command Injection Protection
```typescript
{
  name: 'BLOCK_COMMAND_INJECTION',
  pattern: /(\||;|&&|\$\(|\`)/,
  action: FirewallRuleAction.DENY,
  severity: 'CRITICAL'
}
```

#### 4. Path Traversal Protection
```typescript
{
  name: 'BLOCK_PATH_TRAVERSAL',
  pattern: /(\.\.\/|\.\.\\)/,
  action: FirewallRuleAction.DENY,
  severity: 'HIGH'
}
```

#### 5. API Rate Limiting
```typescript
{
  name: 'RATE_LIMIT_API',
  pattern: /^\/api\//,
  action: FirewallRuleAction.RATE_LIMIT,
  maxRequestsPerMinute: 100
}
```

### Usage Example

```typescript
import { syntaxFirewall } from './config/security-config';

// Validate user input
const result = syntaxFirewall.validate(userInput, 'transaction-form');

if (!result.valid) {
  console.error('Security violation:', result.error);
  // Block request
  return;
}

// Use sanitized input
processTransaction(result.sanitized);
```

---

## 💳 Transaction Security

### Type Definitions
`src/app/types/transaction-types.ts`

### Funds Transfer Transaction

```typescript
interface FundsTransferPayload {
  payload_type: TransactionPayloadType.FUNDS_TRANSFER;
  version: 1;
  txn_id: string; // UUID v4
  
  originator_account: {
    institution: string;
    routing_number: string;
    account_number_token: string; // TOKENIZED
  };
  
  beneficiary_account: {
    institution: string;
    routing_number: string;
    account_number_token: string; // TOKENIZED
  };
  
  amount: {
    currency: "USD";
    units: number;  // Integer dollars
    nanos: number;  // 0-999,999,999
  };
  
  ledger_effect: "DEBIT" | "CREDIT";
  
  event_ts: Date;
  ingest_ts: Date;
  
  metadata: {
    source: "INGEST_API";
    idempotency_key: string;
    hash: string;      // SHA-256 canonical
    signature?: string; // RSA-4096 optional
  };
}
```

### Security Features

#### 1. Account Number Tokenization
- **Never store plaintext account numbers**
- All account numbers are tokenized using HashiCorp Vault
- Tokens are irreversible without vault access
- FIPS 140-2 Level 3 key storage

#### 2. Cryptographic Verification
```typescript
import { EncryptionUtils } from './config/security-config';

// Hash transaction for verification
const hash = await EncryptionUtils.hashTransaction(payload);

// Verify hash matches
if (payload.metadata.hash !== hash) {
  throw new Error('Transaction hash mismatch - possible tampering');
}
```

#### 3. Idempotency Protection
- Every transaction requires unique `idempotency_key`
- Prevents duplicate processing
- 24-hour deduplication window
- Stored in Redis cache for fast lookup

#### 4. Immutable Audit Trail
- All transactions logged to MongoDB Atlas Ledger
- Backup to NULS blockchain for immutability
- 7-year retention (2,555 days)
- Cannot be modified or deleted

---

## 🔐 Certificate Lifecycle Security

### ACT2 SUDI CA Compliance

Following Cisco ACT2 SUDI CA CPS v2.1:

#### Section 4.1: Certificate Application
1. **Subscriber Validation**
   - ACT2 chip serial number verified against pre-registered chips
   - Only legitimate Cisco hardware accepted

2. **Enrollment Process**
   - Encrypted communications (TLS 1.3)
   - Protected information storage
   - No manual intervention required

#### Section 4.2: Application Processing
1. **Authentication (4.2.1)**
   - Serial number validation
   - PID (Product ID) validation
   - Signature verification using ACT2 chip identity

2. **Approval/Rejection (4.2.2)**
   - Automated decision
   - Success/error code transmission
   - No specific SLA (prompt processing)

#### Section 4.3: Certificate Issuance
1. **CA Actions (4.3.1)**
   - TLS mutual certificate authentication
   - Encrypted, authenticated channel
   - Communications proxy for ACT2 products

2. **Notification (4.3.2)**
   - Certificate receipt = notification
   - Success/failure code included

#### Section 4.4: Certificate Acceptance
1. **Acceptance Criteria (4.4.1)**
   - Successful reception over authenticated channel
   - No additional confirmation required

2. **Publication (4.4.2)**
   - **No public repository publication**
   - Certificates kept private

#### Section 4.5: Key Pair & Certificate Usage
1. **Private Key Usage (4.5.1)**
   - **FIPS 140-2 Level 3 certified hardware chip**
   - Not replicable without FIPS 140-2 Level 3 backup protocol
   - Hardware-based generation and storage

2. **Public Key Usage (4.5.2)**
   - Device authentication
   - Data encryption/decryption
   - Digital signatures
   - TLS client/server authentication

---

## ✅ Compliance Frameworks

### Implemented Standards

#### 1. CIS CSC (Center for Internet Security Controls)
- CIS CSC 4: Controlled Use of Administrative Privileges
- CIS CSC 7: Email and Web Browser Protections
- CIS CSC 8: Malware Defenses
- CIS CSC 12: Boundary Defense

#### 2. COBIT 5
- DSS05.01: Security Operations

#### 3. ISA 62443
- ISA 62443-2-1:2009 4.3.4.3.8
- ISA 62443-3-3:2013 SR 3.2

#### 4. ISO/IEC 27001:2013
- A.12.2.1: Controls against malware

#### 5. NIST SP 800-53 Rev. 4
- SI-3: Malicious Code Protection
- SI-8: Spam Protection

#### 6. PCI DSS
- Payment Card Industry Data Security Standard
- Tokenization requirements
- Encryption at rest and in transit

#### 7. FFIEC
- Federal Financial Institutions Examination Council
- Critical infrastructure oversight

---

## 📚 Usage Examples

### Example 1: Validate Transaction Input

```typescript
import { syntaxFirewall } from './config/security-config';
import { EncryptionUtils } from './config/security-config';
import { FundsTransferPayload } from './types/transaction-types';

async function processTransaction(payload: FundsTransferPayload) {
  // 1. Validate inputs against firewall
  const accountValidation = syntaxFirewall.validate(
    payload.originator_account.account_number_token,
    'originator_account'
  );
  
  if (!accountValidation.valid) {
    throw new Error('Invalid originator account');
  }
  
  // 2. Verify hash
  const computedHash = await EncryptionUtils.hashTransaction(payload);
  if (payload.metadata.hash !== computedHash) {
    throw new Error('Transaction hash mismatch');
  }
  
  // 3. Check idempotency
  if (await isDuplicate(payload.metadata.idempotency_key)) {
    throw new Error('Duplicate transaction');
  }
  
  // 4. Process transaction
  return await executeTransaction(payload);
}
```

### Example 2: Certificate Enrollment

```typescript
import { 
  CertificateApplicationStatus,
  CertificateIssuanceResult,
  TLSAuthenticationLevel 
} from './types/security-enums';
import { SECURITY_CONFIG } from './config/security-config';

async function enrollCertificate(chipSerialNumber: string, pid: string) {
  // 1. Validate serial number
  if (!await isChipPreRegistered(chipSerialNumber)) {
    return {
      status: CertificateApplicationStatus.REJECTED,
      result: CertificateIssuanceResult.UNREGISTERED_CHIP
    };
  }
  
  // 2. Validate PID
  if (!await validatePID(pid)) {
    return {
      status: CertificateApplicationStatus.REJECTED,
      result: CertificateIssuanceResult.INVALID_PID
    };
  }
  
  // 3. Verify signature
  if (!await verifyChipSignature(chipSerialNumber)) {
    return {
      status: CertificateApplicationStatus.REJECTED,
      result: CertificateIssuanceResult.SIGNATURE_MISMATCH
    };
  }
  
  // 4. Issue certificate
  const certificate = await issueCertificate({
    serialNumber: chipSerialNumber,
    pid,
    tlsLevel: SECURITY_CONFIG.certificate.ca.tlsLevel,
    keyStorage: SECURITY_CONFIG.certificate.ca.keyStorage
  });
  
  return {
    status: CertificateApplicationStatus.APPROVED,
    result: CertificateIssuanceResult.SUCCESS,
    certificate
  };
}
```

### Example 3: Audit Logging

```typescript
import { AuditEventType, SecurityEventSeverity } from './types/security-enums';

function logSecurityEvent(
  eventType: AuditEventType,
  severity: SecurityEventSeverity,
  details: any
) {
  const auditEvent = {
    timestamp: new Date().toISOString(),
    type: eventType,
    severity,
    details: {
      ...details,
      // Redact sensitive fields
      account_number: '[REDACTED]',
      signature: '[REDACTED]'
    },
    user: getCurrentUser(),
    ip_address: getClientIP(),
    session_id: getSessionID()
  };
  
  // Log to immutable ledger
  await logToBlockchain(auditEvent);
  
  // Log to MongoDB Atlas
  await logToDatabase(auditEvent);
  
  // Send alerts for critical events
  if (severity === SecurityEventSeverity.CRITICAL) {
    await sendSecurityAlert(auditEvent);
  }
}
```

---

## 🚨 Security Alerts

### Alert Channels
- Email notifications
- Slack integration
- PagerDuty integration

### Response Times
- **Critical:** 5 minutes
- **High:** 30 minutes
- **Medium:** 4 hours
- **Low:** 24 hours

---

## 🔄 Key Rotation Schedule

| Component | Rotation Period | Automated |
|-----------|----------------|-----------|
| Encryption Keys | 90 days | ✅ Yes |
| API Keys | 90 days | ✅ Yes |
| Certificates | 30 days before expiry | ✅ Yes |
| TLS Session Tickets | 24 hours | ✅ Yes |
| Database Credentials | 90 days | ⚠️ Manual |

---

## 📞 Security Contacts

- **Security Team:** security@vombanking.com
- **Incident Response:** incident@vombanking.com
- **PagerDuty:** +1-XXX-XXX-XXXX

---

## 📄 License & Compliance

This security implementation follows:
- Cisco ACT2 SUDI CA CPS v2.1
- FIPS 140-2 Level 3 Requirements
- PCI DSS v4.0
- NIST Cybersecurity Framework
- ISO/IEC 27001:2013

**Last Updated:** April 15, 2026
**Version:** 1.0.0
