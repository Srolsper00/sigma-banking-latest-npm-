# Network Management System - Deployment Architecture

**Project**: Sigma Production Banking Platform  
**Component**: Network Infrastructure Manager with mmd02 WebSocket Server  
**Copyright**: © 2026 VOM Services Corporation  
**Author**: Matthew James Sauls - OCIO, CCO, CEO, CFO, CTO  
**EIN**: 83-1427324 | **FCC FRN**: 0033213463  

---

## 🏗️ System Architecture Overview

The Network Management System consists of **three integrated components**:

```
┌─────────────────────────────────────────────────────────────────┐
│                    SIGMA BANKING PLATFORM                        │
│                  (Figma Make / Browser-based)                    │
│                                                                   │
│  ┌───────────────────────────────────────────────────────┐      │
│  │  React Components                                      │      │
│  │  - NetworkInfrastructureManager (Display Only)         │      │
│  │  - NetworkInfrastructureManagerEnhanced (Mock Mode)    │      │
│  │  - Integrated with Dashboard                           │      │
│  └───────────────────────────────────────────────────────┘      │
│                            │                                      │
│                            │ HTTP/WebSocket                       │
│                            ▼                                      │
└─────────────────────────────────────────────────────────────────┘
                             │
                             │
┌────────────────────────────┴──────────────────────────────────┐
│                    mmd02 WebSocket Server                      │
│                  (Vercel or Standalone Node.js)                │
│                                                                 │
│  ┌─────────────────────────────────────────────────────┐      │
│  │  HTTP API Endpoints:                                │      │
│  │  - POST /api/network/create                         │      │
│  │  - DELETE /api/network/:id                          │      │
│  │  - POST /api/network/:id/subnet                     │      │
│  │  - DELETE /api/network/:networkId/subnet/:subnetId  │      │
│  │  - GET /api/events                                  │      │
│  │  - GET /health                                      │      │
│  └─────────────────────────────────────────────────────┘      │
│                                                                 │
│  ┌─────────────────────────────────────────────────────┐      │
│  │  WebSocket Server (Standalone Only):                │      │
│  │  - ws://localhost:8081/ws                           │      │
│  │  - Real-time event broadcasting                     │      │
│  │  - Client connection management                     │      │
│  └─────────────────────────────────────────────────────┘      │
│                            │                                    │
└────────────────────────────┼────────────────────────────────────┘
                             │
                             │
┌────────────────────────────┴──────────────────────────────────┐
│                    CLI Management Tool                         │
│                    (Node.js / Terminal)                        │
│                                                                 │
│  Commands:                                                     │
│  $ rnet create <name> --cidr 10.0.0.0/16                      │
│  $ rnet list                                                   │
│  $ rnet delete <id>                                            │
│  $ rnet subnet add <networkId> <name> <cidr>                  │
│  $ rnet subnet remove <networkId> <subnetId>                  │
│                                                                 │
│  Drivers:                                                      │
│  - MockDriver (development/testing)                            │
│  - LinuxDriver (production infrastructure)                     │
└─────────────────────────────────────────────────────────────────┘
```

---

## 📦 Component Details

### 1. **React Frontend (Figma Make)**

#### Files:
- `/components/NetworkInfrastructureManager.tsx` - **Display-only component** (existing networks view)
- `/components/NetworkInfrastructureManagerEnhanced.tsx` - **Full management UI** (create, delete, manage)
- `/utils/networkApi.ts` - **API client** for mmd02 server integration

#### Capabilities:
- **Mock Mode** (Browser-only):
  - Create/delete networks
  - Add/remove subnets
  - Event stream visualization
  - No backend required
  
- **API-Integrated Mode** (with mmd02 server):
  - Real-time WebSocket events
  - Persistent network management
  - Multi-user support
  - Event history

#### Usage:
```tsx
import { NetworkInfrastructureManagerEnhanced } from './components/NetworkInfrastructureManagerEnhanced';

// In your Dashboard or App.tsx
<NetworkInfrastructureManagerEnhanced />
```

---

### 2. **mmd02 WebSocket Server**

#### Files:
- `/mmd02/index.ts` - Main server implementation
- `/mmd02/api/ws.ts` - Vercel serverless handler (HTTP only)
- `/mmd02/package.json` - Dependencies
- `/mmd02/vercel.json` - Vercel deployment config

#### Deployment Options:

##### **Option A: Standalone Server (Full WebSocket Support)**

**Requirements:**
- Node.js 18+
- Open port 8081 (or custom)

**Installation:**
```bash
cd mmd02
npm install
npm run dev          # Development mode
npm run build        # Production build
npm start            # Production mode
```

**Environment Variables:**
```bash
PORT=8081
NODE_ENV=production
```

**Server Output:**
```
🚀 mmd02 Network Management Server
📡 HTTP API: http://localhost:8081
🔌 WebSocket: ws://localhost:8081/ws
💚 Health Check: http://localhost:8081/health

VOM Services Corporation © 2026
```

##### **Option B: Vercel Deployment (HTTP API Only)**

**Note**: Vercel Serverless Functions don't support WebSocket. Use HTTP polling for events.

**Deployment:**
```bash
cd mmd02
npm install -g vercel
vercel login
vercel --prod
```

**Vercel Configuration** (`vercel.json`):
```json
{
  "version": 2,
  "name": "mmd02-network-management",
  "builds": [
    { "src": "index.ts", "use": "@vercel/node" }
  ],
  "routes": [
    { "src": "/ws", "dest": "/index.ts" },
    { "src": "/api/(.*)", "dest": "/index.ts" }
  ]
}
```

**Environment Variables on Vercel:**
- Set in Vercel Dashboard → Settings → Environment Variables

##### **Option C: Hybrid Deployment (Recommended)**

Use **Railway, Render, or Fly.io** for WebSocket server (full support):

**Railway Deployment:**
```bash
# Install Railway CLI
npm install -g @railway/cli

# Login and deploy
railway login
cd mmd02
railway init
railway up
```

**Environment Variables:**
```
PORT=8081
NODE_ENV=production
```

---

### 3. **CLI Management Tool**

#### Files:
- `/rnet-cli/index.ts` - CLI entry point
- `/rnet-cli/drivers/mockDriver.ts` - Mock driver for testing
- `/rnet-cli/drivers/linuxDriver.ts` - Linux network driver (production)
- `/rnet-cli/events.ts` - Event emitter system

#### Installation:
```bash
cd rnet-cli
npm install
npm link          # Make 'rnet' command globally available
```

#### Usage:
```bash
# Set driver (mock or linux)
export RNET_DRIVER=mock

# Create network
rnet create production-net --cidr 10.0.0.0/16

# List networks
rnet list

# Add subnet
rnet subnet add net-123 dmz-subnet 10.0.1.0/24

# Remove subnet
rnet subnet remove net-123 subnet-456

# Delete network
rnet delete net-123
```

#### Integration with mmd02:
The CLI emits events that are forwarded to the mmd02 server for real-time updates.

```typescript
// In events.ts
import { io } from 'socket.io-client';

const socket = io('http://localhost:8081');

export function emitEvent(type: string, payload: any) {
  socket.emit('rnet:event', { type, payload, timestamp: new Date().toISOString() });
}
```

---

## 🔌 API Reference

### **HTTP Endpoints**

#### 1. Health Check
```
GET /health
```

**Response:**
```json
{
  "status": "healthy",
  "service": "mmd02-network-management",
  "timestamp": "2026-03-18T12:00:00.000Z",
  "environment": "standalone",
  "events_count": 42
}
```

#### 2. Get Events
```
GET /api/events?limit=50
```

**Response:**
```json
{
  "events": [
    {
      "type": "network.created",
      "payload": { "id": "net-123", "name": "Production Network" },
      "timestamp": "2026-03-18T12:00:00.000Z",
      "source": "api"
    }
  ],
  "total": 42
}
```

#### 3. Create Network
```
POST /api/network/create
Content-Type: application/json

{
  "name": "Production Network",
  "cidr": "10.0.0.0/16",
  "datacenter": "3xpres5 Datacenter",
  "metadata": {
    "environment": "production",
    "owner": "VOM Services Corporation"
  }
}
```

**Response:**
```json
{
  "success": true,
  "network": {
    "id": "net-1710763200000",
    "name": "Production Network",
    "cidr": "10.0.0.0/16",
    "status": "provisioning"
  }
}
```

#### 4. Delete Network
```
DELETE /api/network/:id
```

**Response:**
```json
{
  "success": true,
  "message": "Network net-123 deleted"
}
```

#### 5. Add Subnet
```
POST /api/network/:id/subnet
Content-Type: application/json

{
  "name": "DMZ Subnet",
  "cidr": "10.0.1.0/24",
  "zone": "us-west-2a",
  "purpose": "dmz"
}
```

**Response:**
```json
{
  "success": true,
  "subnet": {
    "id": "subnet-1710763200000",
    "name": "DMZ Subnet",
    "cidr": "10.0.1.0/24"
  }
}
```

#### 6. Remove Subnet
```
DELETE /api/network/:networkId/subnet/:subnetId
```

**Response:**
```json
{
  "success": true,
  "message": "Subnet subnet-123 removed from network net-456"
}
```

---

### **WebSocket Events** (Standalone Server Only)

#### Connection:
```javascript
const ws = new WebSocket('ws://localhost:8081/ws');

ws.onopen = () => {
  console.log('Connected to mmd02');
};

ws.onmessage = (event) => {
  const data = JSON.parse(event.data);
  console.log('Event received:', data);
};
```

#### Event Format:
```json
{
  "type": "network.created",
  "payload": {
    "id": "net-123",
    "name": "Production Network",
    "cidr": "10.0.0.0/16"
  },
  "timestamp": "2026-03-18T12:00:00.000Z",
  "source": "api"
}
```

#### Event Types:
- `connection.established` - Client connected
- `network.created` - New network created
- `network.deleted` - Network deleted
- `network.status_changed` - Network status updated
- `subnet.added` - Subnet added to network
- `subnet.removed` - Subnet removed from network

---

## 🚀 Deployment Strategies

### **Strategy 1: Mock Mode (No Backend)**
**Best for**: Development, demos, testing

1. Use `NetworkInfrastructureManagerEnhanced` component
2. All operations run in browser memory
3. No server deployment needed
4. Data lost on page refresh

### **Strategy 2: Standalone mmd02 Server**
**Best for**: Production, full WebSocket support

1. Deploy mmd02 to VPS, Railway, or Render
2. Configure React app to connect:
   ```bash
   NEXT_PUBLIC_MMD02_API_URL=https://mmd02.your-domain.com
   NEXT_PUBLIC_MMD02_WS_URL=wss://mmd02.your-domain.com/ws
   ```
3. Full real-time event streaming
4. Persistent event storage

### **Strategy 3: Hybrid (Vercel + External WS)**
**Best for**: Serverless + Real-time

1. Deploy mmd02 HTTP API to Vercel
2. Deploy separate WebSocket server to Railway
3. Use HTTP API for mutations, WS for events
4. Best of both worlds

---

## 🔧 Configuration

### **React App Environment Variables**

Create `.env.local`:
```bash
# mmd02 Server URLs
NEXT_PUBLIC_MMD02_API_URL=http://localhost:8081
NEXT_PUBLIC_MMD02_WS_URL=ws://localhost:8081/ws

# Production
# NEXT_PUBLIC_MMD02_API_URL=https://mmd02.your-domain.com
# NEXT_PUBLIC_MMD02_WS_URL=wss://mmd02.your-domain.com/ws
```

### **mmd02 Server Environment Variables**

```bash
PORT=8081
NODE_ENV=production
WS_PORT=8081
CORS_ORIGIN=https://your-banking-platform.com
```

---

## 📊 Data Flow

### **Creating a Network (Full Stack)**

```mermaid
sequenceDiagram
    participant UI as React UI
    participant API as networkApi.ts
    participant MMD as mmd02 Server
    participant WS as WebSocket
    participant CLI as rnet CLI

    UI->>API: createNetwork()
    API->>MMD: POST /api/network/create
    MMD->>MMD: Store event
    MMD->>WS: Broadcast event
    WS->>UI: network.created event
    UI->>UI: Update UI
    
    Note over CLI: Alternative path
    CLI->>MMD: POST /api/network/create
    MMD->>WS: Broadcast event
    WS->>UI: network.created event
```

---

## 🛡️ Security Considerations

### **Network Security**
1. **HTTPS/WSS Only** in production
2. **CORS Configuration** - whitelist trusted origins
3. **Rate Limiting** - prevent abuse
4. **Authentication** - implement JWT tokens (future enhancement)

### **Infrastructure Security**
5. **VPN Requirements** - CLI should run within secure network
6. **Firewall Rules** - restrict access to port 8081
7. **Encryption** - TLS/SSL certificates required

### **Compliance**
8. **FFIEC IT Examination Handbook** - logging and audit trails
9. **PCI DSS** - secure network segmentation
10. **SOC 2** - access controls and monitoring

---

## 📝 Logging & Monitoring

### **mmd02 Server Logs**
```bash
# Enable debug logging
DEBUG=* npm start

# Production logging
NODE_ENV=production npm start
```

### **Event Audit Trail**
All events are logged with:
- Event type
- Payload data
- Timestamp
- Source (api, websocket-client, cli)

### **Health Monitoring**
```bash
# Check server health
curl http://localhost:8081/health

# Monitor event count
curl http://localhost:8081/api/events | jq '.total'
```

---

## 🧪 Testing

### **Unit Tests**
```bash
cd mmd02
npm test
```

### **Integration Tests**
```bash
# Start server
npm start

# Run integration tests
npm run test:integration
```

### **Manual Testing**
```bash
# Test WebSocket connection
wscat -c ws://localhost:8081/ws

# Test HTTP API
curl -X POST http://localhost:8081/api/network/create \
  -H "Content-Type: application/json" \
  -d '{"name":"Test Network","cidr":"10.0.0.0/16"}'
```

---

## 📚 Additional Resources

### **Related Documentation**
- `/DEPLOYMENT_INFRASTRUCTURE.md` - Overall platform deployment
- `/INFRASTRUCTURE_3XPRES5_DATACENTER.md` - 3xpres5 datacenter specs
- `/apisix-banking-routes.json` - APISIX routing configuration

### **VOM Services Corporation**
- **EIN**: 83-1427324
- **FCC FRN**: 0033213463
- **FINRA Org ID**: TM6ZAS58-RRGKPOZW-OBLMFGJE-030961767-0033213463
- **Principal**: Matthew James Sauls (OCIO, CCO, CEO, CFO, CTO)

---

## 🎯 System Goals

1. **Real-time Network Management** - Instant visibility into infrastructure changes
2. **Compliance & Audit** - Complete event trail for regulatory requirements
3. **Multi-channel Access** - Web UI, CLI, and API access
4. **Scalability** - Support for thousands of networks and subnets
5. **High Availability** - Redundant deployment across datacenters

---

**Last Updated**: March 18, 2026  
**Version**: 1.0.0  
**Status**: Production Ready  

---

© 2026 VOM Services Corporation. All Rights Reserved.
