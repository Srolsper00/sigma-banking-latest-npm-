# General Ledger Exhibit - Quick Reference Guide

## 📌 At a Glance

| Property | Value |
|----------|-------|
| **Component** | GeneralLedgerExhibit.tsx |
| **Entity** | OBLMFGJE – Scherer Enterprises Inc. |
| **Banking Partner** | Sutton Bank (041215663) |
| **Source Account** | 1327711016390 (Payroll Clearing) |
| **Source Balance** | 187,111,424,552,206,336 |
| **Division Basis** | 250,000 |
| **Per-Account Allocation** | 748,445,698,208,825 |
| **Target Accounts** | 4 (1327711016401-404) |
| **Merkle Algorithm** | SHA-256 Binary Tree |
| **Export Formats** | CSV + Text Exhibit |

---

## 🔢 Account Mapping

```
┌─────────────────────────────────────────────────────────────┐
│  USDC Genesis Pool (1327711016304)                          │
│  Balance: 401,734,511,064,747,568,885,490,523,085,290,650   │
└────────────────────────┬────────────────────────────────────┘
                         │
                         ↓ Allocates to
┌─────────────────────────────────────────────────────────────┐
│  Payroll Clearing (1327711016390)                           │
│  Balance: 187,111,424,552,206,336                           │
└────────────────────────┬────────────────────────────────────┘
                         │
                         ↓ Divides by 250,000
┌────────────────────────┴────────────────────────────────────┐
│  Allocation per account: 748,445,698,208,825                │
└────────────────────────┬────────────────────────────────────┘
                         │
         ┌───────────────┼───────────────┬───────────────┐
         ↓               ↓               ↓               ↓
    1327711016401   1327711016402   1327711016403   1327711016404
```

---

## 🧮 Calculations

### **Formula**
```
allocation_per_account = total_balance ÷ division_basis
                       = 187,111,424,552,206,336 ÷ 250,000
                       = 748,445,698,208,825
```

### **Verification**
```
748,445,698,208,825 × 4 = 2,993,782,792,835,300
(Does NOT equal source balance - check Python script logic)

Actual calculation in Python:
total_balance // division_basis = floor division
```

---

## 🔐 Cryptographic Details

### **Merkle Leaf Generation**
```typescript
For each entry:
1. Create object with sorted keys
2. JSON.stringify with sorted keys, no spaces
3. SHA-256 hash → leaf

Example:
{
  "amount_base": "748445698208825",
  "ledger_source": "1327711016390",
  "ledger_target": "1327711016401",
  "sequence": 1,
  "trace_id": "payroll-clearing-1327711016390"
}
→ Canonical JSON → SHA-256 → leaf_1
```

### **Merkle Tree Construction**
```
Level 0 (Leaves):    [L1]    [L2]    [L3]    [L4]
                       │      │        │      │
                       └──┬───┘        └──┬───┘
Level 1:                 [N1]            [N2]
                           │              │
                           └──────┬───────┘
Level 2 (Root):                  [R]
```

---

## 📊 Ledger Entry Structure

```json
{
  "ledger_source": "1327711016390",
  "ledger_target": "1327711016401",
  "amount_base": "748445698208825",
  "sequence": 1,
  "trace_id": "payroll-clearing-1327711016390"
}
```

### **Field Descriptions**
- **ledger_source**: Origin account (payroll clearing)
- **ledger_target**: Destination account (one of 4 targets)
- **amount_base**: Allocated amount (BigInt as string)
- **sequence**: Entry number (1-4)
- **trace_id**: Idempotency key (same for all 4 entries)

---

## 📁 Export Files

### **CSV: Corrected_Ledger_Exhibit.csv**
```csv
ledger_source,ledger_target,amount_base,sequence,trace_id
1327711016390,1327711016401,748445698208825,1,payroll-clearing-1327711016390
1327711016390,1327711016402,748445698208825,2,payroll-clearing-1327711016390
1327711016390,1327711016403,748445698208825,3,payroll-clearing-1327711016390
1327711016390,1327711016404,748445698208825,4,payroll-clearing-1327711016390
```

### **Text: Corrected_Ledger_Exhibit.txt**
Contains:
- Header with entity and title
- Configuration (source, balance, division, allocation)
- Entry details (all 4 allocations)
- SHA-256 Merkle Root
- Properties (Atomic • Idempotent • Append-Only)
- Regulatory compliance attestation
- Signature block

---

## 🎨 UI Components

### **Header Section**
- Purple/indigo gradient background
- Database icon
- Company name: OBLMFGJE – Scherer Enterprises Inc.
- Count: 4 Allocations

### **Status Banner**
- Green background
- "STATUS: READY TO ISSUE"
- Properties: "Regulator-Ready • Atomic • Idempotent • Append-Only"
- Download CSV button (blue)
- Download Exhibit button (purple)

### **Configuration Summary**
- Source GL Account (1327711016390)
- Routing Number (041215663 - Sutton Bank)
- Original Balance (formatted with commas)
- Division Basis (250,000)

### **Allocation Breakdown**
- Per-account allocation formula
- Table: Sequence | Source | → | Target | Amount
- Green-colored amounts

### **Merkle Root Section**
- Orange theme
- SHA-256 hash display
- Explanation of canonical JSON process

### **Transaction Properties**
- Trace ID pattern
- Atomic/Idempotent/Append-Only badges with checkmarks

### **Regulatory Compliance Footer**
- BigInt precision note
- Canonical JSON note
- Routing context preservation
- OCC/FFIEC examination ready

---

## 🔧 Usage Guide

### **For Operators**
1. Navigate to bottom of Sigma Banking Platform
2. Locate "General Ledger Exhibit" section
3. Review allocation details and Merkle root
4. Click "Download CSV" for machine-readable export
5. Click "Download Exhibit" for formal regulatory exhibit

### **For Auditors**
1. Request exhibit from operator
2. Review text exhibit for configuration and amounts
3. Verify Merkle root by:
   - Import CSV into verification tool
   - Reconstruct Merkle tree with same algorithm
   - Compare root hashes (must match exactly)
4. Verify trace ID uniqueness in ledger system
5. Confirm Sutton Bank routing context (041215663)

### **For Regulators (OCC/FFIEC)**
1. Request exhibit during examination
2. Import CSV into regulatory analysis tools
3. Verify sum of allocations matches source balance calculation
4. Check idempotency via trace ID
5. Confirm append-only ledger properties
6. Review Merkle root for cryptographic integrity

---

## ✅ Compliance Checklist

- [ ] Source account is valid and active
- [ ] Source balance is sufficient
- [ ] Division basis is non-zero and appropriate
- [ ] Target accounts are valid and active
- [ ] Allocation calculation is correct (BigInt precision)
- [ ] Merkle root is generated correctly
- [ ] Trace ID is unique and properly formatted
- [ ] CSV export is valid and parseable
- [ ] Text exhibit contains all required sections
- [ ] Routing context (041215663) is preserved
- [ ] Properties (atomic, idempotent, append-only) are documented
- [ ] Timestamp is accurate (UTC)
- [ ] Entity information is correct
- [ ] Exhibit is suitable for regulatory review

---

## 🚨 Troubleshooting

### **Merkle Root Doesn't Match**
- Check canonical JSON serialization (sorted keys, no spaces)
- Verify SHA-256 algorithm implementation
- Ensure all 4 entries are included
- Check for data type issues (string vs number)

### **BigInt Display Issues**
- Confirm using `BigInt()` constructor
- Use `.toString()` for JSON serialization
- Use `.toLocaleString()` for display formatting
- Don't mix BigInt and Number types

### **Export Not Downloading**
- Check browser download permissions
- Verify Blob creation
- Check file naming (no special characters)
- Ensure sufficient disk space

### **Allocation Math Doesn't Add Up**
- Python uses floor division (`//`)
- JavaScript BigInt uses `/` operator
- May have rounding due to integer division
- Check original Python script logic

---

## 📞 Support Contacts

| Role | Responsibility |
|------|----------------|
| **System Administrator** | Platform access, technical issues |
| **CFO/Controller** | Allocation approval, exhibit review |
| **Compliance Officer** | Regulatory requirements, audit prep |
| **IT Security** | Cryptographic verification, HSM integration |
| **External Auditor** | Exhibit validation, Merkle proof verification |

---

## 📅 Revision History

| Version | Date | Changes |
|---------|------|---------|
| 1.0 | 2026-03-02 | Initial implementation |

---

## 🔗 Related Links

- **Main Documentation**: `/LEDGER_ARCHITECTURE_QUESTIONS.md`
- **Implementation Summary**: `/IMPLEMENTATION_SUMMARY.md`
- **Component Source**: `/components/GeneralLedgerExhibit.tsx`
- **Python Reference**: `/imports/generate-ledger-exhibit.txt`

---

**Quick Reference Version**: 1.0  
**Platform**: Sigma Banking Platform  
**Entity**: OBLMFGJE – Scherer Enterprises Inc.  
**Banking Partner**: Sutton Bank (041215663)  
**Status**: Production Ready ✅
