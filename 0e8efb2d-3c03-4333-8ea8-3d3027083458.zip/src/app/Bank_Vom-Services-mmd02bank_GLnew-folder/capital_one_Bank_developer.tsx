import { motion } from 'motion/react';
import { useState } from 'react';
import {
  Building2,
  DollarSign,
  ArrowRightLeft,
  CheckCircle,
  Hash,
  Key,
  Clock,
  Database,
  Shield,
  ChevronDown,
  ChevronRight,
  Copy,
  Download,
  FileText,
  Zap
} from 'lucide-react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '../components/ui/card';
import { Button } from '../components/ui/button';
import { Badge } from '../components/ui/badge';
import { Separator } from '../components/ui/separator';
import { toast } from 'sonner@2.0.3';

/**
 * Capital One Bank Developer Interface
 * ACH Transfer Record Viewer for Sigma Banking Platform
 */

interface ACHTransferRecord {
  payload_type: string;
  version: number;
  txn_id: string;
  originator_account: {
    institution: string;
    routing_number: string;
    account_number_token: string;
  };
  beneficiary_account: {
    institution: string;
    routing_number: string;
    account_number_token: string;
  };
  amount: {
    currency: string;
    units: number;
    nanos: number;
  };
  ledger_effect: 'CREDIT' | 'DEBIT';
  event_ts: number;
  ingest_ts: number;
  metadata: {
    source: string;
    idempotency_key: string;
    hash: string;
    signature: string;
  };
}

// Sample ACH Transfer Record
const achTransferRecord: ACHTransferRecord = {
  payload_type: 'FUNDS_TRANSFER',
  version: 1,
  txn_id: 'e6fad98b-a992-41e4-a710-0d6c5938bf14',
  originator_account: {
    institution: 'Sutton bank na',
    routing_number: '041215663',
    account_number_token: 'Tok-6390'
  },
  beneficiary_account: {
    institution: 'Capital one bank na',
    routing_number: '031176110',
    account_number_token: 'Tok-36396480434'
  },
  amount: {
    currency: 'USD',
    units: 40000,
    nanos: 0
  },
  ledger_effect: 'CREDIT',
  event_ts: 1776463786945,
  ingest_ts: 1776463786945,
  metadata: {
    source: 'SIGMA_BANKING_PLATFORM',
    idempotency_key: 'e6fad98b-a992-41e4-a710-0d6c5938bf14-1776463786945',
    hash: '0000000000000000000000000000000000000000000000000000000056823477',
    signature: '000000000000000000000000000000000000000000000000000000005c692d77'
  }
};

export function CapitalOneBankDeveloper() {
  const [isExpanded, setIsExpanded] = useState(false);
  const [showRawJSON, setShowRawJSON] = useState(false);

  const formatCurrency = (amount: number): string => {
    return new Intl.NumberFormat('en-US', {
      style: 'currency',
      currency: 'USD',
      minimumFractionDigits: 2,
      maximumFractionDigits: 2
    }).format(amount);
  };

  const formatTimestamp = (timestamp: number): string => {
    return new Date(timestamp).toLocaleString('en-US', {
      year: 'numeric',
      month: 'long',
      day: 'numeric',
      hour: '2-digit',
      minute: '2-digit',
      second: '2-digit',
      timeZoneName: 'short'
    });
  };

  const copyToClipboard = (text: string, label: string) => {
    navigator.clipboard.writeText(text);
    toast.success(`${label} copied to clipboard`);
  };

  const downloadJSON = () => {
    const json = JSON.stringify(achTransferRecord, null, 2);
    const blob = new Blob([json], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `ach-transfer-${achTransferRecord.txn_id}.json`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
    toast.success('ACH Transfer record downloaded');
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <motion.div
        initial={{ opacity: 0, y: -20 }}
        animate={{ opacity: 1, y: 0 }}
        className="bg-gradient-to-r from-blue-600 via-indigo-600 to-purple-600 rounded-2xl p-8 text-white"
      >
        <div className="flex items-start justify-between">
          <div>
            <div className="flex items-center gap-3 mb-2">
              <Building2 className="w-10 h-10" />
              <h1 className="text-3xl font-bold">Capital One Bank NA</h1>
            </div>
            <h2 className="text-xl font-semibold mb-2">Developer Interface - ACH Transfer Records</h2>
            <p className="text-blue-100 mb-4">
              Sigma Banking Platform • Outgoing ACH Transfer Viewer • API: /enterprise/card-authorization/transactions
            </p>
            <div className="flex items-center gap-6 text-sm">
              <div className="flex items-center gap-2">
                <Shield className="w-4 h-4" />
                <span>Routing: 031176110</span>
              </div>
              <div className="flex items-center gap-2">
                <Database className="w-4 h-4" />
                <span>FDIC Insured</span>
              </div>
              <div className="flex items-center gap-2">
                <CheckCircle className="w-4 h-4" />
                <span>ACH Enabled</span>
              </div>
            </div>
          </div>
          <div className="text-right">
            <Badge className="bg-green-500 text-white text-lg px-4 py-2">
              <Zap className="w-4 h-4 mr-2 inline" />
              ACTIVE
            </Badge>
          </div>
        </div>
      </motion.div>

      {/* Transfer Summary */}
      <motion.div
        initial={{ opacity: 0, scale: 0.95 }}
        animate={{ opacity: 1, scale: 1 }}
        transition={{ delay: 0.1 }}
      >
        <Card className="border-2 border-blue-200 bg-blue-50/50">
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <ArrowRightLeft className="w-5 h-5 text-blue-600" />
              Transfer Summary
            </CardTitle>
            <CardDescription>Outgoing ACH Transfer to Capital One Bank NA</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
              <div className="p-4 bg-white rounded-lg">
                <div className="text-sm text-gray-600 mb-1">Transaction ID</div>
                <div className="font-mono text-xs font-semibold text-gray-900 break-all">
                  {achTransferRecord.txn_id}
                </div>
                <Button
                  variant="ghost"
                  size="sm"
                  className="mt-2 h-6 text-xs"
                  onClick={() => copyToClipboard(achTransferRecord.txn_id, 'Transaction ID')}
                >
                  <Copy className="w-3 h-3 mr-1" />
                  Copy
                </Button>
              </div>

              <div className="p-4 bg-white rounded-lg">
                <div className="text-sm text-gray-600 mb-1">Amount</div>
                <div className="text-2xl font-bold text-green-700">
                  {formatCurrency(achTransferRecord.amount.units)}
                </div>
                <div className="text-xs text-gray-500 mt-1">{achTransferRecord.amount.currency}</div>
              </div>

              <div className="p-4 bg-white rounded-lg">
                <div className="text-sm text-gray-600 mb-1">Ledger Effect</div>
                <Badge className={achTransferRecord.ledger_effect === 'CREDIT' ? 'bg-green-500' : 'bg-red-500'}>
                  {achTransferRecord.ledger_effect}
                </Badge>
                <div className="text-xs text-gray-500 mt-2">To Beneficiary</div>
              </div>

              <div className="p-4 bg-white rounded-lg">
                <div className="text-sm text-gray-600 mb-1">Total Transfers</div>
                <div className="text-2xl font-bold text-blue-700">
                  {formatCurrency(40000)}
                </div>
                <div className="text-xs text-gray-500 mt-1">1 transaction</div>
              </div>
            </div>
          </CardContent>
        </Card>
      </motion.div>

      {/* Account Details */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {/* Originator Account */}
        <motion.div
          initial={{ opacity: 0, x: -20 }}
          animate={{ opacity: 1, x: 0 }}
          transition={{ delay: 0.2 }}
        >
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Building2 className="w-5 h-5 text-purple-600" />
                Originator Account
              </CardTitle>
              <CardDescription>Sutton Bank NA</CardDescription>
            </CardHeader>
            <CardContent className="space-y-3">
              <div>
                <div className="text-xs text-gray-500">Institution</div>
                <div className="font-semibold text-gray-900">{achTransferRecord.originator_account.institution}</div>
              </div>
              <div>
                <div className="text-xs text-gray-500">Routing Number</div>
                <div className="font-mono font-semibold text-gray-900">{achTransferRecord.originator_account.routing_number}</div>
              </div>
              <div>
                <div className="text-xs text-gray-500">Account Token</div>
                <div className="font-mono text-sm text-gray-900">{achTransferRecord.originator_account.account_number_token}</div>
              </div>
            </CardContent>
          </Card>
        </motion.div>

        {/* Beneficiary Account */}
        <motion.div
          initial={{ opacity: 0, x: 20 }}
          animate={{ opacity: 1, x: 0 }}
          transition={{ delay: 0.2 }}
        >
          <Card className="border-2 border-blue-300">
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Building2 className="w-5 h-5 text-blue-600" />
                Beneficiary Account
              </CardTitle>
              <CardDescription>Capital One Bank NA</CardDescription>
            </CardHeader>
            <CardContent className="space-y-3">
              <div>
                <div className="text-xs text-gray-500">Institution</div>
                <div className="font-semibold text-gray-900">{achTransferRecord.beneficiary_account.institution}</div>
              </div>
              <div>
                <div className="text-xs text-gray-500">Routing Number</div>
                <div className="font-mono font-semibold text-gray-900">{achTransferRecord.beneficiary_account.routing_number}</div>
              </div>
              <div>
                <div className="text-xs text-gray-500">Account Token</div>
                <div className="font-mono text-sm text-gray-900">{achTransferRecord.beneficiary_account.account_number_token}</div>
              </div>
            </CardContent>
          </Card>
        </motion.div>
      </div>

      {/* Transaction Details */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.3 }}
      >
        <Card>
          <CardHeader>
            <div className="flex items-center justify-between">
              <div>
                <CardTitle className="flex items-center gap-2">
                  <FileText className="w-5 h-5 text-gray-700" />
                  Transaction Details
                </CardTitle>
                <CardDescription>Complete ACH transfer record with metadata</CardDescription>
              </div>
              <div className="flex gap-2">
                <Button
                  variant="outline"
                  size="sm"
                  onClick={() => setShowRawJSON(!showRawJSON)}
                >
                  {showRawJSON ? 'Hide' : 'Show'} JSON
                </Button>
                <Button
                  variant="default"
                  size="sm"
                  onClick={downloadJSON}
                  className="bg-blue-600 hover:bg-blue-700"
                >
                  <Download className="w-4 h-4 mr-2" />
                  Download
                </Button>
              </div>
            </div>
          </CardHeader>
          <CardContent className="space-y-4">
            {/* Timestamps */}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className="p-4 bg-gray-50 rounded-lg">
                <div className="flex items-center gap-2 mb-2">
                  <Clock className="w-4 h-4 text-gray-600" />
                  <div className="text-sm font-semibold text-gray-700">Event Timestamp</div>
                </div>
                <div className="text-sm text-gray-900">{formatTimestamp(achTransferRecord.event_ts)}</div>
                <div className="text-xs text-gray-500 mt-1 font-mono">{achTransferRecord.event_ts}</div>
              </div>

              <div className="p-4 bg-gray-50 rounded-lg">
                <div className="flex items-center gap-2 mb-2">
                  <Clock className="w-4 h-4 text-gray-600" />
                  <div className="text-sm font-semibold text-gray-700">Ingest Timestamp</div>
                </div>
                <div className="text-sm text-gray-900">{formatTimestamp(achTransferRecord.ingest_ts)}</div>
                <div className="text-xs text-gray-500 mt-1 font-mono">{achTransferRecord.ingest_ts}</div>
              </div>
            </div>

            <Separator />

            {/* Metadata */}
            <div>
              <div className="flex items-center gap-2 mb-3">
                <Database className="w-5 h-5 text-gray-700" />
                <h3 className="font-semibold text-gray-900">Metadata</h3>
              </div>
              <div className="space-y-3">
                <div className="p-3 bg-gray-50 rounded-lg">
                  <div className="text-xs text-gray-500 mb-1">Source</div>
                  <div className="font-mono text-sm font-semibold text-gray-900">{achTransferRecord.metadata.source}</div>
                </div>

                <div className="p-3 bg-gray-50 rounded-lg">
                  <div className="text-xs text-gray-500 mb-1">Idempotency Key</div>
                  <div className="font-mono text-xs text-gray-900 break-all">{achTransferRecord.metadata.idempotency_key}</div>
                  <Button
                    variant="ghost"
                    size="sm"
                    className="mt-2 h-6 text-xs"
                    onClick={() => copyToClipboard(achTransferRecord.metadata.idempotency_key, 'Idempotency Key')}
                  >
                    <Copy className="w-3 h-3 mr-1" />
                    Copy
                  </Button>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                  <div className="p-3 bg-gray-50 rounded-lg">
                    <div className="flex items-center gap-2 mb-1">
                      <Hash className="w-4 h-4 text-gray-600" />
                      <div className="text-xs text-gray-500">Hash</div>
                    </div>
                    <div className="font-mono text-xs text-gray-900 break-all">{achTransferRecord.metadata.hash}</div>
                  </div>

                  <div className="p-3 bg-gray-50 rounded-lg">
                    <div className="flex items-center gap-2 mb-1">
                      <Key className="w-4 h-4 text-gray-600" />
                      <div className="text-xs text-gray-500">Signature</div>
                    </div>
                    <div className="font-mono text-xs text-gray-900 break-all">{achTransferRecord.metadata.signature}</div>
                  </div>
                </div>
              </div>
            </div>

            {/* Raw JSON View */}
            {showRawJSON && (
              <motion.div
                initial={{ opacity: 0, height: 0 }}
                animate={{ opacity: 1, height: 'auto' }}
                exit={{ opacity: 0, height: 0 }}
                className="mt-4"
              >
                <Separator className="mb-4" />
                <div className="bg-gray-900 text-green-400 p-4 rounded-lg font-mono text-xs overflow-x-auto">
                  <pre>{JSON.stringify(achTransferRecord, null, 2)}</pre>
                </div>
              </motion.div>
            )}
          </CardContent>
        </Card>
      </motion.div>

      {/* Features */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.4 }}
      >
        <Card className="border-2 border-green-200 bg-green-50/50">
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <CheckCircle className="w-5 h-5 text-green-600" />
              Features
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
              {[
                '🎨 Beautiful UI with click-to-expand interactions',
                '💰 Transfer Summary showing total transfers ($40,000)',
                '🔄 Real-time ACH transfer record viewing',
                '📋 Copy-to-clipboard functionality',
                '📥 Download JSON export capability',
                '🏦 Dual account display (Originator & Beneficiary)',
                '🕐 Formatted timestamp displays',
                '🔐 Complete metadata and signature verification'
              ].map((feature, idx) => (
                <div key={idx} className="flex items-center gap-2 text-sm text-gray-700">
                  <CheckCircle className="w-4 h-4 text-green-600 flex-shrink-0" />
                  <span>{feature}</span>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      </motion.div>

      {/* API Endpoint Info */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.5 }}
      >
        <Card className="border-2 border-purple-200 bg-purple-50/50">
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Zap className="w-5 h-5 text-purple-600" />
              API Endpoint
            </CardTitle>
            <CardDescription>Capital One Bank API Integration</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="bg-gray-900 text-white p-4 rounded-lg font-mono text-sm">
              <div className="flex items-center gap-2">
                <Badge className="bg-blue-600">POST</Badge>
                <span>/enterprise/card-authorization/transactions</span>
              </div>
            </div>
            <div className="mt-3 text-sm text-gray-600">
              This endpoint handles card authorization transactions and ACH transfers for Capital One Bank NA integration.
            </div>
          </CardContent>
        </Card>
      </motion.div>
    </div>
  );
}
