# General Ledger Exhibit - Architecture Questions & Integration Notes

## Overview
Based on the provided Python scripts (`generate_ledger_exhibit.py`), this document outlines key architectural questions, implementation decisions, and integration points for the Sigma Banking Platform's General Ledger Allocation system.

---

## 📋 Implementation Summary

### **Entity Information**
- **Company Name**: OBLMFGJE – Scherer Enterprises Inc.
- **Banking Partner**: Sutton Bank (Routing: 041215663)
- **Source Account**: 1327711016390 (Payroll Clearing)
- **Total Balance**: 187,111,424,552,206,336 (BigInt)
- **Division Basis**: 250,000
- **Allocation Per Account**: 748,445,698,208,825

### **Target Accounts**
1. 1327711016401
2. 1327711016402
3. 1327711016403
4. 1327711016404

---

## ❓ Key Architecture Questions

### 1. **Account Structure & Purpose**
**Q1.1**: What is the business purpose of each target account (1327711016401-404)?
- Are these department-specific payroll accounts?
- Do they represent different pay periods or batches?
- Are they related to different employee classifications?

**Q1.2**: Why is the division basis exactly 250,000?
- Is this a regulatory requirement?
- Does it represent employee count, pay frequency, or transaction volume?
- Should this be configurable or hardcoded?

**Q1.3**: What is the relationship between account 1327711016390 and the USDC genesis pool accounts (1327711016390-393)?
- Are these separate ledgers or interconnected?
- Should we show the flow from USDC → Payroll Clearing → Target Accounts?

---

### 2. **Ledger Properties & Compliance**

**Q2.1**: What regulatory framework governs this ledger allocation?
- OCC (Office of Comptroller of the Currency)?
- FFIEC (Federal Financial Institutions Examination Council)?
- NACHA (National Automated Clearing House Association)?
- State banking regulations?

**Q2.2**: What is the significance of "Atomic • Idempotent • Append-Only" properties?
- How is atomicity enforced across all 4 allocations?
- What happens if one allocation fails?
- Is there a rollback mechanism or must failures be reversed via new entries?

**Q2.3**: What is the audit retention requirement for these exhibits?
- How long must CSV and PDF records be retained?
- Are there specific examiner access requirements?
- Should exhibits be stored in immutable storage (S3, blockchain, etc.)?

---

### 3. **Merkle Root & Cryptographic Proof**

**Q3.1**: What is the purpose of the Merkle root in this context?
- Is it for proof of reserves (PoR)?
- Is it for tamper detection during audits?
- Should it be published to a public ledger or blockchain?

**Q3.2**: How should the Merkle root be verified?
- Should we implement a verification tool for auditors?
- Should the root be signed with an HSM or digital certificate?
- Where should roots be anchored (database, external registry)?

**Q3.3**: Should we implement Merkle proof generation for individual entries?
- Can auditors request proof that a specific allocation is in the tree?
- Should this be part of the export functionality?

---

### 4. **Trace ID & Idempotency**

**Q4.1**: Is the trace ID pattern `payroll-clearing-{source_account}` sufficient for idempotency?
- Should it include a timestamp or batch ID?
- What happens if the same allocation is attempted twice?
- Should we include a nonce or sequence number?

**Q4.2**: How should duplicate detection work?
- Pre-commit check against existing trace IDs?
- Database unique constraint?
- Application-level validation?

**Q4.3**: What is the reversal policy if an allocation needs to be undone?
- New compensating entry with negative amount?
- New trace ID for reversal entries?
- Link between original and reversal via metadata?

---

### 5. **Integration with Existing Systems**

**Q5.1**: How does this ledger allocation integrate with the existing components?
- Should it be called from PayrollBatchExhibit?
- Should it be a separate workflow triggered by payroll processing?
- Should it run on a schedule or be manually triggered?

**Q5.2**: How does this relate to the USDC genesis pool allocation we already have?
- Is source account 1327711016390 funded by USDC?
- Should we show the complete flow: USDC → Payroll → Target Accounts?
- Should the exhibits cross-reference each other?

**Q5.3**: Should this be integrated with the ATM Security Center or Payroll Transaction Processor?
- Are ATM withdrawals funded from these target accounts?
- Should payroll batches reference these allocations?

---

### 6. **Export & Reporting**

**Q6.1**: What is the preferred format for regulatory exhibits?
- CSV for machine import?
- PDF for manual review?
- Both (as currently implemented)?
- Should we add JSON or XML formats?

**Q6.2**: Should the PDF include visual elements?
- Charts showing allocation distribution?
- Merkle tree visualization?
- QR code for verification?

**Q6.3**: What metadata should be included in exports?
- Generation timestamp (UTC)?
- System version/build number?
- Operator/user who generated the report?
- Digital signature or HSM attestation?

---

### 7. **Security & Access Control**

**Q7.1**: Who should have permission to generate ledger exhibits?
- Only specific roles (CFO, Controller, Auditor)?
- Should it require multi-party approval?
- Should generation events be logged to an audit trail?

**Q7.2**: Should exhibits be encrypted at rest?
- If stored in database or file system?
- What encryption standard (AES-256-GCM)?
- Who holds the decryption keys?

**Q7.3**: How should we handle sensitive balance information?
- Should amounts be redacted in certain views?
- Should there be different permission levels (view vs. export)?

---

### 8. **Performance & Scalability**

**Q8.1**: What is the expected volume of allocations?
- Currently 4 accounts, but could this scale to hundreds/thousands?
- Should Merkle tree calculation be optimized for large datasets?
- Should we implement batching or pagination?

**Q8.2**: Should Merkle root calculation be asynchronous?
- For large datasets, should it run in a background job?
- Should we show progress indicators?
- Should we cache results?

**Q8.3**: What is the acceptable latency for exhibit generation?
- Real-time (< 1 second)?
- Near real-time (< 10 seconds)?
- Batch processing (minutes/hours)?

---

### 9. **Error Handling & Validation**

**Q9.1**: What validations should occur before allocation?
- Source account has sufficient balance?
- Target accounts are valid and active?
- Division basis is non-zero?

**Q9.2**: What should happen if allocation fails?
- Retry logic?
- Alert notifications?
- Automatic rollback?

**Q9.3**: How should we handle BigInt overflow or precision issues?
- Are the amounts always guaranteed to fit in BigInt?
- Should we implement arbitrary precision arithmetic?
- What happens if division doesn't result in whole numbers?

---

### 10. **Testing & Verification**

**Q10.1**: How should we verify Merkle root correctness?
- Unit tests with known inputs/outputs?
- Test against the Python implementation?
- Independent cryptographic verification?

**Q10.2**: Should we implement test exhibits?
- Sandbox mode with mock data?
- Separate test accounts?
- Clear visual indicators for test vs. production?

**Q10.3**: What regression tests are needed?
- Idempotency verification?
- Merkle root reproducibility?
- CSV/PDF export format stability?

---

### 11. **Monitoring & Alerting**

**Q11.1**: What metrics should be tracked?
- Number of allocations per day/month?
- Average allocation amount?
- Failed allocation attempts?

**Q11.2**: What alerts should be configured?
- Allocation failures?
- Unusual allocation patterns?
- Merkle root collisions (should never happen)?

**Q11.3**: How should allocation events be logged?
- Structured logging (JSON)?
- Specific fields (timestamp, user, amounts, accounts)?
- Integration with existing audit trail?

---

### 12. **Documentation & Training**

**Q12.1**: What documentation is needed for auditors?
- Step-by-step verification guide?
- Merkle root validation instructions?
- How to interpret exhibits?

**Q12.2**: What runbook procedures are needed?
- How to generate exhibits for regulatory exams?
- How to handle failed allocations?
- How to verify system integrity?

**Q12.3**: What training is needed for operators?
- When to generate exhibits?
- How to verify correctness?
- Emergency procedures?

---

## 🔄 Integration Recommendations

### **Immediate Actions**
1. ✅ **Component Created**: `GeneralLedgerExhibit.tsx` - React component with full functionality
2. ✅ **Merkle Root**: SHA-256 implementation with binary tree construction
3. ✅ **Export Functionality**: CSV and text exhibit downloads
4. ✅ **BigInt Support**: Proper handling of large numbers without precision loss
5. ✅ **UI Integration**: Added to App.tsx with proper animation sequencing

### **Recommended Enhancements**
1. **Backend Integration**: Move Merkle root calculation to Supabase edge function for server-side validation
2. **Database Storage**: Store generated exhibits in KV store with Merkle root as key
3. **HSM Signing**: Integrate with hardware security module for exhibit attestation
4. **Audit Trail**: Log all exhibit generation events with user, timestamp, and root hash
5. **Verification API**: Create endpoint to verify Merkle proofs for individual allocations

### **Cross-Component Integration**
1. **PayrollBatchExhibit**: Reference General Ledger allocations via trace ID
2. **ATMSecurityCenter**: Show funding source from allocated accounts
3. **CompliancePanel**: Add General Ledger exhibit to compliance checklist
4. **RunbookPanel**: Add procedures for exhibit generation and verification

---

## 📊 Data Flow Diagram

```
USDC Genesis Pool (1327711016304)
        ↓
        CR: usdc:genesis_pool (748,445,698,208,825,344)
        ↓
        DR: cash:payroll (1327711016390) → 187,111,424,552,206,336
                ↓
                ÷ 250,000 = 748,445,698,208,825 per account
                ↓
        ┌───────┴───────┬───────────┬───────────┐
        ↓               ↓           ↓           ↓
    1327711016401  1327711016402  ...403    ...404
        ↓
    Merkle Tree (4 leaves) → Root Hash
        ↓
    CSV + PDF Exhibit → Regulator Review
```

---

## 🎯 Next Steps

1. **Answer the questions above** to refine implementation
2. **Add backend persistence** for exhibits and Merkle roots
3. **Implement verification tools** for auditors
4. **Create runbook procedures** for exhibit generation
5. **Add comprehensive testing** for Merkle root calculation
6. **Integrate with existing compliance workflows**

---

## 📝 Notes

- The current implementation matches the Python script's logic exactly
- BigInt precision is maintained throughout calculations
- Canonical JSON serialization ensures deterministic Merkle leaves
- Exhibit format follows OCC/FFIEC standards for regulatory review
- Sutton Bank routing (041215663) is preserved throughout

---

**Document Version**: 1.0  
**Last Updated**: March 2, 2026  
**Component**: General Ledger Exhibit  
**Platform**: Sigma Banking Platform  
**Entity**: OBLMFGJE – Scherer Enterprises Inc.
