export interface Transaction {
  id: string;
  type:
    | "deposit"
    | "topup"
    | "withdrawal"
    | "transfer"
    | "allocation";
  amount: number;
  accountNumber: string;
  walletId?: string;
  timestamp: Date;
  status: "pending" | "completed" | "failed";
  encrypted: boolean;
  encryptedHash?: string;
  description: string;
  category?: string;
}

export interface DDAAccount {
  accountNumber: string;
  accountName: string;
  balance: number;
  currency: string;
  status: "active" | "frozen" | "closed";
  createdAt: Date;
}

export interface Wallet {
  id: string;
  name: string;
  type: "upstream" | "internal" | "external";
  balance: number;
  currency: string;
  address: string;
  encrypted: boolean;
}

export interface FundAllocationRule {
  id: string;
  name: string;
  sourceAccount: string;
  destinationWallet: string;
  percentage: number;
  active: boolean;
}