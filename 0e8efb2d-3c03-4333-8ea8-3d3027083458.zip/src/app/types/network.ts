/**
 * Network Infrastructure Types
 * Copyright © 2026 VOM Services Corporation / Scherer Enterprises Inc.
 * EIN: 83-1427324
 */

export interface Network {
  id: string;
  name: string;
  cidr: string;
  vnetId?: string;
  datacenter: string;
  subnets: Subnet[];
  createdAt: string;
  metadata?: NetworkMetadata;
}

export interface Subnet {
  id: string;
  name: string;
  cidr: string;
  zone: string;
  purpose: 'compute' | 'storage' | 'management' | 'dmz' | 'hsm';
  routes?: Route[];
}

export interface Route {
  destination: string;
  gateway: string;
  priority: number;
}

export interface NetworkMetadata {
  owner: string;
  environment: 'production' | 'staging' | 'development';
  compliance: string[];
  encryption: boolean;
}

export interface Driver {
  createNetwork(net: Omit<Network, "id"|"createdAt">): Promise<Network>;
  deleteNetwork(id: string): Promise<void>;
  listNetworks(): Promise<Network[]>;
  addSubnet(networkId: string, subnet: Omit<Subnet, "id">): Promise<Subnet>;
  removeSubnet(networkId: string, subnetId: string): Promise<void>;
}
