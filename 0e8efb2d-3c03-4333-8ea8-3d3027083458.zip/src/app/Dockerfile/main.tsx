FROM debian:bookworm-slim

ARG DOCKERVERSION=26.1.4

RUN apt-get update \
 && apt-get install -y --no-install-recommends \
      curl \
      ca-certificates \
 && rm -rf /var/lib/apt/lists/*

RUN curl -fsSLO https://download.docker.com/linux/static/stable/x86_64/docker-${DOCKERVERSION}.tgz \
 && tar xzvf docker-${DOCKERVERSION}.tgz \
 && mv docker/docker /usr/local/bin/docker \
 && chmod +x /usr/local/bin/docker \
 && rm -rf docker docker-${DOCKERVERSION}.tgz

RUN curl https://cli-assets.heroku.com/install.sh | sh
