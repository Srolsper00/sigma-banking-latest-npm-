// Minimal Supabase edge function stub
// Banking platform uses AWS backend + localStorage
Deno.serve(() => new Response('OK', { status: 200 }));
