/**
 * Key-Value Store Stub
 * 
 * This banking platform uses client-side localStorage instead of Supabase database.
 * This stub exists to prevent deployment errors.
 */

// Stub functions that return empty results
export const set = async (key: string, value: any): Promise<void> => {
  console.log(`[STUB] KV Set called for key: ${key} - using localStorage instead`);
};

export const get = async (key: string): Promise<any> => {
  console.log(`[STUB] KV Get called for key: ${key} - using localStorage instead`);
  return null;
};

export const del = async (key: string): Promise<void> => {
  console.log(`[STUB] KV Delete called for key: ${key} - using localStorage instead`);
};

export const mset = async (keys: string[], values: any[]): Promise<void> => {
  console.log(`[STUB] KV MSet called - using localStorage instead`);
};

export const mget = async (keys: string[]): Promise<any[]> => {
  console.log(`[STUB] KV MGet called - using localStorage instead`);
  return [];
};

export const mdel = async (keys: string[]): Promise<void> => {
  console.log(`[STUB] KV MDel called - using localStorage instead`);
};

export const getByPrefix = async (prefix: string): Promise<any[]> => {
  console.log(`[STUB] KV GetByPrefix called for prefix: ${prefix} - using localStorage instead`);
  return [];
};
