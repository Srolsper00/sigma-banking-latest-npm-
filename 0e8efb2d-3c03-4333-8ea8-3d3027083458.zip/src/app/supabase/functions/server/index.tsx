// Supabase edge function stub - NOT USED
// Banking platform uses AWS backend + localStorage
Deno.serve(() => new Response('OK', { status: 200 }));
