/**
 * mmd02 - Network Management WebSocket & HTTP Server
 * Hybrid Deployment: Works on Vercel (HTTP) and standalone (WebSocket)
 * Copyright © 2026 VOM Services Corporation
 * Matthew James Sauls - OCIO, CCO, CEO, CFO, CTO
 */

import express from 'express';
import cors from 'cors';
import http from 'http';
import { WebSocketServer, WebSocket } from 'ws';
import EventEmitter from 'eventemitter3';

const app = express();
const PORT = parseInt(process.env.PORT || process.env.WS_PORT || '8081');
const IS_VERCEL = process.env.VERCEL === '1';

// Middleware
app.use(cors());
app.use(express.json());

// Event system
const eventBus = new EventEmitter();
const events: any[] = [];
const MAX_EVENTS = 1000;

interface NetworkEvent {
  type: string;
  payload: any;
  timestamp: string;
  source?: string;
}

// Store event
function storeEvent(event: NetworkEvent) {
  events.unshift(event);
  if (events.length > MAX_EVENTS) {
    events.pop();
  }
  eventBus.emit('event', event);
}

// HTTP API Routes
app.get('/health', (req, res) => {
  res.json({
    status: 'healthy',
    service: 'mmd02-network-management',
    timestamp: new Date().toISOString(),
    environment: IS_VERCEL ? 'vercel' : 'standalone',
    events_count: events.length
  });
});

app.get('/api/events', (req, res) => {
  const limit = parseInt(req.query.limit as string || '50');
  res.json({
    events: events.slice(0, limit),
    total: events.length,
    timestamp: new Date().toISOString()
  });
});

app.post('/api/events', (req, res) => {
  const event: NetworkEvent = {
    type: req.body.type || 'unknown',
    payload: req.body.payload || {},
    timestamp: new Date().toISOString(),
    source: 'http-api'
  };

  storeEvent(event);

  res.status(201).json({
    success: true,
    event,
    message: 'Event created and broadcasted'
  });
});

app.post('/api/network/create', (req, res) => {
  const event: NetworkEvent = {
    type: 'network.created',
    payload: req.body,
    timestamp: new Date().toISOString(),
    source: 'api'
  };

  storeEvent(event);

  res.status(201).json({
    success: true,
    network: {
      id: `net-${Date.now()}`,
      ...req.body,
      status: 'provisioning'
    }
  });
});

app.delete('/api/network/:id', (req, res) => {
  const event: NetworkEvent = {
    type: 'network.deleted',
    payload: { id: req.params.id },
    timestamp: new Date().toISOString(),
    source: 'api'
  };

  storeEvent(event);

  res.json({
    success: true,
    message: `Network ${req.params.id} deleted`
  });
});

app.post('/api/network/:id/subnet', (req, res) => {
  const event: NetworkEvent = {
    type: 'subnet.added',
    payload: {
      networkId: req.params.id,
      subnet: req.body
    },
    timestamp: new Date().toISOString(),
    source: 'api'
  };

  storeEvent(event);

  res.status(201).json({
    success: true,
    subnet: {
      id: `subnet-${Date.now()}`,
      ...req.body
    }
  });
});

app.delete('/api/network/:networkId/subnet/:subnetId', (req, res) => {
  const event: NetworkEvent = {
    type: 'subnet.removed',
    payload: {
      networkId: req.params.networkId,
      subnetId: req.params.subnetId
    },
    timestamp: new Date().toISOString(),
    source: 'api'
  };

  storeEvent(event);

  res.json({
    success: true,
    message: `Subnet ${req.params.subnetId} removed from network ${req.params.networkId}`
  });
});

// WebSocket Server (only in standalone mode)
if (!IS_VERCEL) {
  const server = http.createServer(app);
  const wss = new WebSocketServer({ server, path: '/ws' });

  wss.on('connection', (ws: WebSocket) => {
    console.log('✅ WebSocket client connected');

    // Send recent events
    ws.send(JSON.stringify({
      type: 'connection.established',
      payload: {
        message: 'Connected to mmd02 network management server',
        recent_events: events.slice(0, 10)
      },
      timestamp: new Date().toISOString()
    }));

    // Listen for new events and broadcast
    const listener = (event: NetworkEvent) => {
      if (ws.readyState === WebSocket.OPEN) {
        ws.send(JSON.stringify(event));
      }
    };

    eventBus.on('event', listener);

    ws.on('message', (message: string) => {
      try {
        const data = JSON.parse(message.toString());
        
        const event: NetworkEvent = {
          type: data.type || 'client.message',
          payload: data.payload || data,
          timestamp: new Date().toISOString(),
          source: 'websocket-client'
        };

        storeEvent(event);
      } catch (error) {
        console.error('Error parsing WebSocket message:', error);
      }
    });

    ws.on('close', () => {
      console.log('❌ WebSocket client disconnected');
      eventBus.off('event', listener);
    });

    ws.on('error', (error) => {
      console.error('WebSocket error:', error);
    });
  });

  server.listen(PORT, () => {
    console.log('🚀 mmd02 Network Management Server');
    console.log(`📡 HTTP API: http://localhost:${PORT}`);
    console.log(`🔌 WebSocket: ws://localhost:${PORT}/ws`);
    console.log(`💚 Health Check: http://localhost:${PORT}/health`);
    console.log('');
    console.log('VOM Services Corporation © 2026');
    console.log('Matthew James Sauls - OCIO, CCO, CEO, CFO, CTO');
  });
} else {
  console.log('⚡ Running on Vercel - WebSocket disabled, HTTP API only');
}

// Export for Vercel
export default app;
