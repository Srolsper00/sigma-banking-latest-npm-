/**
 * mmd02 WebSocket Server - Vercel Serverless Function
 * Network Management Event Stream
 * Copyright © 2026 VOM Services Corporation
 */

import { Server } from 'ws';
import type { VercelRequest, VercelResponse } from '@vercel/node';

// In-memory event store (consider Redis for production)
const events: any[] = [];
const clients = new Set<any>();

export default function handler(req: VercelRequest, res: VercelResponse) {
  if (req.method === 'GET' && req.headers.upgrade === 'websocket') {
    // WebSocket upgrade
    handleWebSocket(req, res);
  } else if (req.method === 'POST') {
    // HTTP endpoint to emit events
    const event = {
      type: req.body.type,
      payload: req.body.payload,
      timestamp: new Date().toISOString()
    };
    
    events.push(event);
    
    // Broadcast to all connected clients
    broadcast(event);
    
    res.status(200).json({ success: true, event });
  } else if (req.method === 'GET') {
    // Get recent events
    res.status(200).json({
      events: events.slice(-50),
      connected_clients: clients.size
    });
  } else {
    res.status(405).json({ error: 'Method not allowed' });
  }
}

function handleWebSocket(req: any, res: any) {
  // Note: Vercel doesn't support WebSocket natively
  // This is a placeholder - see alternative implementation below
  res.status(426).json({
    error: 'WebSocket upgrade not supported on Vercel serverless',
    alternative: 'Use Vercel Edge Functions or external WebSocket service'
  });
}

function broadcast(event: any) {
  clients.forEach(client => {
    try {
      if (client.readyState === 1) { // OPEN
        client.send(JSON.stringify(event));
      }
    } catch (error) {
      clients.delete(client);
    }
  });
}
