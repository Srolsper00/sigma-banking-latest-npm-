# mmd02 - Network Management WebSocket Server

**VOM Services Corporation**  
**Matthew James Sauls** - OCIO, CCO, CEO, CFO, CTO  
**EIN**: 83-1427342 | **FCC FRN**: 0033213463

---

## 🚀 Quick Start

### Prerequisites

- Node.js 18+
- npm or yarn

### Installation

```bash
# Install dependencies
npm install

# Development mode (with hot reload)
npm run dev

# Production build
npm run build

# Production mode
npm start
```

### Server Endpoints

Once running, the server will be available at:

- **HTTP API**: `http://localhost:8081`
- **WebSocket**: `ws://localhost:8081/ws`
- **Health Check**: `http://localhost:8081/health`

---

## 📡 API Documentation

### HTTP Endpoints

#### 1. Health Check

```bash
curl http://localhost:8081/health
```

Response:

```json
{
  "status": "healthy",
  "service": "mmd02-network-management",
  "timestamp": "2026-03-18T12:00:00.000Z",
  "environment": "standalone",
  "events_count": 42
}
```

#### 2. Create Network

```bash
curl -X POST http://localhost:8081/api/network/create \
  -H "Content-Type: application/json" \
  -d '{
    "name": "Production Network",
    "cidr": "10.0.0.0/16",
    "datacenter": "3xpres5 Datacenter"
  }'
```

#### 3. Delete Network

```bash
curl -X DELETE http://localhost:8081/api/network/net-123
```

#### 4. Add Subnet

```bash
curl -X POST http://localhost:8081/api/network/net-123/subnet \
  -H "Content-Type: application/json" \
  -d '{
    "name": "DMZ Subnet",
    "cidr": "10.0.1.0/24",
    "zone": "us-west-2a"
  }'
```

#### 5. Get Events

```bash
curl http://localhost:8081/api/events?limit=50
```

---

## 🔌 WebSocket Connection

### JavaScript Example

```javascript
const ws = new WebSocket('ws://localhost:8081/ws');

ws.onopen = () => {
  console.log('✅ Connected to mmd02');
};

ws.onmessage = (event) => {
  const data = JSON.parse(event.data);
  console.log('📨 Event received:', data);
};

ws.onerror = (error) => {
  console.error('❌ WebSocket error:', error);
};

ws.onclose = () => {
  console.log('🔌 Disconnected from mmd02');
};

// Send event
ws.send(JSON.stringify({
  type: 'network.create',
  payload: {
    name: 'Test Network',
    cidr: '192.168.0.0/24'
  }
}));
```

### wscat Testing

```bash
# Install wscat
npm install -g wscat

# Connect to WebSocket
wscat -c ws://localhost:8081/ws

# Send message
> {"type":"network.create","payload":{"name":"Test"}}
```

---

## 🐳 Docker Deployment

### Build Image

```bash
docker build -t mmd02:latest .
```

### Run Container

```bash
docker run -d \
  --name mmd02 \
  -p 8081:8081 \
  -e NODE_ENV=production \
  mmd02:latest
```

### Docker Compose

```yaml
version: '3.8'

services:
  mmd02:
    build: .
    ports:
      - "8081:8081"
    environment:
      - NODE_ENV=production
      - PORT=8081
    restart: unless-stopped
```

---

## ☁️ Cloud Deployment

### Railway

```bash
# Install Railway CLI
npm install -g @railway/cli

# Login
railway login

# Initialize project
railway init

# Deploy
railway up
```

### Render

1. Create `render.yaml`:

```yaml
services:
  - type: web
    name: mmd02
    env: node
    buildCommand: npm install && npm run build
    startCommand: npm start
    envVars:
      - key: NODE_ENV
        value: production
      - key: PORT
        value: 8081
```

2. Connect GitHub repo to Render
3. Deploy automatically

### Fly.io

```bash
# Install flyctl
curl -L https://fly.io/install.sh | sh

# Login
flyctl auth login

# Launch app
flyctl launch

# Deploy
flyctl deploy
```

---

## 🔧 Environment Variables

| Variable      | Default       | Description           |
| ------------- | ------------- | --------------------- |
| `PORT`        | `8081`        | HTTP server port      |
| `WS_PORT`     | `8081`        | WebSocket server port |
| `NODE_ENV`    | `development` | Environment mode      |
| `CORS_ORIGIN` | `*`           | Allowed CORS origins  |
| `MAX_EVENTS`  | `1000`        | Maximum stored events |

### Example `.env`

```bash
PORT=8081
NODE_ENV=production
CORS_ORIGIN=https://banking.vom-services.com
MAX_EVENTS=5000
```

---

## 📊 Event Types

### Network Events

- `network.created` - New network created
- `network.deleted` - Network removed
- `network.status_changed` - Network status updated

### Subnet Events

- `subnet.added` - Subnet added to network
- `subnet.removed` - Subnet removed from network

### Connection Events

- `connection.established` - Client connected to WebSocket

### Event Format

```json
{
  "type": "network.created",
  "payload": {
    "id": "net-1710763200000",
    "name": "Production Network",
    "cidr": "10.0.0.0/16",
    "status": "provisioning"
  },
  "timestamp": "2026-03-18T12:00:00.000Z",
  "source": "api"
}
```

---

## 🧪 Testing

### Run Tests

```bash
npm test
```

### Test Coverage

```bash
npm run test:coverage
```

### Integration Tests

```bash
# Start server in test mode
npm run test:server

# Run integration tests
npm run test:integration
```

---

## 📈 Monitoring

### Health Check Endpoint

```bash
# Check if server is running
curl http://localhost:8081/health

# Expected response
{
  "status": "healthy",
  "service": "mmd02-network-management",
  "timestamp": "2026-03-18T12:00:00.000Z"
}
```

### Metrics

```bash
# Get event count
curl http://localhost:8081/api/events | jq '.total'

# Get recent events
curl http://localhost:8081/api/events?limit=10
```

---

## 🔒 Security

### CORS Configuration

Edit `index.ts`:

```typescript
app.use(
  cors({
    origin:
      process.env.CORS_ORIGIN ||
      "https://banking.vom-services.com",
    methods: ["GET", "POST", "DELETE"],
    credentials: true,
  }),
);
```

### HTTPS/WSS

Use a reverse proxy (Nginx, Caddy) for TLS termination:

```nginx
server {
    listen 443 ssl;
    server_name mmd02.vom-services.com;

    ssl_certificate /path/to/cert.pem;
    ssl_certificate_key /path/to/key.pem;

    location / {
        proxy_pass http://localhost:8081;
        proxy_http_version 1.1;
        proxy_set_header Upgrade $http_upgrade;
        proxy_set_header Connection "upgrade";
    }
}
```

---

## 🛠️ Troubleshooting

### WebSocket Connection Failed

1. Check firewall rules:

```bash
sudo ufw allow 8081/tcp
```

2. Verify server is running:

```bash
curl http://localhost:8081/health
```

3. Check WebSocket endpoint:

```bash
wscat -c ws://localhost:8081/ws
```

### Port Already in Use

```bash
# Find process using port 8081
lsof -i :8081

# Kill process
kill -9 <PID>

# Or use different port
PORT=8082 npm start
```

### CORS Errors

Set allowed origins:

```bash
CORS_ORIGIN=https://your-frontend.com npm start
```

---

## 📚 Architecture

### Component Diagram

```
┌─────────────────────────────────────┐
│         mmd02 Server                │
├─────────────────────────────────────┤
│                                     │
│  ┌───────────────────────────────┐ │
│  │   Express HTTP Server         │ │
│  │   - REST API endpoints        │ │
│  │   - Health checks             │ │
│  │   - Event API                 │ │
│  └───────────────────────────────┘ │
│                                     │
│  ┌───────────────────────────────┐ │
│  │   WebSocket Server            │ │
│  │   - Real-time events          │ │
│  │   - Client management         │ │
│  │   - Event broadcasting        │ │
│  └───────────────────────────────┘ │
│                                     │
│  ┌───────────────────────────────┐ │
│  │   Event Bus (EventEmitter3)   │ │
│  │   - Event storage             │ │
│  │   - Event listeners           │ │
│  └───────────────────────────────┘ │
│                                     │
└─────────────────────────────────────┘
```

---

## 📖 Related Documentation

- [Network Management Deployment Architecture](/NETWORK_MANAGEMENT_DEPLOYMENT_ARCHITECTURE.md)
- [3xpres5 Datacenter Infrastructure](/INFRASTRUCTURE_3XPRES5_DATACENTER.md)
- [Deployment Infrastructure](/DEPLOYMENT_INFRASTRUCTURE.md)

---

## 📞 Support

**VOM Services Corporation**  
**Matthew James Sauls**  
OCIO, CCO, CEO, CFO, CTO

**EIN**: 83-1427324  
**FCC FRN**: 0033213463  
**FINRA Org ID**: TM6ZAS58-RRGKPOZW-OBLMFGJE-030961767-0033213463

---

## 📄 License

**PROPRIETARY** - © 2026 VOM Services Corporation. All Rights Reserved.

---

**Last Updated**: March 18, 2026  
**Version**: 1.0.0  
**Status**: Production Ready