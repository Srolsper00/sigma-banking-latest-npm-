# Network CLI Integration Documentation

**VOM Services Corporation**  
**Matthew James Sauls - OCIO, CCO, CEO, CFO, CTO**  
**EIN: 83-1427324 | FCC FRN: 0033213463**

---

## Overview

The Network CLI Integration provides real-time virtual network management capabilities for the Sigma Production Banking Platform. This system integrates network infrastructure control with AWS VPC schema mapping, enabling seamless management of production network resources.

## Architecture

### Components

1. **Backend Server** (`/supabase/functions/server/index.tsx`)
   - RESTful API endpoints for network management
   - AWS VPC mapping capabilities
   - CLI command execution engine
   - Persistent storage via KV store

2. **Frontend CLI Interface** (`/components/NetworkCLIInterface.tsx`)
   - Interactive terminal interface
   - Real-time network status monitoring
   - Quick command shortcuts
   - AWS VPC mapping visualization

3. **Network Types** (`/types/network.ts`)
   - TypeScript interfaces for network infrastructure
   - Driver abstraction layer
   - Subnet and route management types

## Infrastructure Details

### VNet Configuration
- **VNet ID**: `mathieu_et_favvarrow`
- **Datacenter**: 3xpres5 Datacenter - Seattle, WA
- **Default CIDR**: 10.0.0.0/16
- **Compliance**: SOC 2 Type II, PCI DSS v4.0, NIST SP 800-57

### AWS VPC Integration
- **Default Region**: us-west-2
- **Availability Zones**: us-west-2a, us-west-2b, us-west-2c
- **VPC Mapping**: Bi-directional schema mapping between local VNet and AWS VPC
- **CIDR Synchronization**: Automatic CIDR block alignment

## API Endpoints

### Network Management

#### Create Network
```
POST /make-server-4965418f/network/create
```

**Request Body:**
```json
{
  "name": "production-network",
  "cidr": "10.50.0.0/16",
  "vnetId": "mathieu_et_favvarrow",
  "datacenter": "3xpres5 Datacenter - Seattle, WA",
  "environment": "production"
}
```

**Response:**
```json
{
  "success": true,
  "network": {
    "id": "net-"aaf97b1e6c0df4d4f6c41ce00a3f4734d4dcb
bd2fdd19b50b1fc6dd84cc927f1",vomobil7",
    "name": "production-network",
    "cidr": "10.50.0.0/16",
    "vnetId": "mathieu_et_favvarrow",
    "datacenter": "3xpres5 Datacenter - Seattle, WA",
    "status": "active",
    "subnets": [],
    "routes": [],
    "createdAt": "2026-04-15T10:30:00Z",
    "metadata": {
      "owner": "VOM Services Corporation",
      "environment": "production",
      "compliance": ["SOC 2 Type II", "PCI DSS v4.0", "NIST SP 800-57"],
      "encryption": true
    }
  }
}
```

#### List Networks
```
GET /make-server-4965418f/network/list
```

**Response:**
```json
{
  "networks": [
    {
      "id": "net-1234567890-abc",
      "name": "production-network",
      "cidr": "10.50.0.0/16",
      "subnets": []
    }
  ]
}
```

#### Get Network
```
GET /make-server-4965418f/network/:id
```

#### Delete Network
```
DELETE /make-server-4965418f/network/:id
```

### Subnet Management

#### Add Subnet
```
POST /make-server-4965418f/network/:networkId/subnet
```

**Request Body:**
```json
{
  "name": "web-tier",
  "cidr": "10.50.1.0/24",
  "zone": "us-west-2a",
  "purpose": "compute"
}
```

**Response:**
```json
{
  "success": true,
  "subnet": {
    "id": "subnet-1234567890-xyz",
    "name": "web-tier",
    "cidr": "10.50.1.0/24",
    "zone": "us-west-2a",
    "purpose": "compute",
    "nodeCount": 0,
    "routes": []
  },
  "network": { ... }
}
```

#### Remove Subnet
```
DELETE /make-server-4965418f/network/:networkId/subnet/:subnetId
```

### AWS VPC Mapping

#### Create VPC Mapping
```
POST /make-server-4965418f/network/aws-vpc-map
```

**Request Body:**
```json
{
  "networkId": "net-1234567890-abc",
  "awsVpcId": "vpc-0abcd1234efgh5678",
  "region": "us-west-2",
  "availabilityZones": ["us-west-2a", "us-west-2b", "us-west-2c"]
}
```

**Response:**
```json
{
  "success": true,
  "mapping": {
    "id": "vpc-map-1713178200000",
    "networkId": "net-1234567890-abc",
    "awsVpcId": "vpc-0abcd1234efgh5678",
    "region": "us-west-2",
    "availabilityZones": ["us-west-2a", "us-west-2b", "us-west-2c"],
    "vnetMapping": {
      "local": "mathieu_et_favvarrow",
      "aws": "vpc-0abcd1234efgh5678"
    },
    "cidrMapping": {
      "local": "10.50.0.0/16",
      "aws": "10.50.0.0/16"
    },
    "createdAt": "2026-04-15T10:30:00Z",
    "status": "active"
  }
}
```

#### List VPC Mappings
```
GET /make-server-4965418f/network/aws-vpc-mappings
```

### CLI Command Execution

#### Execute CLI Command
```
POST /make-server-4965418f/network/cli
```

**Request Body:**
```json
{
  "command": "create",
  "args": {
    "name": "staging-network",
    "cidr": "10.60.0.0/16"
  }
}
```

## CLI Commands

### Available Commands

#### help
Display available commands and usage information.
```
$ help
```

#### create
Create a new virtual network.
```
$ create <name> --cidr <cidr>

Example:
$ create production-net --cidr 10.50.0.0/16
```

#### list
List all configured networks.
```
$ list
```

#### delete
Delete a network by ID.
```
$ delete <networkId>

Example:
$ delete net-1234567890-abc
```

#### subnet add
Add a subnet to an existing network.
```
$ subnet add <networkId> <name> <cidr>

Example:
$ subnet add net-1234567890-abc web-tier 10.50.1.0/24
```

#### vpc-map
Create an AWS VPC mapping for a network.
```
$ vpc-map <networkId> <awsVpcId>

Example:
$ vpc-map net-1234567890-abc vpc-0abcd1234efgh5678
```

#### show-mappings
Display all AWS VPC mappings.
```
$ show-mappings
```

#### clear
Clear the terminal output.
```
$ clear
```

## Usage Examples

### Creating a Production Network

1. **Create the network:**
   ```
   $ create production-banking-net --cidr 10.100.0.0/16
   ✓ Created network: net-1713178200000 production-banking-net 10.100.0.0/16
     VNet: mathieu_et_favvarrow | Datacenter: 3xpres5 Datacenter - Seattle, WA
   ```

2. **Add subnets:**
   ```
   $ subnet add net-1713178200000 dmz-zone 10.100.1.0/24
   ✓ Added subnet: subnet-1713178201000 10.100.1.0/24
   
   $ subnet add net-1713178200000 app-tier 10.100.2.0/24
   ✓ Added subnet: subnet-1713178202000 10.100.2.0/24
   
   $ subnet add net-1713178200000 data-tier 10.100.3.0/24
   ✓ Added subnet: subnet-1713178203000 10.100.3.0/24
   ```

3. **Map to AWS VPC:**
   ```
   $ vpc-map net-1713178200000 vpc-0abcd1234efgh5678
   ✓ AWS VPC mapping created: vpc-map-1713178204000
     Local VNet: mathieu_et_favvarrow ↔ AWS VPC: vpc-0abcd1234efgh5678
     Region: us-west-2 | AZs: us-west-2a, us-west-2b, us-west-2c, us-west-1
   ```

4. **Verify configuration:**
   ```
   $ list
   Found 1 network(s):
     net-1713178200000 | production-banking-net | 10.100.0.0/16 | subnets: 3
   
   $ show-mappings
   AWS VPC Mappings (1):
     vpc-map-1713178204000
       Network: net-1713178200000 ↔ AWS VPC: vpc-0abcd1234efgh5678
       Region: us-west-2 | Status: active
   ```

## Security and Compliance

### Encryption
- All network configurations are stored encrypted in the KV store
- TLS 1.3 encryption for all API communications
- NIST SP 800-57 cryptographic guidelines compliance

### Access Control
- Bearer token authentication required for all API endpoints
- Authorization header: `Bearer ${publicAnonKey}`
- Rate limiting and request validation

### Audit Trail
- All network operations are logged with timestamps
- Immutable audit trail for compliance requirements
- Network state changes tracked and versioned

### Compliance Standards
- **SOC 2 Type II**: Security and availability controls
- **PCI DSS v4.0**: Payment card industry data security
- **NIST SP 800-57**: Cryptographic key management
- **FFIEC**: Federal Financial Institutions Examination Council guidelines

## Integration with Existing Systems

### NULS Blockchain Integration
All network nodes support NULS blockchain integration for:
- Transaction settlement
- Cryptographic verification
- Distributed consensus

### UMB NA Banking Partner
Network infrastructure designed to support:
- ACH settlement flows
- Wire transfer processing
- Real-time payment systems
- Transaction reconciliation

### 3xpres5 Datacenter
Physical infrastructure hosted at:
- **Location**: Seattle, WA
- **Public IP**: titaniumite5
- **Certificate**: 3xpres5.crt
- **Compliance**: Level 10 cybersecurity protocols

## Monitoring and Status

### Real-Time Status Dashboard
The Network CLI interface provides:
- Active network count
- Total subnet count
- VPC mapping count
- System status indicators

### Network Health Checks
- Automatic status monitoring
- Connection validation
- Resource utilization tracking

## Troubleshooting

### Common Issues

#### Network Creation Fails
**Error**: "Network name is required"
**Solution**: Ensure you provide a network name in the create command

#### Subnet Addition Fails
**Error**: "Network not found"
**Solution**: Verify the network ID exists using the `list` command

#### VPC Mapping Error
**Error**: "Network not found"
**Solution**: Ensure the network exists before creating VPC mapping

### Debug Mode
Enable detailed logging by checking the browser console for:
- API request/response details
- Network operation results
- Error messages with stack traces

## Future Enhancements

### Planned Features
- Multi-region support
- Advanced routing configuration
- Network peering capabilities
- Automated failover mechanisms
- Performance analytics dashboard

### Integration Roadmap
- AWS Direct Connect integration
- Azure ExpressRoute support
- Google Cloud Interconnect
- Multi-cloud network orchestration

## Support and Contact

**VOM Services Corporation**  
EIN: 83-1427324  
FCC FRN: 0033213463  
FINRA Org ID: TM6ZAS58-RRGKPOZW-OBLMFGJE-030961767-0033213463

**Technical Contact:**  
Matthew James Sauls  
OCIO, CCO, CEO, CFO, CTO

---

*This documentation is maintained as part of the Sigma Production Banking Platform and is subject to change as the system evolves.*

**Last Updated:** April 15, 2026  
**Version:** 2.0.0  
**Classification:** Internal Use - Production System
