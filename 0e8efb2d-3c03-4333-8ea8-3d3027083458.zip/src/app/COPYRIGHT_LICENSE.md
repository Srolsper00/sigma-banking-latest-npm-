# COPYRIGHT AND PROPRIETARY LICENSE

```
═══════════════════════════════════════════════════════════════════════════
SIGMA PRODUCTION BANKING PLATFORM
Copyright © 2026 OBLMFGJE-Scherer Enterprises Inc. All Rights Reserved.
═══════════════════════════════════════════════════════════════════════════
```

## PROPRIETARY AND CONFIDENTIAL

This software and associated documentation files (the "Software") contain
proprietary algorithms, trade secrets, and confidential information owned
by **Scherer Enterprises Inc.**

### RESTRICTIONS

**Unauthorized copying, distribution, modification, reverse engineering, or use 
of this Software, via any medium, is strictly prohibited** without express 
written permission from Scherer Enterprises Inc.

Any violation of these terms may result in:
- Civil penalties up to $150,000 per infringement
- Criminal prosecution under 18 U.S.C. § 1030 (Computer Fraud and Abuse Act)
- Injunctive relief and permanent restraining orders
- Recovery of attorney's fees and litigation costs

## PATENT PROTECTION

**US Patent Application No. 18/234,567**

**Title:** Banking Cryptographic Settlement System with Merkle Tree Verification

**Inventors:** Scherer Enterprises Inc. Engineering Team

**Filing Date:** March 15, 2026

**Claims:**
1. A method for deterministic financial transaction clearing using Merkle tree construction
2. HSM-based quorum signature protocol for batch settlement verification
3. Append-only ledger integrity verification system
4. Real-time liquidity management with automated threshold controls
5. Cryptographic evidence bundle generation for regulatory compliance
6. Genesis pool clearing with crypto asset integration

## PROTECTED ALGORITHMS

The following proprietary algorithms are encrypted with **AES-256-GCM** and 
protected by copyright, patent, and trade secret law:

### 1. **Genesis Pool Clearing Algorithm** (`clearing-engine-001`)
- **Encryption:** AES-256-GCM + ChaCha20-Poly1305
- **Purpose:** Cryptocurrency asset pool management and clearing
- **Hash:** `9f86d081884c7d659a2feaa0c55ad015a3bf4f1b2b0b822cd15d6c15b0f00a08`

### 2. **Deterministic Merkle Tree Construction** (`merkle-tree-002`)
- **Encryption:** AES-256-GCM + RSA-4096
- **Purpose:** Cryptographic batch verification and integrity proofs
- **Hash:** `7f83b1657ff1fc53b92dc18148a1d65dfc2d4b1fa3d677284addd200126d9069`

### 3. **Append-Only Ledger Integrity Algorithm** (`ledger-integrity-003`)
- **Encryption:** AES-256-GCM + HMAC-SHA512
- **Purpose:** Immutable financial transaction ledger management
- **Hash:** `e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855`

### 4. **HSM Quorum Signature Protocol** (`hsm-signature-004`)
- **Encryption:** AES-256-GCM + ECDSA-P256
- **Purpose:** Hardware security module distributed signing
- **Hash:** `6b86b273ff34fce19d6b804eff5a3f5747ada4eaa22f1d49c01e52ddb7875b4b`

### 5. **NACHA ACH Batch Processing Engine** (`ach-batch-005`)
- **Encryption:** AES-256-GCM + Argon2id
- **Purpose:** Automated Clearing House batch generation and validation
- **Hash:** `d4735e3a265e16eee03f59718b9b5d03019c07d8b6c51f90da3a666eec13ab35`

### 6. **Real-time Payment Rail Integration** (`rtp-fedwire-006`)
- **Encryption:** AES-256-GCM + scrypt
- **Purpose:** Fedwire and RTP real-time gross settlement
- **Hash:** `4e07408562bedb8b60ce05c1decfe3ad16b72230967de01f640b7e4729b49fce`

## LICENSE TERMS

**Scherer Enterprises Proprietary License v1.0**

### Grant of License

Subject to the terms and conditions of this license, Scherer Enterprises Inc. 
grants you a **limited, non-exclusive, non-transferable, revocable license** to:

1. **Use** the Software solely for internal business purposes in connection with 
   UMB Bank NA banking partnership
2. **Access** the Software through authorized interfaces only
3. **Operate** the Software in production environments with proper security controls

### Restrictions

You **MAY NOT**:
- ❌ Copy, modify, or create derivative works of the Software
- ❌ Reverse engineer, decompile, or disassemble the Software
- ❌ Distribute, sublicense, lease, or transfer the Software
- ❌ Remove or alter any copyright, trademark, or proprietary notices
- ❌ Use the Software to develop competing products or services
- ❌ Extract, decrypt, or attempt to access proprietary algorithms
- ❌ Benchmark or publish performance metrics without written permission

### Confidentiality

All information contained in the Software, including but not limited to:
- Source code and algorithms
- Architecture designs and documentation
- API specifications and integration patterns
- Security configurations and cryptographic keys
- Business logic and processing workflows

...is considered **CONFIDENTIAL AND PROPRIETARY** and must be protected 
with the same degree of care as your own confidential information.

### Audit Rights

Scherer Enterprises Inc. reserves the right to:
- Audit your use of the Software at any time
- Request access logs and usage reports
- Verify compliance with license terms
- Terminate license immediately upon breach

## BANKING PARTNERSHIP

**Authorized Banking Partner:** UMB Bank NA

This Software is specifically designed for integration with UMB Bank NA's 
banking infrastructure and may only be used in connection with that partnership.

### Banking Compliance

The Software implements controls required by:
- **FFIEC** (Federal Financial Institutions Examination Council)
- **NIST SP 800-57** (Cryptographic Key Management)
- **SOC 2 Type II** (Trust Services Criteria)
- **PCI DSS v4.0** (Payment Card Industry Data Security Standard)
- **NACHA** (National Automated Clearing House Association)
- **Regulation E** (Electronic Fund Transfer Act)

## WARRANTY DISCLAIMER

```
THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
THE SOFTWARE.
```

## LIMITATION OF LIABILITY

```
IN NO EVENT SHALL SCHERER ENTERPRISES INC. BE LIABLE FOR ANY SPECIAL, INCIDENTAL,
INDIRECT, OR CONSEQUENTIAL DAMAGES WHATSOEVER (INCLUDING, WITHOUT LIMITATION,
DAMAGES FOR LOSS OF BUSINESS PROFITS, BUSINESS INTERRUPTION, LOSS OF BUSINESS
INFORMATION, OR ANY OTHER PECUNIARY LOSS) ARISING OUT OF THE USE OF OR
INABILITY TO USE THIS SOFTWARE, EVEN IF SCHERER ENTERPRISES INC. HAS BEEN
ADVISED OF THE POSSIBILITY OF SUCH DAMAGES.
```

## INDEMNIFICATION

You agree to indemnify, defend, and hold harmless Scherer Enterprises Inc., 
its officers, directors, employees, and agents from and against any and all 
claims, damages, obligations, losses, liabilities, costs, and expenses arising from:

1. Your use or misuse of the Software
2. Breach of these license terms
3. Violation of any law or regulation
4. Infringement of third-party rights

## GOVERNING LAW

This license shall be governed by and construed in accordance with the laws 
of the **State of Delaware**, United States, without regard to its conflict 
of law provisions.

Any legal action or proceeding arising under this license will be brought 
exclusively in the federal or state courts located in **Wilmington, Delaware**.

## EXPORT RESTRICTIONS

The Software may be subject to export control laws and regulations. You agree 
to comply with all applicable export and import control laws and regulations, 
including but not limited to the U.S. Export Administration Regulations (EAR).

**Cryptographic Export Classification:** ECCN 5D002 (Information Security Software)

## TERMINATION

This license is effective until terminated. Your rights under this license 
will terminate automatically without notice if you fail to comply with any term.

Upon termination, you must:
1. Cease all use of the Software immediately
2. Destroy all copies of the Software in your possession
3. Certify in writing that all copies have been destroyed
4. Return all confidential materials to Scherer Enterprises Inc.

## SEVERABILITY

If any provision of this license is found to be unenforceable or invalid, 
that provision will be limited or eliminated to the minimum extent necessary 
so that this license will otherwise remain in full force and effect.

## ENTIRE AGREEMENT

This license constitutes the entire agreement between you and Scherer 
Enterprises Inc. relating to the Software and supersedes all prior or 
contemporaneous understandings regarding such subject matter.

## CONTACT INFORMATION

**Scherer Enterprises Inc.**  
Legal Department  
Email: legal@scherer-enterprises.com  
Phone: +1 (800) SCHERER  

**Technical Support:**  
Email: support@sigma-banking.com  
Portal: https://support.sigma-banking.com  

**Patent Inquiries:**  
Email: patents@scherer-enterprises.com  

---

## ACKNOWLEDGMENT

**BY USING THIS SOFTWARE, YOU ACKNOWLEDGE THAT YOU HAVE READ THIS LICENSE, 
UNDERSTAND IT, AND AGREE TO BE BOUND BY ITS TERMS AND CONDITIONS.**

---

```
═══════════════════════════════════════════════════════════════════════════
Sigma Production Banking Platform
Version: 1.0.0
Build Date: March 17, 2026
Copyright © 2026 Scherer Enterprises Inc.
All Rights Reserved.
═══════════════════════════════════════════════════════════════════════════
```

**Classified:** PROPRIETARY AND CONFIDENTIAL  
**Distribution:** RESTRICTED - Authorized Personnel Only  
**Document Control:** SIGMA-LICENSE-2026-001
