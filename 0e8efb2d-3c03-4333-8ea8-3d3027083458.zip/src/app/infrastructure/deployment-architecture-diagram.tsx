/**
 * Complete Deployment Architecture Diagram
 * Sigma Production Banking Platform
 * 
 * Visual representation of Vercel → mmd02 → AWS infrastructure
 */

import React from 'react';
import { Server, Database, Cloud, Shield, Network, HardDrive, Lock, Globe } from 'lucide-react';

export function DeploymentArchitectureDiagram() {
  return (
    <div className="p-6 bg-gradient-to-br from-slate-900 to-slate-800 rounded-lg">
      <h2 className="text-2xl font-bold text-white mb-6 flex items-center gap-2">
        <Network className="w-6 h-6" />
        Deployment Architecture: Vercel + AWS + mmd02
      </h2>

      {/* Architecture Layers */}
      <div className="space-y-8">
        
        {/* Layer 1: Frontend - Vercel */}
        <div className="bg-blue-900/30 border-2 border-blue-500 rounded-lg p-6">
          <div className="flex items-center gap-3 mb-4">
            <Globe className="w-8 h-8 text-blue-400" />
            <h3 className="text-xl font-bold text-blue-300">Layer 1: Frontend (Vercel)</h3>
          </div>
          <div className="grid grid-cols-3 gap-4">
            <div className="bg-blue-800/40 p-4 rounded">
              <div className="text-blue-200 font-semibold mb-2">React Application</div>
              <ul className="text-sm text-blue-300 space-y-1">
                <li>• Vite build system</li>
                <li>• React Router</li>
                <li>• Tailwind CSS</li>
                <li>• 8-tab banking interface</li>
              </ul>
            </div>
            <div className="bg-blue-800/40 p-4 rounded">
              <div className="text-blue-200 font-semibold mb-2">Edge Config</div>
              <ul className="text-sm text-blue-300 space-y-1">
                <li>• Region: iad1 (US East)</li>
                <li>• Edge Functions</li>
                <li>• API Rewrites → mmd02</li>
                <li>• WebSocket proxy</li>
              </ul>
            </div>
            <div className="bg-blue-800/40 p-4 rounded">
              <div className="text-blue-200 font-semibold mb-2">Security</div>
              <ul className="text-sm text-blue-300 space-y-1">
                <li>• TLS 1.3 (3xpres5.crt)</li>
                <li>• CSP headers</li>
                <li>• CORS configured</li>
                <li>• X-Frame-Options: DENY</li>
              </ul>
            </div>
          </div>
        </div>

        {/* Connection Arrow */}
        <div className="flex justify-center">
          <div className="bg-gradient-to-b from-blue-500 to-green-500 w-1 h-12 relative">
            <div className="absolute -bottom-2 left-1/2 -translate-x-1/2 text-yellow-400 text-xs whitespace-nowrap bg-slate-800 px-2 py-1 rounded">
              HTTPS/WSS → mmd02:8080/8081
            </div>
          </div>
        </div>

        {/* Layer 2: API Gateway - mmd02 Server */}
        <div className="bg-green-900/30 border-2 border-green-500 rounded-lg p-6">
          <div className="flex items-center gap-3 mb-4">
            <Server className="w-8 h-8 text-green-400" />
            <h3 className="text-xl font-bold text-green-300">Layer 2: API Gateway (mmd02 Server)</h3>
          </div>
          <div className="grid grid-cols-4 gap-4">
            <div className="bg-green-800/40 p-4 rounded">
              <div className="text-green-200 font-semibold mb-2">Server Specs</div>
              <ul className="text-sm text-green-300 space-y-1">
                <li>• c6i.2xlarge</li>
                <li>• 8 vCPU, 16GB RAM</li>
                <li>• 25 Gbps network</li>
                <li>• Private: 10.0.10.50</li>
                <li>• Public: titaniumite5</li>
              </ul>
            </div>
            <div className="bg-green-800/40 p-4 rounded">
              <div className="text-green-200 font-semibold mb-2">Services</div>
              <ul className="text-sm text-green-300 space-y-1">
                <li>• API Gateway :8080</li>
                <li>• WebSocket :8081</li>
                <li>• Coordinator :8082</li>
                <li>• Health checks</li>
              </ul>
            </div>
            <div className="bg-green-800/40 p-4 rounded">
              <div className="text-green-200 font-semibold mb-2">VPC Integration</div>
              <ul className="text-sm text-green-300 space-y-1">
                <li>• vpc-sigma-prod</li>
                <li>• subnet-priv-1a</li>
                <li>• sg-processor-tier</li>
                <li>• sg-vercel-app</li>
              </ul>
            </div>
            <div className="bg-green-800/40 p-4 rounded">
              <div className="text-green-200 font-semibold mb-2">Upstreams</div>
              <ul className="text-sm text-green-300 space-y-1">
                <li>• Aurora cluster</li>
                <li>• DynamoDB VPC endpoint</li>
                <li>• S3 VPC endpoint</li>
                <li>• Supabase private</li>
                <li>• Processor ALB</li>
              </ul>
            </div>
          </div>
        </div>

        {/* Connection Arrows - Multiple paths */}
        <div className="grid grid-cols-4 gap-4">
          <div className="flex flex-col items-center">
            <div className="bg-gradient-to-b from-green-500 to-purple-500 w-1 h-12"></div>
            <div className="text-purple-400 text-xs mt-2">Aurora :5432</div>
          </div>
          <div className="flex flex-col items-center">
            <div className="bg-gradient-to-b from-green-500 to-orange-500 w-1 h-12"></div>
            <div className="text-orange-400 text-xs mt-2">DynamoDB HTTPS</div>
          </div>
          <div className="flex flex-col items-center">
            <div className="bg-gradient-to-b from-green-500 to-cyan-500 w-1 h-12"></div>
            <div className="text-cyan-400 text-xs mt-2">S3 HTTPS</div>
          </div>
          <div className="flex flex-col items-center">
            <div className="bg-gradient-to-b from-green-500 to-pink-500 w-1 h-12"></div>
            <div className="text-pink-400 text-xs mt-2">Supabase :5432</div>
          </div>
        </div>

        {/* Layer 3: Data Layer - AWS Services */}
        <div className="bg-slate-700/30 border-2 border-slate-400 rounded-lg p-6">
          <div className="flex items-center gap-3 mb-4">
            <Database className="w-8 h-8 text-slate-300" />
            <h3 className="text-xl font-bold text-slate-200">Layer 3: Data Layer (AWS)</h3>
          </div>
          <div className="grid grid-cols-4 gap-4">
            
            {/* Aurora */}
            <div className="bg-purple-800/40 border border-purple-500 p-4 rounded">
              <div className="text-purple-200 font-semibold mb-2 flex items-center gap-2">
                <Database className="w-4 h-4" />
                Aurora PostgreSQL
              </div>
              <ul className="text-sm text-purple-300 space-y-1">
                <li>• db.r6g.2xlarge × 3</li>
                <li>• Multi-AZ cluster</li>
                <li>• Primary databases:</li>
                <li className="ml-2">- Transactions</li>
                <li className="ml-2">- Accounts</li>
                <li className="ml-2">- Compliance</li>
                <li className="ml-2">- Audit trails</li>
                <li className="ml-2">- Genesis pool</li>
                <li className="ml-2">- Reconciliation</li>
              </ul>
            </div>

            {/* DynamoDB */}
            <div className="bg-orange-800/40 border border-orange-500 p-4 rounded">
              <div className="text-orange-200 font-semibold mb-2 flex items-center gap-2">
                <HardDrive className="w-4 h-4" />
                DynamoDB
              </div>
              <ul className="text-sm text-orange-300 space-y-1">
                <li>• High-speed tables:</li>
                <li className="ml-2">- Transactions</li>
                <li className="ml-2">- Audit logs</li>
                <li className="ml-2">- Sessions</li>
                <li className="ml-2">- Genesis pool</li>
                <li>• Point-in-time recovery</li>
                <li>• Streams enabled</li>
                <li>• GSI: Account, Status</li>
              </ul>
            </div>

            {/* S3 */}
            <div className="bg-cyan-800/40 border border-cyan-500 p-4 rounded">
              <div className="text-cyan-200 font-semibold mb-2 flex items-center gap-2">
                <Cloud className="w-4 h-4" />
                S3 Buckets
              </div>
              <ul className="text-sm text-cyan-300 space-y-1">
                <li>• Documents bucket:</li>
                <li className="ml-2">- Compliance docs</li>
                <li className="ml-2">- Audit exports</li>
                <li className="ml-2">- GL exhibits</li>
                <li className="ml-2">- 3xpres5.crt</li>
                <li>• Crypto assets bucket</li>
                <li>• Object lock: 7 years</li>
                <li>• Lifecycle: Glacier</li>
              </ul>
            </div>

            {/* Supabase Limited */}
            <div className="bg-pink-800/40 border border-pink-500 p-4 rounded">
              <div className="text-pink-200 font-semibold mb-2 flex items-center gap-2">
                <Lock className="w-4 h-4" />
                Supabase (Limited)
              </div>
              <ul className="text-sm text-pink-300 space-y-1">
                <li>• <strong>ONLY:</strong> PRIVAT_ADMIN_CERT</li>
                <li>• Schema: PRIVATE</li>
                <li>• Tables:</li>
                <li className="ml-2">- admin_certificates</li>
                <li className="ml-2">- cert_revocations</li>
                <li className="ml-2">- cert_audit</li>
                <li>• Private VPC endpoint</li>
                <li>• No public access</li>
                <li>• AES-256-GCM encrypt</li>
              </ul>
            </div>
          </div>
        </div>

        {/* VPC Network Diagram */}
        <div className="bg-indigo-900/30 border-2 border-indigo-500 rounded-lg p-6">
          <div className="flex items-center gap-3 mb-4">
            <Shield className="w-8 h-8 text-indigo-400" />
            <h3 className="text-xl font-bold text-indigo-300">VPC Network (mathieu_et_favvarrow)</h3>
          </div>
          <div className="grid grid-cols-3 gap-4">
            <div className="bg-indigo-800/40 p-4 rounded">
              <div className="text-indigo-200 font-semibold mb-2">Public Subnets</div>
              <ul className="text-sm text-indigo-300 space-y-1">
                <li>• 10.0.1.0/24 (us-east-1a)</li>
                <li>• 10.0.2.0/24 (us-east-1b)</li>
                <li>• 10.0.3.0/24 (us-east-1c)</li>
                <li>• Internet Gateway</li>
                <li>• NAT Gateways</li>
              </ul>
            </div>
            <div className="bg-indigo-800/40 p-4 rounded">
              <div className="text-indigo-200 font-semibold mb-2">Private Subnets</div>
              <ul className="text-sm text-indigo-300 space-y-1">
                <li>• 10.0.10.0/24 (us-east-1a)</li>
                <li>• 10.0.11.0/24 (us-east-1b)</li>
                <li>• 10.0.12.0/24 (us-east-1c)</li>
                <li>• mmd02: 10.0.10.50</li>
                <li>• Processors: c6i.4xlarge</li>
              </ul>
            </div>
            <div className="bg-indigo-800/40 p-4 rounded">
              <div className="text-indigo-200 font-semibold mb-2">Database Subnets</div>
              <ul className="text-sm text-indigo-300 space-y-1">
                <li>• 10.0.20.0/24 (us-east-1a)</li>
                <li>• 10.0.21.0/24 (us-east-1b)</li>
                <li>• 10.0.22.0/24 (us-east-1c)</li>
                <li>• Aurora cluster</li>
                <li>• Isolated from internet</li>
              </ul>
            </div>
          </div>
        </div>

        {/* Key Features */}
        <div className="bg-yellow-900/30 border-2 border-yellow-500 rounded-lg p-6">
          <h3 className="text-xl font-bold text-yellow-300 mb-4">🔑 Key Architecture Features</h3>
          <div className="grid grid-cols-2 gap-4">
            <ul className="text-sm text-yellow-200 space-y-2">
              <li>✅ <strong>Vercel:</strong> Global CDN, Edge Functions, Zero-downtime deploys</li>
              <li>✅ <strong>mmd02:</strong> API Gateway, WebSocket server, Processor coordinator</li>
              <li>✅ <strong>Aurora:</strong> Multi-AZ, Auto-scaling, 35-day backups</li>
              <li>✅ <strong>DynamoDB:</strong> Single-digit ms latency, Auto-scaling, Streams</li>
            </ul>
            <ul className="text-sm text-yellow-200 space-y-2">
              <li>✅ <strong>S3:</strong> Versioned, Encrypted, Lifecycle policies, Glacier archival</li>
              <li>✅ <strong>Supabase:</strong> Certificate-only, Private VPC, Row-level security</li>
              <li>✅ <strong>Security:</strong> TLS 1.3, VPC isolation, Security groups, NACLs</li>
              <li>✅ <strong>Monitoring:</strong> CloudWatch, Vercel Analytics, Custom metrics</li>
            </ul>
          </div>
        </div>

        {/* Data Flow */}
        <div className="bg-slate-600/30 border-2 border-slate-400 rounded-lg p-4">
          <h3 className="text-lg font-bold text-slate-200 mb-3">📊 Request Flow Example</h3>
          <div className="flex items-center gap-2 text-sm text-slate-300 overflow-x-auto pb-2">
            <div className="bg-blue-700 px-3 py-2 rounded whitespace-nowrap">User → Vercel</div>
            <div className="text-blue-400">→</div>
            <div className="bg-green-700 px-3 py-2 rounded whitespace-nowrap">Edge Function</div>
            <div className="text-green-400">→</div>
            <div className="bg-green-700 px-3 py-2 rounded whitespace-nowrap">mmd02:8080</div>
            <div className="text-yellow-400">→</div>
            <div className="bg-purple-700 px-3 py-2 rounded whitespace-nowrap">Aurora Query</div>
            <div className="text-purple-400">→</div>
            <div className="bg-orange-700 px-3 py-2 rounded whitespace-nowrap">DynamoDB Write</div>
            <div className="text-cyan-400">→</div>
            <div className="bg-cyan-700 px-3 py-2 rounded whitespace-nowrap">S3 Export</div>
            <div className="text-green-400">→</div>
            <div className="bg-green-700 px-3 py-2 rounded whitespace-nowrap">mmd02 Response</div>
            <div className="text-blue-400">→</div>
            <div className="bg-blue-700 px-3 py-2 rounded whitespace-nowrap">Vercel → User</div>
          </div>
        </div>
      </div>
    </div>
  );
}

export default DeploymentArchitectureDiagram;
