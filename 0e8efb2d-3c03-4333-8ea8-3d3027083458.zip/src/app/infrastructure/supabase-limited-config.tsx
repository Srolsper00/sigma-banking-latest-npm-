/**
 * Supabase Limited Configuration
 * Sigma Production Banking Platform
 * 
 * Supabase ONLY handles PRIVAT_ADMIN_CERT.PRIVATE tables
 * All other data uses Aurora/DynamoDB/S3
 */

export const SupabaseLimitedConfig = {
  projectId: "masribasluchcclghsgc",
  region: "us-east-1",
  
  // Limited Role: Only private admin certificates
  scope: "PRIVAT_ADMIN_CERT.PRIVATE",
  
  // VPC Integration
  vpc: {
    enabled: true,
    vpcId: "vpc-sigma-prod-banking",
    subnetGroup: "subnet-group-database",
    securityGroup: "sg-supabase-private",
    privateLink: {
      enabled: true,
      endpointId: "vpce-supabase-private-cert"
    }
  },
  
  // Database Schema - ONLY Admin Certificates
  database: {
    schema: "PRIVAT_ADMIN_CERT",
    tables: {
      // Private Admin Certificate Store
      PRIVATE: {
        tableName: "admin_certificates",
        columns: [
          { name: "cert_id", type: "uuid", primaryKey: true },
          { name: "admin_user_id", type: "uuid", indexed: true },
          { name: "certificate_type", type: "text" },
          { name: "cert_data", type: "bytea", encrypted: true },
          { name: "public_key", type: "text" },
          { name: "private_key_encrypted", type: "bytea", encrypted: true },
          { name: "issuer", type: "text", default: "UMB NA" },
          { name: "subject_dn", type: "text" },
          { name: "serial_number", type: "text", unique: true },
          { name: "not_before", type: "timestamptz" },
          { name: "not_after", type: "timestamptz" },
          { name: "revoked", type: "boolean", default: false },
          { name: "revocation_date", type: "timestamptz", nullable: true },
          { name: "revocation_reason", type: "text", nullable: true },
          { name: "created_at", type: "timestamptz", default: "now()" },
          { name: "updated_at", type: "timestamptz", default: "now()" },
          { name: "created_by", type: "uuid" },
          { name: "audit_trail", type: "jsonb" }
        ],
        indexes: [
          { name: "idx_admin_user", columns: ["admin_user_id"] },
          { name: "idx_serial", columns: ["serial_number"], unique: true },
          { name: "idx_expiry", columns: ["not_after"] },
          { name: "idx_revoked", columns: ["revoked"] }
        ],
        rls: {
          enabled: true,
          policies: [
            {
              name: "admin_only_access",
              command: "ALL",
              roles: ["admin_role"],
              using: "auth.uid() IN (SELECT user_id FROM admin_users)"
            }
          ]
        }
      },
      
      // Certificate Revocation List
      certificate_revocations: {
        tableName: "certificate_revocations",
        columns: [
          { name: "revocation_id", type: "uuid", primaryKey: true },
          { name: "cert_id", type: "uuid", foreignKey: "admin_certificates.cert_id" },
          { name: "revoked_at", type: "timestamptz", default: "now()" },
          { name: "revoked_by", type: "uuid" },
          { name: "reason_code", type: "integer" },
          { name: "reason_text", type: "text" },
          { name: "crl_entry", type: "jsonb" }
        ]
      },
      
      // Certificate Audit Log
      certificate_audit: {
        tableName: "certificate_audit",
        columns: [
          { name: "audit_id", type: "uuid", primaryKey: true },
          { name: "cert_id", type: "uuid" },
          { name: "action", type: "text" },
          { name: "actor_id", type: "uuid" },
          { name: "timestamp", type: "timestamptz", default: "now()" },
          { name: "ip_address", type: "inet" },
          { name: "user_agent", type: "text" },
          { name: "details", type: "jsonb" }
        ],
        indexes: [
          { name: "idx_cert_audit", columns: ["cert_id", "timestamp"] },
          { name: "idx_actor_audit", columns: ["actor_id", "timestamp"] }
        ]
      }
    }
  },
  
  // Encryption Configuration
  encryption: {
    atRest: {
      enabled: true,
      algorithm: "AES-256-GCM",
      kmsProvider: "AWS",
      kmsKeyId: "arn:aws:kms:us-east-1:ACCOUNT:key/sigma-supabase-key"
    },
    inTransit: {
      enabled: true,
      tlsVersion: "1.3",
      certificate: "3xpres5.crt",
      cipherSuites: [
        "TLS_AES_256_GCM_SHA384",
        "TLS_CHACHA20_POLY1305_SHA256"
      ]
    },
    columnLevel: {
      enabled: true,
      encryptedColumns: [
        "cert_data",
        "private_key_encrypted"
      ]
    }
  },
  
  // Access Control
  access: {
    // Restrict to processor tier only
    allowedSources: [
      "sg-processor-tier",
      "10.0.10.0/24",  // Private subnet 1a
      "10.0.11.0/24",  // Private subnet 1b
      "10.0.12.0/24"   // Private subnet 1c
    ],
    
    // No public access
    publicAccess: false,
    
    // API access limited to certificate operations
    apiEndpoints: {
      enabled: [
        "/rest/v1/admin_certificates",
        "/rest/v1/certificate_revocations",
        "/rest/v1/certificate_audit"
      ],
      disabled: [
        "/rest/v1/*"  // All other endpoints
      ]
    }
  },
  
  // Connection Pooling
  connectionPool: {
    mode: "transaction",
    poolSize: 50,
    maxClientConn: 200,
    defaultPoolSize: 20
  },
  
  // Backup Configuration
  backup: {
    enabled: true,
    schedule: "0 2 * * *",  // Daily at 2 AM
    retention: 35,  // 35 days
    destination: "s3://sigma-banking-documents/backups/supabase/",
    encryption: true
  },
  
  // Monitoring
  monitoring: {
    cloudwatch: {
      enabled: true,
      namespace: "Sigma/Supabase",
      metrics: [
        "DatabaseConnections",
        "CertificateOperations",
        "FailedAuthentications",
        "QueryLatency"
      ]
    },
    alarms: [
      {
        name: "HighConnectionCount",
        metric: "DatabaseConnections",
        threshold: 180,
        evaluationPeriods: 2
      },
      {
        name: "UnauthorizedAccess",
        metric: "FailedAuthentications",
        threshold: 10,
        evaluationPeriods: 1
      }
    ]
  },
  
  // Integration with Main Backend
  integration: {
    aurora: {
      enabled: false,
      description: "Supabase does NOT sync with Aurora - separate concerns"
    },
    dynamodb: {
      enabled: false,
      description: "Supabase does NOT sync with DynamoDB - separate concerns"
    },
    s3: {
      enabled: true,
      description: "Certificates can be exported to S3 for backup only",
      backupBucket: "sigma-banking-documents",
      backupPrefix: "certificates/"
    }
  }
};

export default SupabaseLimitedConfig;
