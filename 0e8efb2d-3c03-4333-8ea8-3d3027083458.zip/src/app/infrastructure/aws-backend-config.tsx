/**
 * AWS Backend Infrastructure Configuration
 * Sigma Production Banking Platform
 * 
 * Processor tier with Aurora, DynamoDB, and S3 containers
 */

export const BackendConfig = {
  // Aurora Database Configuration
  aurora: {
    clusterIdentifier: "sigma-banking-aurora-cluster",
    engine: "aurora-postgresql",
    engineVersion: "15.4",
    instanceClass: "db.r6g.2xlarge",
    instances: [
      { id: "sigma-aurora-1a", az: "us-east-1a", type: "writer" },
      { id: "sigma-aurora-1b", az: "us-east-1b", type: "reader" },
      { id: "sigma-aurora-1c", az: "us-east-1c", type: "reader" }
    ],
    subnetGroup: "subnet-group-database",
    securityGroup: "sg-database-tier",
    backupRetention: 35,
    preferredBackupWindow: "03:00-04:00",
    encryption: {
      enabled: true,
      kmsKeyId: "arn:aws:kms:us-east-1:ACCOUNT:key/sigma-banking-key"
    },
    
    // Database Schema
    databases: {
      primary: {
        name: "sigma_banking_prod",
        schemas: [
          "transactions",
          "accounts",
          "compliance",
          "audit_trail",
          "genesis_pool",
          "reconciliation"
        ]
      },
      analytics: {
        name: "sigma_banking_analytics",
        schemas: [
          "reporting",
          "metrics"
        ]
      }
    },
    
    // Connection Configuration
    endpoint: {
      writer: "sigma-banking-aurora-cluster.cluster-xyz.us-east-1.rds.amazonaws.com",
      reader: "sigma-banking-aurora-cluster.cluster-ro-xyz.us-east-1.rds.amazonaws.com",
      port: 5432
    }
  },
  
  // DynamoDB Configuration
  dynamodb: {
    tables: [
      {
        name: "SigmaBanking-Transactions",
        partitionKey: { name: "transactionId", type: "S" },
        sortKey: { name: "timestamp", type: "N" },
        billingMode: "PROVISIONED",
        readCapacity: 1000,
        writeCapacity: 500,
        pointInTimeRecovery: true,
        encryption: { enabled: true },
        globalSecondaryIndexes: [
          {
            name: "AccountIndex",
            partitionKey: { name: "accountId", type: "S" },
            sortKey: { name: "timestamp", type: "N" },
            projection: "ALL"
          },
          {
            name: "StatusIndex",
            partitionKey: { name: "status", type: "S" },
            sortKey: { name: "timestamp", type: "N" },
            projection: "KEYS_ONLY"
          }
        ],
        streamEnabled: true,
        streamViewType: "NEW_AND_OLD_IMAGES"
      },
      {
        name: "SigmaBanking-AuditLog",
        partitionKey: { name: "eventId", type: "S" },
        sortKey: { name: "timestamp", type: "N" },
        billingMode: "PAY_PER_REQUEST",
        timeToLive: { enabled: true, attribute: "expirationTime" },
        pointInTimeRecovery: true,
        encryption: { enabled: true }
      },
      {
        name: "SigmaBanking-Sessions",
        partitionKey: { name: "sessionId", type: "S" },
        billingMode: "PAY_PER_REQUEST",
        timeToLive: { enabled: true, attribute: "ttl" },
        encryption: { enabled: true }
      },
      {
        name: "SigmaBanking-GenesisPool",
        partitionKey: { name: "assetId", type: "S" },
        sortKey: { name: "version", type: "N" },
        billingMode: "PROVISIONED",
        readCapacity: 500,
        writeCapacity: 250,
        pointInTimeRecovery: true,
        encryption: { enabled: true }
      }
    ],
    
    endpoint: "https://dynamodb.us-east-1.amazonaws.com",
    region: "us-east-1"
  },
  
  // S3 Container Storage
  s3: {
    buckets: [
      {
        name: "sigma-banking-documents",
        region: "us-east-1",
        versioning: { enabled: true },
        encryption: {
          type: "AES256",
          kmsKeyId: "arn:aws:kms:us-east-1:ACCOUNT:key/sigma-banking-key"
        },
        lifecycleRules: [
          {
            id: "archive-old-documents",
            status: "Enabled",
            transitions: [
              { days: 90, storageClass: "STANDARD_IA" },
              { days: 365, storageClass: "GLACIER" }
            ]
          }
        ],
        publicAccess: {
          blockPublicAcls: true,
          blockPublicPolicy: true,
          ignorePublicAcls: true,
          restrictPublicBuckets: true
        },
        folders: [
          "compliance/",
          "audit-exports/",
          "gl-exhibits/",
          "certificates/3xpres5.crt",
          "backups/"
        ]
      },
      {
        name: "sigma-banking-crypto-assets",
        region: "us-east-1",
        versioning: { enabled: true },
        encryption: {
          type: "aws:kms",
          kmsKeyId: "arn:aws:kms:us-east-1:ACCOUNT:key/sigma-crypto-key"
        },
        objectLock: {
          enabled: true,
          mode: "COMPLIANCE",
          days: 2555  // 7 years regulatory retention
        },
        publicAccess: {
          blockPublicAcls: true,
          blockPublicPolicy: true,
          ignorePublicAcls: true,
          restrictPublicBuckets: true
        }
      },
      {
        name: "sigma-banking-logs",
        region: "us-east-1",
        versioning: { enabled: false },
        encryption: { type: "AES256" },
        lifecycleRules: [
          {
            id: "delete-old-logs",
            status: "Enabled",
            expiration: { days: 730 }  // 2 years
          }
        ]
      }
    ]
  },
  
  // Processor Tier Configuration
  processors: {
    applicationServers: [
      {
        id: "processor-1a",
        instanceType: "c6i.4xlarge",
        az: "us-east-1a",
        subnet: "subnet-priv-1a",
        securityGroup: "sg-processor-tier",
        role: "primary-processor"
      },
      {
        id: "processor-1b",
        instanceType: "c6i.4xlarge",
        az: "us-east-1b",
        subnet: "subnet-priv-1b",
        securityGroup: "sg-processor-tier",
        role: "secondary-processor"
      },
      {
        id: "processor-1c",
        instanceType: "c6i.4xlarge",
        az: "us-east-1c",
        subnet: "subnet-priv-1c",
        securityGroup: "sg-processor-tier",
        role: "tertiary-processor"
      }
    ],
    
    loadBalancer: {
      type: "application",
      name: "sigma-banking-alb",
      scheme: "internal",
      subnets: ["subnet-priv-1a", "subnet-priv-1b", "subnet-priv-1c"],
      securityGroups: ["sg-processor-tier"],
      targetGroup: {
        name: "sigma-processors",
        port: 8080,
        protocol: "HTTP",
        healthCheck: {
          path: "/health",
          interval: 30,
          timeout: 5,
          healthyThreshold: 2,
          unhealthyThreshold: 3
        }
      }
    },
    
    autoScaling: {
      minSize: 3,
      maxSize: 12,
      desiredCapacity: 3,
      cooldown: 300,
      policies: [
        {
          name: "scale-up-cpu",
          adjustmentType: "ChangeInCapacity",
          scalingAdjustment: 2,
          metric: "CPUUtilization",
          threshold: 70
        },
        {
          name: "scale-down-cpu",
          adjustmentType: "ChangeInCapacity",
          scalingAdjustment: -1,
          metric: "CPUUtilization",
          threshold: 30
        }
      ]
    }
  }
};

export default BackendConfig;
