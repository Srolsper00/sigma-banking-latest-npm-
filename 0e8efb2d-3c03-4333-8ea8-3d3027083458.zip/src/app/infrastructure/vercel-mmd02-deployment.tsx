/**
 * Vercel Deployment Configuration with AWS Integration
 * Sigma Production Banking Platform
 * 
 * Vercel frontend deployment connecting to AWS backend via mmd02 server
 */

export const VercelDeploymentConfig = {
  // Project Configuration
  project: {
    name: "sigma-banking-platform",
    framework: "react",
    buildCommand: "npm run build",
    outputDirectory: "dist",
    installCommand: "npm install",
    devCommand: "npm run dev"
  },
  
  // AWS Integration
  aws: {
    enabled: true,
    integration: "vercel-aws-integration",
    
    // VPC Connection via PrivateLink
    privateLink: {
      enabled: true,
      vpcId: "vpc-sigma-prod-banking",
      endpointService: "com.amazonaws.vpce.us-east-1.vpce-svc-sigma-banking",
      subnets: ["subnet-pub-1a", "subnet-pub-1b", "subnet-pub-1c"]
    },
    
    // Load Balancer Connection
    backend: {
      albDnsName: "sigma-banking-alb-internal.us-east-1.elb.amazonaws.com",
      protocol: "https",
      certificate: "3xpres5.crt",
      port: 443
    },
    
    // S3 Assets
    assets: {
      bucket: "sigma-banking-documents",
      region: "us-east-1",
      cloudFront: {
        enabled: false,
        description: "Assets served directly from Vercel CDN"
      }
    }
  },
  
  // mmd02 Server Configuration
  mmd02: {
    hostname: "mmd02.sigma-banking.internal",
    role: "api-gateway-proxy",
    
    // Server Specifications
    specs: {
      instanceType: "c6i.2xlarge",
      vcpu: 8,
      memory: "16 GiB",
      network: "25 Gbps",
      storage: {
        root: { size: 100, type: "gp3", iops: 3000 },
        data: { size: 500, type: "gp3", iops: 5000 }
      }
    },
    
    // Network Configuration
    network: {
      vpc: "vpc-sigma-prod-banking",
      subnet: "subnet-priv-1a",
      privateIp: "10.0.10.50",
      securityGroups: ["sg-processor-tier", "sg-vercel-app"],
      publicIp: "titaniumite5",
      dnsName: "mmd02.sigma-banking.internal"
    },
    
    // Services Running on mmd02
    services: [
      {
        name: "api-gateway",
        port: 8080,
        protocol: "http",
        healthCheck: "/health",
        description: "Main API gateway for Vercel frontend"
      },
      {
        name: "websocket-server",
        port: 8081,
        protocol: "ws",
        description: "Real-time updates for banking dashboard"
      },
      {
        name: "processor-coordinator",
        port: 8082,
        protocol: "http",
        description: "Coordinates requests to backend processors"
      }
    ],
    
    // Backend Connections from mmd02
    upstreams: {
      aurora: {
        endpoint: "sigma-banking-aurora-cluster.cluster-xyz.us-east-1.rds.amazonaws.com",
        port: 5432,
        protocol: "postgresql",
        connectionPool: 100
      },
      dynamodb: {
        endpoint: "https://dynamodb.us-east-1.amazonaws.com",
        region: "us-east-1",
        vpcEndpoint: "vpce-dynamodb"
      },
      s3: {
        endpoint: "https://s3.us-east-1.amazonaws.com",
        region: "us-east-1",
        vpcEndpoint: "vpce-s3"
      },
      supabase: {
        endpoint: "vpce-supabase-private-cert",
        port: 5432,
        protocol: "postgresql",
        database: "PRIVAT_ADMIN_CERT",
        schema: "PRIVATE",
        connectionPool: 20
      },
      processors: {
        loadBalancer: "sigma-banking-alb-internal.us-east-1.elb.amazonaws.com",
        port: 8080,
        protocol: "http",
        healthCheck: {
          enabled: true,
          interval: 10,
          timeout: 5
        }
      }
    },
    
    // SSL/TLS Configuration
    tls: {
      enabled: true,
      certificate: "3xpres5.crt",
      privateKey: "/etc/ssl/private/3xpres5.key",
      caBundle: "/etc/ssl/certs/umb-na-ca.pem",
      protocols: ["TLSv1.3"],
      cipherSuites: [
        "TLS_AES_256_GCM_SHA384",
        "TLS_CHACHA20_POLY1305_SHA256"
      ]
    }
  },
  
  // Vercel Environment Variables
  env: {
    // Build-time variables
    build: {
      VITE_API_ENDPOINT: "https://api.sigma-banking.com",
      VITE_WS_ENDPOINT: "wss://api.sigma-banking.com/ws",
      VITE_ENVIRONMENT: "production",
      VITE_BANK_PARTNER: "UMB NA"
    },
    
    // Runtime Edge Config (Vercel Edge)
    edge: {
      MMD02_API_URL: "https://mmd02.sigma-banking.internal:8080",
      MMD02_WS_URL: "wss://mmd02.sigma-banking.internal:8081",
      AWS_REGION: "us-east-1",
      CERT_FILE: "3xpres5.crt"
    },
    
    // Secrets (stored in Vercel)
    secrets: [
      "AURORA_CONNECTION_STRING",
      "DYNAMODB_ACCESS_KEY_ID",
      "DYNAMODB_SECRET_ACCESS_KEY",
      "S3_ACCESS_KEY_ID",
      "S3_SECRET_ACCESS_KEY",
      "SUPABASE_ADMIN_CERT_KEY",
      "JWT_SIGNING_KEY",
      "ENCRYPTION_MASTER_KEY"
    ]
  },
  
  // Vercel Deployment Settings
  deployment: {
    regions: ["iad1"],  // US East (closest to us-east-1 AWS)
    
    // Framework Preset
    framework: {
      preset: "vite",
      buildCommand: "vite build",
      devCommand: "vite dev",
      installCommand: "npm install"
    },
    
    // Serverless Functions (for API routes)
    functions: {
      "api/**/*.ts": {
        runtime: "nodejs20.x",
        memory: 1024,
        maxDuration: 10,
        environment: {
          MMD02_API_URL: "https://mmd02.sigma-banking.internal:8080"
        }
      }
    },
    
    // Edge Functions (for low-latency endpoints)
    edge: {
      "api/edge/**/*.ts": {
        runtime: "edge",
        regions: ["iad1"]
      }
    },
    
    // Rewrites (proxy to mmd02)
    rewrites: [
      {
        source: "/api/:path*",
        destination: "https://mmd02.sigma-banking.internal:8080/:path*"
      },
      {
        source: "/ws/:path*",
        destination: "wss://mmd02.sigma-banking.internal:8081/:path*"
      }
    ],
    
    // Headers
    headers: [
      {
        source: "/(.*)",
        headers: [
          { key: "X-Frame-Options", value: "DENY" },
          { key: "X-Content-Type-Options", value: "nosniff" },
          { key: "Referrer-Policy", value: "strict-origin-when-cross-origin" },
          { key: "Permissions-Policy", value: "geolocation=(), microphone=(), camera=()" },
          {
            key: "Content-Security-Policy",
            value: "default-src 'self'; script-src 'self' 'unsafe-inline'; style-src 'self' 'unsafe-inline'; img-src 'self' data: https:; connect-src 'self' https://mmd02.sigma-banking.internal wss://mmd02.sigma-banking.internal"
          }
        ]
      }
    ],
    
    // CORS Configuration
    cors: {
      allowedOrigins: ["https://sigma-banking.com", "https://*.sigma-banking.com"],
      allowedMethods: ["GET", "POST", "PUT", "DELETE", "OPTIONS"],
      allowedHeaders: ["Content-Type", "Authorization", "X-Request-ID"],
      exposedHeaders: ["X-Request-ID"],
      credentials: true,
      maxAge: 86400
    }
  },
  
  // Monitoring & Analytics
  monitoring: {
    vercelAnalytics: {
      enabled: true,
      audienceMode: false  // Privacy-focused
    },
    
    vercelSpeedInsights: {
      enabled: true
    },
    
    customMetrics: {
      enabled: true,
      endpoint: "https://mmd02.sigma-banking.internal:8080/metrics",
      metrics: [
        "page_load_time",
        "api_response_time",
        "transaction_completion_time",
        "error_rate"
      ]
    },
    
    logging: {
      level: "info",
      destination: "cloudwatch",
      logGroup: "/aws/vercel/sigma-banking",
      retention: 30
    }
  },
  
  // CI/CD Integration
  cicd: {
    provider: "github",
    repository: "sigma-banking/platform",
    branch: "main",
    
    // Automatic deployments
    productionBranch: "main",
    previewBranches: ["develop", "staging"],
    
    // Build hooks
    hooks: {
      preBuild: "npm run lint && npm run test",
      postBuild: "npm run generate-build-manifest"
    },
    
    // Environment-specific builds
    environments: {
      production: {
        branch: "main",
        env: "production",
        autoMerge: false,
        requireApproval: true
      },
      staging: {
        branch: "staging",
        env: "staging",
        autoMerge: true
      }
    }
  },
  
  // Performance Optimization
  performance: {
    // Image Optimization
    images: {
      enabled: true,
      domains: ["sigma-banking-documents.s3.us-east-1.amazonaws.com"],
      formats: ["image/avif", "image/webp"],
      sizes: [640, 750, 828, 1080, 1200, 1920, 2048, 3840]
    },
    
    // Edge Caching
    cache: {
      enabled: true,
      staticAssets: {
        maxAge: 31536000,  // 1 year
        staleWhileRevalidate: 86400
      },
      apiResponses: {
        maxAge: 0,  // No caching for banking data
        private: true
      }
    },
    
    // Compression
    compression: {
      enabled: true,
      algorithms: ["br", "gzip"]
    }
  }
};

export default VercelDeploymentConfig;
