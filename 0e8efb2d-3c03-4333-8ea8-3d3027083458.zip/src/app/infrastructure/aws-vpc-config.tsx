/**
 * AWS VPC Network Configuration
 * Sigma Production Banking Platform
 * 
 * VPC Architecture for mathieu_et_favvarrow VNet
 * Integrates with mmd02 server and Vercel deployment
 */

export const VPCConfig = {
  vpcId: "vpc-sigma-prod-banking",
  cidrBlock: "10.0.0.0/16",
  region: "us-east-1",
  
  // VNet Integration
  vnet: {
    name: "mathieu_et_favvarrow",
    peering: {
      enabled: true,
      connectionId: "pcx-mathieu-favvarrow-sigma"
    }
  },
  
  // Subnets
  subnets: {
    public: [
      { id: "subnet-pub-1a", cidr: "10.0.1.0/24", az: "us-east-1a" },
      { id: "subnet-pub-1b", cidr: "10.0.2.0/24", az: "us-east-1b" },
      { id: "subnet-pub-1c", cidr: "10.0.3.0/24", az: "us-east-1c" }
    ],
    private: [
      { id: "subnet-priv-1a", cidr: "10.0.10.0/24", az: "us-east-1a" },
      { id: "subnet-priv-1b", cidr: "10.0.11.0/24", az: "us-east-1b" },
      { id: "subnet-priv-1c", cidr: "10.0.12.0/24", az: "us-east-1c" }
    ],
    database: [
      { id: "subnet-db-1a", cidr: "10.0.20.0/24", az: "us-east-1a" },
      { id: "subnet-db-1b", cidr: "10.0.21.0/24", az: "us-east-1b" },
      { id: "subnet-db-1c", cidr: "10.0.22.0/24", az: "us-east-1c" }
    ]
  },
  
  // Security Groups
  securityGroups: {
    vercel: {
      id: "sg-vercel-app",
      inbound: [
        { port: 443, protocol: "tcp", source: "0.0.0.0/0", description: "HTTPS from Vercel" },
        { port: 80, protocol: "tcp", source: "0.0.0.0/0", description: "HTTP redirect" }
      ],
      outbound: [
        { port: 0, protocol: "-1", destination: "0.0.0.0/0" }
      ]
    },
    processor: {
      id: "sg-processor-tier",
      inbound: [
        { port: 8080, protocol: "tcp", source: "sg-vercel-app", description: "App traffic" },
        { port: 22, protocol: "tcp", source: "titaniumite5", description: "SSH from titaniumite5" }
      ]
    },
    database: {
      id: "sg-database-tier",
      inbound: [
        { port: 5432, protocol: "tcp", source: "sg-processor-tier", description: "PostgreSQL from processors" },
        { port: 3306, protocol: "tcp", source: "sg-processor-tier", description: "Aurora MySQL" }
      ]
    },
    supabase: {
      id: "sg-supabase-private",
      inbound: [
        { port: 5432, protocol: "tcp", source: "sg-processor-tier", description: "Private admin cert tables only" }
      ]
    }
  },
  
  // Network ACLs
  nacls: {
    public: {
      id: "nacl-public",
      inbound: [
        { rule: 100, protocol: "tcp", port: 443, cidr: "0.0.0.0/0", action: "allow" },
        { rule: 110, protocol: "tcp", port: 80, cidr: "0.0.0.0/0", action: "allow" }
      ]
    },
    private: {
      id: "nacl-private",
      inbound: [
        { rule: 100, protocol: "tcp", port: 8080, cidr: "10.0.0.0/16", action: "allow" }
      ]
    }
  },
  
  // Public IP Configuration
  publicIPs: {
    titaniumite5: {
      ip: "titaniumite5",
      description: "Primary public gateway",
      certificate: "3xpres5.crt",
      allocationType: "elastic"
    }
  },
  
  // VPC Endpoints
  endpoints: {
    s3: {
      type: "gateway",
      serviceName: "com.amazonaws.us-east-1.s3"
    },
    dynamodb: {
      type: "gateway",
      serviceName: "com.amazonaws.us-east-1.dynamodb"
    },
    secretsmanager: {
      type: "interface",
      serviceName: "com.amazonaws.us-east-1.secretsmanager"
    }
  }
};

export default VPCConfig;
