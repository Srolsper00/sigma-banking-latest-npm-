/**
 * Firewall Protection System
 * Sigma Production Banking Platform
 * 
 * Blocks unrelenting communication and IP distorted erroneous request hops
 * NIST SP 800-57 Compliant • Tier-1 Security Model
 */

// Safe UUID generator (fallback for environments without crypto.randomUUID)
function generateUUID(): string {
  if (typeof crypto !== 'undefined' && crypto.randomUUID) {
    return crypto.randomUUID();
  }
  // Fallback UUID generator
  return 'xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx'.replace(/[xy]/g, function(c) {
    const r = Math.random() * 16 | 0;
    const v = c === 'x' ? r : (r & 0x3 | 0x8);
    return v.toString(16);
  });
}

export interface FirewallRule {
  id: string;
  type: 'ALLOW' | 'BLOCK' | 'RATE_LIMIT';
  source: string;
  target: string;
  protocol: 'HTTP' | 'HTTPS' | 'WS' | 'ALL';
  enabled: boolean;
  priority: number;
  reason: string;
  timestamp: number;
}

export interface IPAnalysis {
  ip: string;
  status: 'VALID' | 'SUSPICIOUS' | 'BLOCKED' | 'DISTORTED';
  hopCount: number;
  isProxy: boolean;
  isTor: boolean;
  isVpn: boolean;
  geolocation: string;
  riskScore: number;
  lastSeen: number;
}

export interface SecurityEvent {
  id: string;
  timestamp: number;
  type: 'BLOCKED_IP' | 'RATE_LIMIT' | 'INVALID_REQUEST' | 'ENCRYPTION_FAILURE' | 'SUSPICIOUS_PATTERN';
  severity: 'LOW' | 'MEDIUM' | 'HIGH' | 'CRITICAL';
  source: string;
  details: string;
  action: string;
}

export class FirewallProtectionSystem {
  private static readonly STORAGE_KEY = 'sigma_firewall_rules';
  private static readonly IP_BLACKLIST_KEY = 'sigma_ip_blacklist';
  private static readonly SECURITY_LOG_KEY = 'sigma_security_events';
  private static readonly MAX_HOPS = 3; // Maximum allowed proxy hops
  private static readonly RATE_LIMIT_WINDOW = 60000; // 1 minute
  private static readonly MAX_REQUESTS_PER_WINDOW = 100;

  /**
   * Initialize firewall with default rules
   */
  static initialize(): void {
    const existingRules = this.getRules();
    if (existingRules.length === 0) {
      const defaultRules: FirewallRule[] = [
        {
          id: generateUUID(),
          type: 'BLOCK',
          source: 'TOR_NETWORK',
          target: '*',
          protocol: 'ALL',
          enabled: true,
          priority: 1,
          reason: 'Block all TOR exit nodes',
          timestamp: Date.now()
        },
        {
          id: generateUUID(),
          type: 'BLOCK',
          source: 'DISTORTED_IP',
          target: '*',
          protocol: 'ALL',
          enabled: true,
          priority: 2,
          reason: 'Block IP distorted requests',
          timestamp: Date.now()
        },
        {
          id: generateUUID(),
          type: 'RATE_LIMIT',
          source: '*',
          target: 'API',
          protocol: 'HTTPS',
          enabled: true,
          priority: 3,
          reason: 'Rate limit all API requests',
          timestamp: Date.now()
        },
        {
          id: generateUUID(),
          type: 'ALLOW',
          source: 'TITANIUMITE5',
          target: '*',
          protocol: 'HTTPS',
          enabled: true,
          priority: 4,
          reason: 'Allow whitelisted titaniumite5 public IP',
          timestamp: Date.now()
        }
      ];
      
      localStorage.setItem(this.STORAGE_KEY, JSON.stringify(defaultRules));
    }
  }

  /**
   * Analyze IP address for security threats
   */
  static analyzeIP(ip: string): IPAnalysis {
    // Extract hop information from IP
    const hopCount = this.detectHopCount(ip);
    const isProxy = this.isProxyIP(ip);
    const isTor = this.isTorNode(ip);
    const isVpn = this.isVpnProvider(ip);
    
    // Calculate risk score
    let riskScore = 0;
    if (hopCount > this.MAX_HOPS) riskScore += 40;
    if (isProxy) riskScore += 20;
    if (isTor) riskScore += 50;
    if (isVpn) riskScore += 15;
    if (this.isDistortedIP(ip)) riskScore += 60;

    // Determine status
    let status: IPAnalysis['status'] = 'VALID';
    if (riskScore >= 80) status = 'BLOCKED';
    else if (riskScore >= 50) status = 'SUSPICIOUS';
    else if (this.isDistortedIP(ip)) status = 'DISTORTED';

    return {
      ip,
      status,
      hopCount,
      isProxy,
      isTor,
      isVpn,
      geolocation: this.getGeolocation(ip),
      riskScore,
      lastSeen: Date.now()
    };
  }

  /**
   * Validate incoming request
   */
  static validateRequest(request: {
    ip: string;
    method: string;
    endpoint: string;
    headers: Record<string, string>;
    timestamp: number;
  }): { allowed: boolean; reason: string; event?: SecurityEvent } {
    
    // Analyze IP
    const ipAnalysis = this.analyzeIP(request.ip);
    
    // Check if IP is blocked
    if (ipAnalysis.status === 'BLOCKED') {
      const event = this.logSecurityEvent({
        type: 'BLOCKED_IP',
        severity: 'HIGH',
        source: request.ip,
        details: `Blocked IP with risk score ${ipAnalysis.riskScore}`,
        action: 'REQUEST_DENIED'
      });
      return { allowed: false, reason: 'IP BLOCKED - High risk score', event };
    }

    // Check for distorted IP
    if (ipAnalysis.status === 'DISTORTED') {
      const event = this.logSecurityEvent({
        type: 'INVALID_REQUEST',
        severity: 'CRITICAL',
        source: request.ip,
        details: 'IP distortion detected - possible spoofing attempt',
        action: 'REQUEST_DENIED'
      });
      return { allowed: false, reason: 'IP DISTORTED - Erroneous request', event };
    }

    // Check excessive hops
    if (ipAnalysis.hopCount > this.MAX_HOPS) {
      const event = this.logSecurityEvent({
        type: 'SUSPICIOUS_PATTERN',
        severity: 'MEDIUM',
        source: request.ip,
        details: `Excessive proxy hops detected: ${ipAnalysis.hopCount}`,
        action: 'REQUEST_DENIED'
      });
      return { allowed: false, reason: 'EXCESSIVE_HOPS - Suspicious routing', event };
    }

    // Rate limiting
    const rateLimitCheck = this.checkRateLimit(request.ip);
    if (!rateLimitCheck.allowed) {
      const event = this.logSecurityEvent({
        type: 'RATE_LIMIT',
        severity: 'MEDIUM',
        source: request.ip,
        details: `Rate limit exceeded: ${rateLimitCheck.count} requests in window`,
        action: 'REQUEST_THROTTLED'
      });
      return { allowed: false, reason: 'RATE_LIMIT_EXCEEDED', event };
    }

    // Validate encryption
    if (!this.validateEncryption(request.headers)) {
      const event = this.logSecurityEvent({
        type: 'ENCRYPTION_FAILURE',
        severity: 'HIGH',
        source: request.ip,
        details: 'Missing or invalid encryption headers',
        action: 'REQUEST_DENIED'
      });
      return { allowed: false, reason: 'ENCRYPTION_REQUIRED', event };
    }

    // Request allowed
    return { allowed: true, reason: 'VALIDATED' };
  }

  /**
   * Detect hop count from IP headers
   */
  private static detectHopCount(ip: string): number {
    // Simulate hop detection (in production, analyze X-Forwarded-For)
    const segments = ip.split('.');
    if (segments.some(s => parseInt(s) > 255 || parseInt(s) < 0)) {
      return 99; // Invalid IP = excessive hops
    }
    
    // Check for proxy indicators
    if (ip.startsWith('10.') || ip.startsWith('172.') || ip.startsWith('192.168.')) {
      return 2; // Private IP suggests proxy
    }
    
    return 1; // Direct connection
  }

  /**
   * Check if IP is distorted/malformed
   */
  private static isDistortedIP(ip: string): boolean {
    // IPv4 validation
    const ipv4Regex = /^(\d{1,3}\.){3}\d{1,3}$/;
    if (!ipv4Regex.test(ip)) return true;
    
    // Check for invalid octets
    const octets = ip.split('.');
    return octets.some(octet => {
      const num = parseInt(octet);
      return num < 0 || num > 255 || octet !== num.toString();
    });
  }

  /**
   * Detect proxy IP
   */
  private static isProxyIP(ip: string): boolean {
    // Known proxy IP ranges (simplified)
    const proxyRanges = ['10.', '172.16.', '192.168.', '127.'];
    return proxyRanges.some(range => ip.startsWith(range));
  }

  /**
   * Detect TOR node
   */
  private static isTorNode(ip: string): boolean {
    // Known TOR exit node patterns (simplified)
    const torPatterns = ['185.220.', '178.17.', '176.10.'];
    return torPatterns.some(pattern => ip.startsWith(pattern));
  }

  /**
   * Detect VPN provider
   */
  private static isVpnProvider(ip: string): boolean {
    // Known VPN provider ranges (simplified)
    const vpnPatterns = ['104.', '185.', '195.'];
    return vpnPatterns.some(pattern => ip.startsWith(pattern));
  }

  /**
   * Get geolocation from IP
   */
  private static getGeolocation(ip: string): string {
    // Simplified geolocation (in production, use GeoIP database)
    const firstOctet = parseInt(ip.split('.')[0]);
    if (firstOctet >= 1 && firstOctet <= 126) return 'US';
    if (firstOctet >= 127 && firstOctet <= 191) return 'EU';
    if (firstOctet >= 192 && firstOctet <= 223) return 'APAC';
    return 'UNKNOWN';
  }

  /**
   * Rate limiting check
   */
  private static checkRateLimit(ip: string): { allowed: boolean; count: number } {
    const now = Date.now();
    const key = `rate_limit_${ip}`;
    const stored = localStorage.getItem(key);
    
    if (!stored) {
      localStorage.setItem(key, JSON.stringify({ count: 1, windowStart: now }));
      return { allowed: true, count: 1 };
    }
    
    const data = JSON.parse(stored);
    
    // Reset window if expired
    if (now - data.windowStart > this.RATE_LIMIT_WINDOW) {
      localStorage.setItem(key, JSON.stringify({ count: 1, windowStart: now }));
      return { allowed: true, count: 1 };
    }
    
    // Increment count
    data.count++;
    localStorage.setItem(key, JSON.stringify(data));
    
    return {
      allowed: data.count <= this.MAX_REQUESTS_PER_WINDOW,
      count: data.count
    };
  }

  /**
   * Validate encryption headers
   */
  private static validateEncryption(headers: Record<string, string>): boolean {
    // Check for HTTPS
    if (!headers['x-forwarded-proto']?.includes('https')) return false;
    
    // Check for TLS version
    if (headers['x-tls-version'] && parseFloat(headers['x-tls-version']) < 1.2) {
      return false;
    }
    
    return true;
  }

  /**
   * Log security event
   */
  private static logSecurityEvent(event: Omit<SecurityEvent, 'id' | 'timestamp'>): SecurityEvent {
    const securityEvent: SecurityEvent = {
      id: generateUUID(),
      timestamp: Date.now(),
      ...event
    };
    
    const events = this.getSecurityEvents();
    events.unshift(securityEvent);
    
    // Keep last 1000 events
    const trimmed = events.slice(0, 1000);
    localStorage.setItem(this.SECURITY_LOG_KEY, JSON.stringify(trimmed));
    
    return securityEvent;
  }

  /**
   * Get all firewall rules
   */
  static getRules(): FirewallRule[] {
    const stored = localStorage.getItem(this.STORAGE_KEY);
    return stored ? JSON.parse(stored) : [];
  }

  /**
   * Add firewall rule
   */
  static addRule(rule: Omit<FirewallRule, 'id' | 'timestamp'>): FirewallRule {
    const newRule: FirewallRule = {
      id: generateUUID(),
      timestamp: Date.now(),
      ...rule
    };
    
    const rules = this.getRules();
    rules.push(newRule);
    localStorage.setItem(this.STORAGE_KEY, JSON.stringify(rules));
    
    return newRule;
  }

  /**
   * Get security events
   */
  static getSecurityEvents(): SecurityEvent[] {
    const stored = localStorage.getItem(this.SECURITY_LOG_KEY);
    return stored ? JSON.parse(stored) : [];
  }

  /**
   * Block IP address
   */
  static blockIP(ip: string, reason: string): void {
    const blacklist = this.getIPBlacklist();
    blacklist.push({
      ip,
      reason,
      timestamp: Date.now(),
      permanent: true
    });
    localStorage.setItem(this.IP_BLACKLIST_KEY, JSON.stringify(blacklist));
  }

  /**
   * Get IP blacklist
   */
  static getIPBlacklist(): Array<{ ip: string; reason: string; timestamp: number; permanent: boolean }> {
    const stored = localStorage.getItem(this.IP_BLACKLIST_KEY);
    return stored ? JSON.parse(stored) : [];
  }

  /**
   * Clear security logs
   */
  static clearSecurityLogs(): void {
    localStorage.removeItem(this.SECURITY_LOG_KEY);
  }

  /**
   * Export security configuration
   */
  static exportConfiguration(): string {
    return JSON.stringify({
      rules: this.getRules(),
      blacklist: this.getIPBlacklist(),
      events: this.getSecurityEvents(),
      timestamp: Date.now(),
      platform: 'SIGMA_BANKING_PLATFORM',
      version: '1.0.0'
    }, null, 2);
  }
}