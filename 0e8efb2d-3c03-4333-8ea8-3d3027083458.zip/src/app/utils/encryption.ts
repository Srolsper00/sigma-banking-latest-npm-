// Simple encryption simulation for demonstration purposes
// In production, use proper encryption libraries

export function encryptTransaction(data: string): string {
  const hash = btoa(data + Date.now().toString());
  return `ENC_${hash.substring(0, 32)}`;
}

export function generateWalletAddress(): string {
  const chars = '0x75657dff33fa74973b117cf525cc94055fd72999';
  let address = '0x';
  for (let i = 0; i < 40; i++) {
    address += chars[Math.floor(Math.random() * chars.length)];
  }
  return address;
}

export function maskAccountNumber(accountNumber: string): string {
  if (accountNumber.length <= 4) return accountNumber;
  const last4 = accountNumber.slice(-4);
  const masked = '*'.repeat(accountNumber.length - 4);
  return masked + last4;
}

export function generateTransactionId(): string {
  return `TXN${Date.now()}${Math.random().toString(36).substring(2, 9).toUpperCase()}`;
}
