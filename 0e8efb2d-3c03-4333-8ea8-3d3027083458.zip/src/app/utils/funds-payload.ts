/**
 * FundsPayload Builder - TypeScript Implementation
 * Sigma Production Banking Platform
 * 
 * Mirrors Java BSON structure for funds transfer payloads
 * Compatible with MongoDB/DynamoDB backend storage
 */

export interface FundsAmount {
  currency: string;
  units: number;
  nanos: number;
}

export interface AccountDetails {
  institution: string;
  routing_number: string;
  account_number_token: string;
}

export interface PayloadMetadata {
  source: string;
  idempotency_key: string;
  hash: string;
  signature: string;
}

export interface FundsPayload {
  payload_type: 'FUNDS_TRANSFER';
  version: number;
  txn_id: string;
  originator_account: AccountDetails;
  beneficiary_account: AccountDetails;
  amount: FundsAmount;
  ledger_effect: string;
  event_ts: number; // Unix timestamp
  ingest_ts: number; // Unix timestamp
  metadata: PayloadMetadata;
}

export class FundsPayloadBuilder {
  /**
   * Build a complete funds transfer payload
   */
  static build(params: {
    txnId: string;
    origInst: string;
    origRtn: string;
    origAcctToken: string;
    benInst: string;
    benRtn: string;
    benAcctToken: string;
    currency: string;
    units: number;
    nanos: number;
    ledgerEffect: string;
    eventTs?: number;
    ingestTs?: number;
    source: string;
    idempotencyKey?: string;
  }): FundsPayload {
    const now = Date.now();
    
    const amount: FundsAmount = {
      currency: params.currency,
      units: params.units,
      nanos: params.nanos
    };

    const originator: AccountDetails = {
      institution: params.origInst,
      routing_number: params.origRtn,
      account_number_token: params.origAcctToken
    };

    const beneficiary: AccountDetails = {
      institution: params.benInst,
      routing_number: params.benRtn,
      account_number_token: params.benAcctToken
    };

    // Generate payload hash
    const payloadString = JSON.stringify({
      txn_id: params.txnId,
      originator,
      beneficiary,
      amount,
      ledger_effect: params.ledgerEffect
    });
    
    const hash = this.generateSHA256(payloadString);
    const signature = this.generateSignature(hash, params.txnId);

    const metadata: PayloadMetadata = {
      source: params.source,
      idempotency_key: params.idempotencyKey || this.generateIdempotencyKey(params.txnId),
      hash,
      signature
    };

    return {
      payload_type: 'FUNDS_TRANSFER',
      version: 1,
      txn_id: params.txnId,
      originator_account: originator,
      beneficiary_account: beneficiary,
      amount,
      ledger_effect: params.ledgerEffect,
      event_ts: params.eventTs || now,
      ingest_ts: params.ingestTs || now,
      metadata
    };
  }

  /**
   * Generate SHA-256 hash (browser-compatible)
   */
  private static async generateSHA256Async(message: string): Promise<string> {
    const msgBuffer = new TextEncoder().encode(message);
    const hashBuffer = await crypto.subtle.digest('SHA-256', msgBuffer);
    const hashArray = Array.from(new Uint8Array(hashBuffer));
    return hashArray.map(b => b.toString(16).padStart(2, '0')).join('');
  }

  /**
   * Synchronous SHA-256 approximation (for compatibility)
   */
  private static generateSHA256(message: string): string {
    // Simple hash for client-side - in production, use crypto.subtle.digest
    let hash = 0;
    for (let i = 0; i < message.length; i++) {
      const char = message.charCodeAt(i);
      hash = ((hash << 5) - hash) + char;
      hash = hash & hash;
    }
    return Math.abs(hash).toString(16).padStart(64, '0').slice(0, 64);
  }

  /**
   * Generate digital signature
   */
  private static generateSignature(hash: string, txnId: string): string {
    const sigInput = `${hash}:${txnId}:UMB_NA:SIGMA_PROD`;
    return this.generateSHA256(sigInput);
  }

  /**
   * Generate idempotency key
   */
  private static generateIdempotencyKey(txnId: string): string {
    const timestamp = Date.now();
    return `${txnId}-${timestamp}`;
  }

  /**
   * Convert decimal amount to units and nanos
   */
  static decimalToUnitsNanos(amount: number): { units: number; nanos: number } {
    const units = Math.floor(amount);
    const nanos = Math.round((amount - units) * 1_000_000_000);
    return { units, nanos };
  }

  /**
   * Convert units and nanos to decimal
   */
  static unitsNanosToDecimal(units: number, nanos: number): number {
    return units + (nanos / 1_000_000_000);
  }

  /**
   * Validate payload structure
   */
  static validate(payload: FundsPayload): { valid: boolean; errors: string[] } {
    const errors: string[] = [];

    if (payload.payload_type !== 'FUNDS_TRANSFER') {
      errors.push('Invalid payload_type');
    }

    if (payload.version !== 1) {
      errors.push('Unsupported version');
    }

    if (!payload.txn_id || payload.txn_id.length === 0) {
      errors.push('Missing txn_id');
    }

    if (!payload.originator_account?.routing_number) {
      errors.push('Missing originator routing_number');
    }

    if (!payload.beneficiary_account?.routing_number) {
      errors.push('Missing beneficiary routing_number');
    }

    if (!payload.amount || payload.amount.units < 0) {
      errors.push('Invalid amount');
    }

    if (!['DEBIT', 'CREDIT', 'HOLD', 'RELEASE'].includes(payload.ledger_effect)) {
      errors.push('Invalid ledger_effect');
    }

    return {
      valid: errors.length === 0,
      errors
    };
  }

  /**
   * Serialize to BSON-compatible JSON
   */
  static toBSON(payload: FundsPayload): string {
    return JSON.stringify(payload, null, 2);
  }

  /**
   * Parse from BSON-compatible JSON
   */
  static fromBSON(json: string): FundsPayload {
    return JSON.parse(json) as FundsPayload;
  }
}

/**
 * Ledger effect types
 */
export const LEDGER_EFFECTS = {
  DEBIT: 'DEBIT',
  CREDIT: 'CREDIT',
  HOLD: 'HOLD',
  RELEASE: 'RELEASE'
} as const;

export type LedgerEffect = typeof LEDGER_EFFECTS[keyof typeof LEDGER_EFFECTS];
