/**
 * Network Management API Client
 * Integrates with mmd02 WebSocket Server
 * Copyright © 2026 VOM Services Corporation
 */

import { toast } from 'sonner';

// Configuration
const API_BASE_URL = process.env.NEXT_PUBLIC_MMD02_API_URL || 'http://localhost:8081';
const WS_URL = process.env.NEXT_PUBLIC_MMD02_WS_URL || 'ws://localhost:8081/ws';

export interface NetworkConfig {
  id?: string;
  name: string;
  cidr: string;
  datacenter?: string;
  vnetId?: string;
  status?: 'active' | 'provisioning' | 'error';
  subnets?: SubnetConfig[];
  routes?: RouteConfig[];
  createdAt?: string;
  metadata?: {
    owner?: string;
    environment?: string;
    compliance?: string[];
    encryption?: boolean;
  };
}

export interface SubnetConfig {
  id?: string;
  name: string;
  cidr: string;
  zone?: string;
  purpose?: string;
  nodeCount?: number;
}

export interface RouteConfig {
  id: string;
  destination: string;
  gateway: string;
  source: string;
  priority: number;
}

export interface NetworkEvent {
  type: string;
  payload: any;
  timestamp: string;
  source?: string;
}

/**
 * Network Management API Client
 */
export class NetworkApiClient {
  private ws: WebSocket | null = null;
  private eventListeners: ((event: NetworkEvent) => void)[] = [];
  private reconnectAttempts = 0;
  private maxReconnectAttempts = 5;
  private reconnectDelay = 1000;

  /**
   * Initialize WebSocket connection
   */
  connectWebSocket(): Promise<void> {
    return new Promise((resolve, reject) => {
      try {
        this.ws = new WebSocket(WS_URL);

        this.ws.onopen = () => {
          console.log('✅ Connected to mmd02 WebSocket server');
          this.reconnectAttempts = 0;
          toast.success('Connected to network management server');
          resolve();
        };

        this.ws.onmessage = (event) => {
          try {
            const data: NetworkEvent = JSON.parse(event.data);
            this.eventListeners.forEach(listener => listener(data));
          } catch (error) {
            console.error('Error parsing WebSocket message:', error);
          }
        };

        this.ws.onerror = (error) => {
          console.error('WebSocket error:', error);
          reject(error);
        };

        this.ws.onclose = () => {
          console.log('❌ Disconnected from mmd02 WebSocket server');
          this.attemptReconnect();
        };
      } catch (error) {
        console.error('Failed to connect to WebSocket:', error);
        reject(error);
      }
    });
  }

  /**
   * Disconnect WebSocket
   */
  disconnectWebSocket() {
    if (this.ws) {
      this.ws.close();
      this.ws = null;
    }
  }

  /**
   * Attempt to reconnect to WebSocket
   */
  private attemptReconnect() {
    if (this.reconnectAttempts < this.maxReconnectAttempts) {
      this.reconnectAttempts++;
      const delay = this.reconnectDelay * Math.pow(2, this.reconnectAttempts - 1);
      
      console.log(`Attempting to reconnect (${this.reconnectAttempts}/${this.maxReconnectAttempts}) in ${delay}ms...`);
      
      setTimeout(() => {
        this.connectWebSocket().catch(console.error);
      }, delay);
    } else {
      toast.error('Failed to connect to network management server');
    }
  }

  /**
   * Add event listener
   */
  addEventListener(listener: (event: NetworkEvent) => void) {
    this.eventListeners.push(listener);
  }

  /**
   * Remove event listener
   */
  removeEventListener(listener: (event: NetworkEvent) => void) {
    this.eventListeners = this.eventListeners.filter(l => l !== listener);
  }

  /**
   * Send event via WebSocket
   */
  sendEvent(type: string, payload: any) {
    if (this.ws && this.ws.readyState === WebSocket.OPEN) {
      this.ws.send(JSON.stringify({ type, payload }));
    }
  }

  /**
   * Create a new network
   */
  async createNetwork(network: NetworkConfig): Promise<NetworkConfig> {
    try {
      const response = await fetch(`${API_BASE_URL}/api/network/create`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(network)
      });

      if (!response.ok) {
        throw new Error(`HTTP ${response.status}: ${response.statusText}`);
      }

      const data = await response.json();
      return data.network;
    } catch (error) {
      console.error('Error creating network:', error);
      toast.error('Failed to create network');
      throw error;
    }
  }

  /**
   * Delete a network
   */
  async deleteNetwork(networkId: string): Promise<void> {
    try {
      const response = await fetch(`${API_BASE_URL}/api/network/${networkId}`, {
        method: 'DELETE'
      });

      if (!response.ok) {
        throw new Error(`HTTP ${response.status}: ${response.statusText}`);
      }

      toast.success('Network deleted successfully');
    } catch (error) {
      console.error('Error deleting network:', error);
      toast.error('Failed to delete network');
      throw error;
    }
  }

  /**
   * Add subnet to network
   */
  async addSubnet(networkId: string, subnet: SubnetConfig): Promise<SubnetConfig> {
    try {
      const response = await fetch(`${API_BASE_URL}/api/network/${networkId}/subnet`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(subnet)
      });

      if (!response.ok) {
        throw new Error(`HTTP ${response.status}: ${response.statusText}`);
      }

      const data = await response.json();
      return data.subnet;
    } catch (error) {
      console.error('Error adding subnet:', error);
      toast.error('Failed to add subnet');
      throw error;
    }
  }

  /**
   * Remove subnet from network
   */
  async removeSubnet(networkId: string, subnetId: string): Promise<void> {
    try {
      const response = await fetch(`${API_BASE_URL}/api/network/${networkId}/subnet/${subnetId}`, {
        method: 'DELETE'
      });

      if (!response.ok) {
        throw new Error(`HTTP ${response.status}: ${response.statusText}`);
      }

      toast.success('Subnet removed successfully');
    } catch (error) {
      console.error('Error removing subnet:', error);
      toast.error('Failed to remove subnet');
      throw error;
    }
  }

  /**
   * Get recent events
   */
  async getEvents(limit: number = 50): Promise<NetworkEvent[]> {
    try {
      const response = await fetch(`${API_BASE_URL}/api/events?limit=${limit}`);

      if (!response.ok) {
        throw new Error(`HTTP ${response.status}: ${response.statusText}`);
      }

      const data = await response.json();
      return data.events;
    } catch (error) {
      console.error('Error fetching events:', error);
      return [];
    }
  }

  /**
   * Health check
   */
  async healthCheck(): Promise<boolean> {
    try {
      const response = await fetch(`${API_BASE_URL}/health`);
      return response.ok;
    } catch (error) {
      return false;
    }
  }
}

// Singleton instance
export const networkApi = new NetworkApiClient();
