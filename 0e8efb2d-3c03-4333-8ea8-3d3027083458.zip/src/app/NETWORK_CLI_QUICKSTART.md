# Network CLI Quick Start Guide

**Sigma Production Banking Platform**  
**VOM Services Corporation - Network Management System**

---

## Quick Access

Navigate to the **Network CLI** tab in the Sigma Production Banking Platform to access the interactive terminal interface.

## Basic Commands

### Get Help
```bash
$ help
```

### Create Your First Network
```bash
$ create my-network --cidr 10.50.0.0/16
```

### List All Networks
```bash
$ list
```

### Add a Subnet
```bash
$ subnet add <network-id> web-subnet 10.50.1.0/24
```

### Map to AWS VPC
```bash
$ vpc-map <network-id> vpc-0abc123def456
```

### View VPC Mappings
```bash
$ show-mappings
```

### Delete a Network
```bash
$ delete <network-id>
```

### Clear Terminal
```bash
$ clear
```

## Quick Example Workflow

```bash
# 1. Create a production network
$ create prod-banking-network --cidr 10.100.0.0/16

# 2. View the created network (copy the network ID from output)
$ list

# 3. Add three subnets (use the network ID from step 1)
$ subnet add net-1713178200000 dmz-zone 10.100.1.0/24
$ subnet add net-1713178200000 app-tier 10.100.2.0/24
$ subnet add net-1713178200000 data-tier 10.100.3.0/24

# 4. Map to AWS VPC
$ vpc-map net-1713178200000 vpc-0abcd1234efgh5678

# 5. Verify everything
$ list
$ show-mappings
```

## Default Configuration

- **VNet ID**: mathieu_et_favvarrow
- **Datacenter**: 3xpres5 Datacenter - Seattle, WA
- **Default CIDR**: 10.0.0.0/16
- **AWS Region**: us-west-2
- **Availability Zones**: us-west-2a, us-west-2b, us-west-2c

## Quick Command Buttons

Use the Quick Commands section at the bottom of the CLI interface for one-click access to common operations:

- **Show Help**: Display all available commands
- **List Networks**: View all configured networks
- **VPC Mappings**: Show AWS VPC mappings
- **Create Network**: Pre-filled network creation command

## Status Dashboard

Monitor your network infrastructure in real-time:

- **Total Networks**: Active network count
- **Total Subnets**: Aggregate subnet count
- **VPC Mappings**: AWS integration count
- **Status**: System health indicator

## Key Features

✅ **Real-time Management**: Instant network provisioning  
✅ **AWS Integration**: Seamless VPC mapping  
✅ **Compliance Ready**: SOC 2, PCI DSS, NIST SP 800-57  
✅ **Secure**: Encrypted storage and TLS communication  
✅ **Auditable**: Complete operation logging

## Need More Information?

See [NETWORK_CLI_INTEGRATION_DOCUMENTATION.md](NETWORK_CLI_INTEGRATION_DOCUMENTATION.md) for comprehensive documentation.

---

**VOM Services Corporation**  
EIN: 83-1427324  
Production Banking Infrastructure
