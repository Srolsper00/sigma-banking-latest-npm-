# Vercel + AWS Deployment Architecture
## Sigma Production Banking Platform

**Deployment Stack:** Vercel (Frontend) → mmd02 Server (API Gateway) → AWS Backend (Aurora, DynamoDB, S3, Supabase-Limited)

---

## 🏗️ Architecture Overview

```
┌─────────────────────────────────────────────────────────────────┐
│                       LAYER 1: FRONTEND                          │
│                    Vercel Edge Network (iad1)                    │
│                                                                   │
│  ┌──────────────┐  ┌──────────────┐  ┌──────────────┐          │
│  │ React + Vite │  │ Edge Funcs   │  │  TLS 1.3     │          │
│  │ Tailwind CSS │  │ Serverless   │  │  3xpres5.crt │          │
│  └──────────────┘  └──────────────┘  └──────────────┘          │
└─────────────────────────────────────────────────────────────────┘
                              ↓
                    HTTPS/WSS :8080/:8081
                              ↓
┌─────────────────────────────────────────────────────────────────┐
│                    LAYER 2: API GATEWAY                          │
│                   mmd02 Server (c6i.2xlarge)                     │
│         VPC: vpc-sigma-prod-banking (10.0.10.50)                 │
│                                                                   │
│  ┌──────────────┐  ┌──────────────┐  ┌──────────────┐          │
│  │ API Gateway  │  │  WebSocket   │  │ Coordinator  │          │
│  │    :8080     │  │    :8081     │  │    :8082     │          │
│  └──────────────┘  └──────────────┘  └──────────────┘          │
└─────────────────────────────────────────────────────────────────┘
           ↓               ↓               ↓               ↓
      Aurora         DynamoDB             S3          Supabase
      :5432           HTTPS             HTTPS          :5432
         ↓               ↓               ↓               ↓
┌─────────────────────────────────────────────────────────────────┐
│                     LAYER 3: DATA LAYER                          │
│                         AWS Services                             │
│                                                                   │
│  ┌──────────────┐  ┌──────────────┐  ┌──────────────┐          │
│  │   Aurora     │  │  DynamoDB    │  │      S3      │          │
│  │  PostgreSQL  │  │  NoSQL       │  │  Encrypted   │          │
│  │  Multi-AZ    │  │  Streams     │  │  Versioned   │          │
│  └──────────────┘  └──────────────┘  └──────────────┘          │
│                                                                   │
│  ┌──────────────────────────────────────────────────┐          │
│  │     Supabase (LIMITED SCOPE ONLY)                │          │
│  │  Database: PRIVAT_ADMIN_CERT                     │          │
│  │  Schema: PRIVATE                                 │          │
│  │  Tables: admin_certificates, revocations, audit  │          │
│  │  Access: VPC Private Endpoint Only               │          │
│  └──────────────────────────────────────────────────┘          │
└─────────────────────────────────────────────────────────────────┘
```

---

## 📊 Component Breakdown

### **Layer 1: Vercel Frontend**

**Purpose:** Global CDN serving React application with edge computing

| Component | Configuration |
|-----------|---------------|
| **Framework** | Vite + React + TypeScript |
| **Styling** | Tailwind CSS v4 |
| **Region** | iad1 (US East - closest to AWS us-east-1) |
| **Build** | `vite build` → static assets |
| **Edge Functions** | Node.js 20.x runtime |
| **TLS Certificate** | 3xpres5.crt |
| **CSP** | Strict content security policy |
| **CORS** | Restricted to *.sigma-banking.com |

**Environment Variables:**
```env
VITE_API_ENDPOINT=https://api.sigma-banking.com
VITE_WS_ENDPOINT=wss://api.sigma-banking.com/ws
MMD02_API_URL=https://mmd02.sigma-banking.internal:8080
MMD02_WS_URL=wss://mmd02.sigma-banking.internal:8081
```

**Rewrites (Proxy to mmd02):**
```javascript
/api/:path* → https://mmd02.sigma-banking.internal:8080/:path*
/ws/:path*  → wss://mmd02.sigma-banking.internal:8081/:path*
```

---

### **Layer 2: mmd02 API Gateway Server**

**Purpose:** Central API gateway, request router, and backend orchestrator

| Specification | Value |
|---------------|-------|
| **Instance Type** | c6i.2xlarge |
| **vCPU** | 8 cores |
| **Memory** | 16 GiB |
| **Network** | 25 Gbps (Up to) |
| **Storage** | 100 GiB root (gp3, 3000 IOPS) + 500 GiB data (gp3, 5000 IOPS) |
| **VPC** | vpc-sigma-prod-banking |
| **Subnet** | subnet-priv-1a (10.0.10.0/24) |
| **Private IP** | 10.0.10.50 |
| **Public IP** | titaniumite5 (Elastic IP) |
| **Security Groups** | sg-processor-tier, sg-vercel-app |
| **DNS Name** | mmd02.sigma-banking.internal |

**Services Running:**

1. **API Gateway (:8080)**
   - HTTP REST API endpoint
   - Request validation & authentication
   - Rate limiting & throttling
   - Health check: `/health`

2. **WebSocket Server (:8081)**
   - Real-time banking dashboard updates
   - Transaction notifications
   - Live balance updates
   - Connection pooling

3. **Processor Coordinator (:8082)**
   - Routes requests to backend processors
   - Load balancing across processor tier
   - Circuit breaker patterns
   - Retry logic

**Backend Connections (Upstreams):**

```javascript
{
  aurora: "sigma-banking-aurora-cluster.cluster-xyz.us-east-1.rds.amazonaws.com:5432",
  dynamodb: "vpce-dynamodb (VPC Endpoint)",
  s3: "vpce-s3 (VPC Endpoint)",
  supabase: "vpce-supabase-private-cert:5432",
  processors: "sigma-banking-alb-internal.us-east-1.elb.amazonaws.com:8080"
}
```

**TLS Configuration:**
```
Certificate: 3xpres5.crt
Private Key: /etc/ssl/private/3xpres5.key
CA Bundle: /etc/ssl/certs/umb-na-ca.pem
TLS Version: 1.3
Cipher Suites: TLS_AES_256_GCM_SHA384, TLS_CHACHA20_POLY1305_SHA256
```

---

### **Layer 3A: Aurora PostgreSQL Cluster**

**Purpose:** Primary relational database for transactional banking data

| Configuration | Value |
|---------------|-------|
| **Cluster ID** | sigma-banking-aurora-cluster |
| **Engine** | aurora-postgresql 15.4 |
| **Instance Class** | db.r6g.2xlarge (memory-optimized) |
| **Instances** | 3 (1 writer, 2 readers) |
| **Multi-AZ** | Yes (us-east-1a, 1b, 1c) |
| **Subnet Group** | subnet-group-database |
| **Security Group** | sg-database-tier |
| **Backup Retention** | 35 days |
| **Backup Window** | 03:00-04:00 UTC |
| **Encryption** | AES-256 (KMS key: sigma-banking-key) |

**Database Schemas:**

**Primary Database: `sigma_banking_prod`**
- `transactions` - All banking transactions
- `accounts` - Customer accounts
- `compliance` - Regulatory compliance data
- `audit_trail` - Immutable audit logs
- `genesis_pool` - Genesis clearing crypto assets
- `reconciliation` - Daily reconciliation records

**Analytics Database: `sigma_banking_analytics`**
- `reporting` - Business intelligence reports
- `metrics` - Performance metrics

**Endpoints:**
```
Writer: sigma-banking-aurora-cluster.cluster-xyz.us-east-1.rds.amazonaws.com:5432
Reader: sigma-banking-aurora-cluster.cluster-ro-xyz.us-east-1.rds.amazonaws.com:5432
```

---

### **Layer 3B: DynamoDB Tables**

**Purpose:** High-speed NoSQL storage for real-time operations

#### **Table 1: SigmaBanking-Transactions**
```
Partition Key: transactionId (S)
Sort Key: timestamp (N)
Billing: Provisioned (1000 RCU, 500 WCU)
Point-in-Time Recovery: Enabled
Encryption: AWS-managed KMS
Streams: NEW_AND_OLD_IMAGES

Global Secondary Indexes:
- AccountIndex: accountId + timestamp
- StatusIndex: status + timestamp
```

#### **Table 2: SigmaBanking-AuditLog**
```
Partition Key: eventId (S)
Sort Key: timestamp (N)
Billing: PAY_PER_REQUEST
TTL: expirationTime (automatic cleanup)
Point-in-Time Recovery: Enabled
```

#### **Table 3: SigmaBanking-Sessions**
```
Partition Key: sessionId (S)
Billing: PAY_PER_REQUEST
TTL: 24 hours (automatic expiration)
```

#### **Table 4: SigmaBanking-GenesisPool**
```
Partition Key: assetId (S)
Sort Key: version (N)
Billing: Provisioned (500 RCU, 250 WCU)
Point-in-Time Recovery: Enabled
```

---

### **Layer 3C: S3 Buckets**

**Purpose:** Encrypted object storage for documents, exports, and compliance

#### **Bucket 1: sigma-banking-documents**
```yaml
Region: us-east-1
Versioning: Enabled
Encryption: AES256 + KMS (sigma-banking-key)
Public Access: Completely blocked

Lifecycle Rules:
  - After 90 days → STANDARD_IA
  - After 365 days → GLACIER

Folders:
  - compliance/
  - audit-exports/
  - gl-exhibits/
  - certificates/3xpres5.crt
  - backups/
```

#### **Bucket 2: sigma-banking-crypto-assets**
```yaml
Region: us-east-1
Versioning: Enabled
Encryption: aws:kms (sigma-crypto-key)
Object Lock: COMPLIANCE mode (7 years retention)
Public Access: Completely blocked

Purpose: Immutable crypto asset records
```

#### **Bucket 3: sigma-banking-logs**
```yaml
Region: us-east-1
Versioning: Disabled
Encryption: AES256
Lifecycle: Delete after 730 days (2 years)
Purpose: Application and access logs
```

---

### **Layer 3D: Supabase (LIMITED SCOPE)**

**⚠️ CRITICAL: Supabase ONLY handles PRIVAT_ADMIN_CERT.PRIVATE tables**

**Configuration:**
```yaml
Project ID: masribasluchcclghsgc
Region: us-east-1
Scope: PRIVAT_ADMIN_CERT.PRIVATE (ONLY!)

VPC Integration:
  VPC ID: vpc-sigma-prod-banking
  Subnet Group: subnet-group-database
  Security Group: sg-supabase-private
  Private Link: vpce-supabase-private-cert
  
Access Control:
  Public Access: DISABLED
  Allowed Sources: sg-processor-tier, 10.0.10-12.0/24, 10.34.0.0/24
  API Endpoints: /rest/v1/admin_certificates ONLY
```

**Database Schema: PRIVAT_ADMIN_CERT.PRIVATE**

**Table: admin_certificates**
```sql
CREATE TABLE PRIVAT_ADMIN_CERT.PRIVATE.admin_certificates (
  cert_id UUID PRIMARY KEY,
  admin_user_id UUID,
  certificate_type TEXT,
  cert_data BYTEA ENCRYPTED,  -- AES-256-GCM
  public_key TEXT,
  private_key_encrypted BYTEA ENCRYPTED,  -- AES-256-GCM
  issuer TEXT DEFAULT 'UMB NA',
  subject_dn TEXT,
  serial_number TEXT UNIQUE,
  not_before TIMESTAMPTZ,
  not_after TIMESTAMPTZ,
  revoked BOOLEAN DEFAULT false,
  revocation_date TIMESTAMPTZ,
  revocation_reason TEXT,
  created_at TIMESTAMPTZ DEFAULT now(),
  updated_at TIMESTAMPTZ DEFAULT now(),
  created_by UUID,
  audit_trail JSONB
);

CREATE INDEX idx_admin_user ON admin_certificates(admin_user_id);
CREATE INDEX idx_serial ON admin_certificates(serial_number);
CREATE INDEX idx_expiry ON admin_certificates(not_after);
```

**Table: certificate_revocations**
```sql
CREATE TABLE PRIVAT_ADMIN_CERT.PRIVATE.certificate_revocations (
  revocation_id UUID PRIMARY KEY,
  cert_id UUID REFERENCES admin_certificates(cert_id),
  revoked_at TIMESTAMPTZ DEFAULT now(),
  revoked_by UUID,
  reason_code INTEGER,
  reason_text TEXT,
  crl_entry JSONB
);
```

**Table: certificate_audit**
```sql
CREATE TABLE PRIVAT_ADMIN_CERT.PRIVATE.certificate_audit (
  audit_id UUID PRIMARY KEY,
  cert_id UUID,
  action TEXT,
  actor_id UUID,
  timestamp TIMESTAMPTZ DEFAULT now(),
  ip_address INET,
  user_agent TEXT,
  details JSONB
);
```

**Row-Level Security:**
```sql
ALTER TABLE admin_certificates ENABLE ROW LEVEL SECURITY;

CREATE POLICY admin_only_access ON admin_certificates
  FOR ALL
  USING (auth.uid() IN (SELECT user_id FROM admin_users))
  WITH CHECK (auth.uid() IN (SELECT user_id FROM admin_users));
```

**⚠️ Integration Rules:**
- Supabase does NOT sync with Aurora
- Supabase does NOT sync with DynamoDB
- Supabase CAN export to S3 (backup only)
- All other banking data uses Aurora/DynamoDB

---

## 🌐 VPC Network Architecture

**VPC:** `vpc-sigma-prod-banking` (10.0.0.0/16)  
**Region:** us-east-1  
**VNet Integration:** mathieu_et_favvarrow (VNet peering enabled)

### **Subnets**

**Public Subnets (Internet Gateway attached):**
```
subnet-pub-1a: 10.0.1.0/24 (us-east-1a)
subnet-pub-1b: 10.0.2.0/24 (us-east-1b)
subnet-pub-1c: 10.0.3.0/24 (us-east-1c)

Resources: NAT Gateways, Load Balancers (if public)
```

**Private Subnets (Application tier):**
```
subnet-priv-1a: 10.0.10.0/24 (us-east-1a) ← mmd02: 10.0.10.50
subnet-priv-1b: 10.0.11.0/24 (us-east-1b)
subnet-priv-1c: 10.0.12.0/24 (us-east-1c)

Resources: mmd02, Processor EC2 instances, Application Load Balancer
```

**Database Subnets (Isolated, no internet):**
```
subnet-db-1a: 10.0.20.0/24 (us-east-1a)
subnet-db-1b: 10.0.21.0/24 (us-east-1b)
subnet-db-1c: 10.0.22.0/24 (us-east-1c)

Resources: Aurora cluster, RDS instances
```

### **Security Groups**

**sg-vercel-app:**
```
Inbound:
  - 443/tcp from 0.0.0.0/0 (HTTPS from Vercel)
  - 80/tcp from 0.0.0.0/0 (HTTP redirect)
Outbound:
  - All traffic
```

**sg-processor-tier:**
```
Inbound:
  - 8080/tcp from sg-vercel-app
  - 22/tcp from titaniumite5 (SSH admin)
Outbound:
  - All traffic (to databases, S3, etc.)
```

**sg-database-tier:**
```
Inbound:
  - 5432/tcp from sg-processor-tier (PostgreSQL)
  - 3306/tcp from sg-processor-tier (Aurora MySQL - if used)
Outbound:
  - None (databases don't initiate outbound)
```

**sg-supabase-private:**
```
Inbound:
  - 5432/tcp from sg-processor-tier ONLY
Outbound:
  - None
```

### **VPC Endpoints**

**Gateway Endpoints (no cost):**
- `com.amazonaws.us-east-1.s3`
- `com.amazonaws.us-east-1.dynamodb`

**Interface Endpoints (charged):**
- `com.amazonaws.us-east-1.secretsmanager`

---

## 🔐 Security Architecture

### **Encryption**

| Layer | Method | Algorithm |
|-------|--------|-----------|
| **In Transit** | TLS 1.3 | TLS_AES_256_GCM_SHA384 |
| **At Rest (Aurora)** | KMS | AES-256 |
| **At Rest (DynamoDB)** | KMS | AES-256 |
| **At Rest (S3)** | KMS + SSE | AES-256-GCM |
| **At Rest (Supabase)** | KMS + Column | AES-256-GCM |

### **Authentication Flow**

```
1. User → Vercel Edge (OAuth2 token validation)
2. Vercel → mmd02 (JWT bearer token)
3. mmd02 → Backend (mTLS client certificate)
4. Backend → Data Layer (IAM roles + database auth)
```

### **Certificates**

| Purpose | Certificate | Location |
|---------|-------------|----------|
| **Frontend TLS** | 3xpres5.crt | Vercel + mmd02 |
| **mTLS Backend** | 3xpres5.crt | mmd02 ↔ processors |
| **Admin Certs** | Supabase PRIVAT_ADMIN_CERT | Supabase tables |
| **CA Bundle** | umb-na-ca.pem | mmd02 CA trust store |

### **Access Control**

**Vercel:**
- Environment variables (encrypted secrets)
- IP allowlisting (optional)
- Deploy hooks authentication

**mmd02:**
- IAM instance role for AWS API calls
- SSH key-based authentication (titaniumite5 only)
- Security group restrictions

**AWS Services:**
- IAM roles (no API keys in code)
- KMS key policies
- S3 bucket policies (deny public access)

**Supabase:**
- Row-level security (RLS)
- Admin-only policy
- VPC private endpoint (no public internet)

---

## 📈 Scalability & Performance

### **Auto-Scaling Configuration**

**Processor Tier (EC2 Auto Scaling):**
```yaml
Min Size: 3
Max Size: 12
Desired Capacity: 3

Scale-Up Policy:
  Metric: CPUUtilization > 70%
  Action: Add 2 instances
  Cooldown: 300 seconds

Scale-Down Policy:
  Metric: CPUUtilization < 30%
  Action: Remove 1 instance
  Cooldown: 300 seconds
```

**Aurora Auto-Scaling (Read Replicas):**
```yaml
Min Replicas: 2
Max Replicas: 5
Target Metric: Average CPU 70%
```

**DynamoDB Auto-Scaling:**
```yaml
Transactions Table:
  Read: 1000-3000 RCU (target 70%)
  Write: 500-1500 WCU (target 70%)

GenesisPool Table:
  Read: 500-1500 RCU
  Write: 250-750 WCU
```

### **Load Balancing**

**Application Load Balancer:**
```yaml
Name: sigma-banking-alb
Scheme: internal (private subnets only)
Subnets: subnet-priv-1a, 1b, 1c
Security Group: sg-processor-tier

Target Group:
  Name: sigma-processors
  Port: 8080
  Protocol: HTTP
  Health Check:
    Path: /health
    Interval: 30s
    Timeout: 5s
    Healthy Threshold: 2
    Unhealthy Threshold: 3
```

---

## 🔍 Monitoring & Observability

### **CloudWatch Metrics**

**Custom Namespaces:**
- `Sigma/Vercel` - Vercel edge metrics
- `Sigma/mmd02` - API gateway metrics
- `Sigma/Processors` - Application server metrics
- `Sigma/Supabase` - Certificate operations metrics

**Key Metrics:**
```
- Vercel: PageLoadTime, APIResponseTime, ErrorRate
- mmd02: RequestCount, Latency, UpstreamHealth
- Aurora: DatabaseConnections, ReadLatency, WriteLatency
- DynamoDB: ConsumedReadCapacity, ConsumedWriteCapacity
- S3: BucketSize, NumberOfObjects, AllRequests
```

### **Alarms**

| Alarm | Metric | Threshold | Action |
|-------|--------|-----------|--------|
| High mmd02 CPU | CPUUtilization | > 85% | SNS notification |
| Aurora High Connections | DatabaseConnections | > 180 | SNS + Auto-scale |
| DynamoDB Throttling | ThrottledRequests | > 10 | SNS + Increase capacity |
| Supabase Unauthorized | FailedAuthentications | > 10 | SNS + Security team alert |

### **Logging**

**Log Groups:**
```
/aws/vercel/sigma-banking (30 days retention)
/aws/ec2/mmd02 (30 days)
/aws/rds/aurora/sigma-banking (7 days)
/aws/lambda/edge-functions (7 days)
```

**Log Aggregation:**
- Vercel logs → CloudWatch (via Vercel integration)
- mmd02 logs → CloudWatch Agent
- Aurora logs → CloudWatch Logs
- DynamoDB Streams → Lambda → CloudWatch

---

## 🚀 Deployment Workflow

### **CI/CD Pipeline**

**GitHub Actions → Vercel:**
```yaml
1. Push to main branch
2. GitHub triggers webhook
3. Vercel builds React app (vite build)
4. Deploy to edge network (iad1)
5. Automatic HTTPS certificate renewal
6. Edge functions deployed
7. Environment variables injected
```

**Backend Deployment (mmd02 + Processors):**
```yaml
1. Code push to release branch
2. CI/CD runs tests
3. Build Docker image (if containerized)
4. Push to ECR (Elastic Container Registry)
5. Update Auto Scaling Group launch template
6. Rolling deployment (10% at a time)
7. Health checks validate new instances
```

### **Database Migrations**

**Aurora:**
```bash
# Run via mmd02 with database admin role
psql -h sigma-banking-aurora-cluster.cluster-xyz.us-east-1.rds.amazonaws.com -U admin -d sigma_banking_prod
\i migrations/v2.0_add_crypto_assets.sql
```

**DynamoDB:**
```bash
# Table updates via AWS CLI
aws dynamodb update-table \
  --table-name SigmaBanking-Transactions \
  --billing-mode PAY_PER_REQUEST
```

**Supabase:**
```bash
# Migrations via Supabase CLI (VPC access required)
supabase db push --db-url postgresql://vpce-supabase-private-cert:5432/postgres
```

---

## 📋 Request Flow Example

**Complete Transaction Processing Flow:**

```
1. User clicks "Send Payment" in React app
   ↓
2. Vercel Edge Function validates JWT token
   ↓
3. API call proxied to mmd02:8080/api/transactions
   ↓
4. mmd02 API Gateway:
   - Validates request schema
   - Checks rate limits
   - Authenticates via mTLS
   ↓
5. mmd02 queries Aurora for account balance
   Query: SELECT balance FROM accounts WHERE id = ?
   ↓
6. mmd02 writes transaction to DynamoDB (fast write)
   PutItem: SigmaBanking-Transactions
   ↓
7. DynamoDB Stream triggers Lambda (async)
   Lambda writes to Aurora for durability
   ↓
8. mmd02 exports transaction receipt to S3
   PutObject: sigma-banking-documents/audit-exports/
   ↓
9. mmd02 sends WebSocket notification via :8081
   Message: { type: 'transaction_complete', txId: '...' }
   ↓
10. Vercel receives response, updates React UI
   ↓
11. User sees "Payment Sent ✓" notification
```

**Time breakdown:**
- Vercel → mmd02: ~10-20ms (edge to us-east-1)
- mmd02 → Aurora: ~5-10ms (same VPC)
- mmd02 → DynamoDB: ~2-5ms (VPC endpoint)
- mmd02 → S3: ~5-10ms (VPC endpoint)
- Total round-trip: ~50-100ms

---

## 🛡️ Disaster Recovery

### **Backup Strategy**

| Service | Backup Method | Frequency | Retention | RTO | RPO |
|---------|---------------|-----------|-----------|-----|-----|
| **Aurora** | Automated snapshots | Daily | 35 days | 1 hour | 5 min |
| **DynamoDB** | Point-in-time recovery | Continuous | 35 days | 30 min | Seconds |
| **S3** | Versioning + replication | Real-time | Indefinite | Immediate | 0 |
| **Supabase** | Daily backups to S3 | Daily | 35 days | 2 hours | 24 hours |

### **Failover Procedures**

**Aurora Failover:**
- Automatic failover to read replica (~30 seconds)
- DNS update to new writer endpoint
- Application retry logic handles transient errors

**DynamoDB:**
- Global tables (if multi-region)
- Automatic replication across AZs
- No manual failover needed

**mmd02 Failover:**
- Auto Scaling Group replaces unhealthy instances
- Health check fails → new instance launched
- Load balancer removes failed instance from pool

---

## 📞 Support & Troubleshooting

### **Common Issues**

**403 Error - Supabase Deployment:**
- **Cause:** Supabase edge function auto-deployment failure
- **Fix:** Supabase files are protected stubs; error can be ignored
- **Alternative:** Disconnect Supabase integration (not needed for main app)

**mmd02 Connection Timeout:**
- **Check:** Security group sg-processor-tier allows inbound :8080
- **Check:** Route table has route to NAT gateway (for outbound)
- **Check:** `/health` endpoint returns 200 OK

**Aurora Connection Pool Exhausted:**
- **Fix:** Increase max_connections parameter in DB cluster
- **Fix:** Scale up read replicas
- **Monitor:** CloudWatch DatabaseConnections metric

**DynamoDB Throttling:**
- **Fix:** Increase provisioned capacity or switch to PAY_PER_REQUEST
- **Monitor:** ConsumedReadCapacityUnits vs ProvisionedReadCapacityUnits

---

## 🎯 Next Steps

1. ✅ **VPC Setup:** Create VPC, subnets, security groups
2. ✅ **Aurora Cluster:** Deploy multi-AZ PostgreSQL cluster
3. ✅ **DynamoDB Tables:** Create tables with GSIs and streams
4. ✅ **S3 Buckets:** Create encrypted buckets with lifecycle policies
5. ✅ **Supabase Config:** Limit scope to PRIVAT_ADMIN_CERT.PRIVATE
6. ✅ **mmd02 Launch:** Deploy c6i.2xlarge in subnet-priv-1a
7. ✅ **Processor Tier:** Configure Auto Scaling Group
8. ✅ **Vercel Deploy:** Connect GitHub repo, configure environment variables
9. ⏳ **Testing:** End-to-end integration tests
10. ⏳ **Production Launch:** Go-live checklist

---

## 📚 Related Documentation

- [AWS VPC Configuration](/infrastructure/aws-vpc-config.tsx)
- [Backend Configuration](/infrastructure/aws-backend-config.tsx)
- [Supabase Limited Config](/infrastructure/supabase-limited-config.tsx)
- [Vercel Deployment Config](/infrastructure/vercel-mmd02-deployment.tsx)
- [Network Management](/NETWORK_MANAGEMENT_DEPLOYMENT_ARCHITECTURE.md)
- [3xpres5 Datacenter Infrastructure](/INFRASTRUCTURE_3XPRES5_DATACENTER.md)

---

**Deployment Architecture Version:** 2.0  
**Last Updated:** April 15, 2026  
**Banking Partner:** UMB NA  
**Corporation:** VOM Services Corporation (EIN 83-1427324)  
**Platform:** Sigma Production Banking Platform
