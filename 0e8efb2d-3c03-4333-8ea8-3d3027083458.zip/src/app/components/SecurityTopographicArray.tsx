import { motion } from 'motion/react';
import { useState } from 'react';
import { Shield, Key, Lock, FileKey, Globe, Database, Server, Layers } from 'lucide-react';

export function SecurityTopographicArray() {
  const [selectedZone, setSelectedZone] = useState<string | null>(null);
  const [selectedKey, setSelectedKey] = useState<string | null>(null);

  // Security zones with topographic layering
  const securityZones = [
    {
      id: 'internet',
      name: 'Internet Zone',
      level: 0,
      color: 'from-red-600 to-red-700',
      bgColor: 'bg-red-50',
      borderColor: 'border-red-300',
      textColor: 'text-red-700',
      icon: Globe,
      description: 'Public internet traffic',
      components: ['titaniumite5 (Public IP)', 'DDoS Protection', 'DNS Resolution']
    },
    {
      id: 'dmz',
      name: 'DMZ (Demilitarized Zone)',
      level: 1,
      color: 'from-orange-600 to-orange-700',
      bgColor: 'bg-orange-50',
      borderColor: 'border-orange-300',
      textColor: 'text-orange-700',
      icon: Shield,
      description: 'Perimeter security layer',
      components: ['Load Balancer', '3xpres5.crt (WAF)', 'IDS/IPS', 'Rate Limiting']
    },
    {
      id: 'application',
      name: 'Application Layer',
      level: 2,
      color: 'from-blue-600 to-blue-700',
      bgColor: 'bg-blue-50',
      borderColor: 'border-blue-300',
      textColor: 'text-blue-700',
      icon: Server,
      description: 'Application services with mTLS',
      components: ['node 3xpres5 (Policy)', 'API Gateway', 'OAuth2 Validator', 'Session Manager']
    },
    {
      id: 'business',
      name: 'Business Logic Layer',
      level: 3,
      color: 'from-purple-600 to-purple-700',
      bgColor: 'bg-purple-50',
      borderColor: 'border-purple-300',
      textColor: 'text-purple-700',
      icon: Layers,
      description: 'Core banking services (VNet: mathieu_et_favvarrow)',
      components: ['Invoice API (IPP)', 'Matching Engine (3-way/4-way)', 'Settlement OGFI', 'Ledger Engine']
    },
    {
      id: 'data',
      name: 'Data Persistence Layer',
      level: 4,
      color: 'from-green-600 to-green-700',
      bgColor: 'bg-green-50',
      borderColor: 'border-green-300',
      textColor: 'text-green-700',
      icon: Database,
      description: 'Encrypted storage with AES-256-GCM',
      components: ['MongoDB CSFLE', 'Audit Trail DB', 'Key Vault', 'Backup Systems']
    }
  ];

  // Cryptographic key hierarchy
  const keyHierarchy = [
    {
      id: 'root_ca',
      name: 'Root CA Certificate',
      type: 'RSA-4096',
      icon: '🔐',
      color: 'red',
      usage: 'Certificate Authority Root',
      location: 'Hardware Security Module (HSM)',
      rotation: 'Never (Air-gapped)',
      signs: ['intermediate_ca']
    },
    {
      id: 'intermediate_ca',
      name: 'Intermediate CA',
      type: 'RSA-4096',
      icon: '🔏',
      color: 'orange',
      usage: 'Issues Server Certificates',
      location: 'Secure Key Vault',
      rotation: '2 Years',
      signs: ['tls_cert', 'mtls_client']
    },
    {
      id: 'tls_cert',
      name: '3xpres5.crt (TLS 1.3)',
      type: 'ECDSA P-256',
      icon: '🔒',
      color: 'blue',
      usage: 'Server TLS Certificate',
      location: 'Load Balancer',
      rotation: '90 Days',
      signs: []
    },
    {
      id: 'mtls_client',
      name: 'mTLS Client Cert',
      type: 'ECDSA P-256',
      icon: '🔑',
      color: 'purple',
      usage: 'Mutual TLS Authentication',
      location: 'Application Servers',
      rotation: '30 Days',
      signs: []
    },
    {
      id: 'jwt_signing',
      name: 'JWT Signing Key',
      type: 'RSA-2048',
      icon: '✍️',
      color: 'indigo',
      usage: 'OAuth2 Token Signing',
      location: 'Auth Service',
      rotation: '7 Days',
      signs: []
    },
    {
      id: 'aes_master',
      name: 'AES Master Key',
      type: 'AES-256-GCM',
      icon: '🛡️',
      color: 'green',
      usage: 'Data Encryption (CSFLE)',
      location: 'MongoDB Key Vault',
      rotation: '90 Days',
      signs: []
    },
    {
      id: 'hmac_audit',
      name: 'HMAC Audit Key',
      type: 'HMAC-SHA-256',
      icon: '📝',
      color: 'emerald',
      usage: 'Audit Trail Integrity',
      location: 'Audit Service',
      rotation: '30 Days',
      signs: []
    }
  ];

  const getColorClasses = (color: string) => {
    const colors: any = {
      red: { bg: 'bg-red-500', light: 'bg-red-50', border: 'border-red-300', text: 'text-red-700' },
      orange: { bg: 'bg-orange-500', light: 'bg-orange-50', border: 'border-orange-300', text: 'text-orange-700' },
      blue: { bg: 'bg-blue-500', light: 'bg-blue-50', border: 'border-blue-300', text: 'text-blue-700' },
      purple: { bg: 'bg-purple-500', light: 'bg-purple-50', border: 'border-purple-300', text: 'text-purple-700' },
      indigo: { bg: 'bg-indigo-500', light: 'bg-indigo-50', border: 'border-indigo-300', text: 'text-indigo-700' },
      green: { bg: 'bg-green-500', light: 'bg-green-50', border: 'border-green-300', text: 'text-green-700' },
      emerald: { bg: 'bg-emerald-500', light: 'bg-emerald-50', border: 'border-emerald-300', text: 'text-emerald-700' }
    };
    return colors[color];
  };

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.6 }}
      className="bg-white rounded-xl shadow-lg border border-slate-200 overflow-hidden"
    >
      {/* Header */}
      <div className="bg-gradient-to-r from-slate-900 via-blue-900 to-slate-900 p-6">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="p-2 bg-white/10 rounded-lg">
              <Shield className="w-6 h-6 text-white" />
            </div>
            <div>
              <h2 className="text-white text-xl">Security Topographic Key Array</h2>
              <p className="text-slate-300 text-sm">Layered security zones with cryptographic key hierarchy</p>
            </div>
          </div>
          <div className="text-right">
            <div className="text-white text-2xl font-bold">{securityZones.length}</div>
            <div className="text-slate-300 text-xs">Security Layers</div>
          </div>
        </div>
      </div>

      {/* Content */}
      <div className="p-6">
        {/* Topographic Security Zones */}
        <div className="mb-6">
          <h3 className="text-slate-900 font-medium mb-4 flex items-center gap-2">
            <Layers className="w-5 h-5 text-blue-600" />
            Topographic Security Layers
          </h3>
          
          <div className="space-y-2">
            {securityZones.map((zone, index) => {
              const Icon = zone.icon;
              const isSelected = selectedZone === zone.id;
              const indentLevel = zone.level * 20;

              return (
                <motion.div
                  key={zone.id}
                  initial={{ opacity: 0, x: -20 }}
                  animate={{ opacity: 1, x: 0 }}
                  transition={{ delay: index * 0.1 }}
                  style={{ marginLeft: `${indentLevel}px` }}
                  className="relative"
                >
                  {/* Connector Line */}
                  {zone.level > 0 && (
                    <div 
                      className="absolute -left-5 top-1/2 w-5 h-0.5 bg-slate-300"
                      style={{ marginLeft: `-${indentLevel}px` }}
                    />
                  )}

                  <motion.div
                    whileHover={{ scale: 1.01 }}
                    onClick={() => setSelectedZone(isSelected ? null : zone.id)}
                    className={`
                      ${zone.bgColor} border-2 ${zone.borderColor}
                      rounded-lg overflow-hidden cursor-pointer transition-all
                      ${isSelected ? 'ring-2 ring-offset-2 ring-blue-500' : ''}
                    `}
                  >
                    {/* Zone Header */}
                    <div className={`bg-gradient-to-r ${zone.color} p-4`}>
                      <div className="flex items-center justify-between">
                        <div className="flex items-center gap-3">
                          <Icon className="w-6 h-6 text-white" />
                          <div>
                            <div className="text-white font-medium">{zone.name}</div>
                            <div className="text-white/80 text-xs">Level {zone.level}</div>
                          </div>
                        </div>
                        <div className="bg-white/20 text-white px-3 py-1 rounded text-xs">
                          {zone.components.length} Components
                        </div>
                      </div>
                    </div>

                    {/* Zone Details */}
                    {isSelected && (
                      <motion.div
                        initial={{ opacity: 0, height: 0 }}
                        animate={{ opacity: 1, height: 'auto' }}
                        exit={{ opacity: 0, height: 0 }}
                        className="p-4"
                      >
                        <p className={`${zone.textColor} text-sm mb-3`}>{zone.description}</p>
                        <div className="space-y-1">
                          {zone.components.map((component, i) => (
                            <div key={i} className="flex items-center gap-2 text-sm text-slate-600">
                              <div className={`w-2 h-2 ${zone.borderColor} border-2 rounded-full`}></div>
                              {component}
                            </div>
                          ))}
                        </div>
                      </motion.div>
                    )}
                  </motion.div>
                </motion.div>
              );
            })}
          </div>
        </div>

        {/* Cryptographic Key Array */}
        <div>
          <h3 className="text-slate-900 font-medium mb-4 flex items-center gap-2">
            <Key className="w-5 h-5 text-purple-600" />
            Cryptographic Key Hierarchy
          </h3>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-3">
            {keyHierarchy.map((key, index) => {
              const colors = getColorClasses(key.color);
              const isSelected = selectedKey === key.id;

              return (
                <motion.div
                  key={key.id}
                  initial={{ opacity: 0, scale: 0.95 }}
                  animate={{ opacity: 1, scale: 1 }}
                  transition={{ delay: index * 0.05 }}
                  whileHover={{ scale: 1.02 }}
                  onClick={() => setSelectedKey(isSelected ? null : key.id)}
                  className={`
                    ${colors.light} border-2 ${colors.border}
                    rounded-lg overflow-hidden cursor-pointer transition-all
                    ${isSelected ? 'ring-2 ring-offset-2 ring-purple-500' : ''}
                  `}
                >
                  {/* Key Header */}
                  <div className="p-4 bg-white border-b-2 border-slate-200">
                    <div className="flex items-start justify-between mb-2">
                      <span className="text-3xl">{key.icon}</span>
                      <span className={`px-2 py-1 rounded text-xs font-medium ${colors.bg} text-white`}>
                        {key.type}
                      </span>
                    </div>
                    <div className={`${colors.text} font-medium text-sm`}>{key.name}</div>
                  </div>

                  {/* Key Details */}
                  <div className="p-3 space-y-2 text-xs">
                    <div>
                      <span className="text-slate-500">Usage:</span>
                      <div className="text-slate-700 font-medium">{key.usage}</div>
                    </div>
                    <div>
                      <span className="text-slate-500">Location:</span>
                      <div className="text-slate-700 font-medium">{key.location}</div>
                    </div>
                    <div>
                      <span className="text-slate-500">Rotation:</span>
                      <div className={`${colors.text} font-medium`}>{key.rotation}</div>
                    </div>
                    
                    {key.signs.length > 0 && (
                      <div className="pt-2 border-t border-slate-200">
                        <span className="text-slate-500">Signs:</span>
                        <div className="flex flex-wrap gap-1 mt-1">
                          {key.signs.map((signedKey) => (
                            <span key={signedKey} className="bg-slate-100 text-slate-700 px-2 py-0.5 rounded text-xs">
                              {signedKey}
                            </span>
                          ))}
                        </div>
                      </div>
                    )}
                  </div>
                </motion.div>
              );
            })}
          </div>
        </div>

        {/* Network Flow Diagram */}
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 0.4 }}
          className="mt-6 bg-slate-900 rounded-lg p-6 text-white font-mono text-xs overflow-x-auto"
        >
          <div className="text-green-400 mb-3">// Network Security Topology</div>
          <pre className="text-slate-300 whitespace-pre">
{`
                            INTERNET
                               |
                          [titaniumite5] (Public IP)
                               |
                        ┌──────┴──────┐
                        │  DMZ Layer  │
                        │  WAF + IDS  │
                        └──────┬──────┘
                               | TLS 1.3
                    ┌──────────┴──────────┐
                    │   3xpres5.crt       │ (Load Balancer)
                    └──────────┬──────────┘
                               | mTLS
                    ┌──────────┴──────────┐
                    │  node 3xpres5       │ (Policy Engine)
                    │  OAuth2 Validator   │
                    └──────────┬──────────┘
                               |
          ┌────────────────────┼────────────────────┐
          |                    |                    |
    [Invoice API]      [Matching Engine]    [Settlement OGFI]
    (IPP Connector)     (3-way/4-way)       (Datav v0.34.3)
          |                    |                    |
          └────────────────────┼────────────────────┘
                               | AES-256-GCM
                    ┌──────────┴──────────┐
                    │  MongoDB CSFLE      │
                    │  mathieu_et_favvarrow VNet │
                    └─────────────────────┘
                               |
                        [Audit Trail DB]
                        (Immutable Logs)
`}
          </pre>
        </motion.div>

        {/* Security Stats */}
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 0.5 }}
          className="mt-6 bg-slate-50 rounded-lg p-4 border border-slate-200"
        >
          <div className="grid grid-cols-4 gap-4 text-center">
            <div>
              <div className="text-2xl font-bold text-blue-600">5</div>
              <div className="text-xs text-slate-600">Security Zones</div>
            </div>
            <div>
              <div className="text-2xl font-bold text-purple-600">7</div>
              <div className="text-xs text-slate-600">Active Keys</div>
            </div>
            <div>
              <div className="text-2xl font-bold text-green-600">TLS 1.3</div>
              <div className="text-xs text-slate-600">Encryption</div>
            </div>
            <div>
              <div className="text-2xl font-bold text-red-600">mTLS</div>
              <div className="text-xs text-slate-600">Authentication</div>
            </div>
          </div>
        </motion.div>

        {/* Compliance Note */}
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 0.6 }}
          className="mt-4 bg-blue-50 border border-blue-300 rounded-lg p-4"
        >
          <div className="flex items-start gap-3">
            <FileKey className="w-5 h-5 text-blue-600 mt-0.5" />
            <div>
              <div className="text-blue-900 font-medium mb-1">Security Compliance</div>
              <p className="text-blue-800 text-sm">
                All cryptographic keys follow NIST SP 800-57 guidelines for key management. 
                TLS 1.3 with mTLS provides defense-in-depth. AES-256-GCM encryption protects data at rest. 
                Keys are rotated per policy and stored in HSM/Key Vault per CIS IG2/IG3 requirements.
              </p>
            </div>
          </div>
        </motion.div>
      </div>
    </motion.div>
  );
}
