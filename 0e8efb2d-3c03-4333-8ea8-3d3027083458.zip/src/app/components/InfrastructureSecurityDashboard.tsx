import { useState } from 'react';
import { motion } from 'motion/react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from './ui/card';
import { Badge } from './ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from './ui/tabs';
import { Shield, Activity, Server, AlertTriangle, CheckCircle, Lock, Network, Terminal } from 'lucide-react';

export function InfrastructureSecurityDashboard() {
  const [selectedWorker, setSelectedWorker] = useState<string | null>(null);

  // Cisco IOS Firewall Rules
  const firewallRules = [
    {
      id: 'ACL-100',
      protocol: 'TCP',
      source: '192.168.1.0/24',
      destination: 'titaniumite5',
      port: '443',
      action: 'PERMIT',
      status: 'active',
      description: 'HTTPS to production gateway'
    },
    {
      id: 'ACL-101',
      protocol: 'TCP',
      source: 'mathieu_et_favvarrow VNet',
      destination: 'UMB NA Gateway',
      port: '8443',
      action: 'PERMIT',
      status: 'active',
      description: 'Secure banking channel'
    },
    {
      id: 'ACL-102',
      protocol: 'TCP',
      source: '10.39.3.0/24',
      destination: 'ANY',
      port: '23',
      action: 'DENY',
      status: 'active',
      description: 'Block Telnet (insecure)'
    },
    {
      id: 'ACL-103',
      protocol: 'TCP',
      source: '10.0.0.0/8',
      destination: 'Genesis Pool',
      port: '3306',
      action: 'PERMIT',
      status: 'active',
      description: 'Internal database access'
    }
  ];

  // Transaction Workers
  const transactionWorkers = [
    {
      id: 'worker-001',
      name: 'ACH Processing Worker',
      status: 'healthy',
      uptime: '99.97%',
      throughput: '2,450 tx/min',
      lastHeartbeat: '2s ago',
      certificate: '3xpres5.crt',
      vnet: 'mathieu_et_favvarrow'
    },
    {
      id: '10.39.3.0/24',
      name: 'Wire Transfer Worker',
      status: 'healthy',
      uptime: '99.99%',
      throughput: '1,823 tx/min',
      lastHeartbeat: '1s ago',
      certificate: '3xpres5.crt',
      vnet: 'mathieu_et_favvarrow'
    },
    {
      id: 'worker-003',
      name: 'Payroll Batch Worker',
      status: 'healthy',
      uptime: '99.95%',
      throughput: '3,102 tx/min',
      lastHeartbeat: '3s ago',
      certificate: '3xpres5.crt',
      vnet: 'mathieu_et_favvarrow'
    },
    {
      id: 'worker-004',
      name: 'Crypto Settlement Worker',
      status: 'warning',
      uptime: '98.20%',
      throughput: '845 tx/min',
      lastHeartbeat: '45s ago',
      certificate: '3xpres5.crt',
      vnet: 'mathieu_et_favvarrow'
    }
  ];

  // Security Infrastructure Status
  const infrastructureStatus = {
    publicIP: 'titaniumite5',
    certificate: '3xpres5.crt',
    vnet: 'mathieu_et_favvarrow VNet',
    firewallVersion: 'Cisco IOS XE 17.9.3',
    encryptionStandard: 'NIST SP 800-57',
    activeConnections: 14523,
    blockedAttempts: 89,
    lastUpdated: new Date().toLocaleString()
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <motion.div
        initial={{ opacity: 0, y: -20 }}
        animate={{ opacity: 1, y: 0 }}
        className="flex items-center justify-between"
      >
        <div>
          <h2 className="text-3xl font-bold text-slate-800 flex items-center gap-3">
            <Shield className="w-8 h-8 text-blue-600" />
            Firewall Security Infrastructure
          </h2>
          <p className="text-slate-600 mt-1">
            Cisco IOS Hardening • Transaction Worker Monitoring • NIST SP 800-57 Compliance
          </p>
        </div>
        <Badge variant="default" className="bg-green-600 text-white px-4 py-2">
          <CheckCircle className="w-4 h-4 mr-2" />
          All Systems Operational
        </Badge>
      </motion.div>

      {/* Infrastructure Overview */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.1 }}
      >
        <Card className="border-blue-200 bg-gradient-to-br from-blue-50 to-white">
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Network className="w-5 h-5 text-blue-600" />
              Infrastructure Status
            </CardTitle>
            <CardDescription>Real-time security infrastructure metrics</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
              <div className="space-y-1">
                <div className="text-xs text-slate-600 font-medium">Public IP</div>
                <div className="text-lg font-bold text-slate-800">{infrastructureStatus.publicIP}</div>
              </div>
              <div className="space-y-1">
                <div className="text-xs text-slate-600 font-medium">Certificate</div>
                <div className="text-lg font-bold text-slate-800">{infrastructureStatus.certificate}</div>
              </div>
              <div className="space-y-1">
                <div className="text-xs text-slate-600 font-medium">VNet</div>
                <div className="text-lg font-bold text-slate-800">{infrastructureStatus.vnet}</div>
              </div>
              <div className="space-y-1">
                <div className="text-xs text-slate-600 font-medium">Encryption</div>
                <div className="text-sm font-bold text-slate-800">{infrastructureStatus.encryptionStandard}</div>
              </div>
              <div className="space-y-1">
                <div className="text-xs text-slate-600 font-medium">Firewall Version</div>
                <div className="text-sm font-bold text-slate-800">{infrastructureStatus.firewallVersion}</div>
              </div>
              <div className="space-y-1">
                <div className="text-xs text-slate-600 font-medium">Active Connections</div>
                <div className="text-lg font-bold text-green-600">{infrastructureStatus.activeConnections.toLocaleString()}</div>
              </div>
              <div className="space-y-1">
                <div className="text-xs text-slate-600 font-medium">Blocked Attempts</div>
                <div className="text-lg font-bold text-red-600">{infrastructureStatus.blockedAttempts}</div>
              </div>
              <div className="space-y-1">
                <div className="text-xs text-slate-600 font-medium">Last Updated</div>
                <div className="text-xs font-medium text-slate-700">{infrastructureStatus.lastUpdated}</div>
              </div>
            </div>
          </CardContent>
        </Card>
      </motion.div>

      <Tabs defaultValue="firewall" className="w-full">
        <TabsList className="grid w-full grid-cols-2">
          <TabsTrigger value="firewall">Cisco IOS Firewall</TabsTrigger>
          <TabsTrigger value="workers">Transaction Workers</TabsTrigger>
        </TabsList>

        {/* Cisco IOS Firewall Rules */}
        <TabsContent value="firewall" className="space-y-4">
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ delay: 0.2 }}
          >
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Terminal className="w-5 h-5 text-orange-600" />
                  Cisco IOS Access Control Lists (ACL)
                </CardTitle>
                <CardDescription>Production firewall rules and policies</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-3">
                  {firewallRules.map((rule, index) => (
                    <motion.div
                      key={rule.id}
                      initial={{ opacity: 0, x: -20 }}
                      animate={{ opacity: 1, x: 0 }}
                      transition={{ delay: index * 0.1 }}
                      className="border border-slate-200 rounded-lg p-4 hover:shadow-md transition-shadow bg-white"
                    >
                      <div className="flex items-start justify-between mb-2">
                        <div className="flex items-center gap-2">
                          <Badge variant={rule.action === 'PERMIT' ? 'default' : 'destructive'} className="font-mono">
                            {rule.id}
                          </Badge>
                          <Badge variant={rule.action === 'PERMIT' ? 'default' : 'destructive'}>
                            {rule.action}
                          </Badge>
                          <Badge variant="outline" className="bg-slate-50">
                            {rule.protocol}
                          </Badge>
                        </div>
                        <Badge variant="outline" className="bg-green-50 text-green-700 border-green-200">
                          <CheckCircle className="w-3 h-3 mr-1" />
                          {rule.status}
                        </Badge>
                      </div>
                      <div className="text-sm text-slate-700 mb-2">{rule.description}</div>
                      <div className="grid grid-cols-3 gap-3 text-xs">
                        <div>
                          <div className="text-slate-500 font-medium">Source</div>
                          <div className="text-slate-800 font-mono">{rule.source}</div>
                        </div>
                        <div>
                          <div className="text-slate-500 font-medium">Destination</div>
                          <div className="text-slate-800 font-mono">{rule.destination}</div>
                        </div>
                        <div>
                          <div className="text-slate-500 font-medium">Port</div>
                          <div className="text-slate-800 font-mono">{rule.port}</div>
                        </div>
                      </div>
                    </motion.div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </motion.div>

          {/* Cisco IOS Configuration */}
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ delay: 0.3 }}
          >
            <Card className="border-orange-200">
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Lock className="w-5 h-5 text-orange-600" />
                  Hardening Configuration
                </CardTitle>
                <CardDescription>Security hardening measures per Cisco best practices</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="bg-slate-900 text-green-400 p-4 rounded-lg font-mono text-sm overflow-x-auto">
                  <div className="space-y-1">
                    <div>! Cisco IOS XE Security Configuration</div>
                    <div>! Public IP: titaniumite5</div>
                    <div>! Certificate: 3xpres5.crt</div>
                    <div>! VNet: mathieu_et_favvarrow</div>
                    <div className="text-slate-500">!</div>
                    <div className="text-yellow-400">service password-encryption</div>
                    <div className="text-yellow-400">service tcp-keepalives-in</div>
                    <div className="text-yellow-400">service tcp-keepalives-out</div>
                    <div className="text-slate-500">!</div>
                    <div className="text-blue-400">ip ssh version 2</div>
                    <div className="text-blue-400">ip ssh time-out 60</div>
                    <div className="text-blue-400">ip ssh authentication-retries 3</div>
                    <div className="text-slate-500">!</div>
                    <div className="text-purple-400">crypto key generate rsa modulus 2048</div>
                    <div className="text-purple-400">crypto ssl encryption NIST-SP-800-57</div>
                    <div className="text-slate-500">!</div>
                    <div className="text-cyan-400">access-list 100 permit tcp 192.168.1.0 0.0.0.255 host titaniumite5 eq 443</div>
                    <div className="text-cyan-400">access-list 102 deny tcp any any eq 23</div>
                    <div className="text-slate-500">!</div>
                    <div className="text-green-400">line vty 0 4</div>
                    <div className="text-green-400 ml-4">transport input ssh</div>
                    <div className="text-green-400 ml-4">exec-timeout 10 0</div>
                    <div className="text-green-400 ml-4">logging synchronous</div>
                  </div>
                </div>
              </CardContent>
            </Card>
          </motion.div>
        </TabsContent>

        {/* Transaction Workers */}
        <TabsContent value="workers" className="space-y-4">
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ delay: 0.2 }}
            className="grid grid-cols-1 md:grid-cols-2 gap-4"
          >
            {transactionWorkers.map((worker, index) => (
              <motion.div
                key={worker.id}
                initial={{ opacity: 0, scale: 0.95 }}
                animate={{ opacity: 1, scale: 1 }}
                transition={{ delay: index * 0.1 }}
                whileHover={{ scale: 1.02 }}
                onClick={() => setSelectedWorker(selectedWorker === worker.id ? null : worker.id)}
                className="cursor-pointer"
              >
                <Card className={`border-2 transition-all ${
                  selectedWorker === worker.id ? 'border-blue-500 shadow-lg' : 'border-slate-200'
                } ${worker.status === 'warning' ? 'bg-yellow-50' : 'bg-white'}`}>
                  <CardHeader>
                    <div className="flex items-center justify-between">
                      <CardTitle className="text-lg flex items-center gap-2">
                        <Server className="w-5 h-5 text-blue-600" />
                        {worker.name}
                      </CardTitle>
                      <Badge 
                        variant={worker.status === 'healthy' ? 'default' : 'outline'}
                        className={worker.status === 'healthy' 
                          ? 'bg-green-600 text-white' 
                          : 'bg-yellow-100 text-yellow-800 border-yellow-300'
                        }
                      >
                        {worker.status === 'healthy' ? (
                          <CheckCircle className="w-3 h-3 mr-1" />
                        ) : (
                          <AlertTriangle className="w-3 h-3 mr-1" />
                        )}
                        {worker.status.toUpperCase()}
                      </Badge>
                    </div>
                    <CardDescription className="font-mono text-xs">{worker.id}</CardDescription>
                  </CardHeader>
                  <CardContent className="space-y-3">
                    <div className="grid grid-cols-2 gap-3">
                      <div>
                        <div className="text-xs text-slate-600 font-medium">Uptime</div>
                        <div className="text-lg font-bold text-green-600">{worker.uptime}</div>
                      </div>
                      <div>
                        <div className="text-xs text-slate-600 font-medium">Throughput</div>
                        <div className="text-lg font-bold text-blue-600">{worker.throughput}</div>
                      </div>
                    </div>
                    
                    <div className="border-t pt-3 space-y-2">
                      <div className="flex items-center justify-between text-xs">
                        <span className="text-slate-600">Last Heartbeat:</span>
                        <span className="font-mono text-slate-800">{worker.lastHeartbeat}</span>
                      </div>
                      <div className="flex items-center justify-between text-xs">
                        <span className="text-slate-600">Certificate:</span>
                        <span className="font-mono text-slate-800">{worker.certificate}</span>
                      </div>
                      <div className="flex items-center justify-between text-xs">
                        <span className="text-slate-600">VNet:</span>
                        <span className="font-mono text-slate-800">{worker.vnet}</span>
                      </div>
                    </div>

                    {selectedWorker === worker.id && (
                      <motion.div
                        initial={{ opacity: 0, height: 0 }}
                        animate={{ opacity: 1, height: 'auto' }}
                        exit={{ opacity: 0, height: 0 }}
                        className="border-t pt-3"
                      >
                        <div className="text-xs font-medium text-slate-700 mb-2">Performance Metrics</div>
                        <div className="space-y-1 text-xs">
                          <div className="flex justify-between">
                            <span className="text-slate-600">CPU Usage:</span>
                            <span className="font-mono text-slate-800">34%</span>
                          </div>
                          <div className="flex justify-between">
                            <span className="text-slate-600">Memory:</span>
                            <span className="font-mono text-slate-800">2.1 GB / 8 GB</span>
                          </div>
                          <div className="flex justify-between">
                            <span className="text-slate-600">Network I/O:</span>
                            <span className="font-mono text-slate-800">145 MB/s</span>
                          </div>
                        </div>
                      </motion.div>
                    )}
                  </CardContent>
                </Card>
              </motion.div>
            ))}
          </motion.div>
        </TabsContent>
      </Tabs>

      {/* Security Metrics Footer */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.4 }}
        className="grid grid-cols-1 md:grid-cols-4 gap-4"
      >
        <Card className="border-green-200 bg-gradient-to-br from-green-50 to-white">
          <CardContent className="pt-6">
            <div className="flex items-center gap-3">
              <div className="p-3 bg-green-100 rounded-lg">
                <CheckCircle className="w-6 h-6 text-green-600" />
              </div>
              <div>
                <div className="text-2xl font-bold text-green-600">99.97%</div>
                <div className="text-xs text-slate-600">Average Uptime</div>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card className="border-blue-200 bg-gradient-to-br from-blue-50 to-white">
          <CardContent className="pt-6">
            <div className="flex items-center gap-3">
              <div className="p-3 bg-blue-100 rounded-lg">
                <Activity className="w-6 h-6 text-blue-600" />
              </div>
              <div>
                <div className="text-2xl font-bold text-blue-600">8.2K</div>
                <div className="text-xs text-slate-600">Transactions/min</div>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card className="border-purple-200 bg-gradient-to-br from-purple-50 to-white">
          <CardContent className="pt-6">
            <div className="flex items-center gap-3">
              <div className="p-3 bg-purple-100 rounded-lg">
                <Shield className="w-6 h-6 text-purple-600" />
              </div>
              <div>
                <div className="text-2xl font-bold text-purple-600">100%</div>
                <div className="text-xs text-slate-600">NIST Compliant</div>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card className="border-orange-200 bg-gradient-to-br from-orange-50 to-white">
          <CardContent className="pt-6">
            <div className="flex items-center gap-3">
              <div className="p-3 bg-orange-100 rounded-lg">
                <Lock className="w-6 h-6 text-orange-600" />
              </div>
              <div>
                <div className="text-2xl font-bold text-orange-600">4</div>
                <div className="text-xs text-slate-600">Active Workers</div>
              </div>
            </div>
          </CardContent>
        </Card>
      </motion.div>
    </div>
  );
}
