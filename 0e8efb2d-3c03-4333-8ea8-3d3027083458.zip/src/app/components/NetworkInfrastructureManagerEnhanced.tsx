/**
 * Network Infrastructure Manager - Enhanced with Mock Management
 * Copyright © 2026 VOM Services Corporation
 * Matthew James Sauls - OCIO, CCO, CEO, CFO, CTO
 * EIN: 83-1427324 | FCC FRN: 0033213463
 * FINRA Org ID: TM6ZAS58-RRGKPOZW-OBLMFGJE-030961767-0033213463
 * 
 * Full Mock Network Management (Browser-based, No Backend Required)
 * WebSocket Integration Ready for mmd02 Server
 */

import { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from './ui/card';
import { Button } from './ui/button';
import { Input } from './ui/input';
import { Label } from './ui/label';
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle, DialogTrigger } from './ui/dialog';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from './ui/select';
import { Tabs, TabsContent, TabsList, TabsTrigger } from './ui/tabs';
import { Badge } from './ui/badge';
import { 
  Network, 
  Globe, 
  Shield, 
  Server, 
  Database,
  Lock,
  CheckCircle2,
  AlertCircle,
  Building2,
  MapPin,
  Zap,
  Activity,
  Settings,
  Plus,
  Trash2,
  Eye,
  RefreshCw,
  Radio,
  Wifi,
  GitBranch
} from 'lucide-react';
import { toast } from 'sonner';

interface NetworkConfig {
  id: string;
  name: string;
  cidr: string;
  vnetId: string;
  datacenter: string;
  status: 'active' | 'provisioning' | 'error';
  subnets: SubnetConfig[];
  routes: RouteConfig[];
  createdAt: string;
  metadata: {
    owner: string;
    environment: string;
    compliance: string[];
    encryption: boolean;
  };
}

interface SubnetConfig {
  id: string;
  name: string;
  cidr: string;
  zone: string;
  purpose: string;
  nodeCount: number;
}

interface RouteConfig {
  id: string;
  destination: string;
  gateway: string;
  source: string;
  priority: number;
}

interface NetworkEvent {
  type: string;
  payload: any;
  timestamp: string;
}

// Mock Driver (Browser-based)
class MockNetworkDriver {
  private networks: Map<string, NetworkConfig> = new Map();
  private eventListeners: ((event: NetworkEvent) => void)[] = [];

  constructor(initialNetworks: NetworkConfig[]) {
    initialNetworks.forEach(net => this.networks.set(net.id, net));
  }

  async createNetwork(config: Partial<NetworkConfig>): Promise<NetworkConfig> {
    await this.simulateDelay();
    
    const network: NetworkConfig = {
      id: `net-${Date.now()}-${Math.random().toString(36).substr(2, 9)}`,
      name: config.name || 'New Network',
      cidr: config.cidr || '10.0.0.0/16',
      vnetId: `vnet-${Date.now()}`,
      datacenter: config.datacenter || '3xpres5 Datacenter',
      status: 'provisioning',
      subnets: [],
      routes: [],
      createdAt: new Date().toISOString(),
      metadata: {
        owner: config.metadata?.owner || 'VOM Services Corporation',
        environment: config.metadata?.environment || 'development',
        compliance: config.metadata?.compliance || [], ʼ
        encryption: config.metadata?.encryption || true
      }
    };

    this.networks.set(network.id, network);
    this.emitEvent('network.created', network);

    // Simulate provisioning
    setTimeout(() => {
      network.status = 'active';
      this.networks.set(network.id, network);
      this.emitEvent('network.status_changed', { id: network.id, status: 'active' });
    }, 2000);

    return network;
  }

  async listNetworks(): Promise<NetworkConfig[]> {
    await this.simulateDelay(100);
    return Array.from(this.networks.values());
  }

  async deleteNetwork(id: string): Promise<void> {
    await this.simulateDelay();
    this.networks.delete(id);
    this.emitEvent('network.deleted', { id });
  }

  async addSubnet(networkId: string, subnet: Partial<SubnetConfig>): Promise<SubnetConfig> {
    await this.simulateDelay();
    
    const network = this.networks.get(networkId);
    if (!network) throw new Error('Network not found');

    const newSubnet: SubnetConfig = {
      id: `subnet-${Date.now()}-${Math.random().toString(36).substr(2, 9)}`,
      name: subnet.name || 'New Subnet',
      cidr: subnet.cidr || '10.0.1.0/24',
      zone: subnet.zone || 'us-west-2a',
      purpose: subnet.purpose || 'compute',
      nodeCount: subnet.nodeCount || 0
    };

    network.subnets.push(newSubnet);
    this.networks.set(networkId, network);
    this.emitEvent('subnet.added', { networkId, subnet: newSubnet });

    return newSubnet;
  }

  async removeSubnet(networkId: string, subnetId: string): Promise<void> {
    await this.simulateDelay();
    
    const network = this.networks.get(networkId);
    if (!network) throw new Error('Network not found');

    network.subnets = network.subnets.filter(s => s.id !== subnetId);
    this.networks.set(networkId, network);
    this.emitEvent('subnet.removed', { networkId, subnetId });
  }

  addEventListener(listener: (event: NetworkEvent) => void) {
    this.eventListeners.push(listener);
  }

  removeEventListener(listener: (event: NetworkEvent) => void) {
    this.eventListeners = this.eventListeners.filter(l => l !== listener);
  }

  private emitEvent(type: string, payload: any) {
    const event: NetworkEvent = {
      type,
      payload,
      timestamp: new Date().toISOString()
    };
    this.eventListeners.forEach(listener => listener(event));
  }

  private simulateDelay(ms: number = 500): Promise<void> {
    return new Promise(resolve => setTimeout(resolve, ms));
  }
}

export function NetworkInfrastructureManagerEnhanced() {
  // Initial networks
  const initialNetworks: NetworkConfig[] = [
    {
      id: 'net-3xpres5-prod',
      name: '3xpres5 Production Network',
      cidr: '10.0.0.0/16',
      vnetId: 'mathieu_et_favvarrow',
      datacenter: '3xpres5 Datacenter - Seattle, WA',
      status: 'active',
      createdAt: '2026-01-15T08:00:00Z',
      metadata: {
        owner: 'VOM Services Corporation (Matthew James Sauls)',
        environment: 'production',
        compliance: ['SOC 2 Type II', 'PCI DSS v4.0', 'NIST SP 800-57', 'FFIEC'],
        encryption: true
      },
      subnets: [
        {
          id: 'subnet-dmz',
          name: 'DMZ Zone (APISIX Gateway)',
          cidr: '10.0.1.0/24',
          zone: 'us-west-2a',
          purpose: 'dmz',
          nodeCount: 3
        },
        {
          id: 'subnet-compute',
          name: 'Compute Cluster',
          cidr: '10.0.10.0/24',
          zone: 'us-west-2b',
          purpose: 'compute',
          nodeCount: 6
        }
      ],
      routes: [
        {
          id: 'route-umb-na',
          destination: 'UMB Bank NA',
          gateway: 'vpn-gateway-umb.3xpres5.local',
          source: '10.0.10.0/24',
          priority: 100
        }
      ]
    }
  ];

  const [networks, setNetworks] = useState<NetworkConfig[]>(initialNetworks);
  const [driver] = useState(() => new MockNetworkDriver(initialNetworks));
  const [selectedNetwork, setSelectedNetwork] = useState<string | null>(null);
  const [events, setEvents] = useState<NetworkEvent[]>([]);
  const [wsConnected, setWsConnected] = useState(false);

  // Create Network Dialog State
  const [createDialogOpen, setCreateDialogOpen] = useState(false);
  const [newNetworkName, setNewNetworkName] = useState('');
  const [newNetworkCIDR, setNewNetworkCIDR] = useState('');
  const [newNetworkDatacenter, setNewNetworkDatacenter] = useState('');
  const [newNetworkEnv, setNewNetworkEnv] = useState('development');

  // Add Subnet Dialog State
  const [subnetDialogOpen, setSubnetDialogOpen] = useState(false);
  const [selectedNetworkForSubnet, setSelectedNetworkForSubnet] = useState<string>('');
  const [newSubnetName, setNewSubnetName] = useState('');
  const [newSubnetCIDR, setNewSubnetCIDR] = useState('');
  const [newSubnetZone, setNewSubnetZone] = useState('us-west-2a');
  const [newSubnetPurpose, setNewSubnetPurpose] = useState('compute');

  // Event listener for driver events
  useEffect(() => {
    const handleEvent = (event: NetworkEvent) => {
      setEvents(prev => [event, ...prev].slice(0, 50)); // Keep last 50 events
      
      // Update networks list
      driver.listNetworks().then(setNetworks);

      // Show toast notifications
      switch (event.type) {
        case 'network.created':
          toast.success(`Network created: ${event.payload.name}`);
          break;
        case 'network.deleted':
          toast.error(`Network deleted: ${event.payload.id}`);
          break;
        case 'subnet.added':
          toast.success(`Subnet added: ${event.payload.subnet.name}`);
          break;
        case 'subnet.removed':
          toast.info(`Subnet removed from network`);
          break;
        case 'network.status_changed':
          if (event.payload.status === 'active') {
            toast.success(`Network is now active`);
          }
          break;
      }
    };

    driver.addEventListener(handleEvent);
    return () => driver.removeEventListener(handleEvent);
  }, [driver]);

  // WebSocket connection (ready for mmd02 server)
  useEffect(() => {
    // This would connect to ws://mmd02.your-domain.com:8081
    // For now, simulate connection status
    const timer = setTimeout(() => setWsConnected(true), 1000);
    return () => clearTimeout(timer);
  }, []);

  const handleCreateNetwork = async () => {
    if (!newNetworkName || !newNetworkCIDR) {
      toast.error('Please fill in required fields');
      return;
    }

    await driver.createNetwork({
      name: newNetworkName,
      cidr: newNetworkCIDR,
      datacenter: newNetworkDatacenter || '3xpres5 Datacenter',
      metadata: {
        owner: 'VOM Services Corporation',
        environment: newNetworkEnv,
        compliance: [],
        encryption: true
      }
    });

    setCreateDialogOpen(false);
    setNewNetworkName('');
    setNewNetworkCIDR('');
    setNewNetworkDatacenter('');
    setNewNetworkEnv('development');
  };

  const handleDeleteNetwork = async (networkId: string) => {
    if (confirm('Are you sure you want to delete this network?')) {
      await driver.deleteNetwork(networkId);
    }
  };

  const handleAddSubnet = async () => {
    if (!selectedNetworkForSubnet || !newSubnetName || !newSubnetCIDR) {
      toast.error('Please fill in required fields');
      return;
    }

    await driver.addSubnet(selectedNetworkForSubnet, {
      name: newSubnetName,
      cidr: newSubnetCIDR,
      zone: newSubnetZone,
      purpose: newSubnetPurpose,
      nodeCount: 0
    });

    setSubnetDialogOpen(false);
    setNewSubnetName('');
    setNewSubnetCIDR('');
    setSelectedNetworkForSubnet('');
  };

  const handleRemoveSubnet = async (networkId: string, subnetId: string) => {
    if (confirm('Are you sure you want to remove this subnet?')) {
      await driver.removeSubnet(networkId, subnetId);
    }
  };

  const getStatusBadge = (status: string) => {
    switch (status) {
      case 'active':
        return 'bg-green-100 text-green-700 border-green-300';
      case 'provisioning':
        return 'bg-blue-100 text-blue-700 border-blue-300';
      case 'error':
        return 'bg-red-100 text-red-700 border-red-300';
      default:
        return 'bg-slate-100 text-slate-700 border-slate-300';
    }
  };

  const getPurposeIcon = (purpose: string) => {
    switch (purpose) {
      case 'dmz':
        return <Shield className="w-4 h-4" />;
      case 'compute':
        return <Server className="w-4 h-4" />;
      case 'hsm':
        return <Lock className="w-4 h-4" />;
      case 'storage':
        return <Database className="w-4 h-4" />;
      case 'management':
        return <Settings className="w-4 h-4" />;
      default:
        return <Network className="w-4 h-4" />;
    }
  };

  return (
    <div className="space-y-6">
      {/* Header with Connection Status */}
      <motion.div
        initial={{ opacity: 0, y: -20 }}
        animate={{ opacity: 1, y: 0 }}
        className="bg-gradient-to-r from-blue-600 to-purple-600 rounded-lg p-6 text-white"
      >
        <div className="flex items-center justify-between mb-4">
          <div className="flex items-center gap-3">
            <Network className="w-8 h-8" />
            <div>
              <h2 className="text-2xl font-bold">Network Infrastructure Manager</h2>
              <p className="text-blue-100 text-sm">
                VOM Services Corporation • 3xpres5 Datacenter • Full Mock Management
              </p>
            </div>
          </div>
          <div className="flex items-center gap-3">
            <Badge variant="outline" className={wsConnected ? 'bg-green-500 text-white border-green-400' : 'bg-slate-500 text-white border-slate-400'}>
              <Radio className={`w-3 h-3 mr-1 ${wsConnected ? 'animate-pulse' : ''}`} />
              {wsConnected ? 'WS Connected (mmd02)' : 'WS Disconnected'}
            </Badge>
          </div>
        </div>

        <div className="bg-blue-700/30 rounded-lg p-4">
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4 text-sm">
            <div>
              <div className="text-blue-200 text-xs mb-1">Corporate Owner</div>
              <div className="font-semibold">VOM Services Corp</div>
            </div>
            <div>
              <div className="text-blue-200 text-xs mb-1">Principal</div>
              <div className="font-semibold">Matthew James Sauls</div>
            </div>
            <div>
              <div className="text-blue-200 text-xs mb-1">EIN</div>
              <div className="font-mono text-xs">83-1427324</div>
            </div>
            <div>
              <div className="text-blue-200 text-xs mb-1">FCC FRN</div>
              <div className="font-mono text-xs">0033213463</div>
            </div>
          </div>
        </div>
      </motion.div>

      {/* Network Management Controls */}
      <Card>
        <CardHeader>
          <div className="flex items-center justify-between">
            <div>
              <CardTitle className="flex items-center gap-2">
                <Settings className="w-5 h-5" />
                Network Management
              </CardTitle>
              <CardDescription>Create, manage, and monitor virtual networks</CardDescription>
            </div>
            <div className="flex gap-2">
              <Dialog open={createDialogOpen} onOpenChange={setCreateDialogOpen}>
                <DialogTrigger asChild>
                  <Button className="bg-gradient-to-r from-blue-600 to-blue-700">
                    <Plus className="w-4 h-4 mr-2" />
                    Create Network
                  </Button>
                </DialogTrigger>
                <DialogContent className="sm:max-w-[500px]">
                  <DialogHeader>
                    <DialogTitle>Create New Network</DialogTitle>
                    <DialogDescription>
                      Configure a new virtual network with CIDR block and datacenter location.
                    </DialogDescription>
                  </DialogHeader>
                  <div className="space-y-4 py-4">
                    <div className="space-y-2">
                      <Label htmlFor="name">Network Name *</Label>
                      <Input
                        id="name"
                        placeholder="Production Network"
                        value={newNetworkName}
                        onChange={(e) => setNewNetworkName(e.target.value)}
                      />
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="cidr">CIDR Block *</Label>
                      <Input
                        id="cidr"
                        placeholder="10.0.0.0/16"
                        value={newNetworkCIDR}
                        onChange={(e) => setNewNetworkCIDR(e.target.value)}
                      />
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="datacenter">Datacenter</Label>
                      <Input
                        id="datacenter"
                        placeholder="3xpres5 Datacenter"
                        value={newNetworkDatacenter}
                        onChange={(e) => setNewNetworkDatacenter(e.target.value)}
                      />
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="environment">Environment</Label>
                      <Select value={newNetworkEnv} onValueChange={setNewNetworkEnv}>
                        <SelectTrigger>
                          <SelectValue />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="development">Development</SelectItem>
                          <SelectItem value="staging">Staging</SelectItem>
                          <SelectItem value="production">Production</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                  </div>
                  <DialogFooter>
                    <Button variant="outline" onClick={() => setCreateDialogOpen(false)}>
                      Cancel
                    </Button>
                    <Button onClick={handleCreateNetwork} className="bg-blue-600">
                      Create Network
                    </Button>
                  </DialogFooter>
                </DialogContent>
              </Dialog>

              <Dialog open={subnetDialogOpen} onOpenChange={setSubnetDialogOpen}>
                <DialogTrigger asChild>
                  <Button variant="outline">
                    <Plus className="w-4 h-4 mr-2" />
                    Add Subnet
                  </Button>
                </DialogTrigger>
                <DialogContent className="sm:max-w-[500px]">
                  <DialogHeader>
                    <DialogTitle>Add Subnet</DialogTitle>
                    <DialogDescription>
                      Add a new subnet to an existing network.
                    </DialogDescription>
                  </DialogHeader>
                  <div className="space-y-4 py-4">
                    <div className="space-y-2">
                      <Label htmlFor="network">Network *</Label>
                      <Select value={selectedNetworkForSubnet} onValueChange={setSelectedNetworkForSubnet}>
                        <SelectTrigger>
                          <SelectValue placeholder="Select network" />
                        </SelectTrigger>
                        <SelectContent>
                          {networks.map(net => (
                            <SelectItem key={net.id} value={net.id}>{net.name}</SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="subnet-name">Subnet Name *</Label>
                      <Input
                        id="subnet-name"
                        placeholder="Compute Cluster"
                        value={newSubnetName}
                        onChange={(e) => setNewSubnetName(e.target.value)}
                      />
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="subnet-cidr">CIDR Block *</Label>
                      <Input
                        id="subnet-cidr"
                        placeholder="10.0.1.0/24"
                        value={newSubnetCIDR}
                        onChange={(e) => setNewSubnetCIDR(e.target.value)}
                      />
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="zone">Availability Zone</Label>
                      <Input
                        id="zone"
                        placeholder="us-west-2a"
                        value={newSubnetZone}
                        onChange={(e) => setNewSubnetZone(e.target.value)}
                      />
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="purpose">Purpose</Label>
                      <Select value={newSubnetPurpose} onValueChange={setNewSubnetPurpose}>
                        <SelectTrigger>
                          <SelectValue />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="compute">Compute</SelectItem>
                          <SelectItem value="dmz">DMZ</SelectItem>
                          <SelectItem value="storage">Storage</SelectItem>
                          <SelectItem value="hsm">HSM</SelectItem>
                          <SelectItem value="management">Management</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                  </div>
                  <DialogFooter>
                    <Button variant="outline" onClick={() => setSubnetDialogOpen(false)}>
                      Cancel
                    </Button>
                    <Button onClick={handleAddSubnet} className="bg-green-600">
                      Add Subnet
                    </Button>
                  </DialogFooter>
                </DialogContent>
              </Dialog>
            </div>
          </div>
        </CardHeader>
      </Card>

      {/* Tabs for Networks and Events */}
      <Tabs defaultValue="networks" className="w-full">
        <TabsList className="grid w-full grid-cols-2">
          <TabsTrigger value="networks">Networks ({networks.length})</TabsTrigger>
          <TabsTrigger value="events">Event Stream ({events.length})</TabsTrigger>
        </TabsList>

        <TabsContent value="networks" className="space-y-4">
          <div className="grid grid-cols-3 gap-4">
            <Card className="p-4 bg-gradient-to-br from-blue-50 to-blue-100">
              <div className="flex items-center gap-3">
                <div className="bg-blue-600 p-3 rounded-lg">
                  <Globe className="w-6 h-6 text-white" />
                </div>
                <div>
                  <div className="text-sm text-slate-600">Total Networks</div>
                  <div className="text-2xl font-bold text-blue-600">{networks.length}</div>
                </div>
              </div>
            </Card>

            <Card className="p-4 bg-gradient-to-br from-green-50 to-green-100">
              <div className="flex items-center gap-3">
                <div className="bg-green-600 p-3 rounded-lg">
                  <Server className="w-6 h-6 text-white" />
                </div>
                <div>
                  <div className="text-sm text-slate-600">Total Subnets</div>
                  <div className="text-2xl font-bold text-green-600">
                    {networks.reduce((sum, net) => sum + net.subnets.length, 0)}
                  </div>
                </div>
              </div>
            </Card>

            <Card className="p-4 bg-gradient-to-br from-purple-50 to-purple-100">
              <div className="flex items-center gap-3">
                <div className="bg-purple-600 p-3 rounded-lg">
                  <Activity className="w-6 h-6 text-white" />
                </div>
                <div>
                  <div className="text-sm text-slate-600">Active Networks</div>
                  <div className="text-2xl font-bold text-purple-600">
                    {networks.filter(n => n.status === 'active').length}
                  </div>
                </div>
              </div>
            </Card>
          </div>

          {/* Networks List */}
          <div className="space-y-4">
            <AnimatePresence>
              {networks.map((network, index) => (
                <motion.div
                  key={network.id}
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  exit={{ opacity: 0, x: -100 }}
                  transition={{ delay: index * 0.1 }}
                >
                  <Card className="p-6">
                    <div className="flex items-start justify-between mb-4">
                      <div className="flex-1">
                        <div className="flex items-center gap-3 mb-2">
                          <Globe className="w-6 h-6 text-blue-600" />
                          <h3 className="text-lg font-semibold">{network.name}</h3>
                          <Badge variant="outline" className={getStatusBadge(network.status)}>
                            {network.status.toUpperCase()}
                          </Badge>
                        </div>

                        <div className="grid grid-cols-2 md:grid-cols-4 gap-3 text-sm mb-4">
                          <div>
                            <div className="text-slate-500 text-xs">CIDR Block</div>
                            <div className="font-mono font-semibold">{network.cidr}</div>
                          </div>
                          <div>
                            <div className="text-slate-500 text-xs">VNet ID</div>
                            <div className="font-mono text-xs">{network.vnetId}</div>
                          </div>
                          <div>
                            <div className="text-slate-500 text-xs">Datacenter</div>
                            <div className="font-semibold text-xs">{network.datacenter}</div>
                          </div>
                          <div>
                            <div className="text-slate-500 text-xs">Environment</div>
                            <div className="font-semibold text-xs capitalize">{network.metadata.environment}</div>
                          </div>
                        </div>

                        {/* Subnets */}
                        {network.subnets.length > 0 && (
                          <div className="mb-4">
                            <h4 className="font-semibold text-sm mb-3 flex items-center gap-2">
                              <Server className="w-4 h-4 text-blue-600" />
                              Subnets ({network.subnets.length})
                            </h4>
                            <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                              {network.subnets.map((subnet) => (
                                <div
                                  key={subnet.id}
                                  className="bg-white border border-slate-200 rounded-lg p-3 group relative"
                                >
                                  <div className="flex items-center justify-between gap-2 mb-2">
                                    <div className="flex items-center gap-2">
                                      {getPurposeIcon(subnet.purpose)}
                                      <div className="font-semibold text-sm">{subnet.name}</div>
                                    </div>
                                    <Button
                                      variant="ghost"
                                      size="sm"
                                      className="opacity-0 group-hover:opacity-100 transition-opacity"
                                      onClick={() => handleRemoveSubnet(network.id, subnet.id)}
                                    >
                                      <Trash2 className="w-3 h-3 text-red-600" />
                                    </Button>
                                  </div>
                                  <div className="grid grid-cols-2 gap-2 text-xs">
                                    <div>
                                      <div className="text-slate-500">CIDR</div>
                                      <div className="font-mono font-semibold">{subnet.cidr}</div>
                                    </div>
                                    <div>
                                      <div className="text-slate-500">Zone</div>
                                      <div className="font-semibold">{subnet.zone}</div>
                                    </div>
                                  </div>
                                </div>
                              ))}
                            </div>
                          </div>
                        )}
                      </div>

                      <div className="flex gap-2 ml-4">
                        <Button
                          variant="outline"
                          size="sm"
                          onClick={() => {
                            setSelectedNetworkForSubnet(network.id);
                            setSubnetDialogOpen(true);
                          }}
                        >
                          <Plus className="w-4 h-4" />
                        </Button>
                        <Button
                          variant="outline"
                          size="sm"
                          onClick={() => handleDeleteNetwork(network.id)}
                        >
                          <Trash2 className="w-4 h-4 text-red-600" />
                        </Button>
                      </div>
                    </div>
                  </Card>
                </motion.div>
              ))}
            </AnimatePresence>
          </div>
        </TabsContent>

        <TabsContent value="events" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Activity className="w-5 h-5 text-purple-600" />
                Network Event Stream
              </CardTitle>
              <CardDescription>Real-time events from network operations (mmd02 WebSocket)</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-2 max-h-[600px] overflow-y-auto">
                {events.length === 0 && (
                  <div className="text-center py-12 text-slate-500">
                    <GitBranch className="w-12 h-12 mx-auto mb-3 opacity-30" />
                    <p>No events yet. Create or modify networks to see events.</p>
                  </div>
                )}
                {events.map((event, index) => (
                  <motion.div
                    key={index}
                    initial={{ opacity: 0, x: -20 }}
                    animate={{ opacity: 1, x: 0 }}
                    className="border border-slate-200 rounded-lg p-3 bg-slate-50"
                  >
                    <div className="flex items-start justify-between mb-2">
                      <div className="flex items-center gap-2">
                        <Activity className="w-4 h-4 text-blue-600" />
                        <span className="font-semibold text-sm">{event.type}</span>
                      </div>
                      <span className="text-xs text-slate-500">
                        {new Date(event.timestamp).toLocaleTimeString()}
                      </span>
                    </div>
                    <pre className="text-xs bg-white p-2 rounded border border-slate-200 overflow-x-auto">
                      {JSON.stringify(event.payload, null, 2)}
                    </pre>
                  </motion.div>
                ))}
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>

      {/* Status Summary */}
      <Card className="p-4 bg-green-50 border-green-200">
        <div className="flex items-center gap-3">
          <CheckCircle2 className="w-6 h-6 text-green-600" />
          <div>
            <div className="font-semibold text-green-900">Mock Network Manager Active</div>
            <div className="text-sm text-green-700">
              {networks.length} networks • {networks.reduce((sum, n) => sum + n.subnets.length, 0)} subnets • 
              Full browser-based management enabled
            </div>
          </div>
        </div>
      </Card>
    </div>
  );
}
