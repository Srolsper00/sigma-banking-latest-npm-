import { motion } from 'motion/react';
import { Zap, HardDrive, Network, CreditCard, Database } from 'lucide-react';

export function ProcessingModelPanel() {
  const processingModel = {
    model: "3xPres5",
    storage: "nvme",
    network: "10gb",
    outboundRails: ["stripe"],
    authoritativeLedger: true
  };

  const specifications = [
    {
      id: 'model',
      label: 'Processing Model',
      value: processingModel.model,
      icon: Zap,
      color: 'purple',
      description: 'Triple-redundant presidential compute tier',
      metrics: {
        cores: '96 vCPU',
        memory: '384 GB RAM',
        tier: 'Presidential-5'
      }
    },
    {
      id: 'storage',
      label: 'Storage',
      value: processingModel.storage.toUpperCase(),
      icon: HardDrive,
      color: 'blue',
      description: 'NVMe solid-state storage for ultra-low latency',
      metrics: {
        type: 'NVMe SSD',
        iops: '1M IOPS',
        latency: '<100μs'
      }
    },
    {
      id: 'network',
      label: 'Network',
      value: processingModel.network.toUpperCase(),
      icon: Network,
      color: 'green',
      description: '10 Gigabit ethernet for high-throughput transfers',
      metrics: {
        bandwidth: '10 Gbps',
        topology: 'Multi-AZ',
        redundancy: 'Active-Active'
      }
    },
    {
      id: 'rails',
      label: 'Outbound Rails',
      value: processingModel.outboundRails.join(', ').toUpperCase(),
      icon: CreditCard,
      color: 'amber',
      description: 'Stripe payment processing integration',
      metrics: {
        provider: 'Stripe',
        methods: 'Card, ACH, Wire',
        region: 'Global'
      }
    },
    {
      id: 'ledger',
      label: 'Authoritative Ledger',
      value: processingModel.authoritativeLedger ? 'ENABLED' : 'DISABLED',
      icon: Database,
      color: 'emerald',
      description: 'System of record for all financial transactions',
      metrics: {
        consistency: 'Strong',
        durability: '99.999%',
        append: 'Write-once'
      }
    }
  ];

  const getColorClasses = (color: string) => {
    const colors = {
      purple: { 
        bg: 'bg-purple-600', 
        light: 'bg-purple-50', 
        border: 'border-purple-300', 
        text: 'text-purple-700',
        glow: 'shadow-purple-500/50'
      },
      blue: { 
        bg: 'bg-blue-600', 
        light: 'bg-blue-50', 
        border: 'border-blue-300', 
        text: 'text-blue-700',
        glow: 'shadow-blue-500/50'
      },
      green: { 
        bg: 'bg-green-600', 
        light: 'bg-green-50', 
        border: 'border-green-300', 
        text: 'text-green-700',
        glow: 'shadow-green-500/50'
      },
      amber: { 
        bg: 'bg-amber-600', 
        light: 'bg-amber-50', 
        border: 'border-amber-300', 
        text: 'text-amber-700',
        glow: 'shadow-amber-500/50'
      },
      emerald: { 
        bg: 'bg-emerald-600', 
        light: 'bg-emerald-50', 
        border: 'border-emerald-300', 
        text: 'text-emerald-700',
        glow: 'shadow-emerald-500/50'
      }
    };
    return colors[color as keyof typeof colors];
  };

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.6 }}
      className="mt-8"
    >
      <div className="bg-gradient-to-br from-slate-900 to-slate-800 rounded-xl shadow-2xl border border-slate-700 overflow-hidden">
        {/* Header */}
        <div className="bg-gradient-to-r from-purple-600 via-blue-600 to-green-600 p-6">
          <div className="flex items-center justify-between">
            <div>
              <h2 className="text-white text-2xl mb-1">Infrastructure Processing Model</h2>
              <p className="text-white/80 text-sm">High-performance compute topology</p>
            </div>
            <div className="bg-white/20 backdrop-blur-sm text-white px-6 py-3 rounded-lg border border-white/30">
              <div className="text-xs opacity-80 mb-1">Model</div>
              <div className="text-2xl font-bold">{processingModel.model}</div>
            </div>
          </div>
        </div>

        {/* Specifications Grid */}
        <div className="p-6 grid grid-cols-1 md:grid-cols-2 gap-4">
          {specifications.map((spec, index) => {
            const colors = getColorClasses(spec.color);
            const Icon = spec.icon;
            
            return (
              <motion.div
                key={spec.id}
                initial={{ opacity: 0, scale: 0.95 }}
                animate={{ opacity: 1, scale: 1 }}
                transition={{ delay: index * 0.1 }}
                whileHover={{ scale: 1.02 }}
                className={`bg-slate-800 border-2 border-slate-700 rounded-lg overflow-hidden hover:border-slate-600 transition-all hover:${colors.glow}`}
              >
                {/* Spec Header */}
                <div className={`${colors.bg} p-4`}>
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-3">
                      <div className="p-2 bg-white/20 rounded-lg">
                        <Icon className="w-5 h-5 text-white" />
                      </div>
                      <div>
                        <div className="text-white/70 text-xs">{spec.label}</div>
                        <div className="text-white font-bold text-lg">{spec.value}</div>
                      </div>
                    </div>
                  </div>
                </div>

                {/* Spec Details */}
                <div className="p-4">
                  <p className="text-slate-300 text-sm mb-3">{spec.description}</p>
                  
                  {/* Metrics */}
                  <div className="grid grid-cols-3 gap-2">
                    {Object.entries(spec.metrics).map(([key, value]) => (
                      <div key={key} className="bg-slate-700/50 rounded p-2 border border-slate-600">
                        <div className="text-slate-400 text-xs mb-1 capitalize">{key}</div>
                        <div className="text-white text-sm font-medium">{value}</div>
                      </div>
                    ))}
                  </div>
                </div>
              </motion.div>
            );
          })}
        </div>

        {/* Architecture Diagram */}
        <div className="px-6 pb-6">
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ delay: 0.6 }}
            className="bg-slate-800 rounded-lg p-6 border border-slate-700"
          >
            <h3 className="text-white mb-4 flex items-center gap-2">
              <Zap className="w-5 h-5 text-yellow-400" />
              Topology Overview
            </h3>
            
            {/* Visual Flow */}
            <div className="grid grid-cols-5 gap-3">
              {/* Compute */}
              <div className="text-center">
                <div className="bg-gradient-to-br from-purple-600 to-purple-700 rounded-lg p-4 mb-2">
                  <Zap className="w-8 h-8 text-white mx-auto" />
                </div>
                <div className="text-slate-300 text-xs">3xPres5</div>
                <div className="text-slate-500 text-xs">Compute</div>
              </div>

              {/* Arrow */}
              <div className="flex items-center justify-center">
                <div className="w-full h-0.5 bg-gradient-to-r from-purple-500 to-blue-500"></div>
              </div>

              {/* Storage */}
              <div className="text-center">
                <div className="bg-gradient-to-br from-blue-600 to-blue-700 rounded-lg p-4 mb-2">
                  <HardDrive className="w-8 h-8 text-white mx-auto" />
                </div>
                <div className="text-slate-300 text-xs">NVMe</div>
                <div className="text-slate-500 text-xs">Storage</div>
              </div>

              {/* Arrow */}
              <div className="flex items-center justify-center">
                <div className="w-full h-0.5 bg-gradient-to-r from-blue-500 to-green-500"></div>
              </div>

              {/* Network */}
              <div className="text-center">
                <div className="bg-gradient-to-br from-green-600 to-green-700 rounded-lg p-4 mb-2">
                  <Network className="w-8 h-8 text-white mx-auto" />
                </div>
                <div className="text-slate-300 text-xs">10Gb</div>
                <div className="text-slate-500 text-xs">Network</div>
              </div>
            </div>

            {/* Performance Indicators */}
            <div className="mt-6 grid grid-cols-3 gap-3">
              <div className="bg-slate-700/50 rounded-lg p-3 border border-slate-600">
                <div className="text-green-400 text-xl font-bold">99.99%</div>
                <div className="text-slate-400 text-xs">Uptime SLA</div>
              </div>
              <div className="bg-slate-700/50 rounded-lg p-3 border border-slate-600">
                <div className="text-blue-400 text-xl font-bold">&lt;100μs</div>
                <div className="text-slate-400 text-xs">Latency P99</div>
              </div>
              <div className="bg-slate-700/50 rounded-lg p-3 border border-slate-600">
                <div className="text-purple-400 text-xl font-bold">10k TPS</div>
                <div className="text-slate-400 text-xs">Transactions/sec</div>
              </div>
            </div>
          </motion.div>
        </div>
      </div>
    </motion.div>
  );
}
