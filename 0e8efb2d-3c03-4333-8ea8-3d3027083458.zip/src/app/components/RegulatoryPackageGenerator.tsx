import { useState } from 'react';
import { motion } from 'motion/react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from './ui/card';
import { Tabs, TabsContent, TabsList, TabsTrigger } from './ui/tabs';
import { Badge } from './ui/badge';
import { Button } from './ui/button';
import {
  FileText,
  Download,
  CheckCircle,
  Shield,
  Activity,
  Hash,
  Lock,
  FileCheck,
  AlertCircle,
  ArrowRight,
  Server,
  Network,
  Key,
  Eye,
  Zap,
  GitBranch,
  Award
} from 'lucide-react';

interface HashChainEntry {
  timestamp: string;
  action: string;
  hash: string;
  previousHash: string;
}

interface ComplianceControl {
  domain: string;
  requirement: string;
  status: 'compliant' | 'review' | 'pending';
}

export function RegulatoryPackageGenerator() {
  const [selectedTab, setSelectedTab] = useState<'flow' | 'compliance' | 'ledger' | 'hashchain' | 'export'>('flow');
  const [generating, setGenerating] = useState(false);
  const [packageReady, setPackageReady] = useState(false);
  const [hashChain, setHashChain] = useState<HashChainEntry[]>([]);

  // Generate SHA-256 hash simulation
  const generateHash = (data: string): string => {
    let hash = 0;
    for (let i = 0; i < data.length; i++) {
      const char = data.charCodeAt(i);
      hash = ((hash << 5) - hash) + char;
      hash = hash & hash;
    }
    return Math.abs(hash).toString(16).padStart(64, '0');
  };

  // Generate Hash Chain
  const generateHashChain = () => {
    const actions = ['INIT', 'VALIDATE', 'SETTLE', 'COMMIT'];
    const chain: HashChainEntry[] = [];
    let previousHash = 'GENESIS';

    actions.forEach((action) => {
      const timestamp = new Date().toISOString();
      const dataToHash = `${previousHash}${timestamp}${action}`;
      const hash = generateHash(dataToHash);

      chain.push({
        timestamp,
        action,
        hash,
        previousHash
      });

      previousHash = hash;
    });

    setHashChain(chain);
  };

  // Compliance Matrix
  const complianceMatrix: ComplianceControl[] = [
    {
      domain: 'NACHA',
      requirement: 'CCD/PPD classification, batch audit',
      status: 'compliant'
    },
    {
      domain: 'Mastercard',
      requirement: 'Card credit posting, settlement traceability',
      status: 'compliant'
    },
    {
      domain: 'AML/OFAC',
      requirement: 'Screening and sanctions compliance',
      status: 'compliant'
    },
    {
      domain: 'Ledger',
      requirement: 'Append-only, immutable records',
      status: 'compliant'
    },
    {
      domain: 'FDIC',
      requirement: 'Pass-through deposit insurance structure',
      status: 'compliant'
    },
    {
      domain: 'Regulation E',
      requirement: 'Electronic fund transfer disclosure',
      status: 'compliant'
    },
    {
      domain: 'FFIEC',
      requirement: 'IT examination handbook compliance',
      status: 'compliant'
    },
    {
      domain: 'PCI DSS',
      requirement: 'Card data security standards',
      status: 'compliant'
    }
  ];

  // Generate Package
  const generatePackage = () => {
    setGenerating(true);
    generateHashChain();

    setTimeout(() => {
      setGenerating(false);
      setPackageReady(true);
    }, 2000);
  };

  // Export functions (simulated)
  const exportPDF = () => {
    const content = generateDocumentContent();
    const blob = new Blob([content], { type: 'application/pdf' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = 'Full_Financial_Architecture_Package.pdf';
    a.click();
  };

  const exportDOCX = () => {
    const content = generateDocumentContent();
    const blob = new Blob([content], { type: 'application/vnd.openxmlformats-officedocument.wordprocessingml.document' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = 'Full_Financial_Architecture_Package.docx';
    a.click();
  };

  const generateDocumentContent = (): string => {
    return `
Financial Processing Architecture & Compliance Package
Generated: ${new Date().toISOString()}

1. ACH + CARD FUND FLOW ARCHITECTURE
${flowArchitecture}

2. COMPLIANCE MATRIX
${complianceMatrix.map(c => `${c.domain}: ${c.requirement}`).join('\n')}

3. FDIC PASS-THROUGH LEDGER MODEL
${ledgerModel}

4. HASH CHAIN VERIFICATION
${hashChain.map(h => `${h.timestamp} | ${h.action} | ${h.hash}`).join('\n')}
    `.trim();
  };

  const flowArchitecture = `API Gateway → Transaction Engine → Payment Switch Fabric
→ RTP / FedNow (Realtime Rails)
→ ACH Batch Engine (NACHA)
→ Ledger Cluster → Merkle Integrity → HSM Signing → Audit Pipeline`;

  const ledgerModel = `Ledger Entry → SHA256 → Merkle Tree → Root Hash → HSM Signature
Ensures tamper-proof financial records and audit replay capability.`;

  const detailedFlow = `API Gateway (mTLS / OAuth2 / WAF)
        ↓
Transaction Orchestrator (State Machine)
        ↓
Rail Router → RTP / FedNow / ACH / Fedwire
        ↓
Liquidity Engine (available check)
        ↓
Ledger Commit (append-only)
        ↓
Merkle Integrity Layer (SHA-256)
        ↓
HSM Signing (RSA-4096)
        ↓
Regulator Audit Pipeline`;

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'compliant':
        return 'bg-green-100 text-green-800 border-green-300';
      case 'review':
        return 'bg-amber-100 text-amber-800 border-amber-300';
      case 'pending':
        return 'bg-blue-100 text-blue-800 border-blue-300';
      default:
        return 'bg-slate-100 text-slate-800 border-slate-300';
    }
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <motion.div
        initial={{ opacity: 0, y: -20 }}
        animate={{ opacity: 1, y: 0 }}
        className="relative overflow-hidden rounded-xl bg-gradient-to-br from-green-600 via-emerald-600 to-teal-600 p-8 text-white"
      >
        <div className="relative z-10">
          <div className="flex items-center justify-between">
            <div className="flex-1">
              <div className="flex items-center gap-3 mb-3">
                <FileText className="w-10 h-10" />
                <h1 className="text-4xl font-bold">Regulatory Package Generator</h1>
              </div>
              <p className="text-xl text-green-100 mb-4">
                Comprehensive Regulator-Ready PDF & DOCX Compliance Package
              </p>
              <div className="flex items-center gap-3 flex-wrap">
                <Badge variant="outline" className="bg-white/20 text-white border-white/40 backdrop-blur-sm px-4 py-2">
                  <Shield className="w-4 h-4 mr-2" />
                  FFIEC Compliant
                </Badge>
                <Badge variant="outline" className="bg-white/20 text-white border-white/40 backdrop-blur-sm px-4 py-2">
                  <Hash className="w-4 h-4 mr-2" />
                  Hash Chain Verified
                </Badge>
                <Badge variant="outline" className="bg-white/20 text-white border-white/40 backdrop-blur-sm px-4 py-2">
                  <Lock className="w-4 h-4 mr-2" />
                  HSM Signed
                </Badge>
                <Badge variant="outline" className="bg-white/20 text-white border-white/40 backdrop-blur-sm px-4 py-2">
                  <FileCheck className="w-4 h-4 mr-2" />
                  Audit Ready
                </Badge>
              </div>
            </div>
            <div className="hidden md:block">
              <svg width="120" height="120" viewBox="0 0 20 20" fill="none" xmlns="http://www.w3.org/2000/svg">
                <path fillRule="evenodd" clipRule="evenodd"
                  d="M2 2H7V3.5H3.5V7H2V2ZM13 2H18V7H16.5V3.5H13V2ZM2 13H3.5V16.5H7V18H2V13ZM16.5 13H18V18H13V16.5H16.5V13Z"
                  fill="white" opacity="0.8"/>
              </svg>
            </div>
          </div>
        </div>
        
        {/* Background decoration */}
        <div className="absolute top-0 right-0 w-96 h-96 bg-white/10 rounded-full blur-3xl" />
        <div className="absolute bottom-0 left-0 w-64 h-64 bg-teal-400/20 rounded-full blur-2xl" />
      </motion.div>

      {/* Quick Actions */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <Card className="border-2 border-green-200">
          <CardContent className="pt-6">
            <div className="text-center">
              <div className="w-12 h-12 bg-green-100 rounded-full flex items-center justify-center mx-auto mb-3">
                <FileText className="w-6 h-6 text-green-600" />
              </div>
              <h3 className="font-bold text-slate-900 mb-2">Generate Package</h3>
              <Button
                onClick={generatePackage}
                disabled={generating}
                className="w-full bg-green-600 hover:bg-green-700"
              >
                {generating ? 'Generating...' : 'Generate Now'}
              </Button>
            </div>
          </CardContent>
        </Card>

        <Card className="border-2 border-blue-200">
          <CardContent className="pt-6">
            <div className="text-center">
              <div className="w-12 h-12 bg-blue-100 rounded-full flex items-center justify-center mx-auto mb-3">
                <Download className="w-6 h-6 text-blue-600" />
              </div>
              <h3 className="font-bold text-slate-900 mb-2">Export PDF</h3>
              <Button
                onClick={exportPDF}
                disabled={!packageReady}
                className="w-full bg-blue-600 hover:bg-blue-700"
              >
                Download PDF
              </Button>
            </div>
          </CardContent>
        </Card>

        <Card className="border-2 border-purple-200">
          <CardContent className="pt-6">
            <div className="text-center">
              <div className="w-12 h-12 bg-purple-100 rounded-full flex items-center justify-center mx-auto mb-3">
                <Download className="w-6 h-6 text-purple-600" />
              </div>
              <h3 className="font-bold text-slate-900 mb-2">Export DOCX</h3>
              <Button
                onClick={exportDOCX}
                disabled={!packageReady}
                className="w-full bg-purple-600 hover:bg-purple-700"
              >
                Download DOCX
              </Button>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Main Tabs */}
      <Tabs value={selectedTab} onValueChange={(value) => setSelectedTab(value as any)} className="w-full">
        <TabsList className="grid w-full grid-cols-5">
          <TabsTrigger value="flow">Flow Architecture</TabsTrigger>
          <TabsTrigger value="compliance">Compliance Matrix</TabsTrigger>
          <TabsTrigger value="ledger">Ledger Model</TabsTrigger>
          <TabsTrigger value="hashchain">Hash Chain</TabsTrigger>
          <TabsTrigger value="export">Export Options</TabsTrigger>
        </TabsList>

        {/* Flow Architecture Tab */}
        <TabsContent value="flow" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Network className="w-5 h-5 text-blue-600" />
                ACH + Card Fund Flow Architecture
              </CardTitle>
              <CardDescription>
                Complete payment processing flow from gateway to audit pipeline
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-6">
                {/* Simplified Flow */}
                <div className="bg-slate-50 border-2 border-slate-200 rounded-lg p-6">
                  <h3 className="font-bold text-slate-900 mb-4">Simplified Flow Diagram</h3>
                  <div className="font-mono text-sm text-slate-700 whitespace-pre-wrap">
                    {flowArchitecture}
                  </div>
                </div>

                {/* Detailed Flow */}
                <div className="bg-gradient-to-br from-blue-50 to-purple-50 border-2 border-blue-200 rounded-lg p-6">
                  <h3 className="font-bold text-slate-900 mb-4">Detailed Processing Pipeline</h3>
                  <div className="space-y-3">
                    {detailedFlow.split('\n').map((line, index) => {
                      const isArrow = line.trim() === '↓';
                      const isHeader = line.includes('(');
                      
                      return (
                        <motion.div
                          key={index}
                          initial={{ opacity: 0, x: -20 }}
                          animate={{ opacity: 1, x: 0 }}
                          transition={{ delay: index * 0.1 }}
                          className={`flex items-center ${isArrow ? 'justify-center' : ''}`}
                        >
                          {isArrow ? (
                            <ArrowRight className="w-6 h-6 text-blue-600 rotate-90" />
                          ) : (
                            <div className={`${isHeader ? 'bg-blue-600 text-white' : 'bg-white border-2 border-blue-300'} rounded-lg px-4 py-3 w-full`}>
                              <div className="flex items-center gap-3">
                                {index === 0 && <Shield className="w-5 h-5" />}
                                {index === 2 && <Zap className="w-5 h-5" />}
                                {index === 4 && <GitBranch className="w-5 h-5" />}
                                {index === 6 && <Activity className="w-5 h-5" />}
                                {index === 8 && <Server className="w-5 h-5" />}
                                {index === 10 && <Hash className="w-5 h-5" />}
                                {index === 12 && <Key className="w-5 h-5" />}
                                {index === 14 && <Eye className="w-5 h-5" />}
                                <span className={`font-mono text-sm ${isHeader ? '' : 'text-slate-700'}`}>
                                  {line.trim()}
                                </span>
                              </div>
                            </div>
                          )}
                        </motion.div>
                      );
                    })}
                  </div>
                </div>

                {/* Payment Rails */}
                <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                  <Card className="border-2 border-green-200">
                    <CardContent className="pt-6 text-center">
                      <div className="text-2xl font-bold text-green-600 mb-1">RTP</div>
                      <div className="text-xs text-slate-600">Real-Time Payments</div>
                    </CardContent>
                  </Card>
                  <Card className="border-2 border-blue-200">
                    <CardContent className="pt-6 text-center">
                      <div className="text-2xl font-bold text-blue-600 mb-1">FedNow</div>
                      <div className="text-xs text-slate-600">Federal Reserve</div>
                    </CardContent>
                  </Card>
                  <Card className="border-2 border-purple-200">
                    <CardContent className="pt-6 text-center">
                      <div className="text-2xl font-bold text-purple-600 mb-1">ACH</div>
                      <div className="text-xs text-slate-600">NACHA Network</div>
                    </CardContent>
                  </Card>
                  <Card className="border-2 border-orange-200">
                    <CardContent className="pt-6 text-center">
                      <div className="text-2xl font-bold text-orange-600 mb-1">Fedwire</div>
                      <div className="text-xs text-slate-600">Wire Transfer</div>
                    </CardContent>
                  </Card>
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        {/* Compliance Matrix Tab */}
        <TabsContent value="compliance" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Award className="w-5 h-5 text-green-600" />
                Compliance Control Matrix
              </CardTitle>
              <CardDescription>
                Regulatory requirements and compliance status across all domains
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-3">
                {complianceMatrix.map((control, index) => (
                  <motion.div
                    key={index}
                    initial={{ opacity: 0, y: 20 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ delay: index * 0.05 }}
                    className="border-2 border-slate-200 rounded-lg p-4 hover:shadow-md transition-shadow"
                  >
                    <div className="flex items-center justify-between">
                      <div className="flex-1">
                        <div className="flex items-center gap-3 mb-2">
                          <div className="w-10 h-10 bg-green-100 rounded-full flex items-center justify-center">
                            <CheckCircle className="w-5 h-5 text-green-600" />
                          </div>
                          <div>
                            <div className="font-bold text-slate-900">{control.domain}</div>
                            <div className="text-sm text-slate-600">{control.requirement}</div>
                          </div>
                        </div>
                      </div>
                      <Badge variant="outline" className={getStatusColor(control.status)}>
                        {control.status.toUpperCase()}
                      </Badge>
                    </div>
                  </motion.div>
                ))}
              </div>

              {/* Summary Stats */}
              <div className="mt-6 grid grid-cols-3 gap-4">
                <Card className="border-2 border-green-200">
                  <CardContent className="pt-6 text-center">
                    <div className="text-3xl font-bold text-green-600 mb-1">
                      {complianceMatrix.filter(c => c.status === 'compliant').length}
                    </div>
                    <div className="text-xs text-slate-600">Compliant Controls</div>
                  </CardContent>
                </Card>
                <Card className="border-2 border-blue-200">
                  <CardContent className="pt-6 text-center">
                    <div className="text-3xl font-bold text-blue-600 mb-1">
                      {complianceMatrix.length}
                    </div>
                    <div className="text-xs text-slate-600">Total Controls</div>
                  </CardContent>
                </Card>
                <Card className="border-2 border-purple-200">
                  <CardContent className="pt-6 text-center">
                    <div className="text-3xl font-bold text-purple-600 mb-1">100%</div>
                    <div className="text-xs text-slate-600">Compliance Rate</div>
                  </CardContent>
                </Card>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        {/* Ledger Model Tab */}
        <TabsContent value="ledger" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Server className="w-5 h-5 text-purple-600" />
                FDIC Pass-Through Ledger Model
              </CardTitle>
              <CardDescription>
                Tamper-proof financial records with Merkle tree integrity and HSM signing
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-6">
                {/* Ledger Flow */}
                <div className="bg-gradient-to-br from-purple-50 to-indigo-50 border-2 border-purple-200 rounded-lg p-6">
                  <h3 className="font-bold text-slate-900 mb-4">Ledger Processing Flow</h3>
                  <div className="font-mono text-sm text-slate-700 whitespace-pre-wrap mb-4">
                    {ledgerModel}
                  </div>
                  <div className="space-y-3">
                    {['Ledger Entry', 'SHA256 Hash', 'Merkle Tree', 'Root Hash', 'HSM Signature'].map((step, index) => (
                      <motion.div
                        key={index}
                        initial={{ opacity: 0, x: -20 }}
                        animate={{ opacity: 1, x: 0 }}
                        transition={{ delay: index * 0.1 }}
                        className="flex items-center gap-3"
                      >
                        <div className="w-8 h-8 bg-purple-600 text-white rounded-full flex items-center justify-center font-bold text-sm">
                          {index + 1}
                        </div>
                        <div className="flex-1 bg-white border-2 border-purple-300 rounded-lg px-4 py-2">
                          {step}
                        </div>
                        {index < 4 && <ArrowRight className="w-5 h-5 text-purple-600" />}
                      </motion.div>
                    ))}
                  </div>
                </div>

                {/* Features */}
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <Card className="border-2 border-green-200">
                    <CardHeader>
                      <CardTitle className="text-lg flex items-center gap-2">
                        <Lock className="w-5 h-5 text-green-600" />
                        Immutability
                      </CardTitle>
                    </CardHeader>
                    <CardContent>
                      <div className="space-y-2 text-sm">
                        <div className="flex items-center gap-2">
                          <CheckCircle className="w-4 h-4 text-green-600" />
                          <span>Append-only ledger structure</span>
                        </div>
                        <div className="flex items-center gap-2">
                          <CheckCircle className="w-4 h-4 text-green-600" />
                          <span>No modification or deletion allowed</span>
                        </div>
                        <div className="flex items-center gap-2">
                          <CheckCircle className="w-4 h-4 text-green-600" />
                          <span>Cryptographic hash verification</span>
                        </div>
                      </div>
                    </CardContent>
                  </Card>

                  <Card className="border-2 border-blue-200">
                    <CardHeader>
                      <CardTitle className="text-lg flex items-center gap-2">
                        <Eye className="w-5 h-5 text-blue-600" />
                        Auditability
                      </CardTitle>
                    </CardHeader>
                    <CardContent>
                      <div className="space-y-2 text-sm">
                        <div className="flex items-center gap-2">
                          <CheckCircle className="w-4 h-4 text-blue-600" />
                          <span>Complete transaction history</span>
                        </div>
                        <div className="flex items-center gap-2">
                          <CheckCircle className="w-4 h-4 text-blue-600" />
                          <span>Audit replay capability</span>
                        </div>
                        <div className="flex items-center gap-2">
                          <CheckCircle className="w-4 h-4 text-blue-600" />
                          <span>Regulator-ready exports</span>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        {/* Hash Chain Tab */}
        <TabsContent value="hashchain" className="space-y-6">
          <Card>
            <CardHeader>
              <div className="flex items-center justify-between">
                <div>
                  <CardTitle className="flex items-center gap-2">
                    <Hash className="w-5 h-5 text-orange-600" />
                    Hash Chain Verification
                  </CardTitle>
                  <CardDescription>
                    Cryptographic proof of transaction integrity with SHA-256 hashing
                  </CardDescription>
                </div>
                <Button
                  onClick={generateHashChain}
                  className="bg-orange-600 hover:bg-orange-700"
                >
                  Regenerate Chain
                </Button>
              </div>
            </CardHeader>
            <CardContent>
              {hashChain.length > 0 ? (
                <div className="space-y-3">
                  {hashChain.map((entry, index) => (
                    <motion.div
                      key={index}
                      initial={{ opacity: 0, y: 20 }}
                      animate={{ opacity: 1, y: 0 }}
                      transition={{ delay: index * 0.1 }}
                      className="border-2 border-orange-200 rounded-lg p-4 bg-gradient-to-r from-orange-50 to-amber-50"
                    >
                      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
                        <div>
                          <div className="text-xs text-slate-600 mb-1">Timestamp</div>
                          <div className="font-mono text-xs text-slate-900">
                            {new Date(entry.timestamp).toLocaleString()}
                          </div>
                        </div>
                        <div>
                          <div className="text-xs text-slate-600 mb-1">Action</div>
                          <Badge className="bg-orange-600">{entry.action}</Badge>
                        </div>
                        <div className="col-span-2">
                          <div className="text-xs text-slate-600 mb-1">Hash (SHA-256)</div>
                          <div className="font-mono text-xs text-orange-600 break-all">
                            {entry.hash}
                          </div>
                        </div>
                      </div>
                      {index > 0 && (
                        <div className="mt-3 pt-3 border-t border-orange-300">
                          <div className="text-xs text-slate-600 mb-1">Previous Hash</div>
                          <div className="font-mono text-xs text-slate-700 break-all">
                            {entry.previousHash}
                          </div>
                        </div>
                      )}
                    </motion.div>
                  ))}

                  {/* Verification Status */}
                  <div className="bg-green-50 border-2 border-green-300 rounded-lg p-4 mt-6">
                    <div className="flex items-center gap-3">
                      <CheckCircle className="w-6 h-6 text-green-600" />
                      <div>
                        <div className="font-bold text-green-900">Chain Verified</div>
                        <div className="text-sm text-green-700">
                          All {hashChain.length} entries cryptographically linked and verified
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              ) : (
                <div className="text-center py-12">
                  <Hash className="w-16 h-16 text-slate-300 mx-auto mb-4" />
                  <p className="text-slate-600 mb-4">No hash chain generated yet</p>
                  <Button onClick={generateHashChain} className="bg-orange-600">
                    Generate Hash Chain
                  </Button>
                </div>
              )}
            </CardContent>
          </Card>
        </TabsContent>

        {/* Export Options Tab */}
        <TabsContent value="export" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Download className="w-5 h-5 text-blue-600" />
                Export Package Options
              </CardTitle>
              <CardDescription>
                Generate and download comprehensive regulatory compliance packages
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-6">
                {/* Package Status */}
                {packageReady ? (
                  <div className="bg-green-50 border-2 border-green-300 rounded-lg p-6">
                    <div className="flex items-center gap-3 mb-4">
                      <CheckCircle className="w-8 h-8 text-green-600" />
                      <div>
                        <div className="font-bold text-green-900 text-lg">Package Ready for Export</div>
                        <div className="text-sm text-green-700">
                          Generated on {new Date().toLocaleString()}
                        </div>
                      </div>
                    </div>
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                      <Button onClick={exportPDF} className="bg-blue-600 hover:bg-blue-700 h-16">
                        <Download className="w-5 h-5 mr-2" />
                        Download PDF Package
                      </Button>
                      <Button onClick={exportDOCX} className="bg-purple-600 hover:bg-purple-700 h-16">
                        <Download className="w-5 h-5 mr-2" />
                        Download DOCX Package
                      </Button>
                    </div>
                  </div>
                ) : (
                  <div className="bg-amber-50 border-2 border-amber-300 rounded-lg p-6">
                    <div className="flex items-center gap-3 mb-4">
                      <AlertCircle className="w-8 h-8 text-amber-600" />
                      <div>
                        <div className="font-bold text-amber-900 text-lg">Package Not Generated</div>
                        <div className="text-sm text-amber-700">
                          Click "Generate Package" to create regulatory documentation
                        </div>
                      </div>
                    </div>
                    <Button onClick={generatePackage} disabled={generating} className="bg-green-600 hover:bg-green-700 h-16 w-full">
                      {generating ? 'Generating...' : 'Generate Package Now'}
                    </Button>
                  </div>
                )}

                {/* Package Contents */}
                <Card className="border-2 border-blue-200">
                  <CardHeader>
                    <CardTitle className="text-lg">Package Contents</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-2 text-sm">
                      <div className="flex items-center gap-2">
                        <FileCheck className="w-4 h-4 text-blue-600" />
                        <span>ACH + Card Fund Flow Architecture</span>
                      </div>
                      <div className="flex items-center gap-2">
                        <FileCheck className="w-4 h-4 text-blue-600" />
                        <span>Compliance Control Matrix (8 domains)</span>
                      </div>
                      <div className="flex items-center gap-2">
                        <FileCheck className="w-4 h-4 text-blue-600" />
                        <span>FDIC Pass-Through Ledger Model</span>
                      </div>
                      <div className="flex items-center gap-2">
                        <FileCheck className="w-4 h-4 text-blue-600" />
                        <span>Hash Chain Verification (4 entries)</span>
                      </div>
                      <div className="flex items-center gap-2">
                        <FileCheck className="w-4 h-4 text-blue-600" />
                        <span>Merkle Tree Integrity Proof</span>
                      </div>
                      <div className="flex items-center gap-2">
                        <FileCheck className="w-4 h-4 text-blue-600" />
                        <span>HSM Signature Verification</span>
                      </div>
                      <div className="flex items-center gap-2">
                        <FileCheck className="w-4 h-4 text-blue-600" />
                        <span>Audit Pipeline Documentation</span>
                      </div>
                    </div>
                  </CardContent>
                </Card>

                {/* Export Formats */}
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <Card className="border-2 border-red-200">
                    <CardHeader>
                      <CardTitle className="text-lg flex items-center gap-2">
                        <FileText className="w-5 h-5 text-red-600" />
                        PDF Format
                      </CardTitle>
                    </CardHeader>
                    <CardContent>
                      <div className="space-y-2 text-sm">
                        <div className="flex items-center gap-2">
                          <CheckCircle className="w-4 h-4 text-green-600" />
                          <span>Professional formatting</span>
                        </div>
                        <div className="flex items-center gap-2">
                          <CheckCircle className="w-4 h-4 text-green-600" />
                          <span>Print-ready layout</span>
                        </div>
                        <div className="flex items-center gap-2">
                          <CheckCircle className="w-4 h-4 text-green-600" />
                          <span>Universal compatibility</span>
                        </div>
                        <div className="flex items-center gap-2">
                          <CheckCircle className="w-4 h-4 text-green-600" />
                          <span>Regulator preferred format</span>
                        </div>
                      </div>
                    </CardContent>
                  </Card>

                  <Card className="border-2 border-indigo-200">
                    <CardHeader>
                      <CardTitle className="text-lg flex items-center gap-2">
                        <FileText className="w-5 h-5 text-indigo-600" />
                        DOCX Format
                      </CardTitle>
                    </CardHeader>
                    <CardContent>
                      <div className="space-y-2 text-sm">
                        <div className="flex items-center gap-2">
                          <CheckCircle className="w-4 h-4 text-green-600" />
                          <span>Editable content</span>
                        </div>
                        <div className="flex items-center gap-2">
                          <CheckCircle className="w-4 h-4 text-green-600" />
                          <span>Microsoft Word compatible</span>
                        </div>
                        <div className="flex items-center gap-2">
                          <CheckCircle className="w-4 h-4 text-green-600" />
                          <span>Customizable templates</span>
                        </div>
                        <div className="flex items-center gap-2">
                          <CheckCircle className="w-4 h-4 text-green-600" />
                          <span>Collaboration friendly</span>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
}