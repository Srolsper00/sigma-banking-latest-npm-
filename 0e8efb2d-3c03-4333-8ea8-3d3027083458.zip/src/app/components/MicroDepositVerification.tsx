import { useState } from 'react';
import { motion } from 'motion/react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from './ui/card';
import { Tabs, TabsContent, TabsList, TabsTrigger } from './ui/tabs';
import { Badge } from './ui/badge';
import { Button } from './ui/button';
import { Input } from './ui/input';
import { Label } from './ui/label';
import {
  Building2,
  CheckCircle,
  Clock,
  DollarSign,
  Shield,
  AlertCircle,
  ArrowRight,
  Hash,
  Lock,
  FileText,
  RefreshCw,
  XCircle,
  Database,
  Activity
} from 'lucide-react';

interface MicroDepositAccount {
  id: string;
  accountNumber: string;
  routingNumber: string;
  accountType: 'checking' | 'savings';
  accountHolder: string;
  status: 'pending_deposit' | 'pending_verification' | 'verified' | 'failed';
  depositAmount1?: number;
  depositAmount2?: number;
  depositDate?: string;
  verificationAttempts: number;
  maxAttempts: number;
  expiryDate?: string;
  bankName: string;
}

interface VerificationTransaction {
  id: string;
  accountId: string;
  timestamp: string;
  amount: number;
  description: string;
  status: 'initiated' | 'posted' | 'completed';
  achTraceNumber: string;
  settlementDate: string;
}

export function MicroDepositVerification() {
  const [selectedTab, setSelectedTab] = useState<'initiate' | 'verify' | 'monitor' | 'history'>('initiate');
  const [accounts, setAccounts] = useState<MicroDepositAccount[]>([
    {
      id: 'acct-001',
      accountNumber: '****5459050',
      routingNumber: '101205681',
      accountType: 'checking',
      accountHolder: 'Acme Corporation',
      status: 'pending_verification',
      depositAmount1: 0.23,
      depositAmount2: 0.47,
      depositDate: new Date(Date.now() - 86400000).toISOString(),
      verificationAttempts: 0,
      maxAttempts: 3,
      expiryDate: new Date(Date.now() + 86400000 * 2).toISOString(),
      bankName: 'UMB NA'
    },
    {
      id: 'acct-002',
      accountNumber: '****7823401',
      routingNumber: '101205681',
      accountType: 'savings',
      accountHolder: 'Tech Solutions LLC',
      status: 'verified',
      depositAmount1: 0.12,
      depositAmount2: 0.34,
      depositDate: new Date(Date.now() - 172800000).toISOString(),
      verificationAttempts: 1,
      maxAttempts: 3,
      bankName: 'UMB NA'
    }
  ]);

  const [transactions, setTransactions] = useState<VerificationTransaction[]>([
    {
      id: 'txn-001',
      accountId: 'acct-001',
      timestamp: new Date(Date.now() - 86400000).toISOString(),
      amount: 0.23,
      description: 'UMB NA VERIFY 23',
      status: 'completed',
      achTraceNumber: 'ACH-2025-091423-001',
      settlementDate: new Date(Date.now() - 43200000).toISOString()
    },
    {
      id: 'txn-002',
      accountId: 'acct-001',
      timestamp: new Date(Date.now() - 86400000).toISOString(),
      amount: 0.47,
      description: 'UMB NA VERIFY 47',
      status: 'completed',
      achTraceNumber: 'ACH-2025-091423-002',
      settlementDate: new Date(Date.now() - 43200000).toISOString()
    }
  ]);

  const [verificationInput, setVerificationInput] = useState({ amount1: '', amount2: '' });
  const [selectedAccount, setSelectedAccount] = useState<string | null>(null);

  // New account form state
  const [newAccount, setNewAccount] = useState({
    accountNumber: '',
    routingNumber: '',
    accountType: 'checking' as 'checking' | 'savings',
    accountHolder: ''
  });

  const generateMicroDepositAmounts = () => {
    // Generate two random amounts between $0.01 and $0.99
    const amount1 = Math.floor(Math.random() * 99) + 1;
    const amount2 = Math.floor(Math.random() * 99) + 1;
    return [amount1 / 100, amount2 / 100];
  };

  const initiateMicroDeposit = () => {
    if (!newAccount.accountNumber || !newAccount.routingNumber || !newAccount.accountHolder) {
      alert('Please fill in all required fields');
      return;
    }

    const [amount1, amount2] = generateMicroDepositAmounts();
    const accountId = `acct-${String(accounts.length + 1).padStart(3, '0')}`;

    const newAcct: MicroDepositAccount = {
      id: accountId,
      accountNumber: `****${newAccount.accountNumber.slice(-7)}`,
      routingNumber: newAccount.routingNumber,
      accountType: newAccount.accountType,
      accountHolder: newAccount.accountHolder,
      status: 'pending_deposit',
      depositAmount1: amount1,
      depositAmount2: amount2,
      depositDate: new Date().toISOString(),
      verificationAttempts: 0,
      maxAttempts: 3,
      expiryDate: new Date(Date.now() + 259200000).toISOString(), // 3 days
      bankName: 'UMB NA'
    };

    setAccounts([...accounts, newAcct]);

    // Create transactions
    const txn1: VerificationTransaction = {
      id: `txn-${String(transactions.length + 1).padStart(3, '0')}`,
      accountId: accountId,
      timestamp: new Date().toISOString(),
      amount: amount1,
      description: `UMB NA VERIFY ${String(amount1 * 100).padStart(2, '0')}`,
      status: 'initiated',
      achTraceNumber: `ACH-${new Date().toISOString().slice(0, 10).replace(/-/g, '')}-${String(transactions.length + 1).padStart(3, '0')}`,
      settlementDate: new Date(Date.now() + 86400000).toISOString()
    };

    const txn2: VerificationTransaction = {
      id: `txn-${String(transactions.length + 2).padStart(3, '0')}`,
      accountId: accountId,
      timestamp: new Date().toISOString(),
      amount: amount2,
      description: `UMB NA VERIFY ${String(amount2 * 100).padStart(2, '0')}`,
      status: 'initiated',
      achTraceNumber: `ACH-${new Date().toISOString().slice(0, 10).replace(/-/g, '')}-${String(transactions.length + 2).padStart(3, '0')}`,
      settlementDate: new Date(Date.now() + 86400000).toISOString()
    };

    setTransactions([...transactions, txn1, txn2]);

    // Simulate deposit posting after delay
    setTimeout(() => {
      setAccounts(prev => prev.map(acc => 
        acc.id === accountId ? { ...acc, status: 'pending_verification' } : acc
      ));
      setTransactions(prev => prev.map(txn => 
        txn.accountId === accountId ? { ...txn, status: 'posted' } : txn
      ));
    }, 2000);

    // Reset form
    setNewAccount({
      accountNumber: '',
      routingNumber: '',
      accountType: 'checking',
      accountHolder: ''
    });

    setSelectedTab('verify');
  };

  const verifyAccount = (accountId: string) => {
    const account = accounts.find(acc => acc.id === accountId);
    if (!account) return;

    const input1 = parseFloat(verificationInput.amount1);
    const input2 = parseFloat(verificationInput.amount2);

    const isCorrect = (
      (input1 === account.depositAmount1 && input2 === account.depositAmount2) ||
      (input1 === account.depositAmount2 && input2 === account.depositAmount1)
    );

    if (isCorrect) {
      setAccounts(prev => prev.map(acc =>
        acc.id === accountId
          ? { ...acc, status: 'verified', verificationAttempts: acc.verificationAttempts + 1 }
          : acc
      ));
      setTransactions(prev => prev.map(txn =>
        txn.accountId === accountId ? { ...txn, status: 'completed' } : txn
      ));
      setVerificationInput({ amount1: '', amount2: '' });
      setSelectedAccount(null);
    } else {
      const newAttempts = account.verificationAttempts + 1;
      if (newAttempts >= account.maxAttempts) {
        setAccounts(prev => prev.map(acc =>
          acc.id === accountId
            ? { ...acc, status: 'failed', verificationAttempts: newAttempts }
            : acc
        ));
      } else {
        setAccounts(prev => prev.map(acc =>
          acc.id === accountId
            ? { ...acc, verificationAttempts: newAttempts }
            : acc
        ));
      }
      alert(`Incorrect amounts. ${account.maxAttempts - newAttempts} attempts remaining.`);
    }
  };

  const getStatusBadge = (status: MicroDepositAccount['status']) => {
    const statusConfig = {
      pending_deposit: { label: 'Pending Deposit', color: 'bg-yellow-100 text-yellow-800 border-yellow-300', icon: Clock },
      pending_verification: { label: 'Pending Verification', color: 'bg-blue-100 text-blue-800 border-blue-300', icon: Shield },
      verified: { label: 'Verified', color: 'bg-green-100 text-green-800 border-green-300', icon: CheckCircle },
      failed: { label: 'Failed', color: 'bg-red-100 text-red-800 border-red-300', icon: XCircle }
    };

    const config = statusConfig[status];
    const Icon = config.icon;

    return (
      <Badge variant="outline" className={`${config.color} flex items-center gap-1`}>
        <Icon className="w-3 h-3" />
        {config.label}
      </Badge>
    );
  };

  const formatCurrency = (amount: number) => {
    return `$${amount.toFixed(2)}`;
  };

  const maskAccountNumber = (account: string) => {
    return account;
  };

  const systemStats = {
    totalAccounts: accounts.length,
    pendingVerification: accounts.filter(a => a.status === 'pending_verification').length,
    verified: accounts.filter(a => a.status === 'verified').length,
    failed: accounts.filter(a => a.status === 'failed').length,
    totalTransactions: transactions.length,
    successRate: accounts.length > 0 ? ((accounts.filter(a => a.status === 'verified').length / accounts.length) * 100).toFixed(1) : '0'
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <motion.div
        initial={{ opacity: 0, y: -20 }}
        animate={{ opacity: 1, y: 0 }}
        className="flex items-center justify-between"
      >
        <div>
          <h2 className="text-3xl font-bold text-slate-800 flex items-center gap-3">
            <DollarSign className="w-8 h-8 text-green-600" />
            Micro Deposit Verification System
          </h2>
          <p className="text-slate-600 mt-1">
            Account Verification via ACH Micro Deposits • UMB NA Settlement
          </p>
        </div>
        <Badge variant="default" className="bg-green-600 text-white px-4 py-2">
          <CheckCircle className="w-4 h-4 mr-2" />
          System Active
        </Badge>
      </motion.div>

      {/* System Stats */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.1 }}
        className="grid grid-cols-2 md:grid-cols-6 gap-4"
      >
        <Card className="border-blue-200">
          <CardContent className="pt-6">
            <div className="text-center">
              <div className="text-3xl font-bold text-blue-600">{systemStats.totalAccounts}</div>
              <div className="text-xs text-slate-600 mt-1">Total Accounts</div>
            </div>
          </CardContent>
        </Card>
        <Card className="border-yellow-200">
          <CardContent className="pt-6">
            <div className="text-center">
              <div className="text-3xl font-bold text-yellow-600">{systemStats.pendingVerification}</div>
              <div className="text-xs text-slate-600 mt-1">Pending</div>
            </div>
          </CardContent>
        </Card>
        <Card className="border-green-200">
          <CardContent className="pt-6">
            <div className="text-center">
              <div className="text-3xl font-bold text-green-600">{systemStats.verified}</div>
              <div className="text-xs text-slate-600 mt-1">Verified</div>
            </div>
          </CardContent>
        </Card>
        <Card className="border-red-200">
          <CardContent className="pt-6">
            <div className="text-center">
              <div className="text-3xl font-bold text-red-600">{systemStats.failed}</div>
              <div className="text-xs text-slate-600 mt-1">Failed</div>
            </div>
          </CardContent>
        </Card>
        <Card className="border-purple-200">
          <CardContent className="pt-6">
            <div className="text-center">
              <div className="text-3xl font-bold text-purple-600">{systemStats.totalTransactions}</div>
              <div className="text-xs text-slate-600 mt-1">Transactions</div>
            </div>
          </CardContent>
        </Card>
        <Card className="border-indigo-200">
          <CardContent className="pt-6">
            <div className="text-center">
              <div className="text-3xl font-bold text-indigo-600">{systemStats.successRate}%</div>
              <div className="text-xs text-slate-600 mt-1">Success Rate</div>
            </div>
          </CardContent>
        </Card>
      </motion.div>

      {/* Main Tabs */}
      <Tabs value={selectedTab} onValueChange={(value) => setSelectedTab(value as any)} className="w-full">
        <TabsList className="grid w-full grid-cols-4">
          <TabsTrigger value="initiate">Initiate Deposit</TabsTrigger>
          <TabsTrigger value="verify">Verify Account</TabsTrigger>
          <TabsTrigger value="monitor">Monitor Status</TabsTrigger>
          <TabsTrigger value="history">Transaction History</TabsTrigger>
        </TabsList>

        {/* Initiate Micro Deposit Tab */}
        <TabsContent value="initiate" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Building2 className="w-5 h-5 text-blue-600" />
                Initiate Micro Deposit Verification
              </CardTitle>
              <CardDescription>
                Enter bank account details to initiate two micro deposits for verification
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="accountHolder">Account Holder Name</Label>
                  <Input
                    id="accountHolder"
                    placeholder="e.g., Acme Corporation"
                    value={newAccount.accountHolder}
                    onChange={(e) => setNewAccount({ ...newAccount, accountHolder: e.target.value })}
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="accountType">Account Type</Label>
                  <select
                    id="accountType"
                    className="w-full px-3 py-2 border border-slate-300 rounded-md"
                    value={newAccount.accountType}
                    onChange={(e) => setNewAccount({ ...newAccount, accountType: e.target.value as 'checking' | 'savings' })}
                  >
                    <option value="checking">Checking</option>
                    <option value="savings">Savings</option>
                  </select>
                </div>
                <div className="space-y-2">
                  <Label htmlFor="routingNumber">Routing Number (ABA)</Label>
                  <Input
                    id="routingNumber"
                    placeholder="e.g., 101205681"
                    maxLength={9}
                    value={newAccount.routingNumber}
                    onChange={(e) => setNewAccount({ ...newAccount, routingNumber: e.target.value })}
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="accountNumber">Account Number</Label>
                  <Input
                    id="accountNumber"
                    placeholder="e.g., 39900000585459050"
                    value={newAccount.accountNumber}
                    onChange={(e) => setNewAccount({ ...newAccount, accountNumber: e.target.value })}
                  />
                </div>
              </div>

              <div className="bg-blue-50 border-2 border-blue-200 rounded-lg p-4">
                <div className="flex items-start gap-3">
                  <Shield className="w-5 h-5 text-blue-600 mt-0.5" />
                  <div className="text-sm text-blue-900">
                    <p className="font-semibold mb-2">Verification Process:</p>
                    <ul className="list-disc list-inside space-y-1 text-blue-800">
                      <li>Two random deposits between $0.01 - $0.99 will be sent via ACH</li>
                      <li>Deposits will appear in the account within 1-2 business days</li>
                      <li>Account holder must verify the exact amounts to complete setup</li>
                      <li>Verification expires after 3 days with 3 attempts allowed</li>
                    </ul>
                  </div>
                </div>
              </div>

              <Button 
                onClick={initiateMicroDeposit} 
                className="w-full bg-gradient-to-r from-blue-600 to-blue-700"
                size="lg"
              >
                <ArrowRight className="w-4 h-4 mr-2" />
                Initiate Micro Deposits via UMB NA
              </Button>
            </CardContent>
          </Card>
        </TabsContent>

        {/* Verify Account Tab */}
        <TabsContent value="verify" className="space-y-6">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            {accounts.filter(acc => acc.status === 'pending_verification').map((account) => (
              <motion.div
                key={account.id}
                initial={{ opacity: 0, scale: 0.95 }}
                animate={{ opacity: 1, scale: 1 }}
              >
                <Card className="border-2 border-blue-300">
                  <CardHeader>
                    <div className="flex items-center justify-between">
                      <CardTitle className="text-lg">{account.accountHolder}</CardTitle>
                      {getStatusBadge(account.status)}
                    </div>
                    <CardDescription className="font-mono">
                      {account.bankName} • {maskAccountNumber(account.accountNumber)}
                    </CardDescription>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    <div className="grid grid-cols-2 gap-3 text-sm">
                      <div>
                        <div className="text-slate-600">Routing Number</div>
                        <div className="font-mono text-slate-900">{account.routingNumber}</div>
                      </div>
                      <div>
                        <div className="text-slate-600">Account Type</div>
                        <div className="font-semibold text-slate-900 capitalize">{account.accountType}</div>
                      </div>
                      <div>
                        <div className="text-slate-600">Deposit Date</div>
                        <div className="text-slate-900">
                          {account.depositDate && new Date(account.depositDate).toLocaleDateString()}
                        </div>
                      </div>
                      <div>
                        <div className="text-slate-600">Expires</div>
                        <div className="text-slate-900">
                          {account.expiryDate && new Date(account.expiryDate).toLocaleDateString()}
                        </div>
                      </div>
                    </div>

                    <div className="border-t pt-4 space-y-3">
                      <div className="text-sm font-medium text-slate-700">
                        Enter the two deposit amounts:
                      </div>
                      <div className="grid grid-cols-2 gap-3">
                        <div className="space-y-2">
                          <Label htmlFor={`amount1-${account.id}`}>Amount 1</Label>
                          <Input
                            id={`amount1-${account.id}`}
                            type="number"
                            step="0.01"
                            placeholder="0.00"
                            value={selectedAccount === account.id ? verificationInput.amount1 : ''}
                            onChange={(e) => {
                              setSelectedAccount(account.id);
                              setVerificationInput({ ...verificationInput, amount1: e.target.value });
                            }}
                          />
                        </div>
                        <div className="space-y-2">
                          <Label htmlFor={`amount2-${account.id}`}>Amount 2</Label>
                          <Input
                            id={`amount2-${account.id}`}
                            type="number"
                            step="0.01"
                            placeholder="0.00"
                            value={selectedAccount === account.id ? verificationInput.amount2 : ''}
                            onChange={(e) => {
                              setSelectedAccount(account.id);
                              setVerificationInput({ ...verificationInput, amount2: e.target.value });
                            }}
                          />
                        </div>
                      </div>
                      
                      <div className="text-xs text-slate-600">
                        Attempts: {account.verificationAttempts} / {account.maxAttempts}
                      </div>

                      <Button 
                        onClick={() => verifyAccount(account.id)}
                        className="w-full bg-gradient-to-r from-green-600 to-green-700"
                        disabled={selectedAccount !== account.id || !verificationInput.amount1 || !verificationInput.amount2}
                      >
                        <CheckCircle className="w-4 h-4 mr-2" />
                        Verify Account
                      </Button>
                    </div>
                  </CardContent>
                </Card>
              </motion.div>
            ))}

            {accounts.filter(acc => acc.status === 'pending_verification').length === 0 && (
              <div className="col-span-2 text-center py-12">
                <Clock className="w-16 h-16 text-slate-300 mx-auto mb-4" />
                <p className="text-slate-600">No accounts pending verification</p>
              </div>
            )}
          </div>
        </TabsContent>

        {/* Monitor Status Tab */}
        <TabsContent value="monitor" className="space-y-4">
          {accounts.map((account) => (
            <motion.div
              key={account.id}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
            >
              <Card className={`border-2 ${
                account.status === 'verified' ? 'border-green-300 bg-green-50' :
                account.status === 'failed' ? 'border-red-300 bg-red-50' :
                account.status === 'pending_verification' ? 'border-blue-300 bg-blue-50' :
                'border-yellow-300 bg-yellow-50'
              }`}>
                <CardContent className="pt-6">
                  <div className="flex items-center justify-between">
                    <div className="flex-1">
                      <div className="flex items-center gap-3 mb-2">
                        <Building2 className="w-5 h-5 text-slate-600" />
                        <div className="font-bold text-slate-900">{account.accountHolder}</div>
                        {getStatusBadge(account.status)}
                      </div>
                      <div className="grid grid-cols-2 md:grid-cols-4 gap-4 text-sm mt-4">
                        <div>
                          <div className="text-slate-600 text-xs">Bank</div>
                          <div className="font-semibold text-slate-900">{account.bankName}</div>
                        </div>
                        <div>
                          <div className="text-slate-600 text-xs">Account</div>
                          <div className="font-mono text-slate-900">{maskAccountNumber(account.accountNumber)}</div>
                        </div>
                        <div>
                          <div className="text-slate-600 text-xs">Type</div>
                          <div className="font-semibold text-slate-900 capitalize">{account.accountType}</div>
                        </div>
                        <div>
                          <div className="text-slate-600 text-xs">Routing</div>
                          <div className="font-mono text-slate-900">{account.routingNumber}</div>
                        </div>
                      </div>

                      {account.status === 'pending_verification' && account.expiryDate && (
                        <div className="mt-4 flex items-center gap-2 text-sm">
                          <Clock className="w-4 h-4 text-amber-600" />
                          <span className="text-amber-700">
                            Expires: {new Date(account.expiryDate).toLocaleString()}
                          </span>
                        </div>
                      )}

                      {account.status === 'verified' && (
                        <div className="mt-4 flex items-center gap-2 text-sm">
                          <CheckCircle className="w-4 h-4 text-green-600" />
                          <span className="text-green-700 font-semibold">
                            Account verified and ready for transactions
                          </span>
                        </div>
                      )}
                    </div>
                  </div>
                </CardContent>
              </Card>
            </motion.div>
          ))}
        </TabsContent>

        {/* Transaction History Tab */}
        <TabsContent value="history" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Database className="w-5 h-5 text-purple-600" />
                Micro Deposit Transaction History
              </CardTitle>
              <CardDescription>All ACH micro deposit transactions processed via UMB NA</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-3">
                {transactions.map((txn) => {
                  const account = accounts.find(acc => acc.id === txn.accountId);
                  return (
                    <motion.div
                      key={txn.id}
                      initial={{ opacity: 0, x: -20 }}
                      animate={{ opacity: 1, x: 0 }}
                      className="border border-slate-200 rounded-lg p-4 hover:shadow-md transition-shadow"
                    >
                      <div className="flex items-start justify-between">
                        <div className="flex-1">
                          <div className="flex items-center gap-3 mb-2">
                            <Activity className="w-4 h-4 text-purple-600" />
                            <div className="font-semibold text-slate-900">{txn.description}</div>
                            <Badge variant="outline" className={`text-xs ${
                              txn.status === 'completed' ? 'bg-green-50 text-green-700 border-green-300' :
                              txn.status === 'posted' ? 'bg-blue-50 text-blue-700 border-blue-300' :
                              'bg-yellow-50 text-yellow-700 border-yellow-300'
                            }`}>
                              {txn.status.toUpperCase().replace('_', ' ')}
                            </Badge>
                          </div>
                          <div className="grid grid-cols-2 md:grid-cols-4 gap-4 text-sm mt-3">
                            <div>
                              <div className="text-slate-600 text-xs">Amount</div>
                              <div className="font-bold text-green-600">{formatCurrency(txn.amount)}</div>
                            </div>
                            <div>
                              <div className="text-slate-600 text-xs">Account Holder</div>
                              <div className="text-slate-900">{account?.accountHolder}</div>
                            </div>
                            <div>
                              <div className="text-slate-600 text-xs">ACH Trace Number</div>
                              <div className="font-mono text-xs text-slate-900">{txn.achTraceNumber}</div>
                            </div>
                            <div>
                              <div className="text-slate-600 text-xs">Settlement Date</div>
                              <div className="text-slate-900">{new Date(txn.settlementDate).toLocaleDateString()}</div>
                            </div>
                          </div>
                        </div>
                      </div>
                    </motion.div>
                  );
                })}
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>

      {/* Security Footer */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.3 }}
      >
        <Card className="border-indigo-200 bg-gradient-to-br from-indigo-50 to-white">
          <CardContent className="pt-6">
            <div className="flex items-center gap-3">
              <Lock className="w-5 h-5 text-indigo-600" />
              <div className="text-sm text-indigo-900">
                <span className="font-semibold">Security:</span> All micro deposits processed via UMB NA ACH network with SHA-256 hash verification, 
                idempotency protection, and immutable audit trail. NACHA compliance enforced.
              </div>
            </div>
          </CardContent>
        </Card>
      </motion.div>
    </div>
  );
}
