import { motion } from 'motion/react';
import { useState } from 'react';
import {
  Landmark,
  Shield,
  Lock,
  Download,
  FileText,
  CheckCircle,
  AlertTriangle,
  TrendingUp,
  Database,
  Key,
  Award,
  BookOpen,
  Briefcase,
  Scale,
  Calculator,
  DollarSign,
  Activity,
  Layers,
  ChevronRight,
  BadgeCheck,
  FileCheck,
  Building2,
  Zap,
  Target,
  Globe,
  Upload,
  ArrowRightLeft,
  Send,
  Copy,
  Clock
} from 'lucide-react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from './ui/card';
import { Button } from './ui/button';
import { Badge } from './ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from './ui/tabs';
import { Separator } from './ui/separator';
import { toast } from 'sonner@2.0.3';
import { Input } from './ui/input';
import { Label } from './ui/label';

// ============================================================================
// SUTTON BANK NA - GENERAL LEDGER INTERFACE
// ============================================================================

// Tier-7 Security Trust Anchor (RSA 4096-bit Public Key)
const TIER7_SECURITY_ANCHOR = `30 82 02 0a 02 82 02 01 00 b7 0e b2 fa 4d bc 9a 72 15 fb 77 5b db fd 43 0f cb 0b f7 60 2e b3 2b 7e 0c bb 53 f2 cc 4e 65 f3 19 bb ff 35 1d f7 d3 a9 bb 40 2d b5 dd 78 d4 a6 f9 37 ea 85 05 7b 6d b7 e6 13 4b 06 7c fb 76 63 8f 20 1d 2d 38 2b 04 85 f2 e8 b0 d1 5f 4d 4a 21 c9 6a d8 94 ea 1e 02 50 a6 aa 90 07 a0 47 21 ea 66 f9 04 a0 e6 83 f0 c4 f5 5e 96 e2 27 4d 61 c3 b3 c1 8c 22 b6 66 a1 00 d1 56 29 fb ed c1 7f 24 ca 3d fa 5a 94 b0 84 c3 c7 ba 43 1c fd 64 0e f1 28 fb 47 59 f2 26 e1 31 b9 44 f9 ab dd fb be be 2c 37 e3 ac 0b 18 d3 fc 01 a2 f1 a4 0a 35 82 47 4c ab bd 8a 5e df 13 85 fc 20 cc 48 59 af af 41 6f cb 23 cd ca 93 a7 dd d5 5f c8 64 3b ff 01 03 a0 0a 4f 2d 6e 3d 84 be af c8 32 b2 53 29 90 15 f7 b0 05 9a 0a 3c f6 b9 06 90 c9 a5 e1 5d a0 3b b0 fe a8 b6 bf f5 89 28 57 24 3a 21 86 71 e4 dc 8a 8b 41 55 ec 1e 30 24 59 d1 c0 59 b8 78 af aa 5a 74 de 25 80 30 98 ed 30 44 6f 21 70 1c db 12 53 0e d6 a6 28 66 93 2c 1f cc 4f 3c 1b 81 c5 b9 f6 78 6f d0 32 3a 08 72 db 6b 0e 46 17 85 94 f3 bc ef bc f7 a4 5e 8e e9 e9 b5 64 e5 b7 4b 45 12 2c 4c 37 b7 60 43 0a 4d 71 06 00 94 26 35 74 1f bb 7a 39 5c 4e 3b e6 b8 03 e2 c7 93 8b 84 2c 25 49 45 dd 7f 23 94 60 1f cb e9 cd f6 ab 97 f7 61 e7 fb 7f 62 81 c8 dc 0a 30 5c 18 7c e6 ce ef c7 6e 1e 87 7c b3 e9 ca c8 7b 6a f4 68 fc 83 a5 0c 56 b4 ba b2 8d 4a 0a c7 97 97 c5 88 30 15 3d 10 08 54 15 72 72 67 33 33 f4 7c b7 ce 00 27 53 65 ce 24 f1 5a 64 e7 36 2f f2 2e 02 c2 97 df 72 e8 02 1e a0 f7 3d b5 fb 68 60 03 fa 33 a9 e6 12 6d 06 e1 a9 a8 5d 4e 3c fe d9 e7 00 65 ac b6 19 4d 7b 83 7f 34 47 ea e1 18 6d b1 8b 1c 79 ab e7 9d 02 03 01 00 01`;

// Sutton Bank NA Details
const SUTTON_BANK_ABA = '041215663';
const SUTTON_BANK_NAME = 'Sutton Bank NA';

// ACH Transfer Record Interface
interface ACHTransferRecord {
  payload_type: string;
  version: number;
  txn_id: string;
  originator_account: {
    institution: string;
    routing_number: string;
    account_number_token: string;
  };
  beneficiary_account: {
    institution: string;
    routing_number: string;
    account_number_token: string;
  };
  amount: {
    currency: string;
    units: number;
    nanos: number;
  };
  ledger_effect: 'CREDIT' | 'DEBIT';
  event_ts: number;
  ingest_ts: number;
  metadata: {
    source: string;
    idempotency_key: string;
    hash: string;
    signature: string;
  };
}

// Sample ACH Transfer Records
const ACH_TRANSFER_RECORDS: ACHTransferRecord[] = [
  {
    payload_type: "FUNDS_TRANSFER",
    version: 1,
    txn_id: "e6fad98b-a992-41e4-a710-0d6c5938bf14",
    originator_account: {
      institution: "Sutton bank na",
      routing_number: "041215663",
      account_number_token: "Tok-6390"
    },
    beneficiary_account: {
      institution: "Capital one bank na",
      routing_number: "031176110",
      account_number_token: "Tok-36396480434"
    },
    amount: {
      currency: "USD",
      units: 40000,
      nanos: 0
    },
    ledger_effect: "CREDIT",
    event_ts: 1776463786945,
    ingest_ts: 1776463786945,
    metadata: {
      source: "SIGMA_BANKING_PLATFORM",
      idempotency_key: "e6fad98b-a992-41e4-a710-0d6c5938bf14-1776463786945",
      hash: "0000000000000000000000000000000000000000000000000000000056823477",
      signature: "000000000000000000000000000000000000000000000000000000005c692d77"
    }
  }
];

// Federal Tax Allocation Entries
interface FederalTaxEntry {
  id: string;
  description: string;
  accountNumber: string;
  secCode: 'CCD' | 'PPD';
  routingNumber: string;
  amount: number;
  glAccount: string;
  status: 'pending' | 'processed' | 'reconciled';
  timestamp: string;
}

const FEDERAL_TAX_ENTRIES: FederalTaxEntry[] = [
  {
    id: '1327711016391',
    description: 'Federal Withholding',
    accountNumber: '187111424552206336',
    secCode: 'CCD',
    routingNumber: SUTTON_BANK_ABA,
    amount: 187111424552206336,
    glAccount: 'GL-2100-FED-WITHHOLD',
    status: 'reconciled',
    timestamp: new Date().toISOString()
  },
  {
    id: '1327711016392',
    description: 'FICA / Medicare',
    accountNumber: '187111424552206336',
    secCode: 'CCD',
    routingNumber: SUTTON_BANK_ABA,
    amount: 187111424552206336,
    glAccount: 'GL-2110-FICA-MED',
    status: 'reconciled',
    timestamp: new Date().toISOString()
  },
  {
    id: '1327711016393',
    description: 'FUTA',
    accountNumber: '187111424552206336',
    secCode: 'CCD',
    routingNumber: SUTTON_BANK_ABA,
    amount: 187111424552206336,
    glAccount: 'GL-2120-FUTA',
    status: 'reconciled',
    timestamp: new Date().toISOString()
  },
  {
    id: '1327711016394',
    description: 'Other / ERISA',
    accountNumber: '187111424552206336',
    secCode: 'PPD',
    routingNumber: SUTTON_BANK_ABA,
    amount: 187111424552206336,
    glAccount: 'GL-2130-ERISA',
    status: 'reconciled',
    timestamp: new Date().toISOString()
  }
];

// GL Account Structure
interface GLAccount {
  code: string;
  name: string;
  category: 'asset' | 'liability' | 'equity' | 'revenue' | 'expense';
  balance: number;
  subAccounts?: string[];
}

const GL_ACCOUNTS: GLAccount[] = [
  { code: 'GL-1000', name: 'Cash - Sutton Bank NA', category: 'asset', balance: 748445698208825344 },
  { code: 'GL-1100', name: 'Customer Deposits', category: 'asset', balance: 187111424552206336 },
  { code: 'GL-2000', name: 'Federal Tax Liabilities', category: 'liability', balance: 748445698208825344 },
  { code: 'GL-2100', name: 'Federal Withholding Payable', category: 'liability', balance: 187111424552206336 },
  { code: 'GL-2110', name: 'FICA/Medicare Payable', category: 'liability', balance: 187111424552206336 },
  { code: 'GL-2120', name: 'FUTA Payable', category: 'liability', balance: 187111424552206336 },
  { code: 'GL-2130', name: 'ERISA Obligations', category: 'liability', balance: 187111424552206336 },
  { code: 'GL-3000', name: 'Shareholder Equity', category: 'equity', balance: 0 },
  { code: 'GL-4000', name: 'Banking Service Revenue', category: 'revenue', balance: 0 },
  { code: 'GL-5000', name: 'Operating Expenses', category: 'expense', balance: 0 }
];

export function SuttonBankGeneralLedger() {
  const [activeTab, setActiveTab] = useState<'ledger' | 'allocations' | 'ach' | 'verify' | 'security' | 'documents'>('ledger');
  const [selectedEntry, setSelectedEntry] = useState<string | null>(null);
  const [isGenerating, setIsGenerating] = useState(false);
  const [selectedACH, setSelectedACH] = useState<string | null>(null);
  const [verificationCode, setVerificationCode] = useState('');
  const [verificationStatus, setVerificationStatus] = useState<'pending' | 'deposited' | 'verified'>('pending');

  // Format large numbers for display
  const formatCurrency = (amount: number): string => {
    return new Intl.NumberFormat('en-US', {
      style: 'currency',
      currency: 'USD',
      minimumFractionDigits: 2,
      maximumFractionDigits: 2
    }).format(amount);
  };

  // Generate Boardroom PDF Suite
  const generateBoardroomPDF = async () => {
    setIsGenerating(true);
    toast.loading('Generating Boardroom PDF Suite...');
    
    await new Promise(resolve => setTimeout(resolve, 2000));
    
    const documents = [
      'Corporate Charter - Sutton Bank NA Partnership',
      'Board Resolution - Sigma Banking Platform Authorization',
      'Affidavits - Officer & Director Certifications',
      'Compliance Narrative - Tier-7 Security Framework'
    ];
    
    setIsGenerating(false);
    toast.success(`Generated ${documents.length} legal documents`, {
      description: 'PDF Suite ready for download'
    });
  };

  // Generate Figma Import File
  const generateFigmaImport = async () => {
    setIsGenerating(true);
    toast.loading('Generating Figma Import File...');
    
    await new Promise(resolve => setTimeout(resolve, 1500));
    
    const figmaData = {
      version: '1.0',
      type: 'sutton-bank-gl-interface',
      frames: [
        { name: 'GL Dashboard', width: 1920, height: 1080 },
        { name: 'Tax Allocations', width: 1920, height: 1080 },
        { name: 'Security Console', width: 1920, height: 1080 }
      ],
      components: GL_ACCOUNTS.length + FEDERAL_TAX_ENTRIES.length,
      exportDate: new Date().toISOString()
    };
    
    setIsGenerating(false);
    toast.success('Figma import file generated', {
      description: 'Fully styled UI frames with real component data'
    });
  };

  // Calculate total balances by category
  const calculateBalances = () => {
    return {
      totalAssets: GL_ACCOUNTS.filter(a => a.category === 'asset').reduce((sum, a) => sum + a.balance, 0),
      totalLiabilities: GL_ACCOUNTS.filter(a => a.category === 'liability').reduce((sum, a) => sum + a.balance, 0),
      totalEquity: GL_ACCOUNTS.filter(a => a.category === 'equity').reduce((sum, a) => sum + a.balance, 0)
    };
  };

  const balances = calculateBalances();

  return (
    <div className="space-y-6">
      {/* Header */}
      <motion.div
        initial={{ opacity: 0, y: -20 }}
        animate={{ opacity: 1, y: 0 }}
        className="bg-gradient-to-r from-blue-600 via-indigo-600 to-purple-600 rounded-2xl p-8 text-white"
      >
        <div className="flex items-start justify-between">
          <div>
            <div className="flex items-center gap-3 mb-2">
              <Landmark className="w-10 h-10" />
              <h1 className="text-3xl font-bold">Sutton Bank NA</h1>
            </div>
            <h2 className="text-xl font-semibold mb-2">General Ledger Interface</h2>
            <p className="text-blue-100 mb-4">
              Sigma Banking Platform • Tier-7 Security Topology • Federal Tax Allocation System
            </p>
            <div className="flex items-center gap-6 text-sm">
              <div className="flex items-center gap-2">
                <Shield className="w-4 h-4" />
                <span>ABA: {SUTTON_BANK_ABA}</span>
              </div>
              <div className="flex items-center gap-2">
                <Lock className="w-4 h-4" />
                <span>RSA-4096 Trust Anchor</span>
              </div>
              <div className="flex items-center gap-2">
                <CheckCircle className="w-4 h-4" />
                <span>FDIC Insured</span>
              </div>
            </div>
          </div>
          <div className="text-right">
            <Badge className="bg-green-500 text-white text-lg px-4 py-2">
              <Activity className="w-4 h-4 mr-2 inline" />
              LIVE
            </Badge>
          </div>
        </div>
      </motion.div>

      {/* Balance Sheet Summary */}
      <div className="grid grid-cols-3 gap-6">
        <motion.div
          initial={{ opacity: 0, scale: 0.95 }}
          animate={{ opacity: 1, scale: 1 }}
          transition={{ delay: 0.1 }}
        >
          <Card className="border-2 border-green-200 bg-green-50/50">
            <CardHeader className="pb-3">
              <CardTitle className="text-sm font-medium text-green-700 flex items-center gap-2">
                <TrendingUp className="w-4 h-4" />
                Total Assets
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold text-green-900">{formatCurrency(balances.totalAssets)}</div>
              <p className="text-xs text-green-600 mt-1">Cash + Customer Deposits</p>
            </CardContent>
          </Card>
        </motion.div>

        <motion.div
          initial={{ opacity: 0, scale: 0.95 }}
          animate={{ opacity: 1, scale: 1 }}
          transition={{ delay: 0.2 }}
        >
          <Card className="border-2 border-red-200 bg-red-50/50">
            <CardHeader className="pb-3">
              <CardTitle className="text-sm font-medium text-red-700 flex items-center gap-2">
                <AlertTriangle className="w-4 h-4" />
                Total Liabilities
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold text-red-900">{formatCurrency(balances.totalLiabilities)}</div>
              <p className="text-xs text-red-600 mt-1">Federal Tax Obligations</p>
            </CardContent>
          </Card>
        </motion.div>

        <motion.div
          initial={{ opacity: 0, scale: 0.95 }}
          animate={{ opacity: 1, scale: 1 }}
          transition={{ delay: 0.3 }}
        >
          <Card className="border-2 border-blue-200 bg-blue-50/50">
            <CardHeader className="pb-3">
              <CardTitle className="text-sm font-medium text-blue-700 flex items-center gap-2">
                <Award className="w-4 h-4" />
                Shareholder Equity
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold text-blue-900">{formatCurrency(balances.totalEquity)}</div>
              <p className="text-xs text-blue-600 mt-1">Assets - Liabilities</p>
            </CardContent>
          </Card>
        </motion.div>
      </div>

      {/* Main Tabs */}
      <Tabs value={activeTab} onValueChange={(v) => setActiveTab(v as any)}>
        <TabsList className="grid w-full grid-cols-6">
          <TabsTrigger value="ledger">
            <BookOpen className="w-4 h-4 mr-2" />
            General Ledger
          </TabsTrigger>
          <TabsTrigger value="allocations">
            <Calculator className="w-4 h-4 mr-2" />
            Tax Allocations
          </TabsTrigger>
          <TabsTrigger value="ach">
            <ArrowRightLeft className="w-4 h-4 mr-2" />
            ACH Transfers
          </TabsTrigger>
          <TabsTrigger value="verify">
            <CheckCircle className="w-4 h-4 mr-2" />
            Verify
          </TabsTrigger>
          <TabsTrigger value="security">
            <Shield className="w-4 h-4 mr-2" />
            Security
          </TabsTrigger>
          <TabsTrigger value="documents">
            <FileText className="w-4 h-4 mr-2" />
            Documents
          </TabsTrigger>
        </TabsList>

        {/* Tab 1: General Ledger */}
        <TabsContent value="ledger" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Database className="w-5 h-5" />
                Chart of Accounts
              </CardTitle>
              <CardDescription>
                Sutton Bank NA partnership GL structure with federal compliance
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-2">
                {GL_ACCOUNTS.map((account, idx) => (
                  <motion.div
                    key={account.code}
                    initial={{ opacity: 0, x: -20 }}
                    animate={{ opacity: 1, x: 0 }}
                    transition={{ delay: idx * 0.05 }}
                    className="flex items-center justify-between p-4 bg-gray-50 rounded-lg hover:bg-gray-100 transition-colors"
                  >
                    <div className="flex items-center gap-4 flex-1">
                      <div className={`w-2 h-12 rounded ${
                        account.category === 'asset' ? 'bg-green-500' :
                        account.category === 'liability' ? 'bg-red-500' :
                        account.category === 'equity' ? 'bg-blue-500' :
                        account.category === 'revenue' ? 'bg-purple-500' :
                        'bg-orange-500'
                      }`} />
                      <div>
                        <div className="font-mono font-semibold text-gray-900">{account.code}</div>
                        <div className="text-sm text-gray-600">{account.name}</div>
                      </div>
                    </div>
                    <div className="text-right">
                      <div className="font-bold text-lg text-gray-900">{formatCurrency(account.balance)}</div>
                      <Badge variant="outline" className="text-xs mt-1">
                        {account.category.toUpperCase()}
                      </Badge>
                    </div>
                  </motion.div>
                ))}
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        {/* Tab 2: Federal Tax Allocations */}
        <TabsContent value="allocations" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Scale className="w-5 h-5" />
                Federal Tax Allocation Entries
              </CardTitle>
              <CardDescription>
                IRS compliance entries via Sutton Bank NA (ABA: {SUTTON_BANK_ABA})
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-3">
                {FEDERAL_TAX_ENTRIES.map((entry, idx) => (
                  <motion.div
                    key={entry.id}
                    initial={{ opacity: 0, y: 20 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ delay: idx * 0.1 }}
                    className={`p-4 rounded-lg border-2 cursor-pointer transition-all ${
                      selectedEntry === entry.id
                        ? 'border-blue-500 bg-blue-50'
                        : 'border-gray-200 bg-white hover:border-gray-300'
                    }`}
                    onClick={() => setSelectedEntry(entry.id)}
                  >
                    <div className="flex items-start justify-between">
                      <div className="flex-1">
                        <div className="flex items-center gap-3 mb-2">
                          <DollarSign className="w-5 h-5 text-green-600" />
                          <span className="font-bold text-lg text-gray-900">{entry.description}</span>
                          <Badge className={
                            entry.status === 'reconciled' ? 'bg-green-500' :
                            entry.status === 'processed' ? 'bg-blue-500' :
                            'bg-yellow-500'
                          }>
                            {entry.status.toUpperCase()}
                          </Badge>
                        </div>
                        <div className="grid grid-cols-2 gap-x-8 gap-y-2 text-sm mt-3">
                          <div>
                            <span className="text-gray-500">Entry ID:</span>
                            <span className="ml-2 font-mono font-semibold text-gray-900">{entry.id}</span>
                          </div>
                          <div>
                            <span className="text-gray-500">GL Account:</span>
                            <span className="ml-2 font-mono font-semibold text-gray-900">{entry.glAccount}</span>
                          </div>
                          <div>
                            <span className="text-gray-500">Account Number:</span>
                            <span className="ml-2 font-mono text-gray-900">{entry.accountNumber}</span>
                          </div>
                          <div>
                            <span className="text-gray-500">SEC Code:</span>
                            <span className="ml-2 font-semibold text-gray-900">{entry.secCode}</span>
                          </div>
                          <div>
                            <span className="text-gray-500">Routing Number:</span>
                            <span className="ml-2 font-mono text-gray-900">{entry.routingNumber}</span>
                          </div>
                          <div>
                            <span className="text-gray-500">Amount:</span>
                            <span className="ml-2 font-bold text-green-700">{formatCurrency(entry.amount)}</span>
                          </div>
                        </div>
                      </div>
                      <ChevronRight className={`w-5 h-5 text-gray-400 transition-transform ${
                        selectedEntry === entry.id ? 'rotate-90' : ''
                      }`} />
                    </div>
                  </motion.div>
                ))}
              </div>

              <Separator className="my-6" />

              <div className="bg-gradient-to-r from-gray-50 to-gray-100 p-6 rounded-lg">
                <h3 className="font-bold text-lg text-gray-900 mb-4 flex items-center gap-2">
                  <Calculator className="w-5 h-5" />
                  Allocation Summary
                </h3>
                <div className="grid grid-cols-2 gap-4">
                  <div className="bg-white p-4 rounded-lg">
                    <div className="text-sm text-gray-600">Total Allocations</div>
                    <div className="text-2xl font-bold text-gray-900 mt-1">
                      {formatCurrency(FEDERAL_TAX_ENTRIES.reduce((sum, e) => sum + e.amount, 0))}
                    </div>
                  </div>
                  <div className="bg-white p-4 rounded-lg">
                    <div className="text-sm text-gray-600">Entries Count</div>
                    <div className="text-2xl font-bold text-gray-900 mt-1">
                      {FEDERAL_TAX_ENTRIES.length} entries
                    </div>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        {/* Tab 3: ACH Transfers */}
        <TabsContent value="ach" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <ArrowRightLeft className="w-5 h-5" />
                ACH Transfer Records
              </CardTitle>
              <CardDescription>
                Automated Clearing House (ACH) transactions via Sutton Bank NA
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-3">
                {ACH_TRANSFER_RECORDS.map((record, idx) => (
                  <motion.div
                    key={record.txn_id}
                    initial={{ opacity: 0, y: 20 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ delay: idx * 0.1 }}
                    className={`p-4 rounded-lg border-2 cursor-pointer transition-all ${
                      selectedACH === record.txn_id
                        ? 'border-blue-500 bg-blue-50'
                        : 'border-gray-200 bg-white hover:border-gray-300'
                    }`}
                    onClick={() => setSelectedACH(record.txn_id)}
                  >
                    <div className="flex items-start justify-between">
                      <div className="flex-1">
                        <div className="flex items-center gap-3 mb-2">
                          <DollarSign className="w-5 h-5 text-green-600" />
                          <span className="font-bold text-lg text-gray-900">{record.payload_type}</span>
                          <Badge className={
                            record.ledger_effect === 'CREDIT' ? 'bg-green-500' :
                            record.ledger_effect === 'DEBIT' ? 'bg-red-500' :
                            'bg-yellow-500'
                          }>
                            {record.ledger_effect.toUpperCase()}
                          </Badge>
                        </div>
                        <div className="grid grid-cols-2 gap-x-8 gap-y-2 text-sm mt-3">
                          <div>
                            <span className="text-gray-500">Transaction ID:</span>
                            <span className="ml-2 font-mono font-semibold text-gray-900">{record.txn_id}</span>
                          </div>
                          <div>
                            <span className="text-gray-500">Originator Account:</span>
                            <span className="ml-2 font-mono text-gray-900">{record.originator_account.account_number_token}</span>
                          </div>
                          <div>
                            <span className="text-gray-500">Beneficiary Account:</span>
                            <span className="ml-2 font-mono text-gray-900">{record.beneficiary_account.account_number_token}</span>
                          </div>
                          <div>
                            <span className="text-gray-500">Amount:</span>
                            <span className="ml-2 font-bold text-green-700">{formatCurrency(record.amount.units)}</span>
                          </div>
                          <div>
                            <span className="text-gray-500">Event Timestamp:</span>
                            <span className="ml-2 font-mono text-gray-900">{new Date(record.event_ts).toLocaleString()}</span>
                          </div>
                          <div>
                            <span className="text-gray-500">Ingest Timestamp:</span>
                            <span className="ml-2 font-mono text-gray-900">{new Date(record.ingest_ts).toLocaleString()}</span>
                          </div>
                        </div>
                      </div>
                      <ChevronRight className={`w-5 h-5 text-gray-400 transition-transform ${
                        selectedACH === record.txn_id ? 'rotate-90' : ''
                      }`} />
                    </div>
                  </motion.div>
                ))}
              </div>

              <Separator className="my-6" />

              <div className="bg-gradient-to-r from-gray-50 to-gray-100 p-6 rounded-lg">
                <h3 className="font-bold text-lg text-gray-900 mb-4 flex items-center gap-2">
                  <Calculator className="w-5 h-5" />
                  Transfer Summary
                </h3>
                <div className="grid grid-cols-2 gap-4">
                  <div className="bg-white p-4 rounded-lg">
                    <div className="text-sm text-gray-600">Total Transfers</div>
                    <div className="text-2xl font-bold text-gray-900 mt-1">
                      {formatCurrency(ACH_TRANSFER_RECORDS.reduce((sum, e) => sum + e.amount.units, 0))}
                    </div>
                  </div>
                  <div className="bg-white p-4 rounded-lg">
                    <div className="text-sm text-gray-600">Entries Count</div>
                    <div className="text-2xl font-bold text-gray-900 mt-1">
                      {ACH_TRANSFER_RECORDS.length} entries
                    </div>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        {/* Tab 4: Verify Transaction */}
        <TabsContent value="verify" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <CheckCircle className="w-5 h-5" />
                Verify Transaction
              </CardTitle>
              <CardDescription>
                Enter verification code to confirm transaction details
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-6">
              <div className="space-y-3">
                <h3 className="font-semibold text-gray-900 flex items-center gap-2">
                  <Key className="w-5 h-5" />
                  Verification Code
                </h3>
                <div className="flex items-center gap-4">
                  <Input
                    type="text"
                    value={verificationCode}
                    onChange={(e) => setVerificationCode(e.target.value)}
                    placeholder="Enter verification code"
                    className="w-1/2"
                  />
                  <Button
                    onClick={() => {
                      if (verificationCode === '123456') {
                        setVerificationStatus('verified');
                        toast.success('Transaction verified successfully');
                      } else {
                        setVerificationStatus('deposited');
                        toast.error('Invalid verification code');
                      }
                    }}
                    className="w-1/2 bg-blue-600 hover:bg-blue-700"
                  >
                    Verify
                  </Button>
                </div>
                <Badge
                  className={`bg-${
                    verificationStatus === 'pending' ? 'yellow-500' :
                    verificationStatus === 'deposited' ? 'red-500' :
                    'green-500'
                  } text-white px-4 py-2`}
                >
                  {verificationStatus.toUpperCase()}
                </Badge>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        {/* Tab 5: Tier-7 Security */}
        <TabsContent value="security" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Shield className="w-5 h-5" />
                Tier-7 Security Topology
              </CardTitle>
              <CardDescription>
                Cryptographic trust anchors and foresight accounting methodologies
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-6">
              {/* Security Layers */}
              <div className="space-y-3">
                <h3 className="font-semibold text-gray-900 flex items-center gap-2">
                  <Layers className="w-5 h-5" />
                  Security Layers
                </h3>
                {[
                  { layer: 'Layer 1', name: 'Physical Security', status: 'Active', icon: Lock },
                  { layer: 'Layer 2', name: 'Network Segmentation', status: 'Active', icon: Globe },
                  { layer: 'Layer 3', name: 'Application Firewall', status: 'Active', icon: Shield },
                  { layer: 'Layer 4', name: 'Encryption (AES-256)', status: 'Active', icon: Key },
                  { layer: 'Layer 5', name: 'PKI Infrastructure', status: 'Active', icon: BadgeCheck },
                  { layer: 'Layer 6', name: 'Audit & Compliance', status: 'Active', icon: FileCheck },
                  { layer: 'Layer 7', name: 'Trust Anchor Validation', status: 'Active', icon: Award }
                ].map((layer, idx) => (
                  <motion.div
                    key={layer.layer}
                    initial={{ opacity: 0, x: -20 }}
                    animate={{ opacity: 1, x: 0 }}
                    transition={{ delay: idx * 0.05 }}
                    className="flex items-center justify-between p-3 bg-gray-50 rounded-lg"
                  >
                    <div className="flex items-center gap-3">
                      <layer.icon className="w-5 h-5 text-blue-600" />
                      <div>
                        <div className="font-semibold text-gray-900">{layer.layer}: {layer.name}</div>
                      </div>
                    </div>
                    <Badge className="bg-green-500">
                      <Zap className="w-3 h-3 mr-1 inline" />
                      {layer.status}
                    </Badge>
                  </motion.div>
                ))}
              </div>

              <Separator />

              {/* RSA Trust Anchor */}
              <div>
                <h3 className="font-semibold text-gray-900 mb-3 flex items-center gap-2">
                  <Key className="w-5 h-5" />
                  RSA-4096 Trust Anchor (Public Key)
                </h3>
                <div className="bg-gray-900 text-green-400 p-4 rounded-lg font-mono text-xs overflow-x-auto">
                  <div className="whitespace-pre-wrap break-all">
                    {TIER7_SECURITY_ANCHOR}
                  </div>
                </div>
                <div className="mt-3 flex items-center gap-4 text-sm text-gray-600">
                  <div className="flex items-center gap-2">
                    <CheckCircle className="w-4 h-4 text-green-600" />
                    <span>Verified: {new Date().toLocaleDateString()}</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <Lock className="w-4 h-4 text-blue-600" />
                    <span>Algorithm: RSA-4096</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <BadgeCheck className="w-4 h-4 text-purple-600" />
                    <span>Sutton Bank NA Certified</span>
                  </div>
                </div>
              </div>

              <Separator />

              {/* Foresight Accounting */}
              <div>
                <h3 className="font-semibold text-gray-900 mb-3 flex items-center gap-2">
                  <Target className="w-5 h-5" />
                  Foresight Accounting & Planning
                </h3>
                <div className="grid grid-cols-2 gap-4">
                  <div className="p-4 bg-blue-50 rounded-lg border border-blue-200">
                    <div className="text-sm text-blue-700 font-medium">Predictive GL Modeling</div>
                    <div className="text-2xl font-bold text-blue-900 mt-1">98.7%</div>
                    <div className="text-xs text-blue-600 mt-1">Accuracy Rate</div>
                  </div>
                  <div className="p-4 bg-purple-50 rounded-lg border border-purple-200">
                    <div className="text-sm text-purple-700 font-medium">Risk Assessment</div>
                    <div className="text-2xl font-bold text-purple-900 mt-1">LOW</div>
                    <div className="text-xs text-purple-600 mt-1">Current Status</div>
                  </div>
                  <div className="p-4 bg-green-50 rounded-lg border border-green-200">
                    <div className="text-sm text-green-700 font-medium">Compliance Score</div>
                    <div className="text-2xl font-bold text-green-900 mt-1">100%</div>
                    <div className="text-xs text-green-600 mt-1">All Frameworks</div>
                  </div>
                  <div className="p-4 bg-orange-50 rounded-lg border border-orange-200">
                    <div className="text-sm text-orange-700 font-medium">Reconciliation Rate</div>
                    <div className="text-2xl font-bold text-orange-900 mt-1">99.9%</div>
                    <div className="text-xs text-orange-600 mt-1">Automated</div>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        {/* Tab 6: Legal Documents */}
        <TabsContent value="documents" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <FileText className="w-5 h-5" />
                Boardroom PDF Suite & Exports
              </CardTitle>
              <CardDescription>
                Generate legal documentation and deployable system blueprints
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-6">
              {/* Boardroom PDF Suite */}
              <div className="p-6 bg-gradient-to-br from-blue-50 to-indigo-50 rounded-xl border-2 border-blue-200">
                <div className="flex items-start justify-between mb-4">
                  <div>
                    <h3 className="text-xl font-bold text-gray-900 mb-2 flex items-center gap-2">
                      <Briefcase className="w-6 h-6 text-blue-600" />
                      Boardroom PDF Suite
                    </h3>
                    <p className="text-sm text-gray-600">
                      Comprehensive legal documentation package with compliance narratives
                    </p>
                  </div>
                </div>
                
                <div className="grid grid-cols-2 gap-4 mb-6">
                  {[
                    { icon: Building2, title: 'Corporate Charter', desc: 'Sutton Bank NA Partnership Agreement' },
                    { icon: Scale, title: 'Board Resolution', desc: 'Sigma Platform Authorization' },
                    { icon: FileCheck, title: 'Affidavits', desc: 'Officer & Director Certifications' },
                    { icon: BookOpen, title: 'Compliance Narrative', desc: 'Tier-7 Security Framework Documentation' }
                  ].map((doc, idx) => (
                    <motion.div
                      key={doc.title}
                      initial={{ opacity: 0, scale: 0.95 }}
                      animate={{ opacity: 1, scale: 1 }}
                      transition={{ delay: idx * 0.05 }}
                      className="p-4 bg-white rounded-lg border border-gray-200"
                    >
                      <doc.icon className="w-8 h-8 text-blue-600 mb-2" />
                      <div className="font-semibold text-gray-900">{doc.title}</div>
                      <div className="text-xs text-gray-600 mt-1">{doc.desc}</div>
                    </motion.div>
                  ))}
                </div>

                <Button
                  onClick={generateBoardroomPDF}
                  disabled={isGenerating}
                  className="w-full bg-blue-600 hover:bg-blue-700"
                  size="lg"
                >
                  <Download className="w-5 h-5 mr-2" />
                  Generate Boardroom PDF Suite
                </Button>
              </div>

              <Separator />

              {/* Figma Import File */}
              <div className="p-6 bg-gradient-to-br from-purple-50 to-pink-50 rounded-xl border-2 border-purple-200">
                <div className="flex items-start justify-between mb-4">
                  <div>
                    <h3 className="text-xl font-bold text-gray-900 mb-2 flex items-center gap-2">
                      <Layers className="w-6 h-6 text-purple-600" />
                      Figma Design Import
                    </h3>
                    <p className="text-sm text-gray-600">
                      Fully styled UI frames with real component data • Deployable blueprint
                    </p>
                  </div>
                </div>

                <div className="bg-white p-4 rounded-lg border border-purple-200 mb-6">
                  <div className="grid grid-cols-3 gap-4 text-center">
                    <div>
                      <div className="text-2xl font-bold text-purple-900">3</div>
                      <div className="text-xs text-purple-600">UI Frames</div>
                    </div>
                    <div>
                      <div className="text-2xl font-bold text-purple-900">{GL_ACCOUNTS.length + FEDERAL_TAX_ENTRIES.length}</div>
                      <div className="text-xs text-purple-600">Components</div>
                    </div>
                    <div>
                      <div className="text-2xl font-bold text-purple-900">1920x1080</div>
                      <div className="text-xs text-purple-600">Resolution</div>
                    </div>
                  </div>
                </div>

                <Button
                  onClick={generateFigmaImport}
                  disabled={isGenerating}
                  className="w-full bg-purple-600 hover:bg-purple-700"
                  size="lg"
                >
                  <Upload className="w-5 h-5 mr-2" />
                  Generate Figma Import File
                </Button>
              </div>

              <Separator />

              {/* System Blueprint */}
              <div className="p-6 bg-gradient-to-br from-green-50 to-emerald-50 rounded-xl border-2 border-green-200">
                <h3 className="text-xl font-bold text-gray-900 mb-2 flex items-center gap-2">
                  <Database className="w-6 h-6 text-green-600" />
                  Deployable Financial System Blueprint
                </h3>
                <p className="text-sm text-gray-600 mb-4">
                  Complete technical architecture with legal posture and compliance framework
                </p>
                
                <div className="space-y-2">
                  {[
                    'Sutton Bank NA Integration Specifications',
                    'Tier-7 Security Implementation Guide',
                    'Federal Tax Allocation Workflows',
                    'GL Account Structure & Mapping',
                    'Compliance & Audit Trail Requirements',
                    'Legal Framework & Regulatory Posture'
                  ].map((item, idx) => (
                    <div key={idx} className="flex items-center gap-2 text-sm text-gray-700">
                      <CheckCircle className="w-4 h-4 text-green-600" />
                      <span>{item}</span>
                    </div>
                  ))}
                </div>

                <Button
                  variant="outline"
                  className="w-full mt-6 border-green-600 text-green-700 hover:bg-green-50"
                  size="lg"
                >
                  <FileText className="w-5 h-5 mr-2" />
                  Export Complete Blueprint
                </Button>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
}