/**
 * Firewall Security Dashboard
 * Sigma Production Banking Platform
 * 
 * Real-time monitoring and control of firewall protection system
 */

import React, { useState, useEffect } from 'react';
import { Shield, AlertTriangle, Ban, Lock, Activity, Download } from 'lucide-react';
import { FirewallProtectionSystem, FirewallRule, SecurityEvent, IPAnalysis } from '../utils/firewall-protection';

export function FirewallSecurityDashboard() {
  const [rules, setRules] = useState<FirewallRule[]>([]);
  const [events, setEvents] = useState<SecurityEvent[]>([]);
  const [testIP, setTestIP] = useState('');
  const [ipAnalysis, setIpAnalysis] = useState<IPAnalysis | null>(null);
  const [stats, setStats] = useState({
    totalBlocked: 0,
    activeRules: 0,
    criticalEvents: 0,
    encryptionStatus: 'ACTIVE'
  });
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    try {
      // Initialize firewall
      FirewallProtectionSystem.initialize();
      loadData();
      
      // Save all data to localStorage
      saveAllData();
      setIsLoading(false);
    } catch (err) {
      console.error('Error initializing firewall:', err);
      setError(err instanceof Error ? err.message : 'Failed to initialize firewall');
      setIsLoading(false);
    }
  }, []);

  const loadData = () => {
    try {
      const loadedRules = FirewallProtectionSystem.getRules();
      const loadedEvents = FirewallProtectionSystem.getSecurityEvents();
      
      setRules(loadedRules);
      setEvents(loadedEvents.slice(0, 50)); // Show last 50 events
      
      // Calculate stats
      setStats({
        totalBlocked: loadedEvents.filter(e => e.type === 'BLOCKED_IP').length,
        activeRules: loadedRules.filter(r => r.enabled).length,
        criticalEvents: loadedEvents.filter(e => e.severity === 'CRITICAL').length,
        encryptionStatus: 'ACTIVE'
      });
    } catch (err) {
      console.error('Error loading data:', err);
      setError(err instanceof Error ? err.message : 'Failed to load data');
    }
  };

  const saveAllData = () => {
    console.log('💾 Saving all Sigma Banking Platform data...');
    
    // Ensure all data is persisted
    const allData = {
      timestamp: Date.now(),
      platform: 'SIGMA_BANKING_PLATFORM',
      data: {
        firewallRules: FirewallProtectionSystem.getRules(),
        securityEvents: FirewallProtectionSystem.getSecurityEvents(),
        ipBlacklist: FirewallProtectionSystem.getIPBlacklist(),
        fundsPayloads: JSON.parse(localStorage.getItem('fundsPayloads') || '[]'),
        genesisPool: JSON.parse(localStorage.getItem('genesisPool') || '{}'),
        ledgerTransactions: JSON.parse(localStorage.getItem('ledgerTransactions') || '[]')
      }
    };
    
    localStorage.setItem('sigma_complete_backup', JSON.stringify(allData));
    console.log('✅ All data saved successfully!');
  };

  const handleTestIP = () => {
    if (!testIP) return;
    
    const analysis = FirewallProtectionSystem.analyzeIP(testIP);
    setIpAnalysis(analysis);
    
    // Test full request validation
    const validation = FirewallProtectionSystem.validateRequest({
      ip: testIP,
      method: 'POST',
      endpoint: '/api/transfer',
      headers: {
        'x-forwarded-proto': 'https',
        'x-tls-version': '1.3'
      },
      timestamp: Date.now()
    });
    
    console.log('IP Analysis:', analysis);
    console.log('Request Validation:', validation);
    
    loadData(); // Refresh events
  };

  const handleBlockIP = (ip: string) => {
    FirewallProtectionSystem.blockIP(ip, 'Manual block from dashboard');
    loadData();
    alert(`IP ${ip} has been blocked`);
  };

  const handleExportConfig = () => {
    const config = FirewallProtectionSystem.exportConfiguration();
    const blob = new Blob([config], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `sigma-firewall-config-${Date.now()}.json`;
    a.click();
    URL.revokeObjectURL(url);
  };

  const getSeverityColor = (severity: string) => {
    switch (severity) {
      case 'CRITICAL': return 'text-red-600 bg-red-50 border-red-200';
      case 'HIGH': return 'text-orange-600 bg-orange-50 border-orange-200';
      case 'MEDIUM': return 'text-yellow-600 bg-yellow-50 border-yellow-200';
      default: return 'text-blue-600 bg-blue-50 border-blue-200';
    }
  };

  const getRiskColor = (score: number) => {
    if (score >= 80) return 'text-red-600';
    if (score >= 50) return 'text-orange-600';
    if (score >= 25) return 'text-yellow-600';
    return 'text-green-600';
  };

  // Show loading state
  if (isLoading) {
    return (
      <div className="flex items-center justify-center min-h-[400px]">
        <div className="text-center">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-600 mx-auto mb-4"></div>
          <p className="text-gray-600">Loading Firewall Dashboard...</p>
        </div>
      </div>
    );
  }

  // Show error state
  if (error) {
    return (
      <div className="bg-red-50 border border-red-200 rounded-lg p-6">
        <h3 className="text-lg font-semibold text-red-900 mb-2">Error Loading Firewall</h3>
        <p className="text-red-700">{error}</p>
        <button
          onClick={() => {
            setError(null);
            setIsLoading(true);
            setTimeout(() => {
              try {
                FirewallProtectionSystem.initialize();
                loadData();
                setIsLoading(false);
              } catch (err) {
                setError('Failed to initialize');
                setIsLoading(false);
              }
            }, 100);
          }}
          className="mt-4 px-4 py-2 bg-red-600 text-white rounded-lg hover:bg-red-700"
        >
          Retry
        </button>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between border-b border-gray-200 pb-4">
        <div>
          <h2 className="text-2xl font-bold text-gray-900 flex items-center gap-2">
            <Shield className="w-7 h-7 text-blue-600" />
            Firewall Security Dashboard
          </h2>
          <p className="mt-1 text-sm text-gray-600">
            Real-time protection against unrelenting communication and IP distorted erroneous request hops
          </p>
        </div>
        <div className="flex gap-3">
          <button
            onClick={saveAllData}
            className="px-4 py-2 bg-green-600 text-white rounded-lg hover:bg-green-700 transition-colors text-sm font-medium flex items-center gap-2"
          >
            <Download className="w-4 h-4" />
            Save All Data
          </button>
          <button
            onClick={handleExportConfig}
            className="px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors text-sm font-medium flex items-center gap-2"
          >
            <Download className="w-4 h-4" />
            Export Config
          </button>
        </div>
      </div>

      {/* Stats Cards */}
      <div className="grid grid-cols-4 gap-4">
        <div className="bg-gradient-to-br from-blue-50 to-blue-100 border border-blue-200 rounded-lg p-4">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-blue-700 font-medium">Active Rules</p>
              <p className="text-3xl font-bold text-blue-900 mt-1">{stats.activeRules}</p>
            </div>
            <Shield className="w-10 h-10 text-blue-600 opacity-50" />
          </div>
        </div>

        <div className="bg-gradient-to-br from-red-50 to-red-100 border border-red-200 rounded-lg p-4">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-red-700 font-medium">Blocked Requests</p>
              <p className="text-3xl font-bold text-red-900 mt-1">{stats.totalBlocked}</p>
            </div>
            <Ban className="w-10 h-10 text-red-600 opacity-50" />
          </div>
        </div>

        <div className="bg-gradient-to-br from-orange-50 to-orange-100 border border-orange-200 rounded-lg p-4">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-orange-700 font-medium">Critical Events</p>
              <p className="text-3xl font-bold text-orange-900 mt-1">{stats.criticalEvents}</p>
            </div>
            <AlertTriangle className="w-10 h-10 text-orange-600 opacity-50" />
          </div>
        </div>

        <div className="bg-gradient-to-br from-green-50 to-green-100 border border-green-200 rounded-lg p-4">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-green-700 font-medium">Encryption</p>
              <p className="text-xl font-bold text-green-900 mt-1">{stats.encryptionStatus}</p>
            </div>
            <Lock className="w-10 h-10 text-green-600 opacity-50" />
          </div>
        </div>
      </div>

      {/* IP Analysis Tool */}
      <div className="bg-white border border-gray-200 rounded-lg p-6">
        <h3 className="text-lg font-semibold text-gray-900 mb-4 flex items-center gap-2">
          <Activity className="w-5 h-5 text-purple-600" />
          IP Address Analysis
        </h3>
        
        <div className="flex gap-3 mb-4">
          <input
            type="text"
            value={testIP}
            onChange={(e) => setTestIP(e.target.value)}
            placeholder="Enter IP address (e.g., 192.168.1.1)"
            className="flex-1 px-4 py-2 border border-gray-300 rounded-lg text-sm"
          />
          <button
            onClick={handleTestIP}
            className="px-6 py-2 bg-purple-600 text-white rounded-lg hover:bg-purple-700 transition-colors font-medium"
          >
            Analyze
          </button>
        </div>

        {ipAnalysis && (
          <div className="bg-gray-50 border border-gray-200 rounded-lg p-4">
            <div className="grid grid-cols-2 gap-4">
              <div>
                <p className="text-xs text-gray-600 mb-1">IP Address</p>
                <p className="font-mono font-semibold">{ipAnalysis.ip}</p>
              </div>
              <div>
                <p className="text-xs text-gray-600 mb-1">Status</p>
                <span className={`inline-block px-3 py-1 rounded-full text-xs font-semibold ${
                  ipAnalysis.status === 'VALID' ? 'bg-green-100 text-green-800' :
                  ipAnalysis.status === 'SUSPICIOUS' ? 'bg-yellow-100 text-yellow-800' :
                  ipAnalysis.status === 'DISTORTED' ? 'bg-orange-100 text-orange-800' :
                  'bg-red-100 text-red-800'
                }`}>
                  {ipAnalysis.status}
                </span>
              </div>
              <div>
                <p className="text-xs text-gray-600 mb-1">Risk Score</p>
                <p className={`text-2xl font-bold ${getRiskColor(ipAnalysis.riskScore)}`}>
                  {ipAnalysis.riskScore}/100
                </p>
              </div>
              <div>
                <p className="text-xs text-gray-600 mb-1">Hop Count</p>
                <p className="font-semibold">{ipAnalysis.hopCount} hops</p>
              </div>
              <div>
                <p className="text-xs text-gray-600 mb-1">Proxy Detection</p>
                <p className="font-semibold">{ipAnalysis.isProxy ? '⚠️ Proxy' : '✓ Direct'}</p>
              </div>
              <div>
                <p className="text-xs text-gray-600 mb-1">TOR Network</p>
                <p className="font-semibold">{ipAnalysis.isTor ? '🚫 TOR Node' : '✓ Clear'}</p>
              </div>
              <div>
                <p className="text-xs text-gray-600 mb-1">VPN Detection</p>
                <p className="font-semibold">{ipAnalysis.isVpn ? '⚠️ VPN' : '✓ Clear'}</p>
              </div>
              <div>
                <p className="text-xs text-gray-600 mb-1">Geolocation</p>
                <p className="font-semibold">{ipAnalysis.geolocation}</p>
              </div>
            </div>
            
            {ipAnalysis.status === 'BLOCKED' && (
              <div className="mt-4 p-3 bg-red-50 border border-red-200 rounded text-sm text-red-800">
                <strong>🚫 IP BLOCKED:</strong> This IP address has been automatically blocked due to high risk score.
              </div>
            )}
            
            {ipAnalysis.status === 'DISTORTED' && (
              <div className="mt-4 p-3 bg-orange-50 border border-orange-200 rounded text-sm text-orange-800">
                <strong>⚠️ IP DISTORTED:</strong> This IP address appears malformed or spoofed. Request will be denied.
              </div>
            )}
          </div>
        )}
      </div>

      {/* Firewall Rules */}
      <div className="bg-white border border-gray-200 rounded-lg p-6">
        <h3 className="text-lg font-semibold text-gray-900 mb-4">Active Firewall Rules</h3>
        
        <div className="space-y-2">
          {rules.map((rule) => (
            <div
              key={rule.id}
              className={`p-4 border rounded-lg ${
                rule.type === 'BLOCK' ? 'bg-red-50 border-red-200' :
                rule.type === 'ALLOW' ? 'bg-green-50 border-green-200' :
                'bg-yellow-50 border-yellow-200'
              }`}
            >
              <div className="flex items-center justify-between">
                <div className="flex-1">
                  <div className="flex items-center gap-3">
                    <span className={`px-2 py-1 rounded text-xs font-bold ${
                      rule.type === 'BLOCK' ? 'bg-red-600 text-white' :
                      rule.type === 'ALLOW' ? 'bg-green-600 text-white' :
                      'bg-yellow-600 text-white'
                    }`}>
                      {rule.type}
                    </span>
                    <span className="font-mono text-sm font-semibold">
                      {rule.source} → {rule.target}
                    </span>
                    <span className="text-xs text-gray-600">
                      {rule.protocol}
                    </span>
                  </div>
                  <p className="mt-1 text-sm text-gray-700">{rule.reason}</p>
                </div>
                <div className="text-right">
                  <span className={`inline-block px-2 py-1 rounded text-xs font-semibold ${
                    rule.enabled ? 'bg-green-100 text-green-800' : 'bg-gray-100 text-gray-600'
                  }`}>
                    {rule.enabled ? 'ENABLED' : 'DISABLED'}
                  </span>
                  <p className="text-xs text-gray-500 mt-1">Priority: {rule.priority}</p>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Security Events Log */}
      <div className="bg-white border border-gray-200 rounded-lg p-6">
        <h3 className="text-lg font-semibold text-gray-900 mb-4">Recent Security Events</h3>
        
        <div className="space-y-2 max-h-96 overflow-y-auto">
          {events.length === 0 ? (
            <p className="text-center text-gray-500 py-8">No security events recorded</p>
          ) : (
            events.map((event) => (
              <div
                key={event.id}
                className={`p-3 border rounded-lg ${getSeverityColor(event.severity)}`}
              >
                <div className="flex items-start justify-between">
                  <div className="flex-1">
                    <div className="flex items-center gap-2">
                      <span className="font-semibold text-sm">{event.type}</span>
                      <span className="text-xs opacity-75">
                        {new Date(event.timestamp).toLocaleTimeString()}
                      </span>
                    </div>
                    <p className="text-sm mt-1">{event.details}</p>
                    <p className="text-xs mt-1 font-mono opacity-75">Source: {event.source}</p>
                  </div>
                  <div className="ml-4">
                    <span className="text-xs font-bold">{event.severity}</span>
                  </div>
                </div>
              </div>
            ))
          )}
        </div>
      </div>

      {/* Encryption Status */}
      <div className="bg-gradient-to-r from-blue-600 to-purple-600 text-white rounded-lg p-6">
        <div className="flex items-center justify-between">
          <div>
            <h3 className="text-xl font-bold flex items-center gap-2">
              <Lock className="w-6 h-6" />
              Encryption Build Status
            </h3>
            <p className="mt-2 text-blue-100">
              NIST SP 800-57 Compliant • TLS 1.3 • SHA-256 Hashing • AES-256 Encryption
            </p>
            <div className="mt-4 flex gap-4 text-sm">
              <span>✓ Certificate: 3xpres5.crt</span>
              <span>✓ VNet: mathieu_et_favvarrow</span>
              <span>✓ Public IP: titaniumite5</span>
            </div>
          </div>
          <div className="text-right">
            <div className="bg-green-500 text-white px-4 py-2 rounded-lg font-bold text-lg">
              ACTIVE
            </div>
            <p className="mt-2 text-sm text-blue-100">All systems encrypted</p>
          </div>
        </div>
      </div>
    </div>
  );
}