/**
 * Funds Transfer Payload Builder Component
 * Sigma Production Banking Platform
 * 
 * Interactive UI for building BSON-compatible funds transfer payloads
 */

import React, { useState } from 'react';
import { FundsPayloadBuilder, FundsPayload, LEDGER_EFFECTS } from '../utils/funds-payload';

export function FundsTransferBuilder() {
  const [formData, setFormData] = useState({
    txnId: '',
    origInst: 'UMB NA',
    origRtn: '101000695',
    origAcctToken: '',
    benInst: 'UMB NA',
    benRtn: '101000695',
    benAcctToken: '',
    currency: 'USD',
    amount: '',
    ledgerEffect: 'DEBIT' as const,
    source: 'SIGMA_BANKING_PLATFORM'
  });

  const [payload, setPayload] = useState<FundsPayload | null>(null);
  const [validationErrors, setValidationErrors] = useState<string[]>([]);

  const handleInputChange = (field: string, value: string) => {
    setFormData(prev => ({ ...prev, [field]: value }));
  };

  const handleBuildPayload = () => {
    try {
      // Generate transaction ID if not provided
      const txnId = formData.txnId || crypto.randomUUID();

      // Convert amount to units and nanos
      const amountDecimal = parseFloat(formData.amount);
      if (isNaN(amountDecimal) || amountDecimal <= 0) {
        setValidationErrors(['Invalid amount']);
        return;
      }

      const { units, nanos } = FundsPayloadBuilder.decimalToUnitsNanos(amountDecimal);

      // Build payload
      const builtPayload = FundsPayloadBuilder.build({
        txnId,
        origInst: formData.origInst,
        origRtn: formData.origRtn,
        origAcctToken: formData.origAcctToken,
        benInst: formData.benInst,
        benRtn: formData.benRtn,
        benAcctToken: formData.benAcctToken,
        currency: formData.currency,
        units,
        nanos,
        ledgerEffect: formData.ledgerEffect,
        source: formData.source
      });

      // Validate
      const validation = FundsPayloadBuilder.validate(builtPayload);
      if (!validation.valid) {
        setValidationErrors(validation.errors);
        return;
      }

      setPayload(builtPayload);
      setValidationErrors([]);

      // Update form with generated txnId
      if (!formData.txnId) {
        setFormData(prev => ({ ...prev, txnId }));
      }

      // Store in localStorage
      const existingPayloads = JSON.parse(localStorage.getItem('fundsPayloads') || '[]');
      existingPayloads.push(builtPayload);
      localStorage.setItem('fundsPayloads', JSON.stringify(existingPayloads));

    } catch (error) {
      setValidationErrors([`Error: ${error}`]);
    }
  };

  const handleExportBSON = () => {
    if (!payload) return;
    
    const bson = FundsPayloadBuilder.toBSON(payload);
    const blob = new Blob([bson], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `funds-transfer-${payload.txn_id}.json`;
    a.click();
    URL.revokeObjectURL(url);
  };

  const handleReset = () => {
    setFormData({
      txnId: '',
      origInst: 'UMB NA',
      origRtn: '101000695',
      origAcctToken: '',
      benInst: 'UMB NA',
      benRtn: '101000695',
      benAcctToken: '',
      currency: 'USD',
      amount: '',
      ledgerEffect: 'DEBIT',
      source: 'SIGMA_BANKING_PLATFORM'
    });
    setPayload(null);
    setValidationErrors([]);
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="border-b border-gray-200 pb-4">
        <h2 className="text-2xl font-bold text-gray-900">Funds Transfer Payload Builder</h2>
        <p className="mt-1 text-sm text-gray-600">
          Build BSON-compatible funds transfer payloads for MongoDB/DynamoDB storage
        </p>
      </div>

      {/* Form */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Left Column - Transaction Details */}
        <div className="space-y-4">
          <div className="bg-blue-50 border border-blue-200 rounded-lg p-4">
            <h3 className="text-sm font-semibold text-blue-900 mb-3">Transaction Details</h3>
            
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">
                Transaction ID
              </label>
              <input
                type="text"
                value={formData.txnId}
                onChange={(e) => handleInputChange('txnId', e.target.value)}
                placeholder="Auto-generated UUID"
                className="w-full px-3 py-2 border border-gray-300 rounded-md text-sm"
              />
              <p className="mt-1 text-xs text-gray-500">Leave blank to auto-generate</p>
            </div>

            <div className="mt-3">
              <label className="block text-sm font-medium text-gray-700 mb-1">
                Amount ({formData.currency})
              </label>
              <input
                type="number"
                step="0.01"
                value={formData.amount}
                onChange={(e) => handleInputChange('amount', e.target.value)}
                placeholder="0.00"
                className="w-full px-3 py-2 border border-gray-300 rounded-md text-sm"
              />
            </div>

            <div className="mt-3">
              <label className="block text-sm font-medium text-gray-700 mb-1">
                Currency
              </label>
              <select
                value={formData.currency}
                onChange={(e) => handleInputChange('currency', e.target.value)}
                className="w-full px-3 py-2 border border-gray-300 rounded-md text-sm"
              >
                <option value="USD">USD - US Dollar</option>
                <option value="EUR">EUR - Euro</option>
                <option value="GBP">GBP - British Pound</option>
                <option value="JPY">JPY - Japanese Yen</option>
              </select>
            </div>

            <div className="mt-3">
              <label className="block text-sm font-medium text-gray-700 mb-1">
                Ledger Effect
              </label>
              <select
                value={formData.ledgerEffect}
                onChange={(e) => handleInputChange('ledgerEffect', e.target.value)}
                className="w-full px-3 py-2 border border-gray-300 rounded-md text-sm"
              >
                <option value={LEDGER_EFFECTS.DEBIT}>DEBIT</option>
                <option value={LEDGER_EFFECTS.CREDIT}>CREDIT</option>
                <option value={LEDGER_EFFECTS.HOLD}>HOLD</option>
                <option value={LEDGER_EFFECTS.RELEASE}>RELEASE</option>
              </select>
            </div>
          </div>

          {/* Originator Account */}
          <div className="bg-green-50 border border-green-200 rounded-lg p-4">
            <h3 className="text-sm font-semibold text-green-900 mb-3">Originator Account</h3>
            
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">
                Institution
              </label>
              <input
                type="text"
                value={formData.origInst}
                onChange={(e) => handleInputChange('origInst', e.target.value)}
                className="w-full px-3 py-2 border border-gray-300 rounded-md text-sm"
              />
            </div>

            <div className="mt-3">
              <label className="block text-sm font-medium text-gray-700 mb-1">
                Routing Number
              </label>
              <input
                type="text"
                value={formData.origRtn}
                onChange={(e) => handleInputChange('origRtn', e.target.value)}
                placeholder="101000695"
                className="w-full px-3 py-2 border border-gray-300 rounded-md text-sm"
              />
            </div>

            <div className="mt-3">
              <label className="block text-sm font-medium text-gray-700 mb-1">
                Account Token
              </label>
              <input
                type="text"
                value={formData.origAcctToken}
                onChange={(e) => handleInputChange('origAcctToken', e.target.value)}
                placeholder="tok_xxxxxxxxxxxxxxxx"
                className="w-full px-3 py-2 border border-gray-300 rounded-md text-sm"
              />
            </div>
          </div>
        </div>

        {/* Right Column - Beneficiary & Metadata */}
        <div className="space-y-4">
          {/* Beneficiary Account */}
          <div className="bg-purple-50 border border-purple-200 rounded-lg p-4">
            <h3 className="text-sm font-semibold text-purple-900 mb-3">Beneficiary Account</h3>
            
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">
                Institution
              </label>
              <input
                type="text"
                value={formData.benInst}
                onChange={(e) => handleInputChange('benInst', e.target.value)}
                className="w-full px-3 py-2 border border-gray-300 rounded-md text-sm"
              />
            </div>

            <div className="mt-3">
              <label className="block text-sm font-medium text-gray-700 mb-1">
                Routing Number
              </label>
              <input
                type="text"
                value={formData.benRtn}
                onChange={(e) => handleInputChange('benRtn', e.target.value)}
                placeholder="101000695"
                className="w-full px-3 py-2 border border-gray-300 rounded-md text-sm"
              />
            </div>

            <div className="mt-3">
              <label className="block text-sm font-medium text-gray-700 mb-1">
                Account Token
              </label>
              <input
                type="text"
                value={formData.benAcctToken}
                onChange={(e) => handleInputChange('benAcctToken', e.target.value)}
                placeholder="tok_xxxxxxxxxxxxxxxx"
                className="w-full px-3 py-2 border border-gray-300 rounded-md text-sm"
              />
            </div>
          </div>

          {/* Metadata */}
          <div className="bg-gray-50 border border-gray-200 rounded-lg p-4">
            <h3 className="text-sm font-semibold text-gray-900 mb-3">Metadata</h3>
            
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">
                Source System
              </label>
              <input
                type="text"
                value={formData.source}
                onChange={(e) => handleInputChange('source', e.target.value)}
                className="w-full px-3 py-2 border border-gray-300 rounded-md text-sm"
              />
            </div>

            <div className="mt-3 text-xs text-gray-600 space-y-1">
              <p>• Hash: Auto-generated SHA-256</p>
              <p>• Signature: Auto-generated</p>
              <p>• Idempotency Key: Auto-generated</p>
              <p>• Timestamps: Auto-populated</p>
            </div>
          </div>

          {/* Actions */}
          <div className="flex gap-3">
            <button
              onClick={handleBuildPayload}
              className="flex-1 bg-blue-600 text-white px-4 py-2 rounded-md hover:bg-blue-700 transition-colors text-sm font-medium"
            >
              Build Payload
            </button>
            <button
              onClick={handleReset}
              className="px-4 py-2 border border-gray-300 rounded-md hover:bg-gray-50 transition-colors text-sm font-medium"
            >
              Reset
            </button>
          </div>
        </div>
      </div>

      {/* Validation Errors */}
      {validationErrors.length > 0 && (
        <div className="bg-red-50 border border-red-200 rounded-lg p-4">
          <h3 className="text-sm font-semibold text-red-900 mb-2">Validation Errors</h3>
          <ul className="list-disc list-inside text-sm text-red-700 space-y-1">
            {validationErrors.map((error, idx) => (
              <li key={idx}>{error}</li>
            ))}
          </ul>
        </div>
      )}

      {/* Payload Preview */}
      {payload && (
        <div className="bg-white border border-gray-200 rounded-lg p-4">
          <div className="flex items-center justify-between mb-3">
            <h3 className="text-sm font-semibold text-gray-900">BSON Payload (JSON Format)</h3>
            <button
              onClick={handleExportBSON}
              className="px-3 py-1 bg-green-600 text-white rounded text-xs font-medium hover:bg-green-700 transition-colors"
            >
              Export JSON
            </button>
          </div>
          <pre className="bg-gray-50 border border-gray-200 rounded p-3 text-xs overflow-x-auto">
            {FundsPayloadBuilder.toBSON(payload)}
          </pre>
          
          <div className="mt-4 grid grid-cols-3 gap-4 text-xs">
            <div>
              <span className="text-gray-600">Amount:</span>
              <span className="ml-2 font-mono font-semibold">
                {FundsPayloadBuilder.unitsNanosToDecimal(payload.amount.units, payload.amount.nanos).toFixed(9)} {payload.amount.currency}
              </span>
            </div>
            <div>
              <span className="text-gray-600">Hash:</span>
              <span className="ml-2 font-mono text-blue-600">
                {payload.metadata.hash.slice(0, 16)}...
              </span>
            </div>
            <div>
              <span className="text-gray-600">Signature:</span>
              <span className="ml-2 font-mono text-purple-600">
                {payload.metadata.signature.slice(0, 16)}...
              </span>
            </div>
          </div>
        </div>
      )}

      {/* Storage Info */}
      <div className="bg-amber-50 border border-amber-200 rounded-lg p-4">
        <div className="flex items-start gap-3">
          <div className="text-amber-600 mt-0.5">
            <svg className="w-5 h-5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M13 16h-1v-4h-1m1-4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />
            </svg>
          </div>
          <div className="flex-1">
            <h4 className="text-sm font-semibold text-amber-900">Backend Storage</h4>
            <p className="mt-1 text-sm text-amber-800">
              Payloads are stored in <strong>localStorage</strong> and ready for backend sync to:
            </p>
            <ul className="mt-2 text-xs text-amber-700 space-y-1">
              <li>• <strong>DynamoDB:</strong> High-speed transaction table</li>
              <li>• <strong>Aurora PostgreSQL:</strong> Relational audit trail</li>
              <li>• <strong>S3:</strong> Immutable BSON archive</li>
            </ul>
          </div>
        </div>
      </div>
    </div>
  );
}
