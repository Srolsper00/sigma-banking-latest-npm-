import { motion } from 'motion/react';
import { useState, useEffect } from 'react';
import {
  Building2,
  DollarSign,
  TrendingUp,
  TrendingDown,
  Send,
  Download,
  Shield,
  Lock,
  Activity,
  CreditCard,
  ArrowUpRight,
  ArrowDownRight,
  Zap,
  Database,
  CheckCircle,
  Clock,
  AlertTriangle,
  FileText,
  Key,
  Landmark,
  Wallet,
  RefreshCw,
  ChevronRight,
  BadgeCheck,
  ShieldCheck
} from 'lucide-react';

interface Account {
  accountId: string;
  accountName: string;
  accountType: 'checking' | 'savings' | 'credit' | 'wire';
  balance: number;
  availableBalance: number;
  fdicInsured: boolean;
  status: 'active' | 'pending' | 'frozen';
}

interface Transaction {
  id: string;
  timestamp: string;
  type: 'deposit' | 'withdrawal' | 'wire' | 'ach' | 'fee';
  amount: number;
  description: string;
  status: 'completed' | 'pending' | 'processing';
  fromAccount?: string;
  toAccount?: string;
  wireDetails?: {
    routingNumber: string;
    beneficiary: string;
    bankName: string;
  };
}

interface LineOfCredit {
  id: string;
  name: string;
  limit: number;
  utilized: number;
  available: number;
  interestRate: number;
  status: 'active' | 'inactive';
}

export function LiveBankingPlatform() {
  const [selectedTab, setSelectedTab] = useState<'overview' | 'transactions' | 'wire' | 'credit' | 'genesis' | 'compliance'>('overview');
  const [selectedAccount, setSelectedAccount] = useState<string>('main-checking');
  const [isProcessing, setIsProcessing] = useState(false);
  const [transactionAmount, setTransactionAmount] = useState('');
  const [transactionType, setTransactionType] = useState<'deposit' | 'withdrawal' | 'wire'>('deposit');

  // AWS RDS Connection Status
  const [dbStatus, setDbStatus] = useState({
    connected: true,
    host: 'toxcrv2x-sigma-banking-platform.cluster-cx4sug4c2fa2.us-west-2.rds.amazonaws.com',
    region: 'us-west-2',
    accountId: '869576899375',
    lastSync: new Date().toISOString()
  });

  // Accounts with FDIC Insurance
  const [accounts, setAccounts] = useState<Account[]>([
    {
      accountId: 'main-checking',
      accountName: 'UMB NA Main Checking',
      accountType: 'checking',
      balance: 5847293.45,
      availableBalance: 5847293.45,
      fdicInsured: true,
      status: 'active'
    },
    {
      accountId: 'reserve-savings',
      accountName: 'UMB NA Reserve Savings',
      accountType: 'savings',
      balance: 2500000.00,
      availableBalance: 2500000.00,
      fdicInsured: true,
      status: 'active'
    },
    {
      accountId: 'wire-account',
      accountName: 'Wire Transfer Account',
      accountType: 'wire',
      balance: 1250000.00,
      availableBalance: 1250000.00,
      fdicInsured: true,
      status: 'active'
    }
  ]);

  // Lines of Credit
  const [linesOfCredit, setLinesOfCredit] = useState<LineOfCredit[]>([
    {
      id: 'loc-001',
      name: 'Operating Line of Credit',
      limit: 5000000.00,
      utilized: 1200000.00,
      available: 3800000.00,
      interestRate: 5.25,
      status: 'active'
    },
    {
      id: 'loc-002',
      name: 'Equipment Financing Line',
      limit: 2000000.00,
      utilized: 450000.00,
      available: 1550000.00,
      interestRate: 4.75,
      status: 'active'
    }
  ]);

  // Recent Transactions
  const [transactions, setTransactions] = useState<Transaction[]>([
    {
      id: 'TXN-20260324-001',
      timestamp: new Date().toISOString(),
      type: 'deposit',
      amount: 125000.00,
      description: 'Wire Transfer - Client Payment',
      status: 'completed',
      toAccount: 'main-checking'
    },
    {
      id: 'TXN-20260324-002',
      timestamp: new Date(Date.now() - 3600000).toISOString(),
      type: 'wire',
      amount: 50000.00,
      description: 'Wire Transfer - Vendor Payment',
      status: 'completed',
      fromAccount: 'wire-account',
      wireDetails: {
        routingNumber: '101000187',
        beneficiary: 'Acme Corp',
        bankName: 'UMB Bank NA'
      }
    },
    {
      id: 'TXN-20260324-003',
      timestamp: new Date(Date.now() - 7200000).toISOString(),
      type: 'withdrawal',
      amount: 25000.00,
      description: 'ACH Transfer - Payroll Processing',
      status: 'completed',
      fromAccount: 'main-checking'
    },
    {
      id: 'TXN-20260324-004',
      timestamp: new Date(Date.now() - 10800000).toISOString(),
      type: 'deposit',
      amount: 75000.00,
      description: 'ACH Deposit - Revenue Collection',
      status: 'processing',
      toAccount: 'main-checking'
    }
  ]);

  // FDIC Insurance Cushion
  const fdicInsuranceLimit = 250000;
  const totalInsuredBalance = accounts.reduce((sum, acc) => acc.fdicInsured ? sum + acc.balance : sum, 0);
  const insuranceCushion = 2500000; // $2.5M cushion

  // Total Available Credit
  const totalCreditLimit = linesOfCredit.reduce((sum, loc) => sum + loc.limit, 0);
  const totalCreditUtilized = linesOfCredit.reduce((sum, loc) => sum + loc.utilized, 0);
  const totalCreditAvailable = totalCreditLimit - totalCreditUtilized;

  // Calculate total balance
  const totalBalance = accounts.reduce((sum, acc) => sum + acc.balance, 0);

  // Process Transaction
  const processTransaction = () => {
    if (!transactionAmount || parseFloat(transactionAmount) <= 0) return;

    setIsProcessing(true);
    const amount = parseFloat(transactionAmount);

    setTimeout(() => {
      const newTransaction: Transaction = {
        id: `TXN-${Date.now()}`,
        timestamp: new Date().toISOString(),
        type: transactionType,
        amount,
        description: `${transactionType.charAt(0).toUpperCase() + transactionType.slice(1)} via Live Platform`,
        status: 'processing',
        fromAccount: transactionType === 'withdrawal' || transactionType === 'wire' ? selectedAccount : undefined,
        toAccount: transactionType === 'deposit' ? selectedAccount : undefined
      };

      setTransactions(prev => [newTransaction, ...prev]);

      // Update account balance
      setAccounts(prev => prev.map(acc => {
        if (acc.accountId === selectedAccount) {
          const balanceChange = transactionType === 'deposit' ? amount : -amount;
          return {
            ...acc,
            balance: acc.balance + balanceChange,
            availableBalance: acc.availableBalance + balanceChange
          };
        }
        return acc;
      }));

      setTimeout(() => {
        setTransactions(prev => prev.map(txn => 
          txn.id === newTransaction.id ? { ...txn, status: 'completed' as const } : txn
        ));
      }, 2000);

      setIsProcessing(false);
      setTransactionAmount('');
    }, 1500);
  };

  // Simulate real-time updates
  useEffect(() => {
    const interval = setInterval(() => {
      setDbStatus(prev => ({ ...prev, lastSync: new Date().toISOString() }));
    }, 5000);

    return () => clearInterval(interval);
  }, []);

  const selectedAccountData = accounts.find(acc => acc.accountId === selectedAccount);

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.6 }}
      className="bg-white rounded-xl shadow-lg border border-slate-200 overflow-hidden"
    >
      {/* Header */}
      <div className="bg-gradient-to-r from-blue-900 via-indigo-900 to-blue-900 p-6">
        <div className="flex items-center justify-between mb-4">
          <div className="flex items-center gap-3">
            <div className="p-2 bg-white/10 rounded-lg">
              <Landmark className="w-6 h-6 text-white" />
            </div>
            <div>
              <h2 className="text-white text-xl">Live Real-Time Banking Platform</h2>
              <p className="text-slate-300 text-sm">UMB NA • FDIC Insured • Genesis Suite Integrated • HID Compliant</p>
            </div>
          </div>
          <div className="flex items-center gap-2 bg-green-500/20 px-3 py-1 rounded-full">
            <div className="w-2 h-2 bg-green-400 rounded-full animate-pulse" />
            <span className="text-green-300 text-xs font-medium">LIVE</span>
          </div>
        </div>

        {/* Account Overview Cards */}
        <div className="grid grid-cols-4 gap-4">
          <div className="bg-white/10 rounded-lg p-3 backdrop-blur-sm">
            <div className="flex items-center gap-2 mb-1">
              <Wallet className="w-4 h-4 text-blue-200" />
              <div className="text-blue-200 text-xs">Total Balance</div>
            </div>
            <div className="text-white text-2xl font-bold">${totalBalance.toLocaleString('en-US', { minimumFractionDigits: 2 })}</div>
            <div className="text-blue-200 text-xs">FDIC Insured</div>
          </div>

          <div className="bg-white/10 rounded-lg p-3 backdrop-blur-sm">
            <div className="flex items-center gap-2 mb-1">
              <Shield className="w-4 h-4 text-emerald-200" />
              <div className="text-emerald-200 text-xs">Insurance Cushion</div>
            </div>
            <div className="text-white text-2xl font-bold">${insuranceCushion.toLocaleString('en-US')}</div>
            <div className="text-emerald-200 text-xs">$2.5M Reserve</div>
          </div>

          <div className="bg-white/10 rounded-lg p-3 backdrop-blur-sm">
            <div className="flex items-center gap-2 mb-1">
              <CreditCard className="w-4 h-4 text-purple-200" />
              <div className="text-purple-200 text-xs">Available Credit</div>
            </div>
            <div className="text-white text-2xl font-bold">${totalCreditAvailable.toLocaleString('en-US')}</div>
            <div className="text-purple-200 text-xs">Lines of Credit</div>
          </div>

          <div className="bg-white/10 rounded-lg p-3 backdrop-blur-sm">
            <div className="flex items-center gap-2 mb-1">
              <Database className="w-4 h-4 text-amber-200" />
              <div className="text-amber-200 text-xs">AWS RDS</div>
            </div>
            <div className="text-white font-bold flex items-center gap-1">
              <CheckCircle className="w-4 h-4 text-green-400" />
              Connected
            </div>
            <div className="text-amber-200 text-xs">us-west-2</div>
          </div>
        </div>
      </div>

      {/* Navigation Tabs */}
      <div className="border-b border-slate-200 bg-slate-50">
        <div className="flex">
          {[
            { id: 'overview', label: 'Overview', icon: Activity },
            { id: 'transactions', label: 'Transactions', icon: FileText },
            { id: 'wire', label: 'Wire Transfer', icon: Send },
            { id: 'credit', label: 'Lines of Credit', icon: CreditCard },
            { id: 'genesis', label: 'Genesis Suite', icon: Zap },
            { id: 'compliance', label: 'HID Compliance', icon: ShieldCheck }
          ].map(tab => {
            const Icon = tab.icon;
            return (
              <button
                key={tab.id}
                onClick={() => setSelectedTab(tab.id as any)}
                className={`
                  flex items-center gap-2 px-6 py-3 font-medium text-sm transition-colors
                  ${selectedTab === tab.id 
                    ? 'text-blue-700 border-b-2 border-blue-600 bg-white' 
                    : 'text-slate-600 hover:text-slate-900 hover:bg-slate-100'
                  }
                `}
              >
                <Icon className="w-4 h-4" />
                {tab.label}
              </button>
            );
          })}
        </div>
      </div>

      {/* Content */}
      <div className="p-6">
        {/* Tab 1: Overview */}
        {selectedTab === 'overview' && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ duration: 0.3 }}
          >
            <div className="mb-6">
              <h3 className="text-slate-900 font-bold text-lg mb-2">💼 Banking Overview</h3>
              <p className="text-slate-600 text-sm">Real-time account balances, FDIC insurance, and credit facilities</p>
            </div>

            {/* Accounts Grid */}
            <div className="grid grid-cols-3 gap-4 mb-6">
              {accounts.map(account => (
                <motion.div
                  key={account.accountId}
                  whileHover={{ scale: 1.02 }}
                  className={`
                    border-2 rounded-lg p-5 cursor-pointer transition-all
                    ${selectedAccount === account.accountId 
                      ? 'border-blue-500 bg-blue-50' 
                      : 'border-slate-200 bg-white hover:border-slate-300'
                    }
                  `}
                  onClick={() => setSelectedAccount(account.accountId)}
                >
                  <div className="flex items-center justify-between mb-3">
                    <div className={`
                      px-2 py-1 rounded text-xs font-bold
                      ${account.status === 'active' ? 'bg-green-100 text-green-700' : 'bg-slate-100 text-slate-600'}
                    `}>
                      {account.status.toUpperCase()}
                    </div>
                    {account.fdicInsured && (
                      <div className="flex items-center gap-1 text-emerald-600">
                        <Shield className="w-4 h-4" />
                        <span className="text-xs font-medium">FDIC</span>
                      </div>
                    )}
                  </div>
                  
                  <div className="text-slate-900 font-bold mb-1">{account.accountName}</div>
                  <div className="text-slate-500 text-xs mb-3 uppercase">{account.accountType}</div>
                  
                  <div className="text-slate-900 text-2xl font-bold mb-1">
                    ${account.balance.toLocaleString('en-US', { minimumFractionDigits: 2 })}
                  </div>
                  <div className="text-slate-500 text-xs">
                    Available: ${account.availableBalance.toLocaleString('en-US', { minimumFractionDigits: 2 })}
                  </div>
                </motion.div>
              ))}
            </div>

            {/* Quick Transaction Panel */}
            <div className="bg-gradient-to-r from-blue-50 to-indigo-50 border-2 border-blue-200 rounded-lg p-6 mb-6">
              <h4 className="text-slate-900 font-bold mb-4 flex items-center gap-2">
                <Zap className="w-5 h-5 text-blue-600" />
                Quick Transaction
              </h4>
              
              <div className="grid grid-cols-4 gap-4">
                <div>
                  <label className="text-slate-700 text-sm font-medium mb-2 block">Account</label>
                  <select 
                    value={selectedAccount}
                    onChange={(e) => setSelectedAccount(e.target.value)}
                    className="w-full border border-slate-300 rounded-lg px-3 py-2 text-sm"
                  >
                    {accounts.map(acc => (
                      <option key={acc.accountId} value={acc.accountId}>{acc.accountName}</option>
                    ))}
                  </select>
                </div>

                <div>
                  <label className="text-slate-700 text-sm font-medium mb-2 block">Type</label>
                  <select 
                    value={transactionType}
                    onChange={(e) => setTransactionType(e.target.value as any)}
                    className="w-full border border-slate-300 rounded-lg px-3 py-2 text-sm"
                  >
                    <option value="deposit">Deposit</option>
                    <option value="withdrawal">Withdrawal</option>
                    <option value="wire">Wire Transfer</option>
                  </select>
                </div>

                <div>
                  <label className="text-slate-700 text-sm font-medium mb-2 block">Amount</label>
                  <input
                    type="number"
                    value={transactionAmount}
                    onChange={(e) => setTransactionAmount(e.target.value)}
                    placeholder="0.00"
                    className="w-full border border-slate-300 rounded-lg px-3 py-2 text-sm"
                  />
                </div>

                <div className="flex items-end">
                  <motion.button
                    whileHover={{ scale: 1.05 }}
                    whileTap={{ scale: 0.95 }}
                    onClick={processTransaction}
                    disabled={isProcessing}
                    className="w-full bg-blue-600 text-white px-4 py-2 rounded-lg font-medium flex items-center justify-center gap-2 disabled:opacity-50"
                  >
                    {isProcessing ? (
                      <>
                        <RefreshCw className="w-4 h-4 animate-spin" />
                        Processing...
                      </>
                    ) : (
                      <>
                        <Send className="w-4 h-4" />
                        Process
                      </>
                    )}
                  </motion.button>
                </div>
              </div>
            </div>

            {/* FDIC Insurance Info */}
            <div className="bg-emerald-50 border-2 border-emerald-300 rounded-lg p-5">
              <div className="flex items-start gap-3">
                <Shield className="w-6 h-6 text-emerald-600 mt-0.5" />
                <div className="flex-1">
                  <div className="text-emerald-900 font-bold mb-2">FDIC Insurance Coverage</div>
                  <div className="grid grid-cols-3 gap-4">
                    <div>
                      <div className="text-emerald-700 text-xs mb-1">Total Insured Balance</div>
                      <div className="text-emerald-900 font-bold text-lg">
                        ${totalInsuredBalance.toLocaleString('en-US', { minimumFractionDigits: 2 })}
                      </div>
                    </div>
                    <div>
                      <div className="text-emerald-700 text-xs mb-1">Insurance Cushion</div>
                      <div className="text-emerald-900 font-bold text-lg">
                        ${insuranceCushion.toLocaleString('en-US')}
                      </div>
                    </div>
                    <div>
                      <div className="text-emerald-700 text-xs mb-1">Coverage Status</div>
                      <div className="flex items-center gap-2">
                        <CheckCircle className="w-5 h-5 text-emerald-600" />
                        <span className="text-emerald-900 font-bold">Fully Protected</span>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </motion.div>
        )}

        {/* Tab 2: Transactions */}
        {selectedTab === 'transactions' && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ duration: 0.3 }}
          >
            <div className="mb-6">
              <h3 className="text-slate-900 font-bold text-lg mb-2">📊 Transaction History</h3>
              <p className="text-slate-600 text-sm">Real-time transaction processing and history</p>
            </div>

            <div className="space-y-3">
              {transactions.map((txn, index) => (
                <motion.div
                  key={txn.id}
                  initial={{ opacity: 0, x: -20 }}
                  animate={{ opacity: 1, x: 0 }}
                  transition={{ delay: index * 0.05 }}
                  className={`
                    border-2 rounded-lg p-4
                    ${txn.status === 'completed' ? 'bg-green-50 border-green-300' : ''}
                    ${txn.status === 'processing' ? 'bg-amber-50 border-amber-300' : ''}
                    ${txn.status === 'pending' ? 'bg-blue-50 border-blue-300' : ''}
                  `}
                >
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-4">
                      <div className={`
                        p-3 rounded-lg
                        ${txn.type === 'deposit' ? 'bg-green-100' : ''}
                        ${txn.type === 'withdrawal' ? 'bg-red-100' : ''}
                        ${txn.type === 'wire' ? 'bg-purple-100' : ''}
                        ${txn.type === 'ach' ? 'bg-blue-100' : ''}
                      `}>
                        {txn.type === 'deposit' && <ArrowDownRight className="w-6 h-6 text-green-600" />}
                        {txn.type === 'withdrawal' && <ArrowUpRight className="w-6 h-6 text-red-600" />}
                        {txn.type === 'wire' && <Send className="w-6 h-6 text-purple-600" />}
                        {txn.type === 'ach' && <RefreshCw className="w-6 h-6 text-blue-600" />}
                      </div>

                      <div>
                        <div className="text-slate-900 font-bold">{txn.description}</div>
                        <div className="text-slate-600 text-sm">
                          {new Date(txn.timestamp).toLocaleString()} • {txn.id}
                        </div>
                        {txn.wireDetails && (
                          <div className="text-slate-500 text-xs mt-1">
                            {txn.wireDetails.beneficiary} • {txn.wireDetails.bankName} • Routing: {txn.wireDetails.routingNumber}
                          </div>
                        )}
                      </div>
                    </div>

                    <div className="text-right">
                      <div className={`
                        text-2xl font-bold
                        ${txn.type === 'deposit' ? 'text-green-600' : 'text-red-600'}
                      `}>
                        {txn.type === 'deposit' ? '+' : '-'}${txn.amount.toLocaleString('en-US', { minimumFractionDigits: 2 })}
                      </div>
                      <div className={`
                        text-xs font-medium px-2 py-1 rounded mt-1 inline-block
                        ${txn.status === 'completed' ? 'bg-green-200 text-green-800' : ''}
                        ${txn.status === 'processing' ? 'bg-amber-200 text-amber-800' : ''}
                        ${txn.status === 'pending' ? 'bg-blue-200 text-blue-800' : ''}
                      `}>
                        {txn.status.toUpperCase()}
                      </div>
                    </div>
                  </div>
                </motion.div>
              ))}
            </div>
          </motion.div>
        )}

        {/* Tab 3: Wire Transfer */}
        {selectedTab === 'wire' && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ duration: 0.3 }}
          >
            <div className="mb-6">
              <h3 className="text-slate-900 font-bold text-lg mb-2">💸 Wire Transfer Center</h3>
              <p className="text-slate-600 text-sm">Domestic and international wire transfers via UMB NA</p>
            </div>

            <div className="bg-white border-2 border-slate-200 rounded-lg p-6">
              <div className="grid grid-cols-2 gap-6">
                <div>
                  <label className="text-slate-700 font-medium mb-2 block">From Account</label>
                  <select className="w-full border border-slate-300 rounded-lg px-4 py-3">
                    {accounts.map(acc => (
                      <option key={acc.accountId} value={acc.accountId}>
                        {acc.accountName} - ${acc.balance.toLocaleString()}
                      </option>
                    ))}
                  </select>
                </div>

                <div>
                  <label className="text-slate-700 font-medium mb-2 block">Wire Amount</label>
                  <input
                    type="number"
                    placeholder="0.00"
                    className="w-full border border-slate-300 rounded-lg px-4 py-3"
                  />
                </div>

                <div>
                  <label className="text-slate-700 font-medium mb-2 block">Beneficiary Name</label>
                  <input
                    type="text"
                    placeholder="Recipient name"
                    className="w-full border border-slate-300 rounded-lg px-4 py-3"
                  />
                </div>

                <div>
                  <label className="text-slate-700 font-medium mb-2 block">Beneficiary Bank</label>
                  <input
                    type="text"
                    placeholder="Bank name"
                    className="w-full border border-slate-300 rounded-lg px-4 py-3"
                  />
                </div>

                <div>
                  <label className="text-slate-700 font-medium mb-2 block">Routing Number (ABA)</label>
                  <input
                    type="text"
                    placeholder="000000000"
                    maxLength={9}
                    className="w-full border border-slate-300 rounded-lg px-4 py-3"
                  />
                </div>

                <div>
                  <label className="text-slate-700 font-medium mb-2 block">Account Number</label>
                  <input
                    type="text"
                    placeholder="Account number"
                    className="w-full border border-slate-300 rounded-lg px-4 py-3"
                  />
                </div>

                <div className="col-span-2">
                  <label className="text-slate-700 font-medium mb-2 block">Wire Purpose / Reference</label>
                  <textarea
                    placeholder="Purpose of wire transfer"
                    rows={3}
                    className="w-full border border-slate-300 rounded-lg px-4 py-3"
                  />
                </div>
              </div>

              <div className="mt-6 flex gap-3">
                <motion.button
                  whileHover={{ scale: 1.02 }}
                  whileTap={{ scale: 0.98 }}
                  className="flex-1 bg-purple-600 text-white px-6 py-3 rounded-lg font-bold flex items-center justify-center gap-2"
                >
                  <Send className="w-5 h-5" />
                  Initiate Wire Transfer
                </motion.button>
                <button className="bg-slate-200 text-slate-700 px-6 py-3 rounded-lg font-medium">
                  Save as Template
                </button>
              </div>

              <div className="mt-4 bg-amber-50 border border-amber-300 rounded-lg p-4">
                <div className="flex items-start gap-3">
                  <AlertTriangle className="w-5 h-5 text-amber-600 mt-0.5" />
                  <div className="text-amber-900 text-sm">
                    <div className="font-bold mb-1">Wire Transfer Notice</div>
                    <div>Wire transfers are typically irreversible. Please verify all details before submitting. Same-day wires must be initiated before 3:00 PM CT.</div>
                  </div>
                </div>
              </div>
            </div>
          </motion.div>
        )}

        {/* Tab 4: Lines of Credit */}
        {selectedTab === 'credit' && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ duration: 0.3 }}
          >
            <div className="mb-6">
              <h3 className="text-slate-900 font-bold text-lg mb-2">💳 Lines of Credit</h3>
              <p className="text-slate-600 text-sm">Banking credit facilities and utilization</p>
            </div>

            {/* Credit Summary */}
            <div className="grid grid-cols-3 gap-4 mb-6">
              <div className="bg-blue-50 border-2 border-blue-300 rounded-lg p-4">
                <div className="text-blue-700 text-sm mb-1">Total Credit Limit</div>
                <div className="text-blue-900 text-2xl font-bold">
                  ${totalCreditLimit.toLocaleString('en-US', { minimumFractionDigits: 2 })}
                </div>
              </div>
              <div className="bg-red-50 border-2 border-red-300 rounded-lg p-4">
                <div className="text-red-700 text-sm mb-1">Total Utilized</div>
                <div className="text-red-900 text-2xl font-bold">
                  ${totalCreditUtilized.toLocaleString('en-US', { minimumFractionDigits: 2 })}
                </div>
              </div>
              <div className="bg-emerald-50 border-2 border-emerald-300 rounded-lg p-4">
                <div className="text-emerald-700 text-sm mb-1">Available Credit</div>
                <div className="text-emerald-900 text-2xl font-bold">
                  ${totalCreditAvailable.toLocaleString('en-US', { minimumFractionDigits: 2 })}
                </div>
              </div>
            </div>

            {/* Individual Lines of Credit */}
            <div className="space-y-4">
              {linesOfCredit.map(loc => {
                const utilizationPercent = (loc.utilized / loc.limit) * 100;
                return (
                  <div key={loc.id} className="bg-white border-2 border-slate-200 rounded-lg p-5">
                    <div className="flex items-center justify-between mb-4">
                      <div>
                        <div className="text-slate-900 font-bold text-lg">{loc.name}</div>
                        <div className="text-slate-600 text-sm">ID: {loc.id} • Rate: {loc.interestRate}% APR</div>
                      </div>
                      <div className={`
                        px-3 py-1 rounded-full text-xs font-bold
                        ${loc.status === 'active' ? 'bg-green-100 text-green-700' : 'bg-slate-100 text-slate-600'}
                      `}>
                        {loc.status.toUpperCase()}
                      </div>
                    </div>

                    <div className="grid grid-cols-4 gap-4 mb-4">
                      <div>
                        <div className="text-slate-600 text-xs mb-1">Credit Limit</div>
                        <div className="text-slate-900 font-bold">${loc.limit.toLocaleString()}</div>
                      </div>
                      <div>
                        <div className="text-slate-600 text-xs mb-1">Utilized</div>
                        <div className="text-red-600 font-bold">${loc.utilized.toLocaleString()}</div>
                      </div>
                      <div>
                        <div className="text-slate-600 text-xs mb-1">Available</div>
                        <div className="text-emerald-600 font-bold">${loc.available.toLocaleString()}</div>
                      </div>
                      <div>
                        <div className="text-slate-600 text-xs mb-1">Utilization</div>
                        <div className="text-slate-900 font-bold">{utilizationPercent.toFixed(1)}%</div>
                      </div>
                    </div>

                    {/* Utilization Bar */}
                    <div className="w-full bg-slate-200 rounded-full h-3 overflow-hidden">
                      <div 
                        className={`h-full transition-all ${
                          utilizationPercent < 50 ? 'bg-green-500' : 
                          utilizationPercent < 75 ? 'bg-amber-500' : 'bg-red-500'
                        }`}
                        style={{ width: `${utilizationPercent}%` }}
                      />
                    </div>
                  </div>
                );
              })}
            </div>
          </motion.div>
        )}

        {/* Tab 5: Genesis Suite */}
        {selectedTab === 'genesis' && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ duration: 0.3 }}
          >
            <div className="mb-6">
              <h3 className="text-slate-900 font-bold text-lg mb-2">⚡ Genesis Suite Integration</h3>
              <p className="text-slate-600 text-sm">Crypto asset integration and Genesis Pool interface</p>
            </div>

            <div className="bg-gradient-to-r from-purple-900 via-indigo-900 to-purple-900 rounded-lg p-6 text-white mb-6">
              <div className="flex items-center gap-3 mb-4">
                <Zap className="w-8 h-8" />
                <div>
                  <div className="text-2xl font-bold">Genesis Pool Interface</div>
                  <div className="text-purple-200 text-sm">Crypto asset management and integration layer</div>
                </div>
              </div>

              <div className="grid grid-cols-4 gap-4">
                <div className="bg-white/10 rounded-lg p-3 backdrop-blur-sm">
                  <div className="text-purple-200 text-xs mb-1">ETH Balance</div>
                  <div className="text-white font-bold">125.5 ETH</div>
                  <div className="text-purple-300 text-xs">~$425,000</div>
                </div>
                <div className="bg-white/10 rounded-lg p-3 backdrop-blur-sm">
                  <div className="text-purple-200 text-xs mb-1">WBTC Balance</div>
                  <div className="text-white font-bold">8.25 WBTC</div>
                  <div className="text-purple-300 text-xs">~$580,000</div>
                </div>
                <div className="bg-white/10 rounded-lg p-3 backdrop-blur-sm">
                  <div className="text-purple-200 text-xs mb-1">BTC Balance</div>
                  <div className="text-white font-bold">12.5 BTC</div>
                  <div className="text-purple-300 text-xs">~$875,000</div>
                </div>
                <div className="bg-white/10 rounded-lg p-3 backdrop-blur-sm">
                  <div className="text-purple-200 text-xs mb-1">USDC Balance</div>
                  <div className="text-white font-bold">2.5M USDC</div>
                  <div className="text-purple-300 text-xs">~$2,500,000</div>
                </div>
              </div>
            </div>

            <div className="grid grid-cols-2 gap-4">
              <div className="bg-white border-2 border-slate-200 rounded-lg p-5">
                <div className="text-slate-900 font-bold mb-3 flex items-center gap-2">
                  <Activity className="w-5 h-5 text-blue-600" />
                  Genesis Pool Status
                </div>
                <div className="space-y-2 text-sm">
                  <div className="flex justify-between">
                    <span className="text-slate-600">Pool Status:</span>
                    <span className="text-green-600 font-bold">ACTIVE</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-slate-600">Total Value Locked:</span>
                    <span className="text-slate-900 font-bold">$4.38M</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-slate-600">Last Sync:</span>
                    <span className="text-slate-900 font-mono text-xs">{new Date().toLocaleTimeString()}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-slate-600">Smart Contract:</span>
                    <span className="text-slate-900 font-mono text-xs">0x7a...4f2d</span>
                  </div>
                </div>
              </div>

              <div className="bg-white border-2 border-slate-200 rounded-lg p-5">
                <div className="text-slate-900 font-bold mb-3 flex items-center gap-2">
                  <Lock className="w-5 h-5 text-purple-600" />
                  Security & Custody
                </div>
                <div className="space-y-2 text-sm">
                  <div className="flex justify-between">
                    <span className="text-slate-600">Custody Provider:</span>
                    <span className="text-slate-900 font-bold">Genesis</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-slate-600">Cold Storage:</span>
                    <span className="text-green-600 font-bold">95%</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-slate-600">Insurance Coverage:</span>
                    <span className="text-slate-900 font-bold">$10M</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-slate-600">Multi-sig Required:</span>
                    <span className="text-blue-600 font-bold">3 of 5</span>
                  </div>
                </div>
              </div>
            </div>
          </motion.div>
        )}

        {/* Tab 6: HID Compliance */}
        {selectedTab === 'compliance' && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ duration: 0.3 }}
          >
            <div className="mb-6">
              <h3 className="text-slate-900 font-bold text-lg mb-2">🔒 HID Compliance & Security</h3>
              <p className="text-slate-600 text-sm">Hardware identity, certificates, and security infrastructure</p>
            </div>

            {/* AWS Infrastructure */}
            <div className="bg-slate-900 text-white rounded-lg p-6 mb-6">
              <div className="flex items-center gap-3 mb-4">
                <Database className="w-8 h-8 text-blue-400" />
                <div>
                  <div className="text-2xl font-bold">AWS RDS Infrastructure</div>
                  <div className="text-slate-400 text-sm">Secure PostgreSQL cluster with SSL/TLS</div>
                </div>
              </div>

              <div className="grid grid-cols-2 gap-6">
                <div className="space-y-3">
                  <div className="bg-slate-800 rounded p-3">
                    <div className="text-slate-400 text-xs mb-1">AWS Account ID</div>
                    <div className="text-white font-mono text-sm">869576899375</div>
                  </div>
                  <div className="bg-slate-800 rounded p-3">
                    <div className="text-slate-400 text-xs mb-1">Region</div>
                    <div className="text-white font-mono text-sm">us-west-2</div>
                  </div>
                  <div className="bg-slate-800 rounded p-3">
                    <div className="text-slate-400 text-xs mb-1">Database Host</div>
                    <div className="text-white font-mono text-xs">toxcrv2x-sigma-banking-platform.cluster-cx4sug4c2fa2.us-west-2.rds.amazonaws.com</div>
                  </div>
                </div>

                <div className="space-y-3">
                  <div className="bg-slate-800 rounded p-3">
                    <div className="text-slate-400 text-xs mb-1">Resource ARN</div>
                    <div className="text-white font-mono text-xs">arn:aws:rds:us-west-2:869576899375:cluster:toxcrv2x-sigma-banking-platform</div>
                  </div>
                  <div className="bg-slate-800 rounded p-3">
                    <div className="text-slate-400 text-xs mb-1">IAM Role ARN</div>
                    <div className="text-white font-mono text-xs">arn:aws:iam::869576899375:role/Vercel/access-TOXCRV2X-Sigma-Banking-Platform</div>
                  </div>
                  <div className="bg-slate-800 rounded p-3">
                    <div className="text-slate-400 text-xs mb-1">SSL Mode</div>
                    <div className="text-emerald-400 font-bold flex items-center gap-2">
                      <Lock className="w-4 h-4" />
                      REQUIRE
                    </div>
                  </div>
                </div>
              </div>
            </div>

            {/* Security Certificates */}
            <div className="grid grid-cols-2 gap-4 mb-6">
              <div className="bg-white border-2 border-emerald-300 rounded-lg p-5">
                <div className="flex items-center gap-3 mb-4">
                  <BadgeCheck className="w-6 h-6 text-emerald-600" />
                  <div className="text-slate-900 font-bold">HID Compliance Status</div>
                </div>
                <div className="space-y-2 text-sm">
                  <div className="flex items-center justify-between">
                    <span className="text-slate-600">Hardware Identity:</span>
                    <span className="text-green-600 font-bold flex items-center gap-1">
                      <CheckCircle className="w-4 h-4" />
                      Verified
                    </span>
                  </div>
                  <div className="flex items-center justify-between">
                    <span className="text-slate-600">Device Attestation:</span>
                    <span className="text-green-600 font-bold flex items-center gap-1">
                      <CheckCircle className="w-4 h-4" />
                      Active
                    </span>
                  </div>
                  <div className="flex items-center justify-between">
                    <span className="text-slate-600">Certificate Status:</span>
                    <span className="text-green-600 font-bold flex items-center gap-1">
                      <CheckCircle className="w-4 h-4" />
                      Valid
                    </span>
                  </div>
                  <div className="flex items-center justify-between">
                    <span className="text-slate-600">Last Rotation:</span>
                    <span className="text-slate-900 font-medium">24 hours ago</span>
                  </div>
                </div>
              </div>

              <div className="bg-white border-2 border-blue-300 rounded-lg p-5">
                <div className="flex items-center gap-3 mb-4">
                  <Key className="w-6 h-6 text-blue-600" />
                  <div className="text-slate-900 font-bold">Encryption & Keys</div>
                </div>
                <div className="space-y-2 text-sm">
                  <div className="flex items-center justify-between">
                    <span className="text-slate-600">TLS Version:</span>
                    <span className="text-slate-900 font-bold">1.3</span>
                  </div>
                  <div className="flex items-center justify-between">
                    <span className="text-slate-600">Cipher Suite:</span>
                    <span className="text-slate-900 font-mono text-xs">AES-256-GCM</span>
                  </div>
                  <div className="flex items-center justify-between">
                    <span className="text-slate-600">Key Length:</span>
                    <span className="text-slate-900 font-bold">256-bit</span>
                  </div>
                  <div className="flex items-center justify-between">
                    <span className="text-slate-600">FIPS 140-2:</span>
                    <span className="text-green-600 font-bold flex items-center gap-1">
                      <CheckCircle className="w-4 h-4" />
                      Compliant
                    </span>
                  </div>
                </div>
              </div>
            </div>

            {/* Connection Status */}
            <div className="bg-green-50 border-2 border-green-300 rounded-lg p-5">
              <div className="flex items-start gap-3">
                <CheckCircle className="w-6 h-6 text-green-600 mt-0.5" />
                <div className="flex-1">
                  <div className="text-green-900 font-bold mb-2">Database Connection Status</div>
                  <div className="grid grid-cols-4 gap-4 text-sm">
                    <div>
                      <div className="text-green-700 mb-1">Connection State</div>
                      <div className="text-green-900 font-bold">CONNECTED</div>
                    </div>
                    <div>
                      <div className="text-green-700 mb-1">Last Sync</div>
                      <div className="text-green-900 font-mono text-xs">{new Date(dbStatus.lastSync).toLocaleTimeString()}</div>
                    </div>
                    <div>
                      <div className="text-green-700 mb-1">Latency</div>
                      <div className="text-green-900 font-bold">12ms</div>
                    </div>
                    <div>
                      <div className="text-green-700 mb-1">Uptime</div>
                      <div className="text-green-900 font-bold">99.99%</div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </motion.div>
        )}
      </div>
    </motion.div>
  );
}
