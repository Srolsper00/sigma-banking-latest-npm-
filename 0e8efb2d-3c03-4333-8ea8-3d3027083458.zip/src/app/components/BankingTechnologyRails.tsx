import { useState } from 'react';
import { motion } from 'motion/react';
import { 
  Building2,
  ArrowRightLeft,
  Shield,
  Lock,
  Key,
  Database,
  Zap,
  GitBranch,
  Eye,
  CheckCircle,
  AlertTriangle,
  Code,
  Download,
  Copy,
  Terminal,
  Activity,
  Layers,
  Network,
  Search,
  Users,
  FileText,
  Server,
  Cloud
} from 'lucide-react';
import { toast } from 'sonner@2.0.3';

interface TokenizedWithdrawal {
  withdrawal_root_token: string;
  operation: string;
  routing_hint: string;
  account_hint: string;
  ts: string;
}

interface DetectionControl {
  id: string;
  category: string;
  description: string;
  frameworks: string[];
}

export function BankingTechnologyRails() {
  const [activeTab, setActiveTab] = useState<'infrastructure' | 'rails'>('infrastructure');
  const [selectedLanguage, setSelectedLanguage] = useState<'node' | 'java'>('node');
  const [showWorkflow, setShowWorkflow] = useState(false);

  // Tokenized withdrawal example
  const tokenizedWithdrawal: TokenizedWithdrawal = {
    withdrawal_root_token: 'aaf97b1e6c0df4d4f6c41ce00a3f4734d4dcbbd2fdd19b50b1fc6dd84cc927f1',
    operation: 'DDA_CORE_POOL_EXTRACTION',
    routing_hint: '0311****',
    account_hint: '****9925',
    ts: new Date().toISOString()
  };

  const detectionControls: DetectionControl[] = [
    {
      id: 'DE.CM-6',
      category: 'External Service Provider Monitoring',
      description: 'External service provider activity is monitored to detect potential cybersecurity events',
      frameworks: [
        'COBIT 5 APO07.06, APO10.05',
        'ISO/IEC 27001:2013 A.14.2.7, A.15.2.1',
        'NIST SP 800-53 Rev. 4 CA-7, PS-7, SA-4, SA-9, SI-4'
      ]
    },
    {
      id: 'DE.CM-7',
      category: 'Unauthorized Activity Monitoring',
      description: 'Monitoring for unauthorized personnel, connections, devices, and software is performed',
      frameworks: [
        'CIS CSC 1, 2, 3, 5, 9, 12, 13, 15, 16',
        'COBIT 5 DSS05.02, DSS05.05',
        'ISO/IEC 27001:2013 A.12.4.1, A.14.2.7, A.15.2.1',
        'NIST SP 800-53 Rev. 4 AU-12, CA-7, CM-3, CM-8, PE-3, PE-6, PE-20, SI-4'
      ]
    },
    {
      id: 'DE.CM-8',
      category: 'Vulnerability Scanning',
      description: 'Vulnerability scans are performed continuously on banking infrastructure',
      frameworks: [
        'CIS CSC 4, 20',
        'COBIT 5 BAI03.10, DSS05.01',
        'ISA 62443-2-1:2009 4.2.3.1, 4.2.3.7',
        'ISO/IEC 27001:2013 A.12.6.1',
        'NIST SP 800-53 Rev. 4 RA-5'
      ]
    },
    {
      id: 'DE.DP-1',
      category: 'Detection Process Accountability',
      description: 'Roles and responsibilities for detection are well defined to ensure accountability',
      frameworks: [
        'CIS CSC 19',
        'COBIT 5 APO01.02, DSS05.01, DSS06.03',
        'ISA 62443-2-1:2009 4.4.3.1',
        'ISO/IEC 27001:2013 A.6.1.1, A.7.2.2',
        'NIST SP 800-53 Rev. 4 CA-2, CA-7, PM-14'
      ]
    },
    {
      id: 'DE.DP-4',
      category: 'Event Detection Information Communication',
      description: 'Event detection information is communicated',
      frameworks: [
        'CIS CSC 19',
        'COBIT 5 APO08.04, APO12.06, DSS02.05',
        'ISA 62443-2-1:2009 4.3.4.5.9',
        'ISA 62443-3-3:2013 SR 6.1',
        'ISO/IEC 27001:2013 A.16.1.2, A.16.1.3',
        'NIST SP 800-53 Rev. 4 AU-6, CA-2, CA-7, RA-5, SI-4'
      ]
    },
    {
      id: 'DE.DP-5',
      category: 'Detection Process Continuous Improvement',
      description: 'Detection processes are continuously improved',
      frameworks: [
        'COBIT 5 APO11.06, APO12.06, DSS04.05',
        'ISA 62443-2-1:2009 4.4.3.4',
        'ISO/IEC 27001:2013 A.16.1.6',
        'NIST SP 800-53 Rev. 4 CA-2, CA-7, PL-2, RA-5, SI-4, PM-14'
      ]
    }
  ];

  const paymentRails = [
    {
      name: 'ACH Network',
      type: 'Batch Processing',
      speed: '1-2 business days',
      use_case: 'Payroll, bill payments, direct deposits',
      volume: '27.1 billion transactions/year',
      icon: Building2,
      color: 'from-blue-500 to-cyan-500'
    },
    {
      name: 'Real-Time Payments (RTP)',
      type: 'Instant Settlement',
      speed: 'Sub-second',
      use_case: 'Instant transfers, emergency payments',
      volume: '156 million transactions/year',
      icon: Zap,
      color: 'from-purple-500 to-indigo-500'
    },
    {
      name: 'Wire Transfer',
      type: 'High Value',
      speed: 'Same day',
      use_case: 'Large B2B transactions, real estate',
      volume: '695 million transactions/year',
      icon: ArrowRightLeft,
      color: 'from-green-500 to-emerald-500'
    },
    {
      name: 'FedNow',
      type: 'Instant Settlement',
      speed: 'Real-time 24/7/365',
      use_case: 'Consumer P2P, business payments',
      volume: 'Growing (launched 2023)',
      icon: Network,
      color: 'from-amber-500 to-orange-500'
    }
  ];

  const ddaWorkflow = [
    {
      step: 1,
      title: 'Token Arrives',
      description: 'Tokenized withdrawal event enters DDA core pool',
      detail: 'Event contains token pointer, operation type, hints, timestamp'
    },
    {
      step: 2,
      title: 'DDA Service Calls Vault',
      description: 'Authorized service requests detokenization',
      detail: 'VaultDetokenize(withdrawal_root_token)'
    },
    {
      step: 3,
      title: 'Vault Returns Sensitive Fields',
      description: 'Only to authorized role with proper credentials',
      detail: 'Returns routing_number, account_number (plaintext)'
    },
    {
      step: 4,
      title: 'DDA Executes Withdrawal',
      description: 'Settlement process initiated',
      detail: 'Core pool extraction, ACH/Wire processing'
    },
    {
      step: 5,
      title: 'Ledger Posts Event',
      description: 'Transaction recorded with tokenized metadata only',
      detail: 'No sensitive data in audit trail'
    },
    {
      step: 6,
      title: 'Sensitive Fields Re-sealed',
      description: 'Data returned to vault, memory cleared',
      detail: 'Zero-knowledge state restored'
    }
  ];

  const ffiecGuideline8 = {
    title: 'FFIEC Handbook Guideline 8: Information Security',
    subtitle: 'Topology Psychological Awareness for Fundamentals and Ethics',
    principles: [
      {
        area: 'Data Protection',
        guidance: 'Tokenization as primary defense for PII/PCI data in transit and at rest',
        implementation: 'Vault-based tokenization with HMAC-SHA256'
      },
      {
        area: 'Access Controls',
        guidance: 'Role-based access with least privilege for sensitive data detokenization',
        implementation: 'OAuth2 scopes + mTLS authentication'
      },
      {
        area: 'Audit & Accountability',
        guidance: 'Comprehensive logging of all token operations without exposing sensitive data',
        implementation: 'Immutable audit trail with tokenized metadata'
      },
      {
        area: 'Security Awareness',
        guidance: 'Personnel trained on token handling, never logging/displaying raw account numbers',
        implementation: 'Mandatory security training + code reviews'
      },
      {
        area: 'Incident Response',
        guidance: 'Token compromise requires vault key rotation, not account number changes',
        implementation: 'Automated incident response playbooks'
      }
    ]
  };

  const nodeModule = `// Node.js Tokenization Module
// VOM Banking Platform - DDA Withdrawal Tokenization

import crypto from 'crypto';
import { VaultClient } from '@hashicorp/vault';

interface WithdrawalRoot {
  routing_number: string;
  account_number: string;
}

interface TokenizedWithdrawal {
  withdrawal_root_token: string;
  operation: string;
  routing_hint: string;
  account_hint: string;
  ts: string;
}

class DDATokenizationService {
  private vault: VaultClient;
  private readonly TOKEN_PATH = 'withdrawals/dda';
  
  constructor(vaultConfig: any) {
    this.vault = new VaultClient(vaultConfig);
  }

  // Tokenize sensitive withdrawal data
  async tokenize(
    withdrawal: WithdrawalRoot,
    operation: string = 'DDA_CORE_POOL_EXTRACTION'
  ): Promise<TokenizedWithdrawal> {
    // Store sensitive data in vault
    const token = await this.vault.write(
      \`secret/data/\${this.TOKEN_PATH}\`,
      {
        data: {
          routing_number: withdrawal.routing_number,
          account_number: withdrawal.account_number,
          created_at: new Date().toISOString()
        }
      }
    );

    // Generate HMAC token (64 hex chars)
    const hmac = crypto.createHmac('sha256', process.env.TOKEN_SECRET!);
    hmac.update(JSON.stringify(withdrawal));
    const withdrawal_root_token = hmac.digest('hex');

    // Return safe transport object
    return {
      withdrawal_root_token,
      operation,
      routing_hint: this.maskRouting(withdrawal.routing_number),
      account_hint: this.maskAccount(withdrawal.account_number),
      ts: new Date().toISOString()
    };
  }

  // Detokenize for authorized services
  async detokenize(
    token: string,
    requesterRole: string
  ): Promise<WithdrawalRoot | null> {
    // Verify authorization
    if (!this.isAuthorized(requesterRole)) {
      throw new Error('Unauthorized detokenization attempt');
    }

    // Retrieve from vault
    const secret = await this.vault.read(
      \`secret/data/\${this.TOKEN_PATH}/\${token}\`
    );

    if (!secret?.data?.data) {
      return null;
    }

    return {
      routing_number: secret.data.data.routing_number,
      account_number: secret.data.data.account_number
    };
  }

  // Workflow: Process DDA withdrawal
  async processDDAWithdrawal(
    tokenizedWithdrawal: TokenizedWithdrawal
  ): Promise<void> {
    console.log('[1] Token arrived:', tokenizedWithdrawal.withdrawal_root_token);
    
    // [2] DDA service calls vault
    console.log('[2] Calling vault for detokenization...');
    const sensitive = await this.detokenize(
      tokenizedWithdrawal.withdrawal_root_token,
      'dda-service'
    );

    if (!sensitive) {
      throw new Error('Failed to detokenize withdrawal');
    }

    // [3] Vault returns sensitive fields
    console.log('[3] Sensitive fields retrieved (only to authorized role)');
    
    // [4] Execute withdrawal
    console.log('[4] Executing DDA core pool extraction...');
    await this.executeWithdrawal(sensitive);
    
    // [5] Post to ledger (tokenized metadata only)
    console.log('[5] Posting to ledger with tokenized metadata');
    await this.postToLedger({
      token: tokenizedWithdrawal.withdrawal_root_token,
      operation: tokenizedWithdrawal.operation,
      ts: tokenizedWithdrawal.ts
    });
    
    // [6] Re-seal sensitive fields
    console.log('[6] Sensitive fields re-sealed, memory cleared');
    this.clearSensitiveMemory(sensitive);
  }

  private maskRouting(routing: string): string {
    return routing.slice(0, 4) + '****';
  }

  private maskAccount(account: string): string {
    return '****' + account.slice(-4);
  }

  private isAuthorized(role: string): boolean {
    const authorizedRoles = ['dda-service', 'settlement-engine', 'audit-admin'];
    return authorizedRoles.includes(role);
  }

  private async executeWithdrawal(withdrawal: WithdrawalRoot): Promise<void> {
    // Settlement logic here
  }

  private async postToLedger(metadata: any): Promise<void> {
    // Ledger posting logic
  }

  private clearSensitiveMemory(obj: any): void {
    for (const key in obj) {
      obj[key] = null;
    }
  }
}

export default DDATokenizationService;`;

  const javaModule = `// Java Tokenization Module
// VOM Banking Platform - DDA Withdrawal Tokenization

package com.vom.banking.tokenization;

import com.bettercloud.vault.Vault;
import com.bettercloud.vault.VaultConfig;
import com.bettercloud.vault.VaultException;
import javax.crypto.Mac;
import javax.crypto.spec.SecretKeySpec;
import java.nio.charset.StandardCharsets;
import java.time.Instant;
import java.util.HashMap;
import java.util.Map;

public class DDATokenizationService {
    
    private final Vault vault;
    private static final String TOKEN_PATH = "secret/data/withdrawals/dda";
    private static final String[] AUTHORIZED_ROLES = {
        "dda-service", "settlement-engine", "audit-admin"
    };
    
    public DDATokenizationService(VaultConfig vaultConfig) throws VaultException {
        this.vault = new Vault(vaultConfig);
    }
    
    // Tokenize sensitive withdrawal data
    public TokenizedWithdrawal tokenize(
        WithdrawalRoot withdrawal,
        String operation
    ) throws Exception {
        // Store in vault
        Map<String, Object> data = new HashMap<>();
        data.put("routing_number", withdrawal.getRoutingNumber());
        data.put("account_number", withdrawal.getAccountNumber());
        data.put("created_at", Instant.now().toString());
        
        vault.logical().write(TOKEN_PATH, data);
        
        // Generate HMAC token
        String token = generateHMAC(withdrawal);
        
        return TokenizedWithdrawal.builder()
            .withdrawalRootToken(token)
            .operation(operation)
            .routingHint(maskRouting(withdrawal.getRoutingNumber()))
            .accountHint(maskAccount(withdrawal.getAccountNumber()))
            .timestamp(Instant.now().toString())
            .build();
    }
    
    // Detokenize for authorized services
    public WithdrawalRoot detokenize(
        String token,
        String requesterRole
    ) throws VaultException, UnauthorizedException {
        if (!isAuthorized(requesterRole)) {
            throw new UnauthorizedException("Unauthorized detokenization attempt");
        }
        
        Map<String, String> response = vault.logical()
            .read(TOKEN_PATH + "/" + token)
            .getData();
        
        if (response == null) {
            return null;
        }
        
        return WithdrawalRoot.builder()
            .routingNumber(response.get("routing_number"))
            .accountNumber(response.get("account_number"))
            .build();
    }
    
    // Workflow: Process DDA withdrawal
    public void processDDAWithdrawal(
        TokenizedWithdrawal tokenizedWithdrawal
    ) throws Exception {
        System.out.println("[1] Token arrived: " + 
            tokenizedWithdrawal.getWithdrawalRootToken());
        
        // [2] DDA service calls vault
        System.out.println("[2] Calling vault for detokenization...");
        WithdrawalRoot sensitive = detokenize(
            tokenizedWithdrawal.getWithdrawalRootToken(),
            "dda-service"
        );
        
        if (sensitive == null) {
            throw new Exception("Failed to detokenize withdrawal");
        }
        
        // [3] Vault returns sensitive fields
        System.out.println("[3] Sensitive fields retrieved");
        
        // [4] Execute withdrawal
        System.out.println("[4] Executing DDA core pool extraction...");
        executeWithdrawal(sensitive);
        
        // [5] Post to ledger
        System.out.println("[5] Posting to ledger with tokenized metadata");
        postToLedger(tokenizedWithdrawal);
        
        // [6] Re-seal sensitive fields
        System.out.println("[6] Sensitive fields re-sealed");
        clearSensitiveMemory(sensitive);
    }
    
    private String generateHMAC(WithdrawalRoot withdrawal) throws Exception {
        Mac mac = Mac.getInstance("HmacSHA256");
        SecretKeySpec secretKey = new SecretKeySpec(
            System.getenv("TOKEN_SECRET").getBytes(StandardCharsets.UTF_8),
            "HmacSHA256"
        );
        mac.init(secretKey);
        
        String data = withdrawal.getRoutingNumber() + 
                     withdrawal.getAccountNumber();
        byte[] hmacData = mac.doFinal(data.getBytes(StandardCharsets.UTF_8));
        
        StringBuilder sb = new StringBuilder();
        for (byte b : hmacData) {
            sb.append(String.format("%02x", b));
        }
        return sb.toString();
    }
    
    private String maskRouting(String routing) {
        return routing.substring(0, 4) + "****";
    }
    
    private String maskAccount(String account) {
        return "****" + account.substring(account.length() - 4);
    }
    
    private boolean isAuthorized(String role) {
        for (String authorizedRole : AUTHORIZED_ROLES) {
            if (authorizedRole.equals(role)) {
                return true;
            }
        }
        return false;
    }
    
    private void executeWithdrawal(WithdrawalRoot withdrawal) {
        // Settlement logic
    }
    
    private void postToLedger(TokenizedWithdrawal metadata) {
        // Ledger posting logic
    }
    
    private void clearSensitiveMemory(WithdrawalRoot obj) {
        obj.setRoutingNumber(null);
        obj.setAccountNumber(null);
    }
}`;

  const mongoSchema = `// MongoDB Schema for Tokenized Withdrawals

import { Schema, model } from 'mongoose';

const TokenizedWithdrawalSchema = new Schema({
  // Token pointer (safe for storage/transport)
  withdrawal_root_token: {
    type: String,
    required: true,
    index: true,
    unique: true,
    length: 64,
    match: /^[a-f0-9]{64}$/
  },
  
  // Operation metadata
  operation: {
    type: String,
    enum: [
      'DDA_CORE_POOL_EXTRACTION',
      'ACH_SETTLEMENT',
      'WIRE_TRANSFER',
      'RTP_INSTANT_PAYMENT'
    ],
    required: true
  },
  
  // Non-sensitive hints (safe to display)
  routing_hint: {
    type: String,
    required: true,
    match: /^\\d{4}\\*\\*\\*\\*$/
  },
  
  account_hint: {
    type: String,
    required: true,
    match: /^\\*\\*\\*\\*\\d{4}$/
  },
  
  // Workflow tracking
  status: {
    type: String,
    enum: ['pending', 'processing', 'completed', 'failed', 'reversed'],
    default: 'pending'
  },
  
  // Audit trail
  created_at: {
    type: Date,
    default: Date.now,
    immutable: true
  },
  
  processed_at: Date,
  
  completed_at: Date,
  
  // Event sourcing
  events: [{
    event_type: String,
    timestamp: Date,
    metadata: Schema.Types.Mixed
  }],
  
  // Compliance
  compliance_flags: {
    aml_screened: { type: Boolean, default: false },
    sanction_checked: { type: Boolean, default: false },
    fraud_reviewed: { type: Boolean, default: false }
  },
  
  // Never store sensitive data
  // routing_number: FORBIDDEN
  // account_number: FORBIDDEN
}, {
  timestamps: true,
  collection: 'tokenized_withdrawals'
});

// Indexes
TokenizedWithdrawalSchema.index({ created_at: -1 });
TokenizedWithdrawalSchema.index({ status: 1, created_at: -1 });
TokenizedWithdrawalSchema.index({ operation: 1 });

export const TokenizedWithdrawal = model('TokenizedWithdrawal', TokenizedWithdrawalSchema);`;

  const copyToClipboard = (text: string, label: string) => {
    navigator.clipboard.writeText(text);
    toast.success(`${label} copied to clipboard`);
  };

  const downloadModule = (code: string, filename: string) => {
    const blob = new Blob([code], { type: 'text/plain' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = filename;
    a.click();
    URL.revokeObjectURL(url);
    toast.success(`${filename} downloaded`);
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <motion.div
        initial={{ opacity: 0, y: -20 }}
        animate={{ opacity: 1, y: 0 }}
        className="bg-gradient-to-r from-indigo-600 to-purple-600 text-white rounded-lg p-6 shadow-lg"
      >
        <div className="flex items-center gap-3 mb-2">
          <Building2 className="w-8 h-8" />
          <h2 className="text-2xl font-bold">Banking Technology & Payment Rails</h2>
        </div>
        <p className="text-indigo-100">
          Financial Infrastructure Continuity • DDA Core Pool • FFIEC Guideline 8 Compliance
        </p>
      </motion.div>

      {/* Tab Navigation */}
      <div className="bg-white rounded-lg shadow-sm border border-slate-200 p-2">
        <div className="grid grid-cols-2 gap-2">
          <button
            onClick={() => setActiveTab('infrastructure')}
            className={`py-3 px-4 rounded-md transition-all ${
              activeTab === 'infrastructure'
                ? 'bg-indigo-600 text-white shadow-sm'
                : 'bg-slate-50 text-slate-700 hover:bg-slate-100'
            }`}
          >
            <Server className="w-5 h-5 mx-auto mb-1" />
            <span className="font-semibold text-sm">Infrastructure</span>
            <span className="block text-xs opacity-80">DDA Tokenization</span>
          </button>
          <button
            onClick={() => setActiveTab('rails')}
            className={`py-3 px-4 rounded-md transition-all ${
              activeTab === 'rails'
                ? 'bg-indigo-600 text-white shadow-sm'
                : 'bg-slate-50 text-slate-700 hover:bg-slate-100'
            }`}
          >
            <Network className="w-5 h-5 mx-auto mb-1" />
            <span className="font-semibold text-sm">Payment Rails</span>
            <span className="block text-xs opacity-80">ACH • RTP • Wire • FedNow</span>
          </button>
        </div>
      </div>

      {/* Banking Technology Tab */}
      {activeTab === 'infrastructure' && (
        <motion.div
          initial={{ opacity: 0, x: -20 }}
          animate={{ opacity: 1, x: 0 }}
          className="space-y-6"
        >
          {/* FFIEC Guideline 8 */}
          <div className="bg-gradient-to-br from-blue-50 to-cyan-50 rounded-lg p-6 border border-blue-200">
            <div className="flex items-center gap-3 mb-4">
              <FileText className="w-6 h-6 text-blue-600" />
              <div>
                <h3 className="text-lg font-semibold text-slate-800">{ffiecGuideline8.title}</h3>
                <p className="text-sm text-blue-700">{ffiecGuideline8.subtitle}</p>
              </div>
            </div>

            <div className="space-y-3">
              {ffiecGuideline8.principles.map((principle, index) => (
                <div key={index} className="bg-white rounded-lg p-4 border border-blue-200">
                  <div className="font-semibold text-slate-800 mb-2">{principle.area}</div>
                  <div className="text-sm text-slate-600 mb-2">{principle.guidance}</div>
                  <div className="flex items-center gap-2">
                    <CheckCircle className="w-4 h-4 text-green-600" />
                    <span className="text-xs text-green-700 font-mono">{principle.implementation}</span>
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Tokenized Withdrawal Transport */}
          <div className="bg-white rounded-lg shadow-md border border-slate-200 p-6">
            <div className="flex items-center justify-between mb-4">
              <div className="flex items-center gap-3">
                <Shield className="w-6 h-6 text-purple-600" />
                <h3 className="text-lg font-semibold text-slate-800">Safe Transport Object</h3>
              </div>
              <button
                onClick={() => copyToClipboard(JSON.stringify(tokenizedWithdrawal, null, 2), 'Tokenized withdrawal')}
                className="px-3 py-1 bg-purple-600 text-white rounded-md text-sm font-semibold hover:bg-purple-700 transition-colors flex items-center gap-2"
              >
                <Copy className="w-4 h-4" />
                Copy JSON
              </button>
            </div>

            <div className="bg-slate-900 rounded-lg p-4 mb-4">
              <pre className="text-xs text-green-400 font-mono overflow-x-auto">
{JSON.stringify(tokenizedWithdrawal, null, 2)}
              </pre>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className="bg-green-50 rounded-lg p-4 border border-green-200">
                <div className="font-semibold text-green-800 mb-2">✅ Safe for Transport Through:</div>
                <ul className="space-y-1 text-sm text-green-700">
                  <li className="flex items-center gap-2">
                    <CheckCircle className="w-4 h-4" />
                    DDA core pool
                  </li>
                  <li className="flex items-center gap-2">
                    <CheckCircle className="w-4 h-4" />
                    Pub/Sub transport
                  </li>
                  <li className="flex items-center gap-2">
                    <CheckCircle className="w-4 h-4" />
                    Event-driven workflows
                  </li>
                  <li className="flex items-center gap-2">
                    <CheckCircle className="w-4 h-4" />
                    ACH or internal settlement pipelines
                  </li>
                </ul>
              </div>

              <div className="bg-amber-50 rounded-lg p-4 border border-amber-200">
                <div className="font-semibold text-amber-800 mb-2">🔐 Token is a Pointer, Not Data</div>
                <ul className="space-y-1 text-sm text-amber-700">
                  <li>• 64-character HMAC-SHA256 hash</li>
                  <li>• Irreversible cryptographic token</li>
                  <li>• Vault detokenization required</li>
                  <li>• Zero PII/PCI data exposure</li>
                </ul>
              </div>
            </div>
          </div>

          {/* DDA Workflow */}
          <div className="bg-white rounded-lg shadow-md border border-slate-200 p-6">
            <div className="flex items-center justify-between mb-4">
              <div className="flex items-center gap-3">
                <GitBranch className="w-6 h-6 text-cyan-600" />
                <h3 className="text-lg font-semibold text-slate-800">DDA Core Pool Extraction Workflow</h3>
              </div>
              <button
                onClick={() => setShowWorkflow(!showWorkflow)}
                className="px-3 py-1 bg-cyan-600 text-white rounded-md text-sm font-semibold hover:bg-cyan-700 transition-colors flex items-center gap-2"
              >
                <Eye className="w-4 h-4" />
                {showWorkflow ? 'Hide' : 'Show'} Flow
              </button>
            </div>

            {showWorkflow && (
              <div className="space-y-4">
                {ddaWorkflow.map((step, index) => (
                  <motion.div
                    key={step.step}
                    initial={{ opacity: 0, x: -10 }}
                    animate={{ opacity: 1, x: 0 }}
                    transition={{ delay: index * 0.1 }}
                    className="relative"
                  >
                    {index < ddaWorkflow.length - 1 && (
                      <div className="absolute left-6 top-12 bottom-0 w-0.5 bg-gradient-to-b from-cyan-400 to-cyan-200"></div>
                    )}
                    
                    <div className="flex items-start gap-4">
                      <div className="bg-gradient-to-br from-cyan-500 to-blue-500 text-white w-12 h-12 rounded-full flex items-center justify-center font-bold text-lg shadow-lg z-10">
                        {step.step}
                      </div>
                      <div className="flex-1 bg-gradient-to-br from-cyan-50 to-blue-50 rounded-lg p-4 border border-cyan-200">
                        <h4 className="font-semibold text-slate-800 mb-1">{step.title}</h4>
                        <p className="text-sm text-slate-600 mb-2">{step.description}</p>
                        <code className="text-xs text-cyan-700 font-mono bg-white px-2 py-1 rounded border border-cyan-200">
                          {step.detail}
                        </code>
                      </div>
                    </div>
                  </motion.div>
                ))}
              </div>
            )}
          </div>

          {/* Implementation Modules */}
          <div className="bg-white rounded-lg shadow-md border border-slate-200 p-6">
            <div className="flex items-center gap-3 mb-4">
              <Code className="w-6 h-6 text-green-600" />
              <h3 className="text-lg font-semibold text-slate-800">Implementation Modules</h3>
            </div>

            <div className="flex items-center gap-2 mb-4">
              <button
                onClick={() => setSelectedLanguage('node')}
                className={`px-4 py-2 rounded-md transition-all ${
                  selectedLanguage === 'node'
                    ? 'bg-green-600 text-white shadow-sm'
                    : 'bg-slate-100 text-slate-700 hover:bg-slate-200'
                }`}
              >
                Node.js / TypeScript
              </button>
              <button
                onClick={() => setSelectedLanguage('java')}
                className={`px-4 py-2 rounded-md transition-all ${
                  selectedLanguage === 'java'
                    ? 'bg-green-600 text-white shadow-sm'
                    : 'bg-slate-100 text-slate-700 hover:bg-slate-200'
                }`}
              >
                Java / Spring Boot
              </button>
            </div>

            <div className="bg-slate-900 rounded-lg p-4 mb-3">
              <div className="flex items-center justify-between mb-2">
                <div className="flex items-center gap-2">
                  <Terminal className="w-4 h-4 text-green-400" />
                  <span className="text-xs font-semibold text-slate-300">
                    {selectedLanguage === 'node' ? 'DDATokenizationService.ts' : 'DDATokenizationService.java'}
                  </span>
                </div>
                <button
                  onClick={() => downloadModule(
                    selectedLanguage === 'node' ? nodeModule : javaModule,
                    selectedLanguage === 'node' ? 'DDATokenizationService.ts' : 'DDATokenizationService.java'
                  )}
                  className="p-1 hover:bg-slate-700 rounded transition-colors"
                >
                  <Download className="w-4 h-4 text-green-400" />
                </button>
              </div>
              <pre className="text-xs text-green-400 font-mono overflow-x-auto max-h-96">
                {selectedLanguage === 'node' ? nodeModule : javaModule}
              </pre>
            </div>

            <button
              onClick={() => downloadModule(mongoSchema, 'TokenizedWithdrawal.schema.ts')}
              className="w-full bg-blue-600 text-white py-2 rounded-md font-semibold hover:bg-blue-700 transition-colors flex items-center justify-center gap-2"
            >
              <Download className="w-4 h-4" />
              Download MongoDB Schema
            </button>
          </div>

          {/* Detection Controls */}
          <div className="bg-white rounded-lg shadow-md border border-slate-200 p-6">
            <div className="flex items-center gap-3 mb-4">
              <Activity className="w-6 h-6 text-red-600" />
              <h3 className="text-lg font-semibold text-slate-800">NIST Detection Controls (DE.CM / DE.DP)</h3>
            </div>

            <div className="space-y-4">
              {detectionControls.map((control, index) => (
                <motion.div
                  key={control.id}
                  initial={{ opacity: 0, y: 10 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: index * 0.05 }}
                  className="bg-gradient-to-br from-red-50 to-orange-50 rounded-lg p-5 border border-red-200"
                >
                  <div className="flex items-start gap-4">
                    <div className="bg-red-600 text-white px-3 py-1 rounded-lg font-mono text-sm font-semibold">
                      {control.id}
                    </div>
                    <div className="flex-1">
                      <h4 className="font-semibold text-slate-800 mb-2">{control.category}</h4>
                      <p className="text-sm text-slate-700 mb-3">{control.description}</p>
                      <div className="flex flex-wrap gap-2">
                        {control.frameworks.map((framework, idx) => (
                          <span key={idx} className="text-xs bg-white text-red-700 px-2 py-1 rounded border border-red-200">
                            {framework}
                          </span>
                        ))}
                      </div>
                    </div>
                  </div>
                </motion.div>
              ))}
            </div>
          </div>
        </motion.div>
      )}

      {/* Payment Rails Tab */}
      {activeTab === 'rails' && (
        <motion.div
          initial={{ opacity: 0, x: -20 }}
          animate={{ opacity: 1, x: 0 }}
          className="space-y-6"
        >
          {/* Payment Rails Grid */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            {paymentRails.map((rail, index) => (
              <motion.div
                key={rail.name}
                initial={{ opacity: 0, scale: 0.9 }}
                animate={{ opacity: 1, scale: 1 }}
                transition={{ delay: index * 0.1 }}
                className={`bg-gradient-to-br ${rail.color} rounded-lg p-1 shadow-lg`}
              >
                <div className="bg-white rounded-lg p-6">
                  <div className="flex items-center gap-3 mb-4">
                    <rail.icon className="w-8 h-8 text-slate-700" />
                    <div>
                      <h3 className="text-lg font-semibold text-slate-800">{rail.name}</h3>
                      <p className="text-sm text-slate-600">{rail.type}</p>
                    </div>
                  </div>

                  <div className="space-y-3">
                    <div className="bg-slate-50 rounded-lg p-3 border border-slate-200">
                      <div className="text-xs font-semibold text-slate-600 mb-1">Settlement Speed</div>
                      <div className="font-mono text-sm text-slate-800">{rail.speed}</div>
                    </div>

                    <div className="bg-slate-50 rounded-lg p-3 border border-slate-200">
                      <div className="text-xs font-semibold text-slate-600 mb-1">Primary Use Case</div>
                      <div className="text-sm text-slate-800">{rail.use_case}</div>
                    </div>

                    <div className="bg-slate-50 rounded-lg p-3 border border-slate-200">
                      <div className="text-xs font-semibold text-slate-600 mb-1">Annual Volume (US)</div>
                      <div className="text-sm text-slate-800">{rail.volume}</div>
                    </div>
                  </div>
                </div>
              </motion.div>
            ))}
          </div>

          {/* Payment Rail Integration */}
          <div className="bg-white rounded-lg shadow-md border border-slate-200 p-6">
            <div className="flex items-center gap-3 mb-4">
              <Layers className="w-6 h-6 text-indigo-600" />
              <h3 className="text-lg font-semibold text-slate-800">Payment Rail Integration Architecture</h3>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              <div className="bg-blue-50 rounded-lg p-4 border border-blue-200">
                <div className="font-semibold text-blue-800 mb-2">Layer 1: Tokenization</div>
                <ul className="space-y-1 text-sm text-blue-700">
                  <li>• Vault-based tokenization</li>
                  <li>• HMAC-SHA256 tokens</li>
                  <li>• Zero PII exposure</li>
                </ul>
              </div>

              <div className="bg-green-50 rounded-lg p-4 border border-green-200">
                <div className="font-semibold text-green-800 mb-2">Layer 2: Routing</div>
                <ul className="space-y-1 text-sm text-green-700">
                  <li>• Rail selection logic</li>
                  <li>• Cost optimization</li>
                  <li>• SLA enforcement</li>
                </ul>
              </div>

              <div className="bg-purple-50 rounded-lg p-4 border border-purple-200">
                <div className="font-semibold text-purple-800 mb-2">Layer 3: Settlement</div>
                <ul className="space-y-1 text-sm text-purple-700">
                  <li>• Real-time tracking</li>
                  <li>• Reconciliation</li>
                  <li>• Audit compliance</li>
                </ul>
              </div>
            </div>
          </div>

          {/* UMB Bank NA Integration */}
          <div className="bg-gradient-to-br from-green-50 to-emerald-50 rounded-lg p-6 border border-green-200">
            <div className="flex items-center gap-3 mb-4">
              <Building2 className="w-6 h-6 text-green-600" />
              <h3 className="text-lg font-semibold text-slate-800">UMB Bank NA Settlement Integration</h3>
            </div>

            <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
              <div className="bg-white rounded-lg p-4 border border-green-200 text-center">
                <div className="text-xs font-semibold text-green-600 mb-1">ACH Capability</div>
                <div className="text-2xl font-bold text-green-700">✓</div>
              </div>
              <div className="bg-white rounded-lg p-4 border border-green-200 text-center">
                <div className="text-xs font-semibold text-green-600 mb-1">Wire Transfer</div>
                <div className="text-2xl font-bold text-green-700">✓</div>
              </div>
              <div className="bg-white rounded-lg p-4 border border-green-200 text-center">
                <div className="text-xs font-semibold text-green-600 mb-1">RTP Network</div>
                <div className="text-2xl font-bold text-green-700">✓</div>
              </div>
              <div className="bg-white rounded-lg p-4 border border-green-200 text-center">
                <div className="text-xs font-semibold text-green-600 mb-1">FedNow Ready</div>
                <div className="text-2xl font-bold text-green-700">✓</div>
              </div>
            </div>
          </div>
        </motion.div>
      )}
    </div>
  );
}