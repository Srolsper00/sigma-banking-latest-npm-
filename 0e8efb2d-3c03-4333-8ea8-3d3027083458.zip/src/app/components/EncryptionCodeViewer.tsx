import { motion } from 'motion/react';
import { Lock } from 'lucide-react';

export function EncryptionCodeViewer() {
  const code = `import crypto from "crypto";

const KEY = crypto.scryptSync(
  process.env.MASTER_KEY || "dev-only",
  "ledger-salt",
  32
);

export function encrypt(data: Buffer) {
  const iv = crypto.randomBytes(12);
  const cipher = crypto.createCipheriv("aes-256-gcm", KEY, iv);
  const enc = Buffer.concat([cipher.update(data), cipher.final()]);
  return {
    iv,
    tag: cipher.getAuthTag(),
    data: enc
  };
}

export function decrypt(payload: {
  iv: Buffer;
  tag: Buffer;
  data: Buffer;
}) {
  const decipher = crypto.createDecipheriv("aes-256-gcm", KEY, payload.iv);
  decipher.setAuthTag(payload.tag);
  return Buffer.concat([decipher.update(payload.data), decipher.final()]);
}`;

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      exit={{ opacity: 0, y: -20 }}
      transition={{ duration: 0.4 }}
      className="bg-slate-900 rounded-lg p-6 border border-slate-700 shadow-xl"
    >
      <div className="flex items-center gap-2 mb-4">
        <Lock className="w-5 h-5 text-amber-400" />
        <h3 className="text-white">AES-256-GCM Encryption Implementation</h3>
      </div>
      
      <motion.div 
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ delay: 0.2 }}
        className="bg-slate-950 rounded-md p-4 overflow-x-auto"
      >
        <pre className="text-slate-300 text-sm">
          <code>{code}</code>
        </pre>
      </motion.div>

      <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ delay: 0.4 }}
        className="mt-4 grid grid-cols-1 md:grid-cols-3 gap-3"
      >
        <div className="bg-slate-800 rounded p-3 border border-slate-700">
          <div className="text-amber-400 text-sm mb-1">Algorithm</div>
          <div className="text-slate-300 text-xs">AES-256-GCM</div>
        </div>
        <div className="bg-slate-800 rounded p-3 border border-slate-700">
          <div className="text-amber-400 text-sm mb-1">Key Derivation</div>
          <div className="text-slate-300 text-xs">scrypt with salt</div>
        </div>
        <div className="bg-slate-800 rounded p-3 border border-slate-700">
          <div className="text-amber-400 text-sm mb-1">Auth Tag</div>
          <div className="text-slate-300 text-xs">GCM authenticated</div>
        </div>
      </motion.div>
    </motion.div>
  );
}
