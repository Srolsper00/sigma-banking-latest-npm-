import { motion } from 'motion/react';
import { useState } from 'react';
import { CreditCard, DollarSign, TrendingUp, ArrowUpRight, ArrowDownRight, Building2 } from 'lucide-react';

export function EmbeddedBankUI() {
  const [activeTab, setActiveTab] = useState<'dashboard' | 'transactions' | 'transfers'>('dashboard');

  const accounts = [
    { id: 1, name: 'Operating Account', balance: 2847550.50, type: 'Checking', bank: 'UMB NA' },
    { id: 2, name: 'Payroll Account', balance: 1250000.00, type: 'Checking', bank: 'UMB NA' },
    { id: 3, name: 'Reserve Account', balance: 5000000.00, type: 'Savings', bank: 'UMB NA' }
  ];

  const recentTransactions = [
    { id: 1, type: 'credit', amount: 250000.00, description: 'ACH Deposit - Payroll', date: '2025-09-14', status: 'completed' },
    { id: 2, type: 'debit', amount: 125000.00, description: 'Wire Transfer - Vendor Payment', date: '2025-09-14', status: 'completed' },
    { id: 3, type: 'credit', amount: 50000.00, description: 'RTP - Customer Payment', date: '2025-09-13', status: 'completed' },
    { id: 4, type: 'debit', amount: 75500.50, description: 'ACH - Operating Expenses', date: '2025-09-13', status: 'pending' }
  ];

  const formatCurrency = (amount: number) => {
    return `$${amount.toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}`;
  };

  return (
    <motion.div
      initial={{ opacity: 0, scale: 0.95 }}
      animate={{ opacity: 1, scale: 1 }}
      transition={{ duration: 0.5 }}
      className="bg-white rounded-xl shadow-2xl border border-slate-200 overflow-hidden"
    >
      {/* Header */}
      <div className="bg-gradient-to-r from-slate-900 to-slate-800 text-white p-6">
        <div className="flex items-center justify-between mb-4">
          <div className="flex items-center gap-3">
            <Building2 className="w-8 h-8" />
            <div>
              <h2 className="text-xl">Sigma Banking Platform</h2>
              <p className="text-slate-300 text-sm">Production Environment</p>
            </div>
          </div>
          <div className="flex items-center gap-2 bg-green-600 px-4 py-2 rounded-full">
            <div className="w-2 h-2 bg-white rounded-full animate-pulse"></div>
            <span className="text-sm">Live</span>
          </div>
        </div>

        {/* Tabs */}
        <div className="flex gap-2">
          {[
            { id: 'dashboard', label: 'Dashboard' },
            { id: 'transactions', label: 'Transactions' },
            { id: 'transfers', label: 'Transfers' }
          ].map((tab) => (
            <button
              key={tab.id}
              onClick={() => setActiveTab(tab.id as typeof activeTab)}
              className={`
                px-4 py-2 rounded-lg transition-all
                ${activeTab === tab.id 
                  ? 'bg-white text-slate-900' 
                  : 'bg-slate-700 text-slate-300 hover:bg-slate-600'
                }
              `}
            >
              {tab.label}
            </button>
          ))}
        </div>
      </div>

      {/* Content */}
      <div className="p-6">
        {activeTab === 'dashboard' && (
          <div className="space-y-6">
            {/* Total Balance */}
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              className="bg-gradient-to-br from-blue-600 to-purple-600 text-white rounded-lg p-6"
            >
              <div className="text-sm mb-2">Total Balance</div>
              <div className="text-3xl mb-4">{formatCurrency(accounts.reduce((sum, acc) => sum + acc.balance, 0))}</div>
              <div className="flex items-center gap-2 text-sm">
                <TrendingUp className="w-4 h-4" />
                <span>+2.5% from last month</span>
              </div>
            </motion.div>

            {/* Accounts Grid */}
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              {accounts.map((account, index) => (
                <motion.div
                  key={account.id}
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: index * 0.1 }}
                  className="bg-slate-50 rounded-lg p-4 border border-slate-200"
                >
                  <div className="flex items-start justify-between mb-3">
                    <CreditCard className="w-5 h-5 text-slate-600" />
                    <div className="text-xs text-slate-500">{account.type}</div>
                  </div>
                  <div className="text-sm text-slate-600 mb-1">{account.name}</div>
                  <div className="text-lg text-slate-900 mb-2">{formatCurrency(account.balance)}</div>
                  <div className="text-xs text-slate-500">{account.bank}</div>
                </motion.div>
              ))}
            </div>

            {/* Recent Activity */}
            <div>
              <h3 className="text-slate-700 mb-3">Recent Activity</h3>
              <div className="space-y-2">
                {recentTransactions.slice(0, 3).map((tx, index) => (
                  <motion.div
                    key={tx.id}
                    initial={{ opacity: 0, x: -20 }}
                    animate={{ opacity: 1, x: 0 }}
                    transition={{ delay: index * 0.1 }}
                    className="flex items-center justify-between p-3 bg-slate-50 rounded-lg border border-slate-200"
                  >
                    <div className="flex items-center gap-3">
                      <div className={`p-2 rounded-full ${tx.type === 'credit' ? 'bg-green-100' : 'bg-red-100'}`}>
                        {tx.type === 'credit' ? (
                          <ArrowDownRight className="w-4 h-4 text-green-600" />
                        ) : (
                          <ArrowUpRight className="w-4 h-4 text-red-600" />
                        )}
                      </div>
                      <div>
                        <div className="text-sm text-slate-900">{tx.description}</div>
                        <div className="text-xs text-slate-500">{tx.date}</div>
                      </div>
                    </div>
                    <div className={`text-sm font-medium ${tx.type === 'credit' ? 'text-green-600' : 'text-red-600'}`}>
                      {tx.type === 'credit' ? '+' : '-'}{formatCurrency(tx.amount)}
                    </div>
                  </motion.div>
                ))}
              </div>
            </div>
          </div>
        )}

        {activeTab === 'transactions' && (
          <div className="space-y-3">
            <h3 className="text-slate-700 mb-4">All Transactions</h3>
            {recentTransactions.map((tx, index) => (
              <motion.div
                key={tx.id}
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: index * 0.05 }}
                className="flex items-center justify-between p-4 bg-slate-50 rounded-lg border border-slate-200 hover:shadow-md transition-shadow"
              >
                <div className="flex items-center gap-4">
                  <div className={`p-3 rounded-full ${tx.type === 'credit' ? 'bg-green-100' : 'bg-red-100'}`}>
                    {tx.type === 'credit' ? (
                      <ArrowDownRight className="w-5 h-5 text-green-600" />
                    ) : (
                      <ArrowUpRight className="w-5 h-5 text-red-600" />
                    )}
                  </div>
                  <div>
                    <div className="text-slate-900">{tx.description}</div>
                    <div className="text-sm text-slate-500">{tx.date}</div>
                  </div>
                </div>
                <div className="flex items-center gap-4">
                  <span className={`px-3 py-1 rounded-full text-xs ${
                    tx.status === 'completed' 
                      ? 'bg-green-100 text-green-700' 
                      : 'bg-amber-100 text-amber-700'
                  }`}>
                    {tx.status}
                  </span>
                  <div className={`text-lg font-medium ${tx.type === 'credit' ? 'text-green-600' : 'text-red-600'}`}>
                    {tx.type === 'credit' ? '+' : '-'}{formatCurrency(tx.amount)}
                  </div>
                </div>
              </motion.div>
            ))}
          </div>
        )}

        {activeTab === 'transfers' && (
          <div className="text-center py-12">
            <DollarSign className="w-16 h-16 text-slate-300 mx-auto mb-4" />
            <h3 className="text-slate-700 mb-2">Transfer Funds</h3>
            <p className="text-slate-500 mb-6">Initiate secure wire transfers, ACH, or real-time payments</p>
            <button className="bg-gradient-to-r from-blue-600 to-purple-600 text-white px-6 py-3 rounded-lg hover:shadow-lg transition-shadow">
              New Transfer
            </button>
          </div>
        )}
      </div>
    </motion.div>
  );
}