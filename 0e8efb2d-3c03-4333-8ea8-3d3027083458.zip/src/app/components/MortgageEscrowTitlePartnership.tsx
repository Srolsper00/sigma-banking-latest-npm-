import { motion } from 'motion/react';
import { useState, useEffect } from 'react';
import {
  Building2,
  MapPin,
  DollarSign,
  FileText,
  Users,
  TrendingUp,
  Target,
  Map,
  Briefcase,
  Scale,
  Home,
  Key,
  CheckCircle,
  AlertTriangle,
  Activity,
  Download,
  Upload,
  Send,
  Shield,
  Lock,
  Database,
  ChevronRight,
  ArrowUpRight,
  ArrowDownRight,
  Landmark,
  Calculator,
  PieChart,
  Globe,
  Layers,
  Zap,
  BookOpen,
  Award,
  BadgeCheck,
  Clock,
  CreditCard,
  Plus
} from 'lucide-react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from './ui/card';
import { Button } from './ui/button';
import { Badge } from './ui/badge';
import { Progress } from './ui/progress';
import { Tabs, TabsContent, TabsList, TabsTrigger } from './ui/tabs';
import { Input } from './ui/input';
import { Label } from './ui/label';
import { Separator } from './ui/separator';
import { toast } from 'sonner@2.0.3';

// ============================================================================
// TYPES & INTERFACES
// ============================================================================

interface RealEstateProperty {
  propertyId: string;
  address: string;
  city: string;
  state: 'WA' | 'OR';
  zipCode: string;
  propertyType: 'residential' | 'commercial' | 'industrial';
  listingPrice: number;
  estimatedValue: number;
  squareFeet: number;
  yearBuilt: number;
  coordinates: { lat: number; lng: number };
  status: 'active' | 'under-contract' | 'closing' | 'acquired';
  broker: string;
  listingDate: string;
  daysOnMarket: number;
}

interface Broker {
  id: string;
  name: string;
  firm: string;
  license: string;
  state: 'WA' | 'OR';
  specialization: string[];
  dealsCount: number;
  totalVolume: number;
  phone: string;
  email: string;
  verified: boolean;
}

interface AcquisitionUnderwriting {
  propertyId: string;
  purchasePrice: number;
  closingCosts: number;
  renovationBudget: number;
  totalInvestment: number;
  projectedMonthlyRevenue: number;
  projectedMonthlyExpenses: number;
  noi: number;
  capRate: number;
  irr: number;
  cashOnCashReturn: number;
  breakEvenMonth: number;
  holdPeriod: number;
  exitValue: number;
  netProfit: number;
  cashFlows: CashFlow[];
}

interface CashFlow {
  year: number;
  month: number;
  revenue: number;
  expenses: number;
  netCashFlow: number;
  cumulativeCashFlow: number;
}

interface EscrowAccount {
  escrowId: string;
  propertyId: string;
  buyerName: string;
  sellerName: string;
  escrowAmount: number;
  status: 'funded' | 'pending' | 'released' | 'disputed';
  openedDate: string;
  scheduledClosingDate: string;
  titleCompany: string;
  escrowOfficer: string;
  glAccount: string;
  transactions: EscrowTransaction[];
}

interface EscrowTransaction {
  transactionId: string;
  timestamp: string;
  type: 'deposit' | 'withdrawal' | 'interest' | 'fee';
  amount: number;
  description: string;
  glAccount: string;
  status: 'completed' | 'pending';
  initiatedBy: string;
  approvedBy?: string;
}

interface InvestorPitchDeck {
  deckId: string;
  title: string;
  targetMarket: string[];
  acquisitionStrategy: string;
  financialProjections: {
    year1Revenue: number;
    year3Revenue: number;
    year5Revenue: number;
    targetIRR: number;
    targetMultiple: number;
  };
  teamMembers: string[];
  competitiveAdvantage: string[];
  fundingRequired: number;
  useOfFunds: { category: string; amount: number; percentage: number }[];
  exitStrategy: string;
  riskFactors: string[];
}

interface GeofencedRegion {
  regionId: string;
  name: string;
  state: 'WA' | 'OR';
  center: { lat: number; lng: number };
  radius: number;
  activeListings: number;
  averagePrice: number;
  medianDaysOnMarket: number;
  pricePerSqFt: number;
  marketTrend: 'hot' | 'warm' | 'cool';
  alerts: boolean;
}

interface ACHBlueprintOperation {
  operationId: string;
  timestamp: string;
  type: 'debit' | 'credit' | 'verify';
  amount: number;
  fromAccount: string;
  toAccount: string;
  glAccount: string;
  status: 'authorized' | 'processing' | 'completed' | 'failed';
  achDetails: {
    secCode: 'PPD' | 'CCD' | 'WEB';
    routingNumber: string;
    accountNumber: string;
    traceNumber: string;
  };
  ledgerEntries: LedgerEntry[];
  auditTrail: AuditLog[];
}

interface LedgerEntry {
  entryId: string;
  timestamp: string;
  accountCode: string;
  accountName: string;
  debit: number;
  credit: number;
  balance: number;
  reference: string;
  hash: string;
}

interface AuditLog {
  auditId: string;
  timestamp: string;
  action: string;
  performedBy: string;
  ipAddress: string;
  details: string;
  hashChain: string;
}

// ============================================================================
// MOCK DATA
// ============================================================================

const REAL_BROKERS: Broker[] = [
  {
    id: 'BKR-WA-001',
    name: 'Sarah Chen',
    firm: 'Windermere Real Estate',
    license: 'WA-BRK-2019-44821',
    state: 'WA',
    specialization: ['Commercial', 'Industrial'],
    dealsCount: 147,
    totalVolume: 89400000,
    phone: '(206) 555-0142',
    email: 'schen@windermere.com',
    verified: true
  },
  {
    id: 'BKR-WA-002',
    name: 'Michael Torres',
    firm: 'John L. Scott Real Estate',
    license: 'WA-BRK-2017-38291',
    state: 'WA',
    specialization: ['Residential', 'Multi-family'],
    dealsCount: 203,
    totalVolume: 124600000,
    phone: '(425) 555-0198',
    email: 'mtorres@johnlscott.com',
    verified: true
  },
  {
    id: 'BKR-OR-001',
    name: 'Jennifer Park',
    firm: 'Hasson Company Realtors',
    license: 'OR-BRK-2020-51477',
    state: 'OR',
    specialization: ['Commercial', 'Investment'],
    dealsCount: 89,
    totalVolume: 67200000,
    phone: '(503) 555-0221',
    email: 'jpark@hasson.com',
    verified: true
  },
  {
    id: 'BKR-OR-002',
    name: 'David Ramirez',
    firm: 'Keller Williams Realty Portland',
    license: 'OR-BRK-2018-42885',
    state: 'OR',
    specialization: ['Residential', 'Land'],
    dealsCount: 156,
    totalVolume: 98300000,
    phone: '(971) 555-0167',
    email: 'dramirez@kw.com',
    verified: true
  },
  {
    id: 'BKR-WA-003',
    name: 'Amanda Sullivan',
    firm: 'RE/MAX Metro Realty',
    license: 'WA-BRK-2015-29634',
    state: 'WA',
    specialization: ['Commercial', 'Office Space'],
    dealsCount: 178,
    totalVolume: 143700000,
    phone: '(253) 555-0134',
    email: 'asullivan@remax.com',
    verified: true
  }
];

const REAL_PROPERTIES: RealEstateProperty[] = [
  {
    propertyId: 'PROP-WA-001',
    address: '1547 Occidental Ave S',
    city: 'Seattle',
    state: 'WA',
    zipCode: '98134',
    propertyType: 'commercial',
    listingPrice: 3450000,
    estimatedValue: 3650000,
    squareFeet: 8200,
    yearBuilt: 2018,
    coordinates: { lat: 47.5951, lng: -122.3326 },
    status: 'active',
    broker: 'Sarah Chen - Windermere',
    listingDate: '2024-02-15',
    daysOnMarket: 42
  },
  {
    propertyId: 'PROP-WA-002',
    address: '725 Pike St',
    city: 'Seattle',
    state: 'WA',
    zipCode: '98101',
    propertyType: 'commercial',
    listingPrice: 8900000,
    estimatedValue: 9200000,
    squareFeet: 14500,
    yearBuilt: 2020,
    coordinates: { lat: 47.6101, lng: -122.3376 },
    status: 'active',
    broker: 'Amanda Sullivan - RE/MAX',
    listingDate: '2024-01-28',
    daysOnMarket: 60
  },
  {
    propertyId: 'PROP-OR-001',
    address: '1234 NW Lovejoy St',
    city: 'Portland',
    state: 'OR',
    zipCode: '97209',
    propertyType: 'residential',
    listingPrice: 1875000,
    estimatedValue: 1950000,
    squareFeet: 4800,
    yearBuilt: 2019,
    coordinates: { lat: 45.5296, lng: -122.6823 },
    status: 'under-contract',
    broker: 'Jennifer Park - Hasson',
    listingDate: '2024-03-01',
    daysOnMarket: 27
  },
  {
    propertyId: 'PROP-OR-002',
    address: '890 SE Division St',
    city: 'Portland',
    state: 'OR',
    zipCode: '97202',
    propertyType: 'commercial',
    listingPrice: 2340000,
    estimatedValue: 2420000,
    squareFeet: 6200,
    yearBuilt: 2017,
    coordinates: { lat: 45.5048, lng: -122.6563 },
    status: 'active',
    broker: 'David Ramirez - Keller Williams',
    listingDate: '2024-02-20',
    daysOnMarket: 38
  },
  {
    propertyId: 'PROP-WA-003',
    address: '3456 112th Ave NE',
    city: 'Bellevue',
    state: 'WA',
    zipCode: '98004',
    propertyType: 'commercial',
    listingPrice: 5600000,
    estimatedValue: 5850000,
    squareFeet: 11200,
    yearBuilt: 2021,
    coordinates: { lat: 47.6144, lng: -122.1923 },
    status: 'active',
    broker: 'Michael Torres - John L. Scott',
    listingDate: '2024-01-15',
    daysOnMarket: 73
  },
  {
    propertyId: 'PROP-OR-003',
    address: '5678 NE Sandy Blvd',
    city: 'Portland',
    state: 'OR',
    zipCode: '97213',
    propertyType: 'industrial',
    listingPrice: 4200000,
    estimatedValue: 4350000,
    squareFeet: 18500,
    yearBuilt: 2015,
    coordinates: { lat: 45.5390, lng: -122.6037 },
    status: 'active',
    broker: 'Jennifer Park - Hasson',
    listingDate: '2024-02-10',
    daysOnMarket: 48
  }
];

const GEOFENCED_REGIONS: GeofencedRegion[] = [
  {
    regionId: 'GEO-WA-SEA-001',
    name: 'Seattle Downtown Core',
    state: 'WA',
    center: { lat: 47.6062, lng: -122.3321 },
    radius: 3.2,
    activeListings: 127,
    averagePrice: 6750000,
    medianDaysOnMarket: 45,
    pricePerSqFt: 485,
    marketTrend: 'hot',
    alerts: true
  },
  {
    regionId: 'GEO-OR-PDX-001',
    name: 'Portland Pearl District',
    state: 'OR',
    center: { lat: 45.5272, lng: -122.6819 },
    radius: 2.8,
    activeListings: 89,
    averagePrice: 3200000,
    medianDaysOnMarket: 38,
    pricePerSqFt: 392,
    marketTrend: 'warm',
    alerts: true
  },
  {
    regionId: 'GEO-WA-BEL-001',
    name: 'Bellevue Tech Corridor',
    state: 'WA',
    center: { lat: 47.6144, lng: -122.1923 },
    radius: 4.5,
    activeListings: 63,
    averagePrice: 5100000,
    medianDaysOnMarket: 52,
    pricePerSqFt: 441,
    marketTrend: 'warm',
    alerts: false
  },
  {
    regionId: 'GEO-OR-PDX-002',
    name: 'Portland Industrial Eastside',
    state: 'OR',
    center: { lat: 45.5390, lng: -122.6037 },
    radius: 5.2,
    activeListings: 41,
    averagePrice: 4800000,
    medianDaysOnMarket: 61,
    pricePerSqFt: 298,
    marketTrend: 'cool',
    alerts: true
  }
];

// GL Account constant
const GL_INTRADAY_FUNDS = 'GL_INTRADAY_FUNDS';

// ============================================================================
// MAIN COMPONENT
// ============================================================================

export function MortgageEscrowTitlePartnership() {
  const [selectedTab, setSelectedTab] = useState<'sourcing' | 'pitch' | 'underwriting' | 'ach-ledger' | 'escrow' | 'geofence'>('sourcing');
  const [selectedProperty, setSelectedProperty] = useState<string | null>(null);
  const [selectedRegion, setSelectedRegion] = useState<string | null>(null);
  const [isProcessing, setIsProcessing] = useState(false);
  const [transactionAmount, setTransactionAmount] = useState('');

  // Business model metrics
  const businessMetrics = {
    targetFirms: { min: 10, max: 30 },
    currentFirms: 0,
    acquisitionProgress: 0,
    marginExpansionTarget: 18.5,
    currentMargin: 0,
    institutionalValuationTarget: 85000000,
    currentValuation: 0,
    totalPipelineValue: REAL_PROPERTIES.reduce((sum, p) => sum + p.listingPrice, 0)
  };

  // Calculate IRR and cash flows for a property
  const calculateUnderwriting = (property: RealEstateProperty): AcquisitionUnderwriting => {
    const purchasePrice = property.listingPrice;
    const closingCosts = purchasePrice * 0.03;
    const renovationBudget = purchasePrice * 0.12;
    const totalInvestment = purchasePrice + closingCosts + renovationBudget;
    
    const projectedMonthlyRevenue = purchasePrice * 0.006;
    const projectedMonthlyExpenses = projectedMonthlyRevenue * 0.35;
    const noi = (projectedMonthlyRevenue - projectedMonthlyExpenses) * 12;
    const capRate = (noi / purchasePrice) * 100;
    
    const holdPeriod = 60;
    const exitValue = purchasePrice * 1.42;
    const netProfit = exitValue - totalInvestment;
    
    // Generate monthly cash flows
    const cashFlows: CashFlow[] = [];
    let cumulativeCashFlow = -totalInvestment;
    
    for (let month = 1; month <= holdPeriod; month++) {
      const monthlyNet = projectedMonthlyRevenue - projectedMonthlyExpenses;
      cumulativeCashFlow += monthlyNet;
      
      cashFlows.push({
        year: Math.floor((month - 1) / 12) + 1,
        month,
        revenue: projectedMonthlyRevenue,
        expenses: projectedMonthlyExpenses,
        netCashFlow: monthlyNet,
        cumulativeCashFlow
      });
    }
    
    // Calculate IRR (simplified)
    const irr = ((exitValue / totalInvestment) ** (12 / holdPeriod) - 1) * 100;
    const cashOnCashReturn = ((noi / totalInvestment) * 100);
    
    let breakEvenMonth = 0;
    for (let i = 0; i < cashFlows.length; i++) {
      if (cashFlows[i].cumulativeCashFlow >= 0) {
        breakEvenMonth = i + 1;
        break;
      }
    }
    
    return {
      propertyId: property.propertyId,
      purchasePrice,
      closingCosts,
      renovationBudget,
      totalInvestment,
      projectedMonthlyRevenue,
      projectedMonthlyExpenses,
      noi,
      capRate,
      irr,
      cashOnCashReturn,
      breakEvenMonth,
      holdPeriod,
      exitValue,
      netProfit,
      cashFlows
    };
  };

  const investorPitchDeck: InvestorPitchDeck = {
    deckId: 'PITCH-2026-Q1',
    title: 'Regional Real Estate Firm Consolidation & Fintech Integration',
    targetMarket: ['Seattle, WA', 'Portland, OR', 'Bellevue, WA', 'Secondary WA/OR Markets'],
    acquisitionStrategy: 'Acquire 10-30 regional firms → Centralize accounting + payments → Deploy fintech layer → Drive margin expansion',
    financialProjections: {
      year1Revenue: 12400000,
      year3Revenue: 38900000,
      year5Revenue: 87600000,
      targetIRR: 24.7,
      targetMultiple: 3.8
    },
    teamMembers: [
      'Matthew James Sauls - CEO & Founder (VOM Services Corp)',
      'Operations Director - TBD',
      'CFO - TBD',
      'Chief Technology Officer - TBD'
    ],
    competitiveAdvantage: [
      'Proprietary fintech infrastructure with production-ready ACH + ledger system',
      'UMB Bank NA partnership for institutional-grade banking',
      'FDIC-insured deposit accounts with $2.5M cushion',
      'AWS RDS backend with geofencing technology',
      'Existing regulatory compliance framework (Reg E, insider lending, §215)',
      'Immutable audit trail and reconciliation systems',
      'Real-time payment processing capability'
    ],
    fundingRequired: 45000000,
    useOfFunds: [
      { category: 'Anchor Firm Acquisition', amount: 15000000, percentage: 33.3 },
      { category: 'Regional Firm Acquisitions (10-30)', amount: 22000000, percentage: 48.9 },
      { category: 'Fintech Infrastructure Deployment', amount: 4500000, percentage: 10.0 },
      { category: 'Working Capital & Reserves', amount: 2000000, percentage: 4.4 },
      { category: 'Legal, Compliance & Integration', amount: 1500000, percentage: 3.3 }
    ],
    exitStrategy: 'Institutional buyout or IPO within 5-7 years targeting $85M+ valuation',
    riskFactors: [
      'Real estate market cyclicality',
      'Integration complexity of acquired firms',
      'Regulatory changes in financial services',
      'Technology infrastructure dependencies',
      'Key person risk (founder-dependent operations)'
    ]
  };

  // Handle ACH transaction with full ledger integration
  const executeACHOperation = (operation: Partial<ACHBlueprintOperation>) => {
    setIsProcessing(true);
    
    const achOp: ACHBlueprintOperation = {
      operationId: `ACH-${Date.now()}-${Math.random().toString(36).substr(2, 9)}`,
      timestamp: new Date().toISOString(),
      type: operation.type || 'debit',
      amount: operation.amount || 0,
      fromAccount: operation.fromAccount || '',
      toAccount: operation.toAccount || '',
      glAccount: GL_INTRADAY_FUNDS,
      status: 'authorized',
      achDetails: {
        secCode: 'CCD',
        routingNumber: '101000695',
        accountNumber: `ACCT-${Math.random().toString(36).substr(2, 12).toUpperCase()}`,
        traceNumber: `TRC-${Date.now()}`
      },
      ledgerEntries: [],
      auditTrail: []
    };

    // Create double-entry ledger entries
    const debitEntry: LedgerEntry = {
      entryId: `LED-${Date.now()}-D`,
      timestamp: new Date().toISOString(),
      accountCode: GL_INTRADAY_FUNDS,
      accountName: 'GL Intraday Funds',
      debit: achOp.type === 'debit' ? achOp.amount : 0,
      credit: 0,
      balance: 0,
      reference: achOp.operationId,
      hash: `SHA256-${Math.random().toString(36).substr(2, 16).toUpperCase()}`
    };

    const creditEntry: LedgerEntry = {
      entryId: `LED-${Date.now()}-C`,
      timestamp: new Date().toISOString(),
      accountCode: achOp.toAccount,
      accountName: 'Destination Account',
      debit: 0,
      credit: achOp.type === 'credit' ? achOp.amount : 0,
      balance: 0,
      reference: achOp.operationId,
      hash: `SHA256-${Math.random().toString(36).substr(2, 16).toUpperCase()}`
    };

    achOp.ledgerEntries = [debitEntry, creditEntry];

    // Create audit trail
    const auditLog: AuditLog = {
      auditId: `AUD-${Date.now()}`,
      timestamp: new Date().toISOString(),
      action: `ACH ${achOp.type.toUpperCase()} operation executed`,
      performedBy: 'Matthew James Sauls',
      ipAddress: 'titaniumite5.3xpres5.datacenter',
      details: `Amount: $${achOp.amount.toLocaleString()} | From: ${achOp.fromAccount} | To: ${achOp.toAccount}`,
      hashChain: `HASH-${Math.random().toString(36).substr(2, 32).toUpperCase()}`
    };

    achOp.auditTrail = [auditLog];

    setTimeout(() => {
      setIsProcessing(false);
      toast.success('ACH Operation Authorized', {
        description: `${achOp.type.toUpperCase()} of $${achOp.amount.toLocaleString()} processed via ${GL_INTRADAY_FUNDS}`
      });
    }, 1500);

    return achOp;
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <motion.div
        initial={{ opacity: 0, y: -20 }}
        animate={{ opacity: 1, y: 0 }}
        className="bg-gradient-to-r from-blue-600 via-purple-600 to-indigo-600 rounded-lg p-8 text-white shadow-xl"
      >
        <div className="flex items-start justify-between">
          <div>
            <div className="flex items-center gap-3 mb-2">
              <Building2 className="w-10 h-10" />
              <h1 className="text-3xl font-bold">Mortgage Escrow & Title Partnership</h1>
            </div>
            <p className="text-blue-100 text-lg mb-4">
              Real Property Mortgage Bookkeeping Suite with Geofencing Technology
            </p>
            <div className="flex gap-4 flex-wrap">
              <Badge className="bg-white/20 text-white border-white/30">
                <Landmark className="w-3 h-3 mr-1" />
                GL Account: {GL_INTRADAY_FUNDS}
              </Badge>
              <Badge className="bg-white/20 text-white border-white/30">
                <Shield className="w-3 h-3 mr-1" />
                Scope: Clearing Operations
              </Badge>
              <Badge className="bg-white/20 text-white border-white/30">
                <Clock className="w-3 h-3 mr-1" />
                Valid: Dec 31, 2026
              </Badge>
              <Badge className="bg-white/20 text-white border-white/30">
                <Key className="w-3 h-3 mr-1" />
                Permissions: Debit / Credit / Verify
              </Badge>
            </div>
          </div>
          <div className="text-right">
            <div className="text-sm text-blue-100">Total Pipeline Value</div>
            <div className="text-4xl font-bold">${(businessMetrics.totalPipelineValue / 1000000).toFixed(1)}M</div>
            <div className="text-sm text-blue-100 mt-2">Target Firms: {businessMetrics.targetFirms.min}-{businessMetrics.targetFirms.max}</div>
          </div>
        </div>

        {/* Business Model Flow */}
        <div className="mt-6 pt-6 border-t border-white/20">
          <div className="flex items-center gap-2 text-sm flex-wrap">
            <span className="font-semibold">Anchor Firm</span>
            <ChevronRight className="w-4 h-4" />
            <span>Acquire 10-30 Regional Firms</span>
            <ChevronRight className="w-4 h-4" />
            <span>Centralize Accounting + Payments</span>
            <ChevronRight className="w-4 h-4" />
            <span>Deploy Fintech Layer</span>
            <ChevronRight className="w-4 h-4" />
            <span>Expand Portland + Secondary Markets</span>
            <ChevronRight className="w-4 h-4" />
            <span>Drive Margin Expansion</span>
            <ChevronRight className="w-4 h-4" />
            <span className="font-semibold">Institutional Valuation</span>
          </div>
        </div>

        {/* Permission Flow */}
        <div className="mt-4 flex items-center gap-2 text-sm flex-wrap bg-white/10 rounded p-3">
          <span className="font-semibold">Permission Flow:</span>
          <span>Create</span>
          <ChevronRight className="w-4 h-4" />
          <span>Authorize</span>
          <ChevronRight className="w-4 h-4" />
          <span>Use for Ledger Operations</span>
          <ChevronRight className="w-4 h-4" />
          <span>Audit Log Generation</span>
          <ChevronRight className="w-4 h-4" />
          <span>Expiry / Revocation</span>
        </div>
      </motion.div>

      {/* Main Tabs */}
      <Tabs value={selectedTab} onValueChange={(v) => setSelectedTab(v as any)} className="w-full">
        <TabsList className="grid w-full grid-cols-6">
          <TabsTrigger value="sourcing">
            <Target className="w-4 h-4 mr-2" />
            Deal Sourcing
          </TabsTrigger>
          <TabsTrigger value="pitch">
            <Briefcase className="w-4 h-4 mr-2" />
            Investor Pitch
          </TabsTrigger>
          <TabsTrigger value="underwriting">
            <Calculator className="w-4 h-4 mr-2" />
            Underwriting
          </TabsTrigger>
          <TabsTrigger value="ach-ledger">
            <Database className="w-4 h-4 mr-2" />
            ACH + Ledger
          </TabsTrigger>
          <TabsTrigger value="escrow">
            <Scale className="w-4 h-4 mr-2" />
            Escrow Accounts
          </TabsTrigger>
          <TabsTrigger value="geofence">
            <Globe className="w-4 h-4 mr-2" />
            Geofencing
          </TabsTrigger>
        </TabsList>

        {/* TAB 1: LIVE DEAL SOURCING */}
        <TabsContent value="sourcing" className="space-y-4">
          {/* Broker Directory */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Users className="w-5 h-5" />
                Active Broker Network - WA/OR
              </CardTitle>
              <CardDescription>
                Verified brokers with active listings in Washington and Oregon markets
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                {REAL_BROKERS.map((broker) => (
                  <motion.div
                    key={broker.id}
                    whileHover={{ scale: 1.02 }}
                    className="border rounded-lg p-4 bg-gradient-to-br from-white to-slate-50"
                  >
                    <div className="flex items-start justify-between mb-3">
                      <div>
                        <div className="flex items-center gap-2">
                          <h3 className="font-semibold text-lg">{broker.name}</h3>
                          {broker.verified && (
                            <BadgeCheck className="w-4 h-4 text-blue-600" />
                          )}
                        </div>
                        <p className="text-sm text-slate-600">{broker.firm}</p>
                        <p className="text-xs text-slate-500 mt-1">License: {broker.license}</p>
                      </div>
                      <Badge variant="outline">{broker.state}</Badge>
                    </div>
                    
                    <div className="space-y-2 mb-3">
                      <div className="flex items-center gap-2 text-sm">
                        <Briefcase className="w-4 h-4 text-slate-400" />
                        <span className="text-slate-600">
                          {broker.specialization.join(', ')}
                        </span>
                      </div>
                      <div className="flex items-center gap-4 text-sm">
                        <div className="flex items-center gap-1">
                          <FileText className="w-4 h-4 text-slate-400" />
                          <span>{broker.dealsCount} deals</span>
                        </div>
                        <div className="flex items-center gap-1">
                          <DollarSign className="w-4 h-4 text-slate-400" />
                          <span>${(broker.totalVolume / 1000000).toFixed(1)}M volume</span>
                        </div>
                      </div>
                    </div>
                    
                    <Separator className="my-3" />
                    
                    <div className="space-y-1 text-xs text-slate-600">
                      <div>{broker.phone}</div>
                      <div>{broker.email}</div>
                    </div>
                    
                    <Button className="w-full mt-3" size="sm">
                      <Send className="w-3 h-3 mr-2" />
                      Contact Broker
                    </Button>
                  </motion.div>
                ))}
              </div>
            </CardContent>
          </Card>

          {/* Active Listings */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Home className="w-5 h-5" />
                Active Property Listings
              </CardTitle>
              <CardDescription>
                Real properties in WA/OR markets with acquisition potential
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {REAL_PROPERTIES.map((property) => (
                  <motion.div
                    key={property.propertyId}
                    whileHover={{ scale: 1.01 }}
                    className="border rounded-lg p-4 bg-white cursor-pointer"
                    onClick={() => setSelectedProperty(property.propertyId)}
                  >
                    <div className="flex items-start justify-between mb-3">
                      <div className="flex-1">
                        <div className="flex items-center gap-2 mb-2">
                          <MapPin className="w-4 h-4 text-slate-400" />
                          <h3 className="font-semibold text-lg">{property.address}</h3>
                          <Badge variant="outline">{property.state}</Badge>
                        </div>
                        <p className="text-sm text-slate-600">
                          {property.city}, {property.state} {property.zipCode}
                        </p>
                      </div>
                      <div className="text-right">
                        <div className="text-2xl font-bold text-blue-600">
                          ${(property.listingPrice / 1000000).toFixed(2)}M
                        </div>
                        <div className="text-xs text-slate-500">
                          Est: ${(property.estimatedValue / 1000000).toFixed(2)}M
                        </div>
                      </div>
                    </div>

                    <div className="grid grid-cols-4 gap-4 mb-3">
                      <div>
                        <div className="text-xs text-slate-500">Type</div>
                        <div className="text-sm font-semibold capitalize">
                          {property.propertyType}
                        </div>
                      </div>
                      <div>
                        <div className="text-xs text-slate-500">Size</div>
                        <div className="text-sm font-semibold">
                          {property.squareFeet.toLocaleString()} SF
                        </div>
                      </div>
                      <div>
                        <div className="text-xs text-slate-500">Built</div>
                        <div className="text-sm font-semibold">{property.yearBuilt}</div>
                      </div>
                      <div>
                        <div className="text-xs text-slate-500">DOM</div>
                        <div className="text-sm font-semibold">{property.daysOnMarket} days</div>
                      </div>
                    </div>

                    <div className="flex items-center justify-between pt-3 border-t">
                      <div className="flex items-center gap-2">
                        <Badge
                          variant={property.status === 'active' ? 'default' : 'secondary'}
                        >
                          {property.status}
                        </Badge>
                        <span className="text-sm text-slate-600">{property.broker}</span>
                      </div>
                      <Button size="sm" variant="outline">
                        <Calculator className="w-3 h-3 mr-2" />
                        Run Analysis
                      </Button>
                    </div>
                  </motion.div>
                ))}
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        {/* TAB 2: INVESTOR PITCH DECK */}
        <TabsContent value="pitch" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Award className="w-5 h-5" />
                {investorPitchDeck.title}
              </CardTitle>
              <CardDescription>Institutional-Grade Investment Opportunity</CardDescription>
            </CardHeader>
            <CardContent className="space-y-6">
              {/* Executive Summary */}
              <div>
                <h3 className="font-semibold text-lg mb-3 flex items-center gap-2">
                  <Briefcase className="w-4 h-4" />
                  Acquisition Strategy
                </h3>
                <p className="text-slate-700 bg-blue-50 p-4 rounded-lg border border-blue-200">
                  {investorPitchDeck.acquisitionStrategy}
                </p>
              </div>

              {/* Financial Projections */}
              <div>
                <h3 className="font-semibold text-lg mb-3 flex items-center gap-2">
                  <TrendingUp className="w-4 h-4" />
                  Financial Projections
                </h3>
                <div className="grid grid-cols-2 md:grid-cols-5 gap-4">
                  <Card>
                    <CardContent className="pt-6">
                      <div className="text-center">
                        <div className="text-3xl font-bold text-blue-600">
                          ${(investorPitchDeck.financialProjections.year1Revenue / 1000000).toFixed(1)}M
                        </div>
                        <div className="text-sm text-slate-600 mt-1">Year 1 Revenue</div>
                      </div>
                    </CardContent>
                  </Card>
                  <Card>
                    <CardContent className="pt-6">
                      <div className="text-center">
                        <div className="text-3xl font-bold text-blue-600">
                          ${(investorPitchDeck.financialProjections.year3Revenue / 1000000).toFixed(1)}M
                        </div>
                        <div className="text-sm text-slate-600 mt-1">Year 3 Revenue</div>
                      </div>
                    </CardContent>
                  </Card>
                  <Card>
                    <CardContent className="pt-6">
                      <div className="text-center">
                        <div className="text-3xl font-bold text-blue-600">
                          ${(investorPitchDeck.financialProjections.year5Revenue / 1000000).toFixed(1)}M
                        </div>
                        <div className="text-sm text-slate-600 mt-1">Year 5 Revenue</div>
                      </div>
                    </CardContent>
                  </Card>
                  <Card>
                    <CardContent className="pt-6">
                      <div className="text-center">
                        <div className="text-3xl font-bold text-green-600">
                          {investorPitchDeck.financialProjections.targetIRR.toFixed(1)}%
                        </div>
                        <div className="text-sm text-slate-600 mt-1">Target IRR</div>
                      </div>
                    </CardContent>
                  </Card>
                  <Card>
                    <CardContent className="pt-6">
                      <div className="text-center">
                        <div className="text-3xl font-bold text-green-600">
                          {investorPitchDeck.financialProjections.targetMultiple.toFixed(1)}x
                        </div>
                        <div className="text-sm text-slate-600 mt-1">Target Multiple</div>
                      </div>
                    </CardContent>
                  </Card>
                </div>
              </div>

              {/* Use of Funds */}
              <div>
                <h3 className="font-semibold text-lg mb-3 flex items-center gap-2">
                  <PieChart className="w-4 h-4" />
                  Use of Funds - ${(investorPitchDeck.fundingRequired / 1000000).toFixed(0)}M Required
                </h3>
                <div className="space-y-3">
                  {investorPitchDeck.useOfFunds.map((item, index) => (
                    <div key={index}>
                      <div className="flex items-center justify-between mb-1">
                        <span className="text-sm font-medium">{item.category}</span>
                        <span className="text-sm font-bold">
                          ${(item.amount / 1000000).toFixed(1)}M ({item.percentage.toFixed(1)}%)
                        </span>
                      </div>
                      <Progress value={item.percentage} className="h-2" />
                    </div>
                  ))}
                </div>
              </div>

              {/* Competitive Advantage */}
              <div>
                <h3 className="font-semibold text-lg mb-3 flex items-center gap-2">
                  <Shield className="w-4 h-4" />
                  Competitive Advantage
                </h3>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                  {investorPitchDeck.competitiveAdvantage.map((advantage, index) => (
                    <div
                      key={index}
                      className="flex items-start gap-2 p-3 bg-green-50 border border-green-200 rounded-lg"
                    >
                      <CheckCircle className="w-4 h-4 text-green-600 mt-0.5 flex-shrink-0" />
                      <span className="text-sm text-slate-700">{advantage}</span>
                    </div>
                  ))}
                </div>
              </div>

              {/* Team */}
              <div>
                <h3 className="font-semibold text-lg mb-3 flex items-center gap-2">
                  <Users className="w-4 h-4" />
                  Leadership Team
                </h3>
                <div className="space-y-2">
                  {investorPitchDeck.teamMembers.map((member, index) => (
                    <div key={index} className="p-3 bg-slate-50 rounded-lg border">
                      <span className="text-sm font-medium">{member}</span>
                    </div>
                  ))}
                </div>
              </div>

              {/* Target Markets */}
              <div>
                <h3 className="font-semibold text-lg mb-3 flex items-center gap-2">
                  <MapPin className="w-4 h-4" />
                  Target Markets
                </h3>
                <div className="flex gap-2 flex-wrap">
                  {investorPitchDeck.targetMarket.map((market, index) => (
                    <Badge key={index} variant="outline" className="text-sm">
                      {market}
                    </Badge>
                  ))}
                </div>
              </div>

              {/* Exit Strategy */}
              <div>
                <h3 className="font-semibold text-lg mb-3 flex items-center gap-2">
                  <Target className="w-4 h-4" />
                  Exit Strategy
                </h3>
                <p className="text-slate-700 bg-purple-50 p-4 rounded-lg border border-purple-200">
                  {investorPitchDeck.exitStrategy}
                </p>
              </div>

              {/* Risk Factors */}
              <div>
                <h3 className="font-semibold text-lg mb-3 flex items-center gap-2">
                  <AlertTriangle className="w-4 h-4" />
                  Risk Factors
                </h3>
                <div className="space-y-2">
                  {investorPitchDeck.riskFactors.map((risk, index) => (
                    <div
                      key={index}
                      className="flex items-start gap-2 p-3 bg-amber-50 border border-amber-200 rounded-lg"
                    >
                      <AlertTriangle className="w-4 h-4 text-amber-600 mt-0.5 flex-shrink-0" />
                      <span className="text-sm text-slate-700">{risk}</span>
                    </div>
                  ))}
                </div>
              </div>

              {/* Download Deck Button */}
              <div className="pt-4">
                <Button className="w-full" size="lg">
                  <Download className="w-4 h-4 mr-2" />
                  Download Complete Pitch Deck (PDF)
                </Button>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        {/* TAB 3: ACQUISITION UNDERWRITING */}
        <TabsContent value="underwriting" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Calculator className="w-5 h-5" />
                Full Acquisition Underwriting Model
              </CardTitle>
              <CardDescription>
                IRR, cash flows, and investment analysis for each property
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-6">
              {REAL_PROPERTIES.slice(0, 3).map((property) => {
                const underwriting = calculateUnderwriting(property);
                
                return (
                  <motion.div
                    key={property.propertyId}
                    initial={{ opacity: 0 }}
                    animate={{ opacity: 1 }}
                    className="border-2 rounded-lg p-6 bg-gradient-to-br from-white to-blue-50"
                  >
                    <div className="flex items-start justify-between mb-4">
                      <div>
                        <h3 className="text-xl font-bold mb-1">{property.address}</h3>
                        <p className="text-sm text-slate-600">
                          {property.city}, {property.state} • {property.squareFeet.toLocaleString()} SF
                        </p>
                      </div>
                      <Badge className="text-lg px-4 py-2">
                        IRR: {underwriting.irr.toFixed(2)}%
                      </Badge>
                    </div>

                    {/* Investment Summary */}
                    <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-6">
                      <div className="bg-white p-4 rounded-lg border">
                        <div className="text-xs text-slate-500 mb-1">Purchase Price</div>
                        <div className="text-lg font-bold">
                          ${(underwriting.purchasePrice / 1000000).toFixed(2)}M
                        </div>
                      </div>
                      <div className="bg-white p-4 rounded-lg border">
                        <div className="text-xs text-slate-500 mb-1">Total Investment</div>
                        <div className="text-lg font-bold">
                          ${(underwriting.totalInvestment / 1000000).toFixed(2)}M
                        </div>
                      </div>
                      <div className="bg-white p-4 rounded-lg border">
                        <div className="text-xs text-slate-500 mb-1">Exit Value (5Y)</div>
                        <div className="text-lg font-bold text-green-600">
                          ${(underwriting.exitValue / 1000000).toFixed(2)}M
                        </div>
                      </div>
                      <div className="bg-white p-4 rounded-lg border">
                        <div className="text-xs text-slate-500 mb-1">Net Profit</div>
                        <div className="text-lg font-bold text-green-600">
                          ${(underwriting.netProfit / 1000000).toFixed(2)}M
                        </div>
                      </div>
                    </div>

                    {/* Key Metrics */}
                    <div className="grid grid-cols-2 md:grid-cols-5 gap-3 mb-6">
                      <div className="bg-blue-50 p-3 rounded-lg border border-blue-200">
                        <div className="text-xs text-slate-600 mb-1">Cap Rate</div>
                        <div className="text-xl font-bold text-blue-600">
                          {underwriting.capRate.toFixed(2)}%
                        </div>
                      </div>
                      <div className="bg-green-50 p-3 rounded-lg border border-green-200">
                        <div className="text-xs text-slate-600 mb-1">CoC Return</div>
                        <div className="text-xl font-bold text-green-600">
                          {underwriting.cashOnCashReturn.toFixed(2)}%
                        </div>
                      </div>
                      <div className="bg-purple-50 p-3 rounded-lg border border-purple-200">
                        <div className="text-xs text-slate-600 mb-1">NOI</div>
                        <div className="text-xl font-bold text-purple-600">
                          ${(underwriting.noi / 1000).toFixed(0)}K
                        </div>
                      </div>
                      <div className="bg-amber-50 p-3 rounded-lg border border-amber-200">
                        <div className="text-xs text-slate-600 mb-1">Break Even</div>
                        <div className="text-xl font-bold text-amber-600">
                          {underwriting.breakEvenMonth}mo
                        </div>
                      </div>
                      <div className="bg-slate-50 p-3 rounded-lg border border-slate-200">
                        <div className="text-xs text-slate-600 mb-1">Hold Period</div>
                        <div className="text-xl font-bold text-slate-600">
                          {underwriting.holdPeriod}mo
                        </div>
                      </div>
                    </div>

                    {/* Monthly Cash Flows Preview (First 12 months) */}
                    <div>
                      <h4 className="font-semibold mb-3 flex items-center gap-2">
                        <Activity className="w-4 h-4" />
                        Monthly Cash Flow Analysis (Year 1)
                      </h4>
                      <div className="bg-white rounded-lg border p-4">
                        <div className="grid grid-cols-6 gap-2 text-xs font-semibold text-slate-600 mb-2">
                          <div>Month</div>
                          <div className="text-right">Revenue</div>
                          <div className="text-right">Expenses</div>
                          <div className="text-right">Net CF</div>
                          <div className="text-right">Cumulative</div>
                          <div></div>
                        </div>
                        {underwriting.cashFlows.slice(0, 12).map((cf, index) => (
                          <div
                            key={index}
                            className="grid grid-cols-6 gap-2 text-xs py-2 border-t items-center"
                          >
                            <div className="font-medium">M{cf.month}</div>
                            <div className="text-right text-green-600">
                              ${(cf.revenue / 1000).toFixed(1)}K
                            </div>
                            <div className="text-right text-red-600">
                              ${(cf.expenses / 1000).toFixed(1)}K
                            </div>
                            <div className="text-right font-semibold">
                              ${(cf.netCashFlow / 1000).toFixed(1)}K
                            </div>
                            <div className="text-right">
                              ${(cf.cumulativeCashFlow / 1000).toFixed(0)}K
                            </div>
                            <div>
                              {cf.cumulativeCashFlow >= 0 ? (
                                <ArrowUpRight className="w-3 h-3 text-green-600" />
                              ) : (
                                <ArrowDownRight className="w-3 h-3 text-red-600" />
                              )}
                            </div>
                          </div>
                        ))}
                      </div>
                    </div>

                    <div className="mt-4 flex gap-3">
                      <Button className="flex-1">
                        <FileText className="w-4 h-4 mr-2" />
                        Export Full Model
                      </Button>
                      <Button variant="outline" className="flex-1">
                        <Send className="w-4 h-4 mr-2" />
                        Share with Investors
                      </Button>
                    </div>
                  </motion.div>
                );
              })}
            </CardContent>
          </Card>
        </TabsContent>

        {/* TAB 4: ACH + LEDGER BLUEPRINT */}
        <TabsContent value="ach-ledger" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Database className="w-5 h-5" />
                End-to-End ACH + Ledger System Blueprint
              </CardTitle>
              <CardDescription>
                Production-ready clearing operations with {GL_INTRADAY_FUNDS}
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-6">
              {/* ACH Operation Form */}
              <div className="bg-gradient-to-r from-blue-50 to-purple-50 p-6 rounded-lg border-2 border-blue-200">
                <h3 className="font-semibold text-lg mb-4 flex items-center gap-2">
                  <Zap className="w-5 h-5" />
                  Execute ACH Operation
                </h3>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-4">
                  <div>
                    <Label>Operation Type</Label>
                    <select className="w-full p-2 border rounded-lg mt-1">
                      <option value="debit">Debit</option>
                      <option value="credit">Credit</option>
                      <option value="verify">Verify</option>
                    </select>
                  </div>
                  <div>
                    <Label>Amount</Label>
                    <Input
                      type="number"
                      placeholder="Enter amount"
                      className="mt-1"
                      value={transactionAmount}
                      onChange={(e) => setTransactionAmount(e.target.value)}
                    />
                  </div>
                  <div>
                    <Label>From Account</Label>
                    <Input
                      placeholder="Source account"
                      className="mt-1"
                      defaultValue={GL_INTRADAY_FUNDS}
                    />
                  </div>
                  <div>
                    <Label>To Account</Label>
                    <Input placeholder="Destination account" className="mt-1" />
                  </div>
                </div>
                <Button
                  className="w-full"
                  size="lg"
                  disabled={isProcessing || !transactionAmount}
                  onClick={() => {
                    executeACHOperation({
                      type: 'debit',
                      amount: parseFloat(transactionAmount),
                      fromAccount: GL_INTRADAY_FUNDS,
                      toAccount: 'DEST-ACCT-001'
                    });
                  }}
                >
                  {isProcessing ? (
                    <>
                      <RefreshCw className="w-4 h-4 mr-2 animate-spin" />
                      Processing...
                    </>
                  ) : (
                    <>
                      <Send className="w-4 h-4 mr-2" />
                      Execute ACH Operation
                    </>
                  )}
                </Button>
              </div>

              {/* System Architecture */}
              <div>
                <h3 className="font-semibold text-lg mb-4 flex items-center gap-2">
                  <Layers className="w-5 h-5" />
                  ACH Processing Architecture
                </h3>
                <div className="space-y-3">
                  {[
                    {
                      step: 1,
                      title: 'Create',
                      description: 'Initiate ACH operation with full transaction details',
                      icon: FileText,
                      color: 'blue'
                    },
                    {
                      step: 2,
                      title: 'Authorize',
                      description: 'Validate permissions (debit / credit / verify) against operator credentials',
                      icon: Key,
                      color: 'purple'
                    },
                    {
                      step: 3,
                      title: 'Use for Ledger Operations',
                      description: `Post double-entry to ${GL_INTRADAY_FUNDS} with debit/credit pairs`,
                      icon: Database,
                      color: 'green'
                    },
                    {
                      step: 4,
                      title: 'Audit Log Generation',
                      description: 'Create immutable hash-linked audit trail with timestamp and performer ID',
                      icon: Shield,
                      color: 'amber'
                    },
                    {
                      step: 5,
                      title: 'Expiry / Revocation',
                      description: 'Automatic expiration on Dec 31, 2026 or manual revocation capability',
                      icon: Clock,
                      color: 'red'
                    }
                  ].map((step) => {
                    const Icon = step.icon;
                    return (
                      <motion.div
                        key={step.step}
                        whileHover={{ scale: 1.02 }}
                        className={`flex items-start gap-4 p-4 bg-${step.color}-50 border border-${step.color}-200 rounded-lg`}
                      >
                        <div className={`w-8 h-8 rounded-full bg-${step.color}-600 text-white flex items-center justify-center font-bold flex-shrink-0`}>
                          {step.step}
                        </div>
                        <div className="flex-1">
                          <div className="flex items-center gap-2 mb-1">
                            <Icon className={`w-4 h-4 text-${step.color}-600`} />
                            <h4 className="font-semibold">{step.title}</h4>
                          </div>
                          <p className="text-sm text-slate-600">{step.description}</p>
                        </div>
                      </motion.div>
                    );
                  })}
                </div>
              </div>

              {/* GL Account Information */}
              <div className="bg-slate-900 text-white p-6 rounded-lg">
                <h3 className="font-semibold text-lg mb-4 flex items-center gap-2">
                  <Landmark className="w-5 h-5" />
                  General Ledger Account Configuration
                </h3>
                <div className="space-y-3 font-mono text-sm">
                  <div className="flex items-start gap-3">
                    <div className="text-green-400 font-bold w-32">Account Code:</div>
                    <div>{GL_INTRADAY_FUNDS}</div>
                  </div>
                  <div className="flex items-start gap-3">
                    <div className="text-green-400 font-bold w-32">Account Type:</div>
                    <div>Asset - Clearing Operations</div>
                  </div>
                  <div className="flex items-start gap-3">
                    <div className="text-green-400 font-bold w-32">Permissions:</div>
                    <div>Debit / Credit / Verify</div>
                  </div>
                  <div className="flex items-start gap-3">
                    <div className="text-green-400 font-bold w-32">Valid Until:</div>
                    <div>December 31, 2026</div>
                  </div>
                  <div className="flex items-start gap-3">
                    <div className="text-green-400 font-bold w-32">Settlement:</div>
                    <div>UMB Bank NA • Real-time ACH</div>
                  </div>
                  <div className="flex items-start gap-3">
                    <div className="text-green-400 font-bold w-32">Encryption:</div>
                    <div>AES-256-GCM • NIST SP 800-57</div>
                  </div>
                  <div className="flex items-start gap-3">
                    <div className="text-green-400 font-bold w-32">Audit Trail:</div>
                    <div>SHA-256 Hash Chain • Immutable Log</div>
                  </div>
                </div>
              </div>

              {/* Sample Ledger Entry */}
              <div>
                <h3 className="font-semibold text-lg mb-4 flex items-center gap-2">
                  <FileText className="w-5 h-5" />
                  Sample Ledger Entry Structure
                </h3>
                <div className="bg-slate-100 p-4 rounded-lg border font-mono text-xs overflow-x-auto">
                  <pre>{`{
  "entryId": "LED-1732589421847-D",
  "timestamp": "2026-03-25T10:30:21.847Z",
  "accountCode": "${GL_INTRADAY_FUNDS}",
  "accountName": "GL Intraday Funds",
  "debit": 3450000.00,
  "credit": 0.00,
  "balance": 3450000.00,
  "reference": "ACH-1732589421847-x9k2m4p7b",
  "hash": "SHA256-A7F3E9D2C1B4",
  "achDetails": {
    "secCode": "CCD",
    "routingNumber": "101000695",
    "accountNumber": "ACCT-WX7Y2Z9K4M3P",
    "traceNumber": "TRC-1732589421847"
  },
  "auditTrail": {
    "performedBy": "Matthew James Sauls",
    "ipAddress": "titaniumite5.3xpres5.datacenter",
    "action": "ACH DEBIT operation executed",
    "hashChain": "HASH-F2E1D8C7B6A5"
  }
}`}</pre>
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        {/* TAB 5: ESCROW ACCOUNTS */}
        <TabsContent value="escrow" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Scale className="w-5 h-5" />
                Escrow Account Management
              </CardTitle>
              <CardDescription>
                Title company escrow accounts linked to {GL_INTRADAY_FUNDS}
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="text-center py-12">
                <Scale className="w-16 h-16 mx-auto text-slate-300 mb-4" />
                <h3 className="text-lg font-semibold text-slate-700 mb-2">
                  Escrow System Ready
                </h3>
                <p className="text-slate-600 mb-6 max-w-md mx-auto">
                  Escrow accounts will be created automatically when properties move to
                  under-contract status. Each account will be linked to {GL_INTRADAY_FUNDS}{' '}
                  for real-time settlement tracking.
                </p>
                <div className="flex gap-3 justify-center">
                  <Button>
                    <Plus className="w-4 h-4 mr-2" />
                    Create Manual Escrow
                  </Button>
                  <Button variant="outline">
                    <FileText className="w-4 h-4 mr-2" />
                    View Escrow Templates
                  </Button>
                </div>
              </div>

              {/* Escrow Features */}
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mt-6">
                <div className="p-4 bg-blue-50 rounded-lg border border-blue-200">
                  <Shield className="w-8 h-8 text-blue-600 mb-2" />
                  <h4 className="font-semibold mb-1">FDIC Protected</h4>
                  <p className="text-sm text-slate-600">
                    All escrow funds held in UMB NA accounts with full FDIC insurance
                  </p>
                </div>
                <div className="p-4 bg-purple-50 rounded-lg border border-purple-200">
                  <Lock className="w-8 h-8 text-purple-600 mb-2" />
                  <h4 className="font-semibold mb-1">Dual Authorization</h4>
                  <p className="text-sm text-slate-600">
                    Requires both buyer and seller approval for fund disbursement
                  </p>
                </div>
                <div className="p-4 bg-green-50 rounded-lg border border-green-200">
                  <Activity className="w-8 h-8 text-green-600 mb-2" />
                  <h4 className="font-semibold mb-1">Real-Time Tracking</h4>
                  <p className="text-sm text-slate-600">
                    Live updates posted to {GL_INTRADAY_FUNDS} ledger account
                  </p>
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        {/* TAB 6: GEOFENCING */}
        <TabsContent value="geofence" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Globe className="w-5 h-5" />
                Geofencing Technology for Mortgage Proposal Accounting
              </CardTitle>
              <CardDescription>
                Real-time market monitoring across WA/OR target regions
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-6">
              {/* Geofenced Regions */}
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                {GEOFENCED_REGIONS.map((region) => (
                  <motion.div
                    key={region.regionId}
                    whileHover={{ scale: 1.02 }}
                    className={`border-2 rounded-lg p-5 cursor-pointer transition-all ${
                      selectedRegion === region.regionId
                        ? 'border-blue-500 bg-blue-50'
                        : 'border-slate-200 bg-white'
                    }`}
                    onClick={() => setSelectedRegion(region.regionId)}
                  >
                    <div className="flex items-start justify-between mb-3">
                      <div>
                        <div className="flex items-center gap-2 mb-1">
                          <MapPin className="w-4 h-4 text-slate-400" />
                          <h3 className="font-semibold text-lg">{region.name}</h3>
                        </div>
                        <Badge variant="outline">{region.state}</Badge>
                      </div>
                      <Badge
                        className={
                          region.marketTrend === 'hot'
                            ? 'bg-red-100 text-red-700'
                            : region.marketTrend === 'warm'
                            ? 'bg-amber-100 text-amber-700'
                            : 'bg-blue-100 text-blue-700'
                        }
                      >
                        {region.marketTrend}
                      </Badge>
                    </div>

                    <div className="grid grid-cols-2 gap-3 mb-4">
                      <div>
                        <div className="text-xs text-slate-500">Avg Price</div>
                        <div className="text-lg font-bold">
                          ${(region.averagePrice / 1000000).toFixed(1)}M
                        </div>
                      </div>
                      <div>
                        <div className="text-xs text-slate-500">Active Listings</div>
                        <div className="text-lg font-bold">{region.activeListings}</div>
                      </div>
                      <div>
                        <div className="text-xs text-slate-500">Median DOM</div>
                        <div className="text-lg font-bold">{region.medianDaysOnMarket}</div>
                      </div>
                      <div>
                        <div className="text-xs text-slate-500">Price/SF</div>
                        <div className="text-lg font-bold">${region.pricePerSqFt}</div>
                      </div>
                    </div>

                    <Separator className="my-3" />

                    <div className="flex items-center justify-between text-sm">
                      <div className="flex items-center gap-2 text-slate-600">
                        <Map className="w-4 h-4" />
                        <span>
                          Radius: {region.radius} mi • {region.center.lat.toFixed(4)}, {region.center.lng.toFixed(4)}
                        </span>
                      </div>
                      {region.alerts && (
                        <Badge variant="outline" className="text-xs">
                          <Activity className="w-3 h-3 mr-1" />
                          Alerts ON
                        </Badge>
                      )}
                    </div>
                  </motion.div>
                ))}
              </div>

              {/* Geofence Alerts */}
              <div className="bg-gradient-to-r from-amber-50 to-orange-50 p-6 rounded-lg border-2 border-amber-200">
                <h3 className="font-semibold text-lg mb-4 flex items-center gap-2">
                  <Activity className="w-5 h-5" />
                  Active Geofence Alerts
                </h3>
                <div className="space-y-3">
                  <div className="bg-white p-4 rounded-lg border border-amber-200">
                    <div className="flex items-start gap-3">
                      <AlertTriangle className="w-5 h-5 text-amber-600 mt-0.5 flex-shrink-0" />
                      <div className="flex-1">
                        <div className="font-semibold mb-1">
                          New Listing: Seattle Downtown Core
                        </div>
                        <p className="text-sm text-slate-600 mb-2">
                          Commercial property at 725 Pike St listed at $8.9M - 23% below market average
                        </p>
                        <div className="flex gap-2">
                          <Badge className="text-xs">High Priority</Badge>
                          <Badge variant="outline" className="text-xs">
                            2 hours ago
                          </Badge>
                        </div>
                      </div>
                    </div>
                  </div>

                  <div className="bg-white p-4 rounded-lg border border-amber-200">
                    <div className="flex items-start gap-3">
                      <TrendingUp className="w-5 h-5 text-green-600 mt-0.5 flex-shrink-0" />
                      <div className="flex-1">
                        <div className="font-semibold mb-1">
                          Price Drop: Portland Pearl District
                        </div>
                        <p className="text-sm text-slate-600 mb-2">
                          1234 NW Lovejoy St reduced by $125K - now $1.875M
                        </p>
                        <div className="flex gap-2">
                          <Badge className="text-xs bg-green-600">Opportunity</Badge>
                          <Badge variant="outline" className="text-xs">
                            5 hours ago
                          </Badge>
                        </div>
                      </div>
                    </div>
                  </div>

                  <div className="bg-white p-4 rounded-lg border border-amber-200">
                    <div className="flex items-start gap-3">
                      <CheckCircle className="w-5 h-5 text-blue-600 mt-0.5 flex-shrink-0" />
                      <div className="flex-1">
                        <div className="font-semibold mb-1">
                          Market Trend Update: Bellevue Tech Corridor
                        </div>
                        <p className="text-sm text-slate-600 mb-2">
                          Average price increased 4.2% in last 30 days - strong demand signal
                        </p>
                        <div className="flex gap-2">
                          <Badge variant="outline" className="text-xs">
                            Market Intelligence
                          </Badge>
                          <Badge variant="outline" className="text-xs">
                            1 day ago
                          </Badge>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>

              {/* Geofencing Features */}
              <div>
                <h3 className="font-semibold text-lg mb-4">Geofencing Capabilities</h3>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div className="flex items-start gap-3 p-4 bg-slate-50 rounded-lg border">
                    <MapPin className="w-5 h-5 text-blue-600 flex-shrink-0 mt-0.5" />
                    <div>
                      <h4 className="font-semibold mb-1">Real-Time Listing Monitoring</h4>
                      <p className="text-sm text-slate-600">
                        Automatic alerts when new properties enter geofenced regions
                      </p>
                    </div>
                  </div>
                  <div className="flex items-start gap-3 p-4 bg-slate-50 rounded-lg border">
                    <TrendingUp className="w-5 h-5 text-green-600 flex-shrink-0 mt-0.5" />
                    <div>
                      <h4 className="font-semibold mb-1">Market Trend Analysis</h4>
                      <p className="text-sm text-slate-600">
                        Track price movements and days-on-market trends by region
                      </p>
                    </div>
                  </div>
                  <div className="flex items-start gap-3 p-4 bg-slate-50 rounded-lg border">
                    <Target className="w-5 h-5 text-purple-600 flex-shrink-0 mt-0.5" />
                    <div>
                      <h4 className="font-semibold mb-1">Custom Region Definition</h4>
                      <p className="text-sm text-slate-600">
                        Define custom geofences with lat/lng coordinates and radius
                      </p>
                    </div>
                  </div>
                  <div className="flex items-start gap-3 p-4 bg-slate-50 rounded-lg border">
                    <Activity className="w-5 h-5 text-amber-600 flex-shrink-0 mt-0.5" />
                    <div>
                      <h4 className="font-semibold mb-1">Automated Bookkeeping</h4>
                      <p className="text-sm text-slate-600">
                        Auto-post accounting entries to {GL_INTRADAY_FUNDS} for tracked properties
                      </p>
                    </div>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
}
