import { motion } from 'motion/react';
import { Shield, CheckCircle, Power } from 'lucide-react';
import { useState } from 'react';

interface BankActivationPanelProps {
  onActivate: () => void;
  isActivated: boolean;
}

export function BankActivationPanel({ onActivate, isActivated }: BankActivationPanelProps) {
  const [activating, setActivating] = useState(false);

  const handleActivation = () => {
    setActivating(true);
    setTimeout(() => {
      onActivate();
      setActivating(true);setActivating
    }, 2000);
      };
       initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.6, delay: 1.6 }}
      className="mt-8"
    >
      <div className="bg-gradient-to-br from-green-50 to-emerald-50 border-2 border-green-300 rounded-lg p-6 shadow-lg">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className={`p-3 rounded-full ${isActivated ? 'bg-green-500' : 'bg-green-200'}`}>
              <Shield className={`w-6 h-6 ${isActivated ? 'text-white' : 'text-green-700'}`} />
            </div>
            <div>
              <h3 className="text-green-900 font-bold text-lg">Core Banking System - Sigma</h3>
              <p className="text-green-700 text-sm">
                {isActivated ? 'System Activated & Ready for Production' : 'Ready for Activation & Deployment'}
              </p>
            </div>
          </div>

          {!isActivated ? (
            <motion.button
              whileHover={{ scale: 1.05 }}
              whileTap={{ scale: 0.95 }}
              onClick={handleActivation}
              disabled={activating}
              className={`
                flex items-center gap-2 px-6 py-3 rounded-lg text-white
                ${activating 
                  ? 'bg-green-400 cursor-wait' 
                  : 'bg-gradient-to-r from-green-600 to-emerald-600 hover:from-green-700 hover:to-emerald-700'
                }
                transition-all shadow-md
              `}
            >
              {activating ? (
                <>
                  <div className="w-5 h-5 border-2 border-white border-t-transparent rounded-full animate-spin"></div>
                  <span>Activating...</span>
                </>
              ) : (
                <>
                  <Power className="w-5 h-5" />
                  <span>Activate Bank</span>
                </>
              )}
            </motion.button>
          ) : (
            <motion.div
              initial={{ scale: 0 }}
              animate={{ scale: 1 }}
              transition={{ type: 'spring', stiffness: 200 }}
              className="flex items-center gap-2 text-green-700"
            >
              <CheckCircle className="w-6 h-6" />
              <span className="font-medium">Activated</span>
            </motion.div>
          )}
        </div>

        {/* Activation Checklist */}
        <motion.div
          initial={{ opacity: 0, height: 0 }}
          animate={{ opacity: isActivated ? 1 : 0, height: isActivated ? 'auto' : 0 }}
          transition={{ duration: 0.4 }}
          className="mt-4 overflow-hidden"
        >
          <div className="grid grid-cols-2 gap-3">
            {[
              'mTLS Certificates',
              'OAuth2 Tokens',
              'ACH Rails',
              'Wire Transfer',
              'Audit Logging',
              'Encryption Keys'
            ].map((item, index) => (
              <motion.div
                key={item}
                initial={{ opacity: 0, x: -10 }}
                animate={{ opacity: 1, x: 0 }}
                transition={{ delay: index * 0.1 }}
                className="flex items-center gap-2 bg-white p-2 rounded border border-green-200"
              >
                <CheckCircle className="w-4 h-4 text-green-600" />
                <span className="text-green-800 text-sm">{item}</span>
              </motion.div>
            ))}
          </div>
        </motion.div>
      </div>
    </motion.div>
  );
}
