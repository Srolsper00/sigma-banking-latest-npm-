import { motion } from 'motion/react';
import { useState } from 'react';
import {
  Server,
  Activity,
  AlertCircle,
  BarChart3,
  Database,
  Zap,
  Clock,
  Globe,
  CheckCircle,
  AlertTriangle,
  TrendingUp,
  TrendingDown,
  Shield,
  Info
} from 'lucide-react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from './ui/card';
import { Badge } from './ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from './ui/tabs';
import { Separator } from './ui/separator';
import {
  LineChart,
  Line,
  BarChart,
  Bar,
  AreaChart,
  Area,
  PieChart,
  Pie,
  Cell,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  Legend,
  ResponsiveContainer
} from 'recharts';

// ============================================================================
// SYSTEM EVENTS MONITORING - DATABASE SCHEMA
// ============================================================================

/*
CREATE TABLE system_events (
    system_event_id     UUID PRIMARY KEY,
    service_name        VARCHAR,
    event_type          VARCHAR, -- LATENCY / ERROR / THROTTLE / FAILOVER
    metrics             JSONB,
    region              VARCHAR,
    created_at          TIMESTAMP DEFAULT NOW()
);
*/

interface SystemEvent {
  system_event_id: string;
  service_name: string;
  event_type: 'LATENCY' | 'ERROR' | 'THROTTLE' | 'FAILOVER';
  metrics: {
    latency_ms?: number;
    error_code?: string;
    error_message?: string;
    throttle_reason?: string;
    failover_target?: string;
    success_rate?: number;
    request_count?: number;
  };
  region: string;
  created_at: string;
}

// Sample System Events Data
const SYSTEM_EVENTS: SystemEvent[] = [
  {
    system_event_id: 'evt-001-latency',
    service_name: 'Sutton Bank ACH Service',
    event_type: 'LATENCY',
    metrics: {
      latency_ms: 145,
      success_rate: 99.8,
      request_count: 1247
    },
    region: 'us-east-1',
    created_at: new Date(Date.now() - 300000).toISOString()
  },
  {
    system_event_id: 'evt-002-error',
    service_name: 'General Ledger API',
    event_type: 'ERROR',
    metrics: {
      error_code: 'GL-500',
      error_message: 'Connection timeout to Aurora cluster',
      request_count: 23
    },
    region: 'us-west-2',
    created_at: new Date(Date.now() - 600000).toISOString()
  },
  {
    system_event_id: 'evt-003-throttle',
    service_name: 'Federal Tax Allocation Service',
    event_type: 'THROTTLE',
    metrics: {
      throttle_reason: 'Rate limit exceeded (1000 req/min)',
      request_count: 1523
    },
    region: 'us-east-1',
    created_at: new Date(Date.now() - 900000).toISOString()
  },
  {
    system_event_id: 'evt-004-failover',
    service_name: 'Tier-7 Security Validator',
    event_type: 'FAILOVER',
    metrics: {
      failover_target: 'us-west-2-secondary',
      success_rate: 100,
      request_count: 456
    },
    region: 'us-east-1',
    created_at: new Date(Date.now() - 1200000).toISOString()
  },
  {
    system_event_id: 'evt-005-latency',
    service_name: 'Capital One Integration',
    event_type: 'LATENCY',
    metrics: {
      latency_ms: 89,
      success_rate: 99.9,
      request_count: 892
    },
    region: 'us-east-1',
    created_at: new Date(Date.now() - 1500000).toISOString()
  },
  {
    system_event_id: 'evt-006-latency',
    service_name: 'Boardroom PDF Generator',
    event_type: 'LATENCY',
    metrics: {
      latency_ms: 234,
      success_rate: 98.5,
      request_count: 67
    },
    region: 'us-west-2',
    created_at: new Date(Date.now() - 1800000).toISOString()
  }
];

// Chart Data - Event Type Distribution
const eventTypeData = [
  { name: 'LATENCY', value: SYSTEM_EVENTS.filter(e => e.event_type === 'LATENCY').length, color: '#3b82f6' },
  { name: 'ERROR', value: SYSTEM_EVENTS.filter(e => e.event_type === 'ERROR').length, color: '#ef4444' },
  { name: 'THROTTLE', value: SYSTEM_EVENTS.filter(e => e.event_type === 'THROTTLE').length, color: '#f59e0b' },
  { name: 'FAILOVER', value: SYSTEM_EVENTS.filter(e => e.event_type === 'FAILOVER').length, color: '#8b5cf6' }
];

// Chart Data - Regional Distribution
const regionalData = [
  { name: 'us-east-1', events: SYSTEM_EVENTS.filter(e => e.region === 'us-east-1').length },
  { name: 'us-west-2', events: SYSTEM_EVENTS.filter(e => e.region === 'us-west-2').length }
];

// Chart Data - Service Performance
const servicePerformanceData = [
  { service: 'ACH Service', latency: 145, requests: 1247 },
  { service: 'GL API', latency: 200, requests: 890 },
  { service: 'Tax Service', latency: 98, requests: 1523 },
  { service: 'Security', latency: 45, requests: 456 },
  { service: 'Capital One', latency: 89, requests: 892 }
];

// Chart Data - Timeline
const timelineData = SYSTEM_EVENTS.map((event, idx) => ({
  time: new Date(event.created_at).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
  latency: event.metrics.latency_ms || 0,
  requests: event.metrics.request_count || 0,
  success_rate: event.metrics.success_rate || 0
})).reverse();

export function SystemEventsMonitoring() {
  const [selectedEvent, setSelectedEvent] = useState<string | null>(null);
  const [activeTab, setActiveTab] = useState<'events' | 'charts' | 'schema'>('events');

  // Calculate statistics
  const totalEvents = SYSTEM_EVENTS.length;
  const errorCount = SYSTEM_EVENTS.filter(e => e.event_type === 'ERROR').length;
  const avgLatency = Math.round(
    SYSTEM_EVENTS
      .filter(e => e.metrics.latency_ms)
      .reduce((sum, e) => sum + (e.metrics.latency_ms || 0), 0) /
    SYSTEM_EVENTS.filter(e => e.metrics.latency_ms).length
  );
  const avgSuccessRate = Math.round(
    SYSTEM_EVENTS
      .filter(e => e.metrics.success_rate)
      .reduce((sum, e) => sum + (e.metrics.success_rate || 0), 0) /
    SYSTEM_EVENTS.filter(e => e.metrics.success_rate).length * 10
  ) / 10;

  return (
    <div className="space-y-6">
      {/* Header */}
      <motion.div
        initial={{ opacity: 0, y: -20 }}
        animate={{ opacity: 1, y: 0 }}
        className="bg-gradient-to-r from-indigo-600 via-purple-600 to-pink-600 rounded-2xl p-8 text-white"
      >
        <div className="flex items-start justify-between">
          <div>
            <div className="flex items-center gap-3 mb-2">
              <Server className="w-10 h-10" />
              <h1 className="text-3xl font-bold">System Events Monitoring</h1>
            </div>
            <h2 className="text-xl font-semibold mb-2">Real-Time Event Analytics & Performance Tracking</h2>
            <p className="text-purple-100 mb-4">
              PostgreSQL Event Store • JSONB Metrics • Multi-Region Observability
            </p>
            <div className="flex items-center gap-6 text-sm">
              <div className="flex items-center gap-2">
                <Activity className="w-4 h-4" />
                <span>Live Monitoring</span>
              </div>
              <div className="flex items-center gap-2">
                <Database className="w-4 h-4" />
                <span>PostgreSQL Backend</span>
              </div>
              <div className="flex items-center gap-2">
                <Globe className="w-4 h-4" />
                <span>Multi-Region</span>
              </div>
            </div>
          </div>
          <div className="text-right">
            <Badge className="bg-green-500 text-white text-lg px-4 py-2">
              <Zap className="w-4 h-4 mr-2 inline" />
              ACTIVE
            </Badge>
          </div>
        </div>
      </motion.div>

      {/* Statistics Summary */}
      <div className="grid grid-cols-4 gap-6">
        <motion.div
          initial={{ opacity: 0, scale: 0.95 }}
          animate={{ opacity: 1, scale: 1 }}
          transition={{ delay: 0.1 }}
        >
          <Card className="border-2 border-blue-200 bg-blue-50/50">
            <CardHeader className="pb-3">
              <CardTitle className="text-sm font-medium text-blue-700 flex items-center gap-2">
                <BarChart3 className="w-4 h-4" />
                Total Events
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold text-blue-900">{totalEvents}</div>
              <p className="text-xs text-blue-600 mt-1">Last 24 hours</p>
            </CardContent>
          </Card>
        </motion.div>

        <motion.div
          initial={{ opacity: 0, scale: 0.95 }}
          animate={{ opacity: 1, scale: 1 }}
          transition={{ delay: 0.2 }}
        >
          <Card className="border-2 border-red-200 bg-red-50/50">
            <CardHeader className="pb-3">
              <CardTitle className="text-sm font-medium text-red-700 flex items-center gap-2">
                <AlertCircle className="w-4 h-4" />
                Error Count
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold text-red-900">{errorCount}</div>
              <p className="text-xs text-red-600 mt-1">{((errorCount / totalEvents) * 100).toFixed(1)}% error rate</p>
            </CardContent>
          </Card>
        </motion.div>

        <motion.div
          initial={{ opacity: 0, scale: 0.95 }}
          animate={{ opacity: 1, scale: 1 }}
          transition={{ delay: 0.3 }}
        >
          <Card className="border-2 border-green-200 bg-green-50/50">
            <CardHeader className="pb-3">
              <CardTitle className="text-sm font-medium text-green-700 flex items-center gap-2">
                <Clock className="w-4 h-4" />
                Avg Latency
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold text-green-900">{avgLatency}ms</div>
              <p className="text-xs text-green-600 mt-1">Response time</p>
            </CardContent>
          </Card>
        </motion.div>

        <motion.div
          initial={{ opacity: 0, scale: 0.95 }}
          animate={{ opacity: 1, scale: 1 }}
          transition={{ delay: 0.4 }}
        >
          <Card className="border-2 border-purple-200 bg-purple-50/50">
            <CardHeader className="pb-3">
              <CardTitle className="text-sm font-medium text-purple-700 flex items-center gap-2">
                <TrendingUp className="w-4 h-4" />
                Success Rate
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold text-purple-900">{avgSuccessRate}%</div>
              <p className="text-xs text-purple-600 mt-1">System uptime</p>
            </CardContent>
          </Card>
        </motion.div>
      </div>

      {/* Main Tabs */}
      <Tabs value={activeTab} onValueChange={(v) => setActiveTab(v as any)}>
        <TabsList className="grid w-full grid-cols-3">
          <TabsTrigger value="events">
            <Activity className="w-4 h-4 mr-2" />
            Event Stream
          </TabsTrigger>
          <TabsTrigger value="charts">
            <BarChart3 className="w-4 h-4 mr-2" />
            Analytics Charts
          </TabsTrigger>
          <TabsTrigger value="schema">
            <Database className="w-4 h-4 mr-2" />
            Database Schema
          </TabsTrigger>
        </TabsList>

        {/* Tab 1: Event Stream */}
        <TabsContent value="events" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Activity className="w-5 h-5" />
                Live System Events
              </CardTitle>
              <CardDescription>
                Real-time monitoring of LATENCY, ERROR, THROTTLE, and FAILOVER events
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-3">
                {SYSTEM_EVENTS.map((event, idx) => (
                  <motion.div
                    key={event.system_event_id}
                    initial={{ opacity: 0, x: -20 }}
                    animate={{ opacity: 1, x: 0 }}
                    transition={{ delay: idx * 0.05 }}
                    className={`p-4 rounded-lg border-2 cursor-pointer transition-all ${
                      selectedEvent === event.system_event_id
                        ? 'border-blue-500 bg-blue-50'
                        : 'border-gray-200 bg-white hover:border-gray-300'
                    }`}
                    onClick={() => setSelectedEvent(event.system_event_id)}
                  >
                    <div className="flex items-start justify-between">
                      <div className="flex-1">
                        <div className="flex items-center gap-3 mb-2">
                          {event.event_type === 'LATENCY' && <Clock className="w-5 h-5 text-blue-600" />}
                          {event.event_type === 'ERROR' && <AlertCircle className="w-5 h-5 text-red-600" />}
                          {event.event_type === 'THROTTLE' && <AlertTriangle className="w-5 h-5 text-orange-600" />}
                          {event.event_type === 'FAILOVER' && <Shield className="w-5 h-5 text-purple-600" />}
                          <span className="font-bold text-lg text-gray-900">{event.service_name}</span>
                          <Badge
                            className={
                              event.event_type === 'LATENCY' ? 'bg-blue-500' :
                              event.event_type === 'ERROR' ? 'bg-red-500' :
                              event.event_type === 'THROTTLE' ? 'bg-orange-500' :
                              'bg-purple-500'
                            }
                          >
                            {event.event_type}
                          </Badge>
                        </div>
                        <div className="grid grid-cols-3 gap-x-8 gap-y-2 text-sm mt-3">
                          <div>
                            <span className="text-gray-500">Event ID:</span>
                            <span className="ml-2 font-mono font-semibold text-gray-900">{event.system_event_id}</span>
                          </div>
                          <div>
                            <span className="text-gray-500">Region:</span>
                            <span className="ml-2 font-semibold text-gray-900">{event.region}</span>
                          </div>
                          <div>
                            <span className="text-gray-500">Timestamp:</span>
                            <span className="ml-2 font-mono text-gray-900">
                              {new Date(event.created_at).toLocaleString()}
                            </span>
                          </div>
                          {event.metrics.latency_ms && (
                            <div>
                              <span className="text-gray-500">Latency:</span>
                              <span className="ml-2 font-bold text-blue-700">{event.metrics.latency_ms}ms</span>
                            </div>
                          )}
                          {event.metrics.success_rate && (
                            <div>
                              <span className="text-gray-500">Success Rate:</span>
                              <span className="ml-2 font-bold text-green-700">{event.metrics.success_rate}%</span>
                            </div>
                          )}
                          {event.metrics.request_count && (
                            <div>
                              <span className="text-gray-500">Requests:</span>
                              <span className="ml-2 font-bold text-gray-900">{event.metrics.request_count}</span>
                            </div>
                          )}
                          {event.metrics.error_code && (
                            <div>
                              <span className="text-gray-500">Error Code:</span>
                              <span className="ml-2 font-mono text-red-700">{event.metrics.error_code}</span>
                            </div>
                          )}
                          {event.metrics.error_message && (
                            <div className="col-span-3">
                              <span className="text-gray-500">Message:</span>
                              <span className="ml-2 text-red-700">{event.metrics.error_message}</span>
                            </div>
                          )}
                          {event.metrics.throttle_reason && (
                            <div className="col-span-3">
                              <span className="text-gray-500">Throttle Reason:</span>
                              <span className="ml-2 text-orange-700">{event.metrics.throttle_reason}</span>
                            </div>
                          )}
                          {event.metrics.failover_target && (
                            <div>
                              <span className="text-gray-500">Failover Target:</span>
                              <span className="ml-2 font-mono text-purple-700">{event.metrics.failover_target}</span>
                            </div>
                          )}
                        </div>
                      </div>
                    </div>
                  </motion.div>
                ))}
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        {/* Tab 2: Analytics Charts */}
        <TabsContent value="charts" className="space-y-4">
          {/* Event Type Distribution */}
          <div className="grid grid-cols-2 gap-6">
            <Card>
              <CardHeader>
                <CardTitle className="text-lg">Event Type Distribution</CardTitle>
                <CardDescription>Breakdown by event category</CardDescription>
              </CardHeader>
              <CardContent>
                <ResponsiveContainer width="100%" height={300}>
                  <PieChart>
                    <Pie
                      data={eventTypeData}
                      cx="50%"
                      cy="50%"
                      labelLine={false}
                      label={({ name, value }) => `${name}: ${value}`}
                      outerRadius={100}
                      fill="#8884d8"
                      dataKey="value"
                    >
                      {eventTypeData.map((entry, index) => (
                        <Cell key={`cell-${index}`} fill={entry.color} />
                      ))}
                    </Pie>
                    <Tooltip />
                  </PieChart>
                </ResponsiveContainer>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle className="text-lg">Regional Distribution</CardTitle>
                <CardDescription>Events by AWS region</CardDescription>
              </CardHeader>
              <CardContent>
                <ResponsiveContainer width="100%" height={300}>
                  <BarChart data={regionalData}>
                    <CartesianGrid strokeDasharray="3 3" />
                    <XAxis dataKey="name" />
                    <YAxis />
                    <Tooltip />
                    <Legend />
                    <Bar dataKey="events" fill="#8b5cf6" />
                  </BarChart>
                </ResponsiveContainer>
              </CardContent>
            </Card>
          </div>

          {/* Service Performance */}
          <Card>
            <CardHeader>
              <CardTitle className="text-lg">Service Performance Metrics</CardTitle>
              <CardDescription>Latency and request volume by service</CardDescription>
            </CardHeader>
            <CardContent>
              <ResponsiveContainer width="100%" height={300}>
                <BarChart data={servicePerformanceData}>
                  <CartesianGrid strokeDasharray="3 3" />
                  <XAxis dataKey="service" />
                  <YAxis yAxisId="left" />
                  <YAxis yAxisId="right" orientation="right" />
                  <Tooltip />
                  <Legend />
                  <Bar yAxisId="left" dataKey="latency" fill="#3b82f6" name="Latency (ms)" />
                  <Bar yAxisId="right" dataKey="requests" fill="#10b981" name="Requests" />
                </BarChart>
              </ResponsiveContainer>
            </CardContent>
          </Card>

          {/* Timeline Chart */}
          <Card>
            <CardHeader>
              <CardTitle className="text-lg">Performance Timeline</CardTitle>
              <CardDescription>Latency and success rate over time</CardDescription>
            </CardHeader>
            <CardContent>
              <ResponsiveContainer width="100%" height={300}>
                <AreaChart data={timelineData}>
                  <CartesianGrid strokeDasharray="3 3" />
                  <XAxis dataKey="time" />
                  <YAxis yAxisId="left" />
                  <YAxis yAxisId="right" orientation="right" />
                  <Tooltip />
                  <Legend />
                  <Area yAxisId="left" type="monotone" dataKey="latency" stroke="#3b82f6" fill="#93c5fd" name="Latency (ms)" />
                  <Area yAxisId="right" type="monotone" dataKey="success_rate" stroke="#10b981" fill="#86efac" name="Success Rate (%)" />
                </AreaChart>
              </ResponsiveContainer>
            </CardContent>
          </Card>
        </TabsContent>

        {/* Tab 3: Database Schema */}
        <TabsContent value="schema" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Database className="w-5 h-5" />
                PostgreSQL Schema Definition
              </CardTitle>
              <CardDescription>
                System events table structure with JSONB metrics storage
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-6">
              {/* SQL Schema */}
              <div>
                <h3 className="font-semibold text-gray-900 mb-3 flex items-center gap-2">
                  <Info className="w-5 h-5" />
                  CREATE TABLE Statement
                </h3>
                <div className="bg-gray-900 text-green-400 p-4 rounded-lg font-mono text-sm overflow-x-auto">
                  <pre>{`CREATE TABLE system_events (
    system_event_id     UUID PRIMARY KEY,
    service_name        VARCHAR,
    event_type          VARCHAR, -- LATENCY / ERROR / THROTTLE / FAILOVER
    metrics             JSONB,
    region              VARCHAR,
    created_at          TIMESTAMP DEFAULT NOW()
);`}</pre>
                </div>
              </div>

              <Separator />

              {/* Column Details */}
              <div>
                <h3 className="font-semibold text-gray-900 mb-3">Column Specifications</h3>
                <div className="space-y-2">
                  {[
                    { name: 'system_event_id', type: 'UUID', description: 'Unique identifier for each system event', constraint: 'PRIMARY KEY' },
                    { name: 'service_name', type: 'VARCHAR', description: 'Name of the service generating the event', constraint: null },
                    { name: 'event_type', type: 'VARCHAR', description: 'Event category: LATENCY, ERROR, THROTTLE, FAILOVER', constraint: 'ENUM-like' },
                    { name: 'metrics', type: 'JSONB', description: 'Flexible JSON storage for event-specific metrics', constraint: 'Indexed' },
                    { name: 'region', type: 'VARCHAR', description: 'AWS region where event occurred (e.g., us-east-1)', constraint: null },
                    { name: 'created_at', type: 'TIMESTAMP', description: 'Timestamp when event was created', constraint: 'DEFAULT NOW()' }
                  ].map((col, idx) => (
                    <motion.div
                      key={col.name}
                      initial={{ opacity: 0, x: -20 }}
                      animate={{ opacity: 1, x: 0 }}
                      transition={{ delay: idx * 0.05 }}
                      className="p-4 bg-gray-50 rounded-lg"
                    >
                      <div className="flex items-center justify-between mb-2">
                        <div className="flex items-center gap-3">
                          <div className="font-mono font-bold text-gray-900">{col.name}</div>
                          <Badge variant="outline">{col.type}</Badge>
                          {col.constraint && <Badge className="bg-blue-500">{col.constraint}</Badge>}
                        </div>
                      </div>
                      <div className="text-sm text-gray-600">{col.description}</div>
                    </motion.div>
                  ))}
                </div>
              </div>

              <Separator />

              {/* Metrics JSONB Structure */}
              <div>
                <h3 className="font-semibold text-gray-900 mb-3">JSONB Metrics Schema</h3>
                <div className="bg-gray-50 p-4 rounded-lg">
                  <div className="space-y-3 font-mono text-sm">
                    <div className="text-gray-700">
                      <span className="text-blue-600">&#123;</span>
                    </div>
                    <div className="ml-4 text-gray-700">
                      <span className="text-purple-600">"latency_ms"</span>: <span className="text-green-600">number</span>,
                      <span className="text-gray-500 ml-2">// For LATENCY events</span>
                    </div>
                    <div className="ml-4 text-gray-700">
                      <span className="text-purple-600">"error_code"</span>: <span className="text-green-600">string</span>,
                      <span className="text-gray-500 ml-2">// For ERROR events</span>
                    </div>
                    <div className="ml-4 text-gray-700">
                      <span className="text-purple-600">"error_message"</span>: <span className="text-green-600">string</span>,
                    </div>
                    <div className="ml-4 text-gray-700">
                      <span className="text-purple-600">"throttle_reason"</span>: <span className="text-green-600">string</span>,
                      <span className="text-gray-500 ml-2">// For THROTTLE events</span>
                    </div>
                    <div className="ml-4 text-gray-700">
                      <span className="text-purple-600">"failover_target"</span>: <span className="text-green-600">string</span>,
                      <span className="text-gray-500 ml-2">// For FAILOVER events</span>
                    </div>
                    <div className="ml-4 text-gray-700">
                      <span className="text-purple-600">"success_rate"</span>: <span className="text-green-600">number</span>,
                    </div>
                    <div className="ml-4 text-gray-700">
                      <span className="text-purple-600">"request_count"</span>: <span className="text-green-600">number</span>
                    </div>
                    <div className="text-gray-700">
                      <span className="text-blue-600">&#125;</span>
                    </div>
                  </div>
                </div>
              </div>

              <Separator />

              {/* Indexes & Performance */}
              <div>
                <h3 className="font-semibold text-gray-900 mb-3">Recommended Indexes</h3>
                <div className="bg-gray-900 text-green-400 p-4 rounded-lg font-mono text-sm space-y-2">
                  <div>CREATE INDEX idx_event_type ON system_events(event_type);</div>
                  <div>CREATE INDEX idx_service_name ON system_events(service_name);</div>
                  <div>CREATE INDEX idx_region ON system_events(region);</div>
                  <div>CREATE INDEX idx_created_at ON system_events(created_at DESC);</div>
                  <div>CREATE INDEX idx_metrics_gin ON system_events USING GIN(metrics);</div>
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
}
