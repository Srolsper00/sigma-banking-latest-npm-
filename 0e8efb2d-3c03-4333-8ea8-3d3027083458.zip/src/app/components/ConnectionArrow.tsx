import React from 'react';

interface ConnectionArrowProps {
  from: string;
  to: string;
}

export function ConnectionArrow({ from, to }: ConnectionArrowProps) {
  // This component renders SVG arrows between architecture nodes
  // For now, it returns null since the arrows are positioned based on node IDs
  // In a production implementation, this would calculate positions and draw SVG paths
  return null;
}
