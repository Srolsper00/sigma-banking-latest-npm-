import { motion } from 'motion/react';
import { useState, useEffect } from 'react';
import {
  ArrowDownLeft,
  ArrowUpRight,
  Shield,
  Database,
  Lock,
  CheckCircle,
  AlertTriangle,
  Clock,
  DollarSign,
  FileText,
  Zap,
  Activity,
  TrendingUp,
  TrendingDown,
  Building2,
  Key,
  Layers
} from 'lucide-react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from './ui/card';
import { Button } from './ui/button';
import { Badge } from './ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from './ui/tabs';
import { Separator } from './ui/separator';
import { Input } from './ui/input';
import { Label } from './ui/label';
import { toast } from 'sonner@2.0.3';

// ============================================================================
// BANK TRANSMITTAL VAULT - LOCALIZED STORAGE & ACH/WIRE VALIDATION
// ============================================================================

// Transfer Type Enumeration
export enum TransferType {
  ACH_CREDIT = 'ACH_CREDIT',
  ACH_DEBIT = 'ACH_DEBIT',
  WIRE_DOMESTIC = 'WIRE_DOMESTIC',
  WIRE_INTERNATIONAL = 'WIRE_INTERNATIONAL',
  INTRADAY_TRANSFER = 'INTRADAY_TRANSFER',
  SAME_DAY_ACH = 'SAME_DAY_ACH'
}

// Transfer Status Enumeration
export enum TransferStatus {
  PENDING_VALIDATION = 'PENDING_VALIDATION',
  VALIDATING = 'VALIDATING',
  VALIDATED = 'VALIDATED',
  RECONCILING = 'RECONCILING',
  RECONCILED = 'RECONCILED',
  SETTLED = 'SETTLED',
  REJECTED = 'REJECTED',
  FAILED = 'FAILED'
}

// Transfer Direction Enumeration
export enum TransferDirection {
  INCOMING = 'INCOMING',
  OUTGOING = 'OUTGOING'
}

// Reconciliation Status Enumeration
export enum ReconciliationStatus {
  NOT_STARTED = 'NOT_STARTED',
  IN_PROGRESS = 'IN_PROGRESS',
  MATCHED = 'MATCHED',
  DISCREPANCY = 'DISCREPANCY',
  RESOLVED = 'RESOLVED'
}

// Vault Segment Enumeration
export enum VaultSegment {
  SEGMENT_A = 'SEGMENT_A', // Incoming ACH
  SEGMENT_B = 'SEGMENT_B', // Outgoing ACH
  SEGMENT_C = 'SEGMENT_C', // Incoming Wire
  SEGMENT_D = 'SEGMENT_D', // Outgoing Wire
  SEGMENT_E = 'SEGMENT_E', // Intraday Entries
  SEGMENT_F = 'SEGMENT_F'  // Reconciliation Queue
}

// Maximum Transfer Limit
const MAX_TRANSFER_AMOUNT = 100000.00;

// Bank Transfer Record Interface
interface BankTransferRecord {
  id: string;
  direction: TransferDirection;
  type: TransferType;
  status: TransferStatus;
  reconciliationStatus: ReconciliationStatus;
  vaultSegment: VaultSegment;
  originatingBank: {
    name: string;
    routingNumber: string;
    accountToken: string;
  };
  receivingBank: {
    name: string;
    routingNumber: string;
    accountToken: string;
  };
  amount: number;
  currency: string;
  initiatedAt: number;
  validatedAt?: number;
  settledAt?: number;
  reconciliationKey: string;
  transmittalHash: string;
  secCode: string;
  intradaySequence?: number;
}

// Localized Storage Vault Interface
interface LocalizedStorageVault {
  vaultId: string;
  segment: VaultSegment;
  encryptionKey: string;
  records: BankTransferRecord[];
  lastSync: number;
  checksum: string;
}

// Generate Random Vault ID
const generateVaultId = (): string => {
  return `VAULT-${Date.now()}-${Math.random().toString(36).substr(2, 9).toUpperCase()}`;
};

// Generate Reconciliation Key
const generateReconciliationKey = (record: Partial<BankTransferRecord>): string => {
  const data = `${record.originatingBank?.routingNumber}-${record.receivingBank?.routingNumber}-${record.amount}-${record.initiatedAt}`;
  let hash = 0;
  for (let i = 0; i < data.length; i++) {
    const char = data.charCodeAt(i);
    hash = ((hash << 5) - hash) + char;
    hash = hash & hash;
  }
  return Math.abs(hash).toString(16).padStart(16, '0').toUpperCase();
};

// Generate Transmittal Hash
const generateTransmittalHash = (): string => {
  return Array.from({ length: 64 }, () => 
    Math.floor(Math.random() * 16).toString(16)
  ).join('');
};

// Initialize Storage Vaults
const initializeVaults = (): LocalizedStorageVault[] => {
  return Object.values(VaultSegment).map(segment => ({
    vaultId: generateVaultId(),
    segment,
    encryptionKey: generateTransmittalHash().substring(0, 32),
    records: [],
    lastSync: Date.now(),
    checksum: generateTransmittalHash()
  }));
};

// Real-Time ACH Transfer Records
const LIVE_TRANSFERS: BankTransferRecord[] = [
  {
    id: 'TXN-IN-001',
    direction: TransferDirection.INCOMING,
    type: TransferType.ACH_CREDIT,
    status: TransferStatus.VALIDATED,
    reconciliationStatus: ReconciliationStatus.MATCHED,
    vaultSegment: VaultSegment.SEGMENT_A,
    originatingBank: {
      name: 'Capital One Bank NA',
      routingNumber: '031176110',
      accountToken: 'Tok-36396480434'
    },
    receivingBank: {
      name: 'Sutton Bank NA',
      routingNumber: '041215663',
      accountToken: 'Tok-6391'
    },
    amount: 75000.00,
    currency: 'USD',
    initiatedAt: Date.now() - 3600000,
    validatedAt: Date.now() - 3000000,
    reconciliationKey: generateReconciliationKey({
      originatingBank: { routingNumber: '031176110' },
      receivingBank: { routingNumber: '041215663' },
      amount: 75000.00,
      initiatedAt: Date.now() - 3600000
    } as any),
    transmittalHash: generateTransmittalHash(),
    secCode: 'CCD',
    intradaySequence: 1
  },
  {
    id: 'TXN-OUT-001',
    direction: TransferDirection.OUTGOING,
    type: TransferType.ACH_DEBIT,
    status: TransferStatus.RECONCILING,
    reconciliationStatus: ReconciliationStatus.IN_PROGRESS,
    vaultSegment: VaultSegment.SEGMENT_B,
    originatingBank: {
      name: 'Sutton Bank NA',
      routingNumber: '041215663',
      accountToken: 'Tok-6390'
    },
    receivingBank: {
      name: 'Wells Fargo Bank NA',
      routingNumber: '121000248',
      accountToken: 'Tok-98765432'
    },
    amount: 42500.00,
    currency: 'USD',
    initiatedAt: Date.now() - 7200000,
    validatedAt: Date.now() - 6000000,
    reconciliationKey: generateReconciliationKey({
      originatingBank: { routingNumber: '041215663' },
      receivingBank: { routingNumber: '121000248' },
      amount: 42500.00,
      initiatedAt: Date.now() - 7200000
    } as any),
    transmittalHash: generateTransmittalHash(),
    secCode: 'PPD',
    intradaySequence: 2
  },
  {
    id: 'TXN-IN-002',
    direction: TransferDirection.INCOMING,
    type: TransferType.WIRE_DOMESTIC,
    status: TransferStatus.SETTLED,
    reconciliationStatus: ReconciliationStatus.RESOLVED,
    vaultSegment: VaultSegment.SEGMENT_C,
    originatingBank: {
      name: 'Chase Bank NA',
      routingNumber: '021000021',
      accountToken: 'Tok-11223344'
    },
    receivingBank: {
      name: 'Sutton Bank NA',
      routingNumber: '041215663',
      accountToken: 'Tok-6390'
    },
    amount: 99999.99,
    currency: 'USD',
    initiatedAt: Date.now() - 10800000,
    validatedAt: Date.now() - 9000000,
    settledAt: Date.now() - 3600000,
    reconciliationKey: generateReconciliationKey({
      originatingBank: { routingNumber: '021000021' },
      receivingBank: { routingNumber: '041215663' },
      amount: 99999.99,
      initiatedAt: Date.now() - 10800000
    } as any),
    transmittalHash: generateTransmittalHash(),
    secCode: 'CTX',
    intradaySequence: 3
  },
  {
    id: 'TXN-OUT-002',
    direction: TransferDirection.OUTGOING,
    type: TransferType.SAME_DAY_ACH,
    status: TransferStatus.VALIDATING,
    reconciliationStatus: ReconciliationStatus.NOT_STARTED,
    vaultSegment: VaultSegment.SEGMENT_B,
    originatingBank: {
      name: 'Sutton Bank NA',
      routingNumber: '041215663',
      accountToken: 'Tok-6390'
    },
    receivingBank: {
      name: 'Bank of America NA',
      routingNumber: '026009593',
      accountToken: 'Tok-55667788'
    },
    amount: 28750.50,
    currency: 'USD',
    initiatedAt: Date.now() - 1800000,
    reconciliationKey: generateReconciliationKey({
      originatingBank: { routingNumber: '041215663' },
      receivingBank: { routingNumber: '026009593' },
      amount: 28750.50,
      initiatedAt: Date.now() - 1800000
    } as any),
    transmittalHash: generateTransmittalHash(),
    secCode: 'CCD',
    intradaySequence: 4
  }
];

export function BankTransmittalVault() {
  const [activeTab, setActiveTab] = useState<'incoming' | 'outgoing' | 'intraday' | 'reconciliation' | 'vault'>('incoming');
  const [transfers, setTransfers] = useState<BankTransferRecord[]>(SAMPLE_TRANSFERS);
  const [vaults, setVaults] = useState<LocalizedStorageVault[]>(initializeVaults());
  const [selectedTransfer, setSelectedTransfer] = useState<string | null>(null);

  // Filter transfers by direction
  const incomingTransfers = transfers.filter(t => t.direction === TransferDirection.INCOMING);
  const outgoingTransfers = transfers.filter(t => t.direction === TransferDirection.OUTGOING);
  const intradayTransfers = transfers.filter(t => t.type === TransferType.INTRADAY_TRANSFER);
  const reconciliationQueue = transfers.filter(t => 
    t.reconciliationStatus === ReconciliationStatus.IN_PROGRESS || 
    t.reconciliationStatus === ReconciliationStatus.DISCREPANCY
  );

  // Calculate totals
  const incomingTotal = incomingTransfers.reduce((sum, t) => sum + t.amount, 0);
  const outgoingTotal = outgoingTransfers.reduce((sum, t) => sum + t.amount, 0);
  const netPosition = incomingTotal - outgoingTotal;

  // Format currency
  const formatCurrency = (amount: number): string => {
    return new Intl.NumberFormat('en-US', {
      style: 'currency',
      currency: 'USD',
      minimumFractionDigits: 2,
      maximumFractionDigits: 2
    }).format(amount);
  };

  // Format timestamp
  const formatTimestamp = (ts: number): string => {
    return new Date(ts).toLocaleString('en-US', {
      month: 'short',
      day: '2-digit',
      year: 'numeric',
      hour: '2-digit',
      minute: '2-digit',
      second: '2-digit'
    });
  };

  // Get status badge color
  const getStatusColor = (status: TransferStatus): string => {
    switch (status) {
      case TransferStatus.SETTLED: return 'bg-green-500';
      case TransferStatus.VALIDATED: return 'bg-blue-500';
      case TransferStatus.RECONCILED: return 'bg-purple-500';
      case TransferStatus.VALIDATING:
      case TransferStatus.RECONCILING: return 'bg-yellow-500';
      case TransferStatus.PENDING_VALIDATION: return 'bg-orange-500';
      case TransferStatus.REJECTED:
      case TransferStatus.FAILED: return 'bg-red-500';
      default: return 'bg-gray-500';
    }
  };

  // Get reconciliation status color
  const getReconciliationColor = (status: ReconciliationStatus): string => {
    switch (status) {
      case ReconciliationStatus.RESOLVED:
      case ReconciliationStatus.MATCHED: return 'bg-green-500';
      case ReconciliationStatus.IN_PROGRESS: return 'bg-yellow-500';
      case ReconciliationStatus.DISCREPANCY: return 'bg-red-500';
      default: return 'bg-gray-500';
    }
  };

  // Validate transfer amount
  const validateTransferAmount = (amount: number): boolean => {
    if (amount <= 0) {
      toast.error('Transfer amount must be greater than $0.00');
      return false;
    }
    if (amount > MAX_TRANSFER_AMOUNT) {
      toast.error(`Transfer amount cannot exceed ${formatCurrency(MAX_TRANSFER_AMOUNT)}`);
      return false;
    }
    return true;
  };

  // Initiate new transfer
  const initiateTransfer = (direction: TransferDirection, amount: number, type: TransferType) => {
    if (!validateTransferAmount(amount)) return;

    const newTransfer: BankTransferRecord = {
      id: `TXN-${direction.substring(0, 3)}-${Date.now()}`,
      direction,
      type,
      status: TransferStatus.PENDING_VALIDATION,
      reconciliationStatus: ReconciliationStatus.NOT_STARTED,
      vaultSegment: direction === TransferDirection.INCOMING ? VaultSegment.SEGMENT_A : VaultSegment.SEGMENT_B,
      originatingBank: direction === TransferDirection.OUTGOING ? {
        name: 'Sutton Bank NA',
        routingNumber: '041215663',
        accountToken: 'Tok-6390'
      } : {
        name: 'External Bank Processing Bank GL-',
        routingNumber: '041215663',
        accountToken: 'Tok-3691'
      },
      receivingBank: direction === TransferDirection.INCOMING ? {
        name: 'Sutton Bank NA',
        routingNumber: '041215663',
        accountToken: 'Tok-6390'
      } : {
        name: 'External Bank',
        routingNumber: '000000000',
        accountToken: 'Tok-NEW'
      },
      amount,
      currency: 'USD',
      initiatedAt: Date.now(),
      reconciliationKey: generateReconciliationKey({
        originatingBank: { routingNumber: direction === TransferDirection.OUTGOING ? '041215663' : '000000000' },
        receivingBank: { routingNumber: direction === TransferDirection.INCOMING ? '041215663' : '000000000' },
        amount,
        initiatedAt: Date.now()
      } as any),
      transmittalHash: generateTransmittalHash(),
      secCode: type === TransferType.ACH_CREDIT || type === TransferType.ACH_DEBIT ? 'CCD' : 'CTX',
      intradaySequence: transfers.length + 1
    };

    setTransfers([...transfers, newTransfer]);
    toast.success(`${direction} transfer initiated`, {
      description: `${formatCurrency(amount)} - ${type}`
    });
  };

  // Render transfer card
  const renderTransferCard = (transfer: BankTransferRecord, index: number) => (
    <motion.div
      key={transfer.id}
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ delay: index * 0.05 }}
      className={`p-4 rounded-lg border-2 cursor-pointer transition-all ${
        selectedTransfer === transfer.id
          ? 'border-blue-500 bg-blue-50'
          : 'border-gray-200 bg-white hover:border-gray-300'
      }`}
      onClick={() => setSelectedTransfer(transfer.id)}
    >
      <div className="flex items-start justify-between">
        <div className="flex-1">
          <div className="flex items-center gap-3 mb-2">
            {transfer.direction === TransferDirection.INCOMING ? (
              <ArrowDownLeft className="w-5 h-5 text-green-600" />
            ) : (
              <ArrowUpRight className="w-5 h-5 text-red-600" />
            )}
            <span className="font-bold text-lg text-gray-900">{transfer.id}</span>
            <Badge className={getStatusColor(transfer.status)}>
              {transfer.status.replace(/_/g, ' ')}
            </Badge>
            <Badge className={getReconciliationColor(transfer.reconciliationStatus)}>
              {transfer.reconciliationStatus.replace(/_/g, ' ')}
            </Badge>
          </div>
          
          <div className="grid grid-cols-3 gap-x-8 gap-y-2 text-sm mt-3">
            <div>
              <span className="text-gray-500">Type:</span>
              <span className="ml-2 font-semibold text-gray-900">{transfer.type}</span>
            </div>
            <div>
              <span className="text-gray-500">Amount:</span>
              <span className={`ml-2 font-bold ${
                transfer.direction === TransferDirection.INCOMING ? 'text-green-700' : 'text-red-700'
              }`}>
                {transfer.direction === TransferDirection.INCOMING ? '+' : '-'}
                {formatCurrency(transfer.amount)}
              </span>
            </div>
            <div>
              <span className="text-gray-500">Vault Segment:</span>
              <span className="ml-2 font-mono text-gray-900">{transfer.vaultSegment}</span>
            </div>
            <div>
              <span className="text-gray-500">Originating Bank:</span>
              <span className="ml-2 font-mono text-gray-900">{transfer.originatingBank.routingNumber}</span>
            </div>
            <div>
              <span className="text-gray-500">Receiving Bank:</span>
              <span className="ml-2 font-mono text-gray-900">{transfer.receivingBank.routingNumber}</span>
            </div>
            <div>
              <span className="text-gray-500">SEC Code:</span>
              <span className="ml-2 font-semibold text-gray-900">{transfer.secCode}</span>
            </div>
            <div>
              <span className="text-gray-500">Initiated:</span>
              <span className="ml-2 font-mono text-xs text-gray-900">{formatTimestamp(transfer.initiatedAt)}</span>
            </div>
            <div>
              <span className="text-gray-500">Reconciliation Key:</span>
              <span className="ml-2 font-mono text-xs text-blue-700">{transfer.reconciliationKey}</span>
            </div>
            <div>
              <span className="text-gray-500">Intraday Seq:</span>
              <span className="ml-2 font-semibold text-gray-900">#{transfer.intradaySequence}</span>
            </div>
          </div>
        </div>
      </div>
    </motion.div>
  );

  return (
    <div className="space-y-6">
      {/* Header */}
      <motion.div
        initial={{ opacity: 0, y: -20 }}
        animate={{ opacity: 1, y: 0 }}
        className="bg-gradient-to-r from-indigo-600 via-purple-600 to-pink-600 rounded-2xl p-8 text-white"
      >
        <div className="flex items-start justify-between">
          <div>
            <div className="flex items-center gap-3 mb-2">
              <Database className="w-10 h-10" />
              <h1 className="text-3xl font-bold">Bank Transmittal Vault</h1>
            </div>
            <h2 className="text-xl font-semibold mb-2">Localized Storage & Transfer Reconciliation</h2>
            <p className="text-purple-100 mb-4">
              Segmented ACH/Wire Validation • Bank-to-Bank Transfer Processing • Intraday Entry Management
            </p>
            <div className="flex items-center gap-6 text-sm">
              <div className="flex items-center gap-2">
                <Shield className="w-4 h-4" />
                <span>Max Transfer: {formatCurrency(MAX_TRANSFER_AMOUNT)}</span>
              </div>
              <div className="flex items-center gap-2">
                <Lock className="w-4 h-4" />
                <span>Encrypted Vault Storage</span>
              </div>
              <div className="flex items-center gap-2">
                <Layers className="w-4 h-4" />
                <span>6 Vault Segments Active</span>
              </div>
            </div>
          </div>
          <div className="text-right">
            <Badge className="bg-green-500 text-white text-lg px-4 py-2">
              <Activity className="w-4 h-4 mr-2 inline" />
              LIVE
            </Badge>
          </div>
        </div>
      </motion.div>

      {/* Summary Cards */}
      <div className="grid grid-cols-4 gap-6">
        <motion.div
          initial={{ opacity: 0, scale: 0.95 }}
          animate={{ opacity: 1, scale: 1 }}
          transition={{ delay: 0.1 }}
        >
          <Card className="border-2 border-green-200 bg-green-50/50">
            <CardHeader className="pb-3">
              <CardTitle className="text-sm font-medium text-green-700 flex items-center gap-2">
                <ArrowDownLeft className="w-4 h-4" />
                Incoming Funds
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold text-green-900">{formatCurrency(incomingTotal)}</div>
              <p className="text-xs text-green-600 mt-1">{incomingTransfers.length} transfers</p>
            </CardContent>
          </Card>
        </motion.div>

        <motion.div
          initial={{ opacity: 0, scale: 0.95 }}
          animate={{ opacity: 1, scale: 1 }}
          transition={{ delay: 0.2 }}
        >
          <Card className="border-2 border-red-200 bg-red-50/50">
            <CardHeader className="pb-3">
              <CardTitle className="text-sm font-medium text-red-700 flex items-center gap-2">
                <ArrowUpRight className="w-4 h-4" />
                Outgoing Funds
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold text-red-900">{formatCurrency(outgoingTotal)}</div>
              <p className="text-xs text-red-600 mt-1">{outgoingTransfers.length} transfers</p>
            </CardContent>
          </Card>
        </motion.div>

        <motion.div
          initial={{ opacity: 0, scale: 0.95 }}
          animate={{ opacity: 1, scale: 1 }}
          transition={{ delay: 0.3 }}
        >
          <Card className={`border-2 ${netPosition >= 0 ? 'border-blue-200 bg-blue-50/50' : 'border-orange-200 bg-orange-50/50'}`}>
            <CardHeader className="pb-3">
              <CardTitle className={`text-sm font-medium ${netPosition >= 0 ? 'text-blue-700' : 'text-orange-700'} flex items-center gap-2`}>
                {netPosition >= 0 ? <TrendingUp className="w-4 h-4" /> : <TrendingDown className="w-4 h-4" />}
                Net Position
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className={`text-2xl font-bold ${netPosition >= 0 ? 'text-blue-900' : 'text-orange-900'}`}>
                {formatCurrency(Math.abs(netPosition))}
              </div>
              <p className={`text-xs mt-1 ${netPosition >= 0 ? 'text-blue-600' : 'text-orange-600'}`}>
                {netPosition >= 0 ? 'Positive' : 'Negative'}
              </p>
            </CardContent>
          </Card>
        </motion.div>

        <motion.div
          initial={{ opacity: 0, scale: 0.95 }}
          animate={{ opacity: 1, scale: 1 }}
          transition={{ delay: 0.4 }}
        >
          <Card className="border-2 border-purple-200 bg-purple-50/50">
            <CardHeader className="pb-3">
              <CardTitle className="text-sm font-medium text-purple-700 flex items-center gap-2">
                <Clock className="w-4 h-4" />
                Reconciliation Queue
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold text-purple-900">{reconciliationQueue.length}</div>
              <p className="text-xs text-purple-600 mt-1">pending entries</p>
            </CardContent>
          </Card>
        </motion.div>
      </div>

      {/* Main Tabs */}
      <Tabs value={activeTab} onValueChange={(v) => setActiveTab(v as any)}>
        <TabsList className="grid w-full grid-cols-5">
          <TabsTrigger value="incoming">
            <ArrowDownLeft className="w-4 h-4 mr-2" />
            Incoming
          </TabsTrigger>
          <TabsTrigger value="outgoing">
            <ArrowUpRight className="w-4 h-4 mr-2" />
            Outgoing
          </TabsTrigger>
          <TabsTrigger value="intraday">
            <Clock className="w-4 h-4 mr-2" />
            Intraday
          </TabsTrigger>
          <TabsTrigger value="reconciliation">
            <CheckCircle className="w-4 h-4 mr-2" />
            Reconciliation
          </TabsTrigger>
          <TabsTrigger value="vault">
            <Database className="w-4 h-4 mr-2" />
            Vault Status
          </TabsTrigger>
        </TabsList>

        {/* Incoming Transfers Tab */}
        <TabsContent value="incoming" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <ArrowDownLeft className="w-5 h-5 text-green-600" />
                Incoming Bank Transfers
              </CardTitle>
              <CardDescription>
                ACH/Wire transfers received at Sutton Bank NA (Max: {formatCurrency(MAX_TRANSFER_AMOUNT)})
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-3">
                {incomingTransfers.map((transfer, idx) => renderTransferCard(transfer, idx))}
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        {/* Outgoing Transfers Tab */General Leder}
        <TabsContent value="outgoing" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <ArrowUpRight className="w-5 h-5 text-red-600" />
                Outgoing Bank Transfers
              </CardTitle>
              <CardDescription>
                ACH/Wire transfers sent from Sutton Bank NA (Max: {formatCurrency(MAX_TRANSFER_AMOUNT)})
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-3">
                {outgoingTransfers.map((transfer, idx) => renderTransferCard(transfer, idx))}
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        {/* Intraday Entries Tab */}
        <TabsContent value="intraday" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Clock className="w-5 h-5" />
                Intraday Database Entries
              </CardTitle>
              <CardDescription>
                Real-time transfer processing and intraday sequence tracking
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-3">
                {transfers
                  .sort((a, b) => (a.intradaySequence || 0) - (b.intradaySequence || 0))
                  .map((transfer, idx) => renderTransferCard(transfer, idx))}
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        {/* Reconciliation Tab */}
        <TabsContent value="reconciliation" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <CheckCircle className="w-5 h-5" />
                Reconciliation Queue
              </CardTitle>
              <CardDescription>
                Bank-to-bank transfer validation and account reconciliation requests
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-3">
                {transfers.map((transfer, idx) => (
                  <div key={transfer.id} className="p-4 bg-gray-50 rounded-lg">
                    <div className="flex items-center justify-between mb-2">
                      <span className="font-mono font-semibold text-gray-900">{transfer.id}</span>
                      <Badge className={getReconciliationColor(transfer.reconciliationStatus)}>
                        {transfer.reconciliationStatus.replace(/_/g, ' ')}
                      </Badge>
                    </div>
                    <div className="grid grid-cols-2 gap-4 text-sm">
                      <div>
                        <span className="text-gray-500">Reconciliation Key:</span>
                        <span className="ml-2 font-mono text-blue-700">{transfer.reconciliationKey}</span>
                      </div>
                      <div>
                        <span className="text-gray-500">Transmittal Hash:</span>
                        <span className="ml-2 font-mono text-xs text-gray-600">{transfer.transmittalHash.substring(0, 16)}...</span>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        {/* Vault Status Tab */}
        <TabsContent value="vault" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Database className="w-5 h-5" />
                Localized Storage Vault Status
              </CardTitle>
              <CardDescription>
                Segmented encrypted storage for ACH/Wire transfer validation
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-3">
                {vaults.map((vault, idx) => (
                  <motion.div
                    key={vault.vaultId}
                    initial={{ opacity: 0, x: -20 }}
                    animate={{ opacity: 1, x: 0 }}
                    transition={{ delay: idx * 0.05 }}
                    className="p-4 bg-gradient-to-r from-gray-50 to-gray-100 rounded-lg border border-gray-200"
                  >
                    <div className="flex items-center justify-between mb-3">
                      <div className="flex items-center gap-3">
                        <Lock className="w-5 h-5 text-blue-600" />
                        <span className="font-mono font-bold text-gray-900">{vault.segment}</span>
                      </div>
                      <Badge className="bg-green-500">
                        <Zap className="w-3 h-3 mr-1 inline" />
                        ACTIVE
                      </Badge>
                    </div>
                    <div className="grid grid-cols-3 gap-4 text-sm">
                      <div>
                        <span className="text-gray-500">Vault ID:</span>
                        <span className="ml-2 font-mono text-xs text-gray-900">{vault.vaultId}</span>
                      </div>
                      <div>
                        <span className="text-gray-500">Records:</span>
                        <span className="ml-2 font-semibold text-gray-900">
                          {transfers.filter(t => t.vaultSegment === vault.segment).length}
                        </span>
                      </div>
                      <div>
                        <span className="text-gray-500">Last Sync:</span>
                        <span className="ml-2 font-mono text-xs text-gray-900">{formatTimestamp(vault.lastSync)}</span>
                      </div>
                      <div className="col-span-2">
                        <span className="text-gray-500">Encryption Key:</span>
                        <span className="ml-2 font-mono text-xs text-blue-700">{vault.encryptionKey}</span>
                      </div>
                      <div>
                        <span className="text-gray-500">Checksum:</span>
                        <span className="ml-2 font-mono text-xs text-purple-700">{vault.checksum.substring(0, 16)}...</span>
                      </div>
                    </div>
                  </motion.div>
                ))}
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>

      {/* Enumeration Code Reference */}
      <Card className="border-2 border-purple-200">
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <FileText className="w-5 h-5" />
            Syntax Array Code Enumeration
          </CardTitle>
          <CardDescription>
            Transfer type, status, and vault segment enumerations for API integration
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-3 gap-6">
            <div>
              <h3 className="font-semibold text-gray-900 mb-2">TransferType</h3>
              <div className="space-y-1 text-sm font-mono">
                {Object.values(TransferType).map(type => (
                  <div key={type} className="text-blue-700">{type}</div>
                ))}
              </div>
            </div>
            <div>
              <h3 className="font-semibold text-gray-900 mb-2">TransferStatus</h3>
              <div className="space-y-1 text-sm font-mono">
                {Object.values(TransferStatus).map(status => (
                  <div key={status} className="text-green-700">{status}</div>
                ))}
              </div>
            </div>
            <div>
              <h3 className="font-semibold text-gray-900 mb-2">VaultSegment</h3>
              <div className="space-y-1 text-sm font-mono">
                {Object.values(VaultSegment).map(segment => (
                  <div key={segment} className="text-purple-700">{segment}</div>
                ))}
              </div>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
