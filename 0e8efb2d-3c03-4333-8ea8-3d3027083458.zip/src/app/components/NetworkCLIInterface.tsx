/**
 * Network CLI Interface - Real-time Virtual Network Management
 * Copyright © 2026 VOM Services Corporation
 * Matthew James Sauls - OCIO, CCO, CEO, CFO, CTO
 * EIN: 83-1427324 | FCC FRN: 0033213463
 * 
 * Integrated with AWS VPC Schema Mapping
 * VNet: mathieu_et_favvarrow
 * Datacenter: 3xpres5 - Seattle, WA
 */

import { useState, useEffect, useRef } from 'react';
import { motion } from 'motion/react';
import { Card } from './ui/card';
import { Button } from './ui/button';
import { Input } from './ui/input';
import { Badge } from './ui/badge';
import { 
  Terminal, 
  Network, 
  Play, 
  RefreshCw, 
  Server,
  Cloud,
  Database,
  Shield,
  CheckCircle2,
  AlertCircle,
  Globe,
  Layers,
  Activity
} from 'lucide-react';
import { toast } from 'sonner';

interface CLIOutput {
  timestamp: string;
  type: 'command' | 'success' | 'error' | 'info';
  message: string;
}

interface NetworkData {
  id: string;
  name: string;
  cidr: string;
  vnetId: string;
  datacenter: string;
  status: string;
  subnets: any[];
}

export function NetworkCLIInterface() {
  const [command, setCommand] = useState('');
  const [output, setOutput] = useState<CLIOutput[]>([
    {
      timestamp: new Date().toISOString(),
      type: 'info',
      message: 'Network Management CLI v2.0.0 - VOM Services Corporation'
    },
    {
      timestamp: new Date().toISOString(),
      type: 'info',
      message: 'VNet Infrastructure: mathieu_et_favvarrow | Datacenter: 3xpres5 Seattle'
    },
    {
      timestamp: new Date().toISOString(),
      type: 'info',
      message: 'Type "help" for available commands'
    }
  ]);
  const [networks, setNetworks] = useState<NetworkData[]>([]);
  const [vpcMappings, setVpcMappings] = useState<any[]>([]);
  const [isExecuting, setIsExecuting] = useState(false);
  const outputRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    // Load from localStorage on mount
    const savedNetworks = localStorage.getItem('banking_networks');
    const savedMappings = localStorage.getItem('banking_vpc_mappings');
    if (savedNetworks) setNetworks(JSON.parse(savedNetworks));
    if (savedMappings) setVpcMappings(JSON.parse(savedMappings));
  }, []);

  useEffect(() => {
    // Auto-scroll to bottom when output changes
    if (outputRef.current) {
      outputRef.current.scrollTop = outputRef.current.scrollHeight;
    }
  }, [output]);

  const addOutput = (type: CLIOutput['type'], message: string) => {
    setOutput(prev => [...prev, {
      timestamp: new Date().toISOString(),
      type,
      message
    }]);
  };

  const saveNetworks = (newNetworks: NetworkData[]) => {
    setNetworks(newNetworks);
    localStorage.setItem('banking_networks', JSON.stringify(newNetworks));
  };

  const saveMappings = (newMappings: any[]) => {
    setVpcMappings(newMappings);
    localStorage.setItem('banking_vpc_mappings', JSON.stringify(newMappings));
  };

  const executeCommand = async () => {
    if (!command.trim()) return;

    setIsExecuting(true);
    addOutput('command', `$ ${command}`);

    const parts = command.trim().split(/\s+/);
    const cmd = parts[0];
    const args = parts.slice(1);

    try {
      if (cmd === 'help') {
        addOutput('info', 'Available Commands:');
        addOutput('info', '  create <name> --cidr <cidr>  Create new virtual network');
        addOutput('info', '  list                          List all networks');
        addOutput('info', '  delete <networkId>            Delete network');
        addOutput('info', '  subnet add <netId> <name> <cidr>  Add subnet');
        addOutput('info', '  vpc-map <netId> <awsVpcId>    Map to AWS VPC');
        addOutput('info', '  show-mappings                 Show AWS VPC mappings');
        addOutput('info', '  clear                         Clear output');
      } else if (cmd === 'clear') {
        setOutput([{
          timestamp: new Date().toISOString(),
          type: 'info',
          message: 'Network Management CLI - Ready'
        }]);
      } else if (cmd === 'create') {
        const name = args[0];
        const cidrIndex = args.indexOf('--cidr');
        const cidr = cidrIndex >= 0 ? args[cidrIndex + 1] : '10.0.0.0/16';

        if (!name) {
          addOutput('error', '✗ Error: Network name required');
        } else {
          const newNetwork: NetworkData = {
            id: `net-${Date.now()}`,
            name,
            cidr,
            vnetId: 'mathieu_et_favvarrow',
            datacenter: '3xpres5 Datacenter - Seattle, WA',
            status: 'active',
            subnets: []
          };

          saveNetworks([...networks, newNetwork]);
          addOutput('success', `✓ Created network: ${newNetwork.id} ${newNetwork.name} ${newNetwork.cidr}`);
          addOutput('info', `  VNet: ${newNetwork.vnetId} | Datacenter: ${newNetwork.datacenter}`);
          toast.success('Network created successfully');
        }
      } else if (cmd === 'list') {
        if (networks.length === 0) {
          addOutput('info', 'No networks found');
        } else {
          addOutput('info', `Found ${networks.length} network(s):`);
          networks.forEach(net => {
            addOutput('success', `  ${net.id} | ${net.name} | ${net.cidr} | subnets: ${net.subnets?.length || 0}`);
          });
        }
      } else if (cmd === 'delete') {
        const networkId = args[0];
        if (!networkId) {
          addOutput('error', '✗ Error: Network ID required');
        } else {
          const network = networks.find(net => net.id === networkId);
          if (network) {
            saveNetworks(networks.filter(net => net.id !== networkId));
            addOutput('success', `✓ Deleted network: ${networkId}`);
            toast.success('Network deleted');
          } else {
            addOutput('error', `✗ Error: Network ${networkId} not found`);
          }
        }
      } else if (cmd === 'subnet' && args[0] === 'add') {
        const [, networkId, name, cidr] = args;
        if (!networkId || !name || !cidr) {
          addOutput('error', '✗ Error: subnet add requires: networkId name cidr');
        } else {
          const network = networks.find(net => net.id === networkId);
          if (network) {
            const newSubnet = {
              id: `subnet-${Date.now()}`,
              name,
              cidr,
              zone: 'us-west-2a',
              purpose: 'compute'
            };
            saveNetworks(networks.map(net => 
              net.id === networkId ? { ...net, subnets: [...net.subnets, newSubnet] } : net
            ));
            addOutput('success', `✓ Added subnet: ${newSubnet.id} ${newSubnet.cidr}`);
            toast.success('Subnet added');
          } else {
            addOutput('error', `✗ Error: Network ${networkId} not found`);
          }
        }
      } else if (cmd === 'vpc-map') {
        const [networkId, awsVpcId] = args;
        if (!networkId || !awsVpcId) {
          addOutput('error', '✗ Error: vpc-map requires: networkId awsVpcId');
        } else {
          const network = networks.find(net => net.id === networkId);
          if (network) {
            const newMapping = {
              id: `vpc-map-${Date.now()}`,
              networkId,
              awsVpcId,
              region: 'us-west-2',
              status: 'active',
              vnetMapping: {
                local: network.vnetId,
                aws: awsVpcId
              },
              availabilityZones: ['us-west-2a', 'us-west-2b', 'us-west-2c']
            };
            saveMappings([...vpcMappings, newMapping]);
            addOutput('success', `✓ AWS VPC mapping created: ${newMapping.id}`);
            addOutput('info', `  Local VNet: ${newMapping.vnetMapping.local} ↔ AWS VPC: ${newMapping.vnetMapping.aws}`);
            addOutput('info', `  Region: ${newMapping.region} | AZs: ${newMapping.availabilityZones.join(', ')}`);
            toast.success('VPC mapping created');
          } else {
            addOutput('error', `✗ Error: Network ${networkId} not found`);
          }
        }
      } else if (cmd === 'show-mappings') {
        if (vpcMappings.length === 0) {
          addOutput('info', 'No VPC mappings found');
        } else {
          addOutput('info', `AWS VPC Mappings (${vpcMappings.length}):`);
          vpcMappings.forEach(mapping => {
            addOutput('success', `  ${mapping.id}`);
            addOutput('info', `    Network: ${mapping.networkId} ↔ AWS VPC: ${mapping.awsVpcId}`);
            addOutput('info', `    Region: ${mapping.region} | Status: ${mapping.status}`);
          });
        }
      } else {
        addOutput('error', `✗ Unknown command: ${cmd}. Type "help" for available commands.`);
      }
    } catch (error) {
      addOutput('error', `✗ Error executing command: ${error}`);
      console.error('Command execution error:', error);
    }

    setCommand('');
    setIsExecuting(false);
  };

  const handleKeyPress = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter') {
      executeCommand();
    }
  };

  const getOutputColor = (type: CLIOutput['type']) => {
    switch (type) {
      case 'command': return 'text-blue-300';
      case 'success': return 'text-green-300';
      case 'error': return 'text-red-300';
      case 'info': return 'text-gray-300';
      default: return 'text-gray-300';
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-900 via-blue-900 to-slate-900 p-8">
      <div className="max-w-7xl mx-auto space-y-6">
        {/* Header */}
        <motion.div
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          className="text-center space-y-2"
        >
          <div className="flex items-center justify-center gap-3 mb-4">
            <Terminal className="w-8 h-8 text-blue-400" />
            <h1 className="text-4xl font-bold text-white">Network Management CLI</h1>
          </div>
          <p className="text-blue-200">Real-time Virtual Network Infrastructure Control</p>
          <div className="flex items-center justify-center gap-4 text-sm text-blue-300">
            <Badge variant="outline" className="border-blue-400 text-blue-300">
              <Globe className="w-3 h-3 mr-1" />
              VNet: mathieu_et_favvarrow
            </Badge>
            <Badge variant="outline" className="border-green-400 text-green-300">
              <Server className="w-3 h-3 mr-1" />
              3xpres5 Datacenter
            </Badge>
            <Badge variant="outline" className="border-purple-400 text-purple-300">
              <Shield className="w-3 h-3 mr-1" />
              NIST SP 800-57
            </Badge>
          </div>
        </motion.div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          {/* CLI Terminal */}
          <motion.div
            initial={{ opacity: 0, x: -20 }}
            animate={{ opacity: 1, x: 0 }}
            className="lg:col-span-2"
          >
            <Card className="bg-gray-900 border-blue-500/30 p-6">
              <div className="flex items-center justify-between mb-4">
                <div className="flex items-center gap-2">
                  <Terminal className="w-5 h-5 text-blue-400" />
                  <h2 className="text-xl font-semibold text-white">Terminal</h2>
                </div>
                <Badge variant="outline" className="border-green-500/50 text-green-300 text-xs">
                  <CheckCircle2 className="w-3 h-3 mr-1" />
                  Local Mode
                </Badge>
              </div>

              {/* Terminal Output */}
              <div 
                ref={outputRef}
                className="bg-black/60 rounded-lg p-4 mb-4 h-[500px] overflow-y-auto font-mono text-sm"
              >
                {output.map((line, idx) => (
                  <div key={idx} className={`mb-1 ${getOutputColor(line.type)}`}>
                    {line.type === 'command' && <span className="text-yellow-400">{'> '}</span>}
                    {line.message}
                  </div>
                ))}
                {isExecuting && (
                  <div className="flex items-center gap-2 text-blue-400">
                    <Activity className="w-4 h-4 animate-spin" />
                    <span>Executing...</span>
                  </div>
                )}
              </div>

              {/* Command Input */}
              <div className="flex gap-2">
                <span className="text-green-400 font-mono text-lg flex items-center">$</span>
                <Input
                  value={command}
                  onChange={(e) => setCommand(e.target.value)}
                  onKeyPress={handleKeyPress}
                  placeholder="Enter command (type 'help' for commands)"
                  disabled={isExecuting}
                  className="flex-1 bg-black/40 border-blue-500/30 text-white font-mono"
                />
                <Button
                  onClick={executeCommand}
                  disabled={isExecuting || !command.trim()}
                  className="bg-blue-600 hover:bg-blue-700 text-white"
                >
                  <Play className="w-4 h-4 mr-1" />
                  Execute
                </Button>
              </div>
            </Card>
          </motion.div>

          {/* Status Panel */}
          <motion.div
            initial={{ opacity: 0, x: 20 }}
            animate={{ opacity: 1, x: 0 }}
            className="space-y-6"
          >
            {/* Network Stats */}
            <Card className="bg-gradient-to-br from-blue-900/50 to-purple-900/50 border-blue-500/30 p-6">
              <div className="flex items-center gap-2 mb-4">
                <Network className="w-5 h-5 text-blue-400" />
                <h3 className="text-lg font-semibold text-white">Network Status</h3>
              </div>
              <div className="space-y-3">
                <div className="flex justify-between items-center">
                  <span className="text-gray-300">Total Networks</span>
                  <Badge className="bg-blue-600 text-white">{networks.length}</Badge>
                </div>
                <div className="flex justify-between items-center">
                  <span className="text-gray-300">Total Subnets</span>
                  <Badge className="bg-purple-600 text-white">
                    {networks.reduce((sum, net) => sum + (net.subnets?.length || 0), 0)}
                  </Badge>
                </div>
                <div className="flex justify-between items-center">
                  <span className="text-gray-300">VPC Mappings</span>
                  <Badge className="bg-green-600 text-white">{vpcMappings.length}</Badge>
                </div>
                <div className="flex justify-between items-center">
                  <span className="text-gray-300">Status</span>
                  <Badge className="bg-green-600 text-white flex items-center gap-1">
                    <CheckCircle2 className="w-3 h-3" />
                    Online
                  </Badge>
                </div>
              </div>
            </Card>

            {/* Active Networks */}
            <Card className="bg-gradient-to-br from-green-900/30 to-blue-900/30 border-green-500/30 p-6">
              <div className="flex items-center gap-2 mb-4">
                <Layers className="w-5 h-5 text-green-400" />
                <h3 className="text-lg font-semibold text-white">Active Networks</h3>
              </div>
              <div className="space-y-2 max-h-64 overflow-y-auto">
                {networks.length === 0 ? (
                  <p className="text-gray-400 text-sm">No networks configured</p>
                ) : (
                  networks.map(net => (
                    <div key={net.id} className="bg-black/30 rounded p-3 space-y-1">
                      <div className="flex items-center justify-between">
                        <span className="text-white font-medium text-sm truncate">{net.name}</span>
                        <Badge variant="outline" className="border-green-500 text-green-300 text-xs">
                          {net.status}
                        </Badge>
                      </div>
                      <p className="text-xs text-gray-400 font-mono">{net.cidr}</p>
                      <p className="text-xs text-blue-400">{net.subnets?.length || 0} subnets</p>
                    </div>
                  ))
                )}
              </div>
            </Card>

            {/* VPC Mappings */}
            <Card className="bg-gradient-to-br from-orange-900/30 to-red-900/30 border-orange-500/30 p-6">
              <div className="flex items-center gap-2 mb-4">
                <Cloud className="w-5 h-5 text-orange-400" />
                <h3 className="text-lg font-semibold text-white">AWS VPC Mappings</h3>
              </div>
              <div className="space-y-2 max-h-64 overflow-y-auto">
                {vpcMappings.length === 0 ? (
                  <p className="text-gray-400 text-sm">No VPC mappings</p>
                ) : (
                  vpcMappings.map(mapping => (
                    <div key={mapping.id} className="bg-black/30 rounded p-3 space-y-1">
                      <div className="flex items-center justify-between">
                        <span className="text-white font-medium text-xs">{mapping.awsVpcId}</span>
                        <Badge variant="outline" className="border-orange-500 text-orange-300 text-xs">
                          {mapping.region}
                        </Badge>
                      </div>
                      <p className="text-xs text-gray-400">Network: {mapping.networkId}</p>
                    </div>
                  ))
                )}
              </div>
            </Card>
          </motion.div>
        </div>

        {/* Quick Commands */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
        >
          <Card className="bg-gray-900/50 border-blue-500/30 p-6">
            <h3 className="text-lg font-semibold text-white mb-4">Quick Commands</h3>
            <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
              <Button
                onClick={() => setCommand('help')}
                variant="outline"
                className="border-blue-500/50 text-blue-300 hover:bg-blue-500/20"
              >
                Show Help
              </Button>
              <Button
                onClick={() => setCommand('list')}
                variant="outline"
                className="border-green-500/50 text-green-300 hover:bg-green-500/20"
              >
                List Networks
              </Button>
              <Button
                onClick={() => setCommand('show-mappings')}
                variant="outline"
                className="border-purple-500/50 text-purple-300 hover:bg-purple-500/20"
              >
                VPC Mappings
              </Button>
              <Button
                onClick={() => setCommand('create production-net --cidr 10.50.0.0/16')}
                variant="outline"
                className="border-orange-500/50 text-orange-300 hover:bg-orange-500/20"
              >
                Create Network
              </Button>
            </div>
          </Card>
        </motion.div>
      </div>
    </div>
  );
}