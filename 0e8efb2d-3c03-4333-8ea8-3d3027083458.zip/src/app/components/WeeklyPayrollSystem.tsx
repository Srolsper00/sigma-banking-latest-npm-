import { motion } from 'motion/react';
import { useState, useEffect } from 'react';
import { 
  Calendar,
  DollarSign,
  Users,
  CheckCircle,
  Clock,
  AlertCircle,
  Download,
  FileText,
  TrendingUp,
  Send,
  AlertTriangle,
  Shield,
  Database,
  Hash,
  Lock
} from 'lucide-react';

interface Worker {
  associateOID: string;
  name: string;
  department: string;
  hourlyRate: number;
  hoursWorked: number;
  deductions: Deduction[];
  status: 'active' | 'pending' | 'processed' | 'submitted';
}

interface Deduction {
  code: string;
  name: string;
  type: 'fixed' | 'percentage';
  amount: number;
}

interface PayrollRun {
  id: string;
  weekEnding: string;
  status: 'draft' | 'admitted' | 'submitted' | 'processed';
  totalWorkers: number;
  totalGross: number;
  totalDeductions: number;
  totalNet: number;
  submittedAt?: string;
  processedAt?: string;
}

export function WeeklyPayrollSystem() {
  const [selectedTab, setSelectedTab] = useState<'current' | 'workers' | 'history' | 'schedule'>('current');
  const [currentPayrollRun, setCurrentPayrollRun] = useState<PayrollRun | null>(null);
  const [nextThursday, setNextThursday] = useState<Date>(new Date());
  const [isAdmitted, setIsAdmitted] = useState(false);
  const [isSubmitted, setIsSubmitted] = useState(false);
  const [autoProcessEnabled, setAutoProcessEnabled] = useState(true);
  const [thursdayScheduleLog, setThursdayScheduleLog] = useState<string[]>([]);

  const [workers, setWorkers] = useState<Worker[]>([
    {
      associateOID: 'G3V1NEC2XSVMQDB6',
      name: 'Matthew James Saul',
      department: 'Executive Operations',
      hourlyRate: 85.00,
      hoursWorked: 167,
      deductions: [
        { code: 'HSACA', name: 'HSA Contribution', type: 'percentage', amount: 20 },
        { code: 'MISC', name: 'Misc Deduction', type: 'fixed', amount: 222 }
      ],
      status: 'active'
    }
  ]);

  const [payrollHistory, setPayrollHistory] = useState<PayrollRun[]>([
    {
      id: 'Oblm-8',
      weekEnding: '2026-03-25',
      status: 'processed',
      totalWorkers: 1,
      totalGross: 14188.81,
      totalDeductions: 0,
      totalNet: 14188.81,
      submittedAt: '2026-03-19T10:00:00Z',
      processedAt: '2026-03-20T09:00:00Z'
    },
    {
      id: 'PR-2026-03-13',
      weekEnding: '2026-03-13',
      status: 'processed',
      totalWorkers: 1,
      totalGross: 14188.81,
      totalDeductions: 0,
      totalNet: 14188.81,
      submittedAt: '2026-03-13T10:00:00Z',
      processedAt: '2026-03-13T14:30:00Z'
    }
  ]);

  // Calculate next Thursday
  useEffect(() => {
    const getNextThursday = () => {
      const today = new Date();
      const dayOfWeek = today.getDay();
      const daysUntilThursday = (4 - dayOfWeek + 7) % 7 || 7; // 4 = Thursday
      const nextThurs = new Date(today);
      nextThurs.setDate(today.getDate() + daysUntilThursday);
      return nextThurs;
    };
    setNextThursday(getNextThursday());
  }, []);

  // Calculate payroll totals
  const calculateWorkerPay = (worker: Worker) => {
    const gross = worker.hourlyRate * worker.hoursWorked;
    let totalDeductions = 0;
    
    worker.deductions.forEach(deduction => {
      if (deduction.type === 'fixed') {
        totalDeductions += deduction.amount;
      } else {
        totalDeductions += (gross * deduction.amount) / 100;
      }
    });

    return {
      gross,
      deductions: totalDeductions,
      net: gross - totalDeductions
    };
  };

  const calculateTotals = () => {
    let totalGross = 0;
    let totalDeductions = 0;
    let totalNet = 0;

    workers.forEach(worker => {
      const pay = calculateWorkerPay(worker);
      totalGross += pay.gross;
      totalDeductions += pay.deductions;
      totalNet += pay.net;
    });

    return { totalGross, totalDeductions, totalNet };
  };

  const admitPayroll = () => {
    const totals = calculateTotals();
    const runId = `PR-${nextThursday.toISOString().split('T')[0]}`;
    
    setCurrentPayrollRun({
      id: runId,
      weekEnding: nextThursday.toISOString().split('T')[0],
      status: 'admitted',
      totalWorkers: workers.length,
      ...totals,
      submittedAt: undefined,
      processedAt: undefined
    });

    setWorkers(prev => prev.map(w => ({ ...w, status: 'pending' as const })));
    setIsAdmitted(true);
  };

  const submitPayroll = () => {
    if (!currentPayrollRun) return;

    const updatedRun: PayrollRun = {
      ...currentPayrollRun,
      status: 'submitted',
      submittedAt: new Date().toISOString()
    };

    setCurrentPayrollRun(updatedRun);
    setWorkers(prev => prev.map(w => ({ ...w, status: 'submitted' as const })));
    setIsSubmitted(true);

    // Simulate processing
    setTimeout(() => {
      const processedRun: PayrollRun = {
        ...updatedRun,
        status: 'processed',
        processedAt: new Date().toISOString()
      };
      setCurrentPayrollRun(processedRun);
      setPayrollHistory(prev => [processedRun, ...prev]);
      setWorkers(prev => prev.map(w => ({ ...w, status: 'processed' as const })));
    }, 2000);
  };

  const resetPayroll = () => {
    setCurrentPayrollRun(null);
    setIsAdmitted(false);
    setIsSubmitted(false);
    setWorkers(prev => prev.map(w => ({ ...w, status: 'active' as const })));
  };

  const totals = calculateTotals();
  const daysUntilThursday = Math.ceil((nextThursday.getTime() - new Date().getTime()) / (1000 * 60 * 60 * 24));

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.6 }}
      className="bg-white rounded-xl shadow-lg border border-slate-200 overflow-hidden"
    >
      {/* Header */}
      <div className="bg-gradient-to-r from-emerald-900 via-green-800 to-emerald-900 p-6">
        <div className="flex items-center justify-between mb-4">
          <div className="flex items-center gap-3">
            <div className="p-2 bg-white/10 rounded-lg">
              <DollarSign className="w-6 h-6 text-white" />
            </div>
            <div>
              <h2 className="text-white text-xl">Weekly Payroll Processing Center</h2>
              <p className="text-slate-300 text-sm">Automated Thursday submission • UMB NA integration • ADP Worker API</p>
            </div>
          </div>
        </div>

        {/* Next Run Info */}
        <div className="grid grid-cols-4 gap-4">
          <div className="bg-white/10 rounded-lg p-3 backdrop-blur-sm">
            <div className="flex items-center gap-2 mb-1">
              <Calendar className="w-4 h-4 text-emerald-200" />
              <div className="text-emerald-200 text-xs">Next Thursday</div>
            </div>
            <div className="text-white font-bold">{nextThursday.toLocaleDateString()}</div>
            <div className="text-emerald-200 text-xs">{daysUntilThursday} days away</div>
          </div>
          
          <div className="bg-white/10 rounded-lg p-3 backdrop-blur-sm">
            <div className="flex items-center gap-2 mb-1">
              <Users className="w-4 h-4 text-emerald-200" />
              <div className="text-emerald-200 text-xs">Active Workers</div>
            </div>
            <div className="text-white text-2xl font-bold">{workers.length}</div>
          </div>

          <div className="bg-white/10 rounded-lg p-3 backdrop-blur-sm">
            <div className="flex items-center gap-2 mb-1">
              <DollarSign className="w-4 h-4 text-emerald-200" />
              <div className="text-emerald-200 text-xs">Total Gross</div>
            </div>
            <div className="text-white text-2xl font-bold">${totals.totalGross.toLocaleString('en-US', { minimumFractionDigits: 2 })}</div>
          </div>

          <div className="bg-white/10 rounded-lg p-3 backdrop-blur-sm">
            <div className="flex items-center gap-2 mb-1">
              <TrendingUp className="w-4 h-4 text-emerald-200" />
              <div className="text-emerald-200 text-xs">Net Payable</div>
            </div>
            <div className="text-white text-2xl font-bold">${totals.totalNet.toLocaleString('en-US', { minimumFractionDigits: 2 })}</div>
          </div>
        </div>
      </div>

      {/* Navigation Tabs */}
      <div className="border-b border-slate-200 bg-slate-50">
        <div className="flex">
          {[
            { id: 'current', label: 'Current Week', icon: Clock },
            { id: 'workers', label: 'Worker Details', icon: Users },
            { id: 'history', label: 'Payroll History', icon: FileText },
            { id: 'schedule', label: 'Thursday Schedule', icon: Calendar }
          ].map(tab => {
            const Icon = tab.icon;
            return (
              <button
                key={tab.id}
                onClick={() => setSelectedTab(tab.id as any)}
                className={`
                  flex items-center gap-2 px-6 py-3 font-medium text-sm transition-colors
                  ${selectedTab === tab.id 
                    ? 'text-emerald-700 border-b-2 border-emerald-600 bg-white' 
                    : 'text-slate-600 hover:text-slate-900 hover:bg-slate-100'
                  }
                `}
              >
                <Icon className="w-4 h-4" />
                {tab.label}
              </button>
            );
          })}
        </div>
      </div>

      {/* Content */}
      <div className="p-6">
        {/* Tab 1: Current Week Payroll */}
        {selectedTab === 'current' && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ duration: 0.3 }}
          >
            <div className="mb-6">
              <h3 className="text-slate-900 font-bold text-lg mb-2">💰 Weekly Payroll Admission & Submission</h3>
              <p className="text-slate-600 text-sm mb-4">
                Admit payroll for review, then submit every Thursday for processing via ADP Worker Payroll API
              </p>
            </div>

            {/* Status Alert */}
            {!isAdmitted && (
              <div className="bg-blue-50 border-2 border-blue-300 rounded-lg p-4 mb-6">
                <div className="flex items-start gap-3">
                  <AlertCircle className="w-5 h-5 text-blue-600 mt-0.5" />
                  <div>
                    <div className="text-blue-900 font-medium mb-1">Ready to Admit Payroll</div>
                    <div className="text-blue-800 text-sm">
                      Review worker hours and deductions, then admit for final approval before Thursday submission
                    </div>
                  </div>
                </div>
              </div>
            )}

            {isAdmitted && !isSubmitted && (
              <div className="bg-amber-50 border-2 border-amber-300 rounded-lg p-4 mb-6">
                <div className="flex items-start gap-3">
                  <Clock className="w-5 h-5 text-amber-600 mt-0.5" />
                  <div>
                    <div className="text-amber-900 font-medium mb-1">Payroll Admitted - Ready for Submission</div>
                    <div className="text-amber-800 text-sm">
                      Payroll has been admitted. Submit now to process via ADP API for Thursday {nextThursday.toLocaleDateString()}
                    </div>
                  </div>
                </div>
              </div>
            )}

            {isSubmitted && currentPayrollRun?.status === 'submitted' && (
              <div className="bg-purple-50 border-2 border-purple-300 rounded-lg p-4 mb-6">
                <div className="flex items-start gap-3">
                  <Send className="w-5 h-5 text-purple-600 mt-0.5 animate-pulse" />
                  <div>
                    <div className="text-purple-900 font-medium mb-1">Processing Payroll Submission...</div>
                    <div className="text-purple-800 text-sm">
                      Submitting to ADP Worker API • Applying deductions • Calculating net pay
                    </div>
                  </div>
                </div>
              </div>
            )}

            {currentPayrollRun?.status === 'processed' && (
              <div className="bg-green-50 border-2 border-green-300 rounded-lg p-4 mb-6">
                <div className="flex items-start gap-3">
                  <CheckCircle className="w-5 h-5 text-green-600 mt-0.5" />
                  <div>
                    <div className="text-green-900 font-medium mb-1">✅ Payroll Processed Successfully</div>
                    <div className="text-green-800 text-sm">
                      Run ID: {currentPayrollRun.id} • Submitted: {new Date(currentPayrollRun.submittedAt!).toLocaleString()} • {currentPayrollRun.totalWorkers} workers paid
                    </div>
                  </div>
                </div>
              </div>
            )}

            {/* Payroll Summary */}
            <div className="bg-slate-50 border border-slate-200 rounded-lg p-6 mb-6">
              <h4 className="text-slate-900 font-bold mb-4">Payroll Summary - Week Ending {nextThursday.toLocaleDateString()}</h4>
              
              <div className="grid grid-cols-3 gap-4 mb-4">
                <div className="bg-white rounded-lg p-4 border border-slate-200">
                  <div className="text-slate-600 text-sm mb-1">Total Gross Wages</div>
                  <div className="text-slate-900 text-2xl font-bold">${totals.totalGross.toLocaleString('en-US', { minimumFractionDigits: 2 })}</div>
                </div>
                <div className="bg-white rounded-lg p-4 border border-slate-200">
                  <div className="text-slate-600 text-sm mb-1">Total Deductions</div>
                  <div className="text-red-600 text-2xl font-bold">-${totals.totalDeductions.toLocaleString('en-US', { minimumFractionDigits: 2 })}</div>
                </div>
                <div className="bg-emerald-50 rounded-lg p-4 border-2 border-emerald-300">
                  <div className="text-emerald-700 text-sm mb-1 font-medium">Net Payable</div>
                  <div className="text-emerald-900 text-2xl font-bold">${totals.totalNet.toLocaleString('en-US', { minimumFractionDigits: 2 })}</div>
                </div>
              </div>

              {/* Worker List Summary */}
              <div className="space-y-2">
                {workers.map(worker => {
                  const pay = calculateWorkerPay(worker);
                  return (
                    <div key={worker.associateOID} className="bg-white rounded p-3 border border-slate-200">
                      <div className="flex items-center justify-between">
                        <div className="flex-1">
                          <div className="flex items-center gap-3">
                            <div className={`
                              px-2 py-1 rounded text-xs font-medium
                              ${worker.status === 'active' ? 'bg-blue-100 text-blue-700' : ''}
                              ${worker.status === 'pending' ? 'bg-amber-100 text-amber-700' : ''}
                              ${worker.status === 'submitted' ? 'bg-purple-100 text-purple-700' : ''}
                              ${worker.status === 'processed' ? 'bg-green-100 text-green-700' : ''}
                            `}>
                              {worker.status.toUpperCase()}
                            </div>
                            <div className="text-slate-900 font-medium">{worker.name}</div>
                            <div className="text-slate-600 text-sm">{worker.department}</div>
                          </div>
                          <div className="text-slate-600 text-xs mt-1">
                            AOID: {worker.associateOID} • ${worker.hourlyRate}/hr × {worker.hoursWorked} hrs
                          </div>
                        </div>
                        <div className="text-right">
                          <div className="text-slate-900 font-bold">${pay.net.toLocaleString('en-US', { minimumFractionDigits: 2 })}</div>
                          <div className="text-slate-500 text-xs">Gross: ${pay.gross.toFixed(2)} - Deductions: ${pay.deductions.toFixed(2)}</div>
                        </div>
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>

            {/* Action Buttons */}
            <div className="flex gap-3">
              {!isAdmitted && (
                <motion.button
                  whileHover={{ scale: 1.02 }}
                  whileTap={{ scale: 0.98 }}
                  onClick={admitPayroll}
                  className="flex-1 bg-blue-600 text-white px-6 py-4 rounded-lg font-bold flex items-center justify-center gap-2 shadow-lg"
                >
                  <Shield className="w-5 h-5" />
                  Admit Payroll for Review
                </motion.button>
              )}

              {isAdmitted && !isSubmitted && (
                <motion.button
                  whileHover={{ scale: 1.02 }}
                  whileTap={{ scale: 0.98 }}
                  onClick={submitPayroll}
                  className="flex-1 bg-gradient-to-r from-emerald-600 to-green-600 text-white px-6 py-4 rounded-lg font-bold flex items-center justify-center gap-2 shadow-lg"
                >
                  <Send className="w-5 h-5" />
                  Submit Payroll for Thursday {nextThursday.toLocaleDateString()}
                </motion.button>
              )}

              {currentPayrollRun?.status === 'processed' && (
                <>
                  <motion.button
                    whileHover={{ scale: 1.02 }}
                    whileTap={{ scale: 0.98 }}
                    className="bg-purple-600 text-white px-6 py-3 rounded-lg font-medium flex items-center gap-2"
                  >
                    <Download className="w-5 h-5" />
                    Download Payroll Report
                  </motion.button>
                  <motion.button
                    whileHover={{ scale: 1.02 }}
                    whileTap={{ scale: 0.98 }}
                    onClick={resetPayroll}
                    className="bg-slate-600 text-white px-6 py-3 rounded-lg font-medium"
                  >
                    Reset for Next Week
                  </motion.button>
                </>
              )}
            </div>
          </motion.div>
        )}

        {/* Tab 2: Worker Details */}
        {selectedTab === 'workers' && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ duration: 0.3 }}
          >
            <div className="mb-6">
              <h3 className="text-slate-900 font-bold text-lg mb-2">👥 Worker Payroll Details</h3>
              <p className="text-slate-600 text-sm">
                Individual worker breakdown with deductions and net pay calculations
              </p>
            </div>

            <div className="space-y-4">
              {workers.map(worker => {
                const pay = calculateWorkerPay(worker);
                return (
                  <div key={worker.associateOID} className="bg-white border-2 border-slate-200 rounded-lg p-5">
                    <div className="flex items-start justify-between mb-4">
                      <div>
                        <div className="text-slate-900 font-bold text-lg">{worker.name}</div>
                        <div className="text-slate-600 text-sm">{worker.department}</div>
                        <div className="text-slate-500 text-xs font-mono mt-1">AOID: {worker.associateOID}</div>
                      </div>
                      <div className="text-right">
                        <div className="text-emerald-600 font-bold text-2xl">${pay.net.toLocaleString('en-US', { minimumFractionDigits: 2 })}</div>
                        <div className="text-slate-500 text-xs">Net Pay</div>
                      </div>
                    </div>

                    <div className="grid grid-cols-3 gap-4 mb-4">
                      <div className="bg-slate-50 rounded p-3">
                        <div className="text-slate-600 text-xs mb-1">Hourly Rate</div>
                        <div className="text-slate-900 font-bold">${worker.hourlyRate.toFixed(2)}</div>
                      </div>
                      <div className="bg-slate-50 rounded p-3">
                        <div className="text-slate-600 text-xs mb-1">Hours Worked</div>
                        <div className="text-slate-900 font-bold">{worker.hoursWorked}</div>
                      </div>
                      <div className="bg-green-50 rounded p-3">
                        <div className="text-green-700 text-xs mb-1">Gross Pay</div>
                        <div className="text-green-900 font-bold">${pay.gross.toFixed(2)}</div>
                      </div>
                    </div>

                    <div className="bg-red-50 border border-red-200 rounded p-3">
                      <div className="text-red-900 font-medium text-sm mb-2">Deductions</div>
                      <div className="space-y-2">
                        {worker.deductions.map((deduction, idx) => {
                          const amount = deduction.type === 'fixed' 
                            ? deduction.amount 
                            : (pay.gross * deduction.amount) / 100;
                          return (
                            <div key={idx} className="flex items-center justify-between text-sm">
                              <div>
                                <span className="text-red-800 font-medium">{deduction.name}</span>
                                <span className="text-red-600 text-xs ml-2">({deduction.code})</span>
                              </div>
                              <div className="text-red-900 font-mono">
                                {deduction.type === 'percentage' && `${deduction.amount}% = `}
                                ${amount.toFixed(2)}
                              </div>
                            </div>
                          );
                        })}
                        <div className="border-t border-red-300 pt-2 mt-2 flex justify-between">
                          <div className="text-red-900 font-bold">Total Deductions</div>
                          <div className="text-red-900 font-bold">${pay.deductions.toFixed(2)}</div>
                        </div>
                      </div>
                    </div>
                  </div>
                );
              })}
            </div>
          </motion.div>
        )}

        {/* Tab 3: Payroll History */}
        {selectedTab === 'history' && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ duration: 0.3 }}
          >
            <div className="mb-6">
              <h3 className="text-slate-900 font-bold text-lg mb-2">📊 Historical Payroll Runs</h3>
              <p className="text-slate-600 text-sm">
                Previous Thursday submissions and processing history
              </p>
            </div>

            <div className="space-y-4">
              {payrollHistory.map(run => (
                <div key={run.id} className="bg-white border-2 border-slate-200 rounded-lg p-5">
                  <div className="flex items-start justify-between mb-4">
                    <div>
                      <div className="flex items-center gap-3 mb-2">
                        <div className="text-slate-900 font-bold text-lg">{run.id}</div>
                        <div className={`
                          px-3 py-1 rounded-full text-xs font-bold
                          ${run.status === 'processed' ? 'bg-green-100 text-green-700' : ''}
                          ${run.status === 'submitted' ? 'bg-purple-100 text-purple-700' : ''}
                          ${run.status === 'admitted' ? 'bg-amber-100 text-amber-700' : ''}
                        `}>
                          {run.status.toUpperCase()}
                        </div>
                      </div>
                      <div className="text-slate-600 text-sm">
                        Week Ending: {new Date(run.weekEnding).toLocaleDateString()}
                      </div>
                      {run.submittedAt && (
                        <div className="text-slate-500 text-xs mt-1">
                          Submitted: {new Date(run.submittedAt).toLocaleString()}
                        </div>
                      )}
                    </div>
                    <div className="text-right">
                      <div className="text-emerald-600 font-bold text-2xl">${run.totalNet.toLocaleString('en-US', { minimumFractionDigits: 2 })}</div>
                      <div className="text-slate-500 text-xs">Net Paid</div>
                    </div>
                  </div>

                  <div className="grid grid-cols-4 gap-3">
                    <div className="bg-slate-50 rounded p-3">
                      <div className="text-slate-600 text-xs mb-1">Workers</div>
                      <div className="text-slate-900 font-bold">{run.totalWorkers}</div>
                    </div>
                    <div className="bg-green-50 rounded p-3">
                      <div className="text-green-700 text-xs mb-1">Gross</div>
                      <div className="text-green-900 font-bold">${run.totalGross.toFixed(2)}</div>
                    </div>
                    <div className="bg-red-50 rounded p-3">
                      <div className="text-red-700 text-xs mb-1">Deductions</div>
                      <div className="text-red-900 font-bold">${run.totalDeductions.toFixed(2)}</div>
                    </div>
                    <div className="bg-emerald-50 rounded p-3">
                      <div className="text-emerald-700 text-xs mb-1">Net</div>
                      <div className="text-emerald-900 font-bold">${run.totalNet.toFixed(2)}</div>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </motion.div>
        )}

        {/* Tab 4: Thursday Schedule */}
        {selectedTab === 'schedule' && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ duration: 0.3 }}
          >
            <div className="mb-6">
              <h3 className="text-slate-900 font-bold text-lg mb-2">📅 Thursday Payroll Schedule</h3>
              <p className="text-slate-600 text-sm">
                Automated weekly payroll submission schedule and configuration
              </p>
            </div>

            <div className="bg-gradient-to-r from-emerald-600 to-green-600 rounded-lg p-6 mb-6 text-white">
              <div className="flex items-center gap-3 mb-4">
                <Calendar className="w-8 h-8" />
                <div>
                  <div className="text-2xl font-bold">Every Thursday</div>
                  <div className="text-emerald-100 text-sm">Automated Payroll Submission Schedule</div>
                </div>
              </div>
              <div className="grid grid-cols-2 gap-4">
                <div className="bg-white/10 rounded p-3 backdrop-blur-sm">
                  <div className="text-emerald-100 text-xs mb-1">Next Submission</div>
                  <div className="text-white font-bold text-lg">{nextThursday.toLocaleDateString()}</div>
                </div>
                <div className="bg-white/10 rounded p-3 backdrop-blur-sm">
                  <div className="text-emerald-100 text-xs mb-1">Days Remaining</div>
                  <div className="text-white font-bold text-lg">{daysUntilThursday} days</div>
                </div>
              </div>
            </div>

            {/* Schedule Configuration */}
            <div className="bg-white border-2 border-slate-200 rounded-lg p-6 mb-6">
              <h4 className="text-slate-900 font-bold mb-4">Schedule Configuration</h4>
              <div className="space-y-4">
                <div className="flex items-center justify-between py-3 border-b border-slate-200">
                  <div>
                    <div className="text-slate-900 font-medium">Submission Day</div>
                    <div className="text-slate-600 text-sm">Day of week for payroll submission</div>
                  </div>
                  <div className="bg-emerald-100 text-emerald-700 px-4 py-2 rounded-lg font-bold">
                    Thursday
                  </div>
                </div>
                <div className="flex items-center justify-between py-3 border-b border-slate-200">
                  <div>
                    <div className="text-slate-900 font-medium">Pay Period</div>
                    <div className="text-slate-600 text-sm">Frequency of payroll processing</div>
                  </div>
                  <div className="bg-blue-100 text-blue-700 px-4 py-2 rounded-lg font-bold">
                    Weekly
                  </div>
                </div>
                <div className="flex items-center justify-between py-3 border-b border-slate-200">
                  <div>
                    <div className="text-slate-900 font-medium">Integration</div>
                    <div className="text-slate-600 text-sm">Payment processor and API</div>
                  </div>
                  <div className="bg-purple-100 text-purple-700 px-4 py-2 rounded-lg font-bold">
                    ADP Worker API
                  </div>
                </div>
                <div className="flex items-center justify-between py-3">
                  <div>
                    <div className="text-slate-900 font-medium">Banking Partner</div>
                    <div className="text-slate-600 text-sm">Financial institution for disbursement</div>
                  </div>
                  <div className="bg-slate-100 text-slate-700 px-4 py-2 rounded-lg font-bold">
                    UMB NA
                  </div>
                </div>
              </div>
            </div>

            {/* API Configuration */}
            <div className="bg-slate-900 text-white rounded-lg p-6">
              <div className="flex items-center gap-2 mb-4">
                <Database className="w-5 h-5 text-emerald-400" />
                <h4 className="font-bold">ADP Payroll API Configuration</h4>
              </div>
              <div className="space-y-3 font-mono text-xs">
                <div className="bg-slate-800 rounded p-3">
                  <div className="text-slate-400 mb-1">Deduction Change Endpoint</div>
                  <div className="text-emerald-400">POST /events/payroll/v2/worker-general-deduction-instruction.change</div>
                </div>
                <div className="bg-slate-800 rounded p-3">
                  <div className="text-slate-400 mb-1">Deduction Start Endpoint</div>
                  <div className="text-emerald-400">POST /events/payroll/v2/worker-general-deduction-instruction.start</div>
                </div>
                <div className="bg-slate-800 rounded p-3">
                  <div className="text-slate-400 mb-1">Deduction Stop Endpoint</div>
                  <div className="text-emerald-400">POST /events/payroll/v2/worker-general-deduction-instruction.stop</div>
                </div>
                <div className="bg-slate-800 rounded p-3">
                  <div className="text-slate-400 mb-1">Worker Info Endpoint</div>
                  <div className="text-emerald-400">GET /hr/v2/workers/&#123;associateOID&#125;</div>
                </div>
              </div>
            </div>
          </motion.div>
        )}
      </div>
    </motion.div>
  );
}