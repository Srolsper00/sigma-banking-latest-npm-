import { motion } from 'motion/react';
import { useState } from 'react';
import {
  FileText,
  XCircle,
  CheckCircle,
  Clock,
  AlertTriangle,
  Shield,
  Hash,
  Download,
  RotateCcw,
  Eye,
  Info,
  Calendar,
  DollarSign,
  Building2
} from 'lucide-react';
import { createHash } from 'crypto';

interface BankDraft {
  draft_id: string;
  amount: number;
  currency: string;
  issuer: string;
  routing: string;
  status: 'pending' | 'cleared' | 'canceled' | 'reversed';
  cancellation_reason?: string;
  canceled_on?: string;
  ledger_reference: string;
  audit_hash: string;
  reversal_event?: string;
  created_on: string;
  cleared_on?: string;
  source_gl?: string;
  target_gl?: string;
  intent_hash?: string;
}

interface ReversalEvent {
  id: string;
  type: 'DRAFT_CANCELLATION' | 'CREDIT_RESCINDED' | 'LEDGER_CORRECTION';
  timestamp: string;
  affected_drafts: string[];
  initiated_by: string;
  reason: string;
  amount_reversed: number;
  verification_hash: string;
}

export function BankDraftManagement() {
  const [selectedDraft, setSelectedDraft] = useState<BankDraft | null>(null);
  const [showIntentHashCalc, setShowIntentHashCalc] = useState(false);
  const [verificationMode, setVerificationMode] = useState(false);

  // Sample drafts including the provided canceled draft
  const [drafts] = useState<BankDraft[]>([
    {
      draft_id: "BD-2026-000145",
      amount: 30000.00,
      currency: "USD",
      issuer: "Genesis Financial Systems",
      routing: "031176110",
      status: "processingk",
      cancellation_reason: "Associated $8,000 credit draft rescinded prior to settlement",
      canceled_on: "2026-03-04",
      ledger_reference: "GL_INTRADAY_FUNDS",
      audit_hash: "9e21af3c8b4f7a2d1e5c9b8a7f6e5d4c3b2a1f0e9d8c7b6a5f4e3d2c1b0a9f8",
      reversal_event: "LEDGER_REV_2026_03_04_01",
      created_on: "2026-03-03",
      source_gl: "1327711016390",
      target_gl: "1327711016401",
      intent_hash: "a7b3c9d2e1f4a8b5c6d7e8f9a0b1c2d3e4f5a6b7c8d9e0f1a2b3c4d5e6f7a8b9"
    },
    {
      draft_id: "BD-2026-000144",
      amount: 187111424552206336,
      currency: "USD",
      issuer: "Genesis Financial Systems",
      routing: "041215663",
      status: "cleared",
      ledger_reference: "GL_PAYROLL_CLEARING",
      audit_hash: "7f8e9d0c1b2a3f4e5d6c7b8a9f0e1d2c3b4a5f6e7d8c9b0a1f2e3d4c5b6a7f8",
      created_on: "2026-03-01",
      cleared_on: "2026-03-02",
      source_gl: "1327711016390",
      target_gl: "1327711016401",
      intent_hash: "f3e4d5c6b7a8f9e0d1c2b3a4f5e6d7c8b9a0f1e2d3c4b5a6f7e8d9c0b1a2f3e4"
    },
    {
      draft_id: "BD-2026-000143",
      amount: 748445698208825344,
      currency: "USD",
      issuer: "Genesis Financial Systems",
      routing: "041215663",
      status: "cleared",
      ledger_reference: "GL_PAYROLL_ALLOCATION",
      audit_hash: "5d6c7b8a9f0e1d2c3b4a5f6e7d8c9b0a1f2e3d4c5b6a7f8e9d0c1b2a3f4e5d6",
      created_on: "2026-02-28",
      cleared_on: "2026-03-01",
      source_gl: "1327711016390",
      target_gl: "1327711016402",
      intent_hash: "c2d3e4f5a6b7c8d9e0f1a2b3c4d5e6f7a8b9c0d1e2f3a4b5c6d7e8f9a0b1c2d3"
    },
    {
      draft_id: "BD-2026-000146",
      amount: 8000.00,
      currency: "USD",
      issuer: "Genesis Financial Systems",
      routing: "031176110",
      status: "cleared",
      cancellation_reason: "Credit draft rescinded - triggering BD-2026-000145 cancellation",
      canceled_on: "2026-03-04",
      ledger_reference: "GL_CREDIT_FACILITY",
      audit_hash: "1a2b3c4d5e6f7a8b9c0d1e2f3a4b5c6d7e8f9a0b1c2d3e4f5a6b7c8d9e0f1a2",
      reversal_event: "LEDGER_REV_2026_03_04_01",
      created_on: "2026-03-03"
    }
  ]);

  const [reversalEvents] = useState<ReversalEvent[]>([
    {
      id: "LEDGER_REV_2026_03_04_01",
      type: "CREDIT_RESCINDED",
      timestamp: "2026-03-04T14:23:17Z",
      affected_drafts: ["BD-2026-000145", "BD-2026-000146"],
      initiated_by: "SYSTEM_AUTO_REVERSAL",
      reason: "Credit draft BD-2026-000146 ($8,000) rescinded prior to settlement, triggering cancellation of dependent draft BD-2026-000145 ($30,000)",
      amount_reversed: 38000.00,
      verification_hash: "rev_9e21af3c8b4f7a2d1e5c9b8a7f6e5d4c3b2a1f0e9d8c7b6a5f4e3d2c1b0a9f8"
    }
  ]);

  // Calculate intent hash
  const calculateIntentHash = (draft: BankDraft): string => {
    if (!draft.source_gl || !draft.target_gl) return 'N/A';
    
    const intent_data = `${draft.source_gl}${draft.target_gl}${draft.amount}${draft.created_on}`;
    
    // Simulate SHA-256 (in production, use Web Crypto API or backend)
    // For demo purposes, we'll use a simplified hash representation
    const hashValue = intent_data.split('').reduce((acc, char) => {
      return ((acc << 5) - acc) + char.charCodeAt(0);
    }, 0);
    
    return Math.abs(hashValue).toString(16).padStart(64, '0').substring(0, 64);
  };

  const formatCurrency = (amount: number): string => {
    if (amount >= 1e15) {
      return `$${(amount / 1e15).toFixed(2)} quadrillion`;
    } else if (amount >= 1e12) {
      return `$${(amount / 1e12).toFixed(2)} trillion`;
    } else if (amount >= 1e9) {
      return `$${(amount / 1e9).toFixed(2)} billion`;
    } else if (amount >= 1e6) {
      return `$${(amount / 1e6).toFixed(2)} million`;
    } else {
      return new Intl.NumberFormat('en-US', {
        style: 'currency',
        currency: 'USD'
      }).format(amount);
    }
  };

  const formatScientific = (amount: number): string => {
    return amount.toExponential(17);
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'cleared': return 'text-green-700 bg-green-100';
      case 'pending': return 'text-yellow-700 bg-yellow-100';
      case 'canceled': return 'text-red-700 bg-red-100';
      case 'reversed': return 'text-orange-700 bg-orange-100';
      default: return 'text-slate-700 bg-slate-100';
    }
  };

  const getStatusIcon = (status: string) => {
    switch (status) {
      case 'cleared': return <CheckCircle className="w-4 h-4" />;
      case 'pending': return <Clock className="w-4 h-4" />;
      case 'canceled': return <XCircle className="w-4 h-4" />;
      case 'reversed': return <RotateCcw className="w-4 h-4" />;
      default: return <FileText className="w-4 h-4" />;
    }
  };

  const downloadDraftReport = (draft: BankDraft) => {
    const reversalEvent = draft.reversal_event 
      ? reversalEvents.find(e => e.id === draft.reversal_event)
      : null;

    const report = `
═══════════════════════════════════════════════════════════════════
                    SIGMA BANKING PLATFORM
                   Bank Draft Status Report
═══════════════════════════════════════════════════════════════════

Generated: ${new Date().toISOString()}
Banking Partner: UMB NA (Routing: ${draft.routing})
Entity: OBLMFGJE – Scherer Enterprises Inc.

═══════════════════════════════════════════════════════════════════
                      DRAFT INFORMATION
═══════════════════════════════════════════════════════════════════

Draft ID:                    ${draft.draft_id}
Status:                      ${draft.status.toUpperCase()}
Amount:                      ${formatCurrency(draft.amount)}
Scientific Notation:         ${formatScientific(draft.amount)}
Currency:                    ${draft.currency}
Issuer:                      ${draft.issuer}
Routing Number:              ${draft.routing}

═══════════════════════════════════════════════════════════════════
                      TIMELINE
═══════════════════════════════════════════════════════════════════

Created:                     ${draft.created_on}
${draft.cleared_on ? `Cleared:                     ${draft.cleared_on}` : ''}
${draft.canceled_on ? `Canceled:                    ${draft.canceled_on}` : ''}

═══════════════════════════════════════════════════════════════════
                  LEDGER & AUDIT TRAIL
═══════════════════════════════════════════════════════════════════

Ledger Reference:            ${draft.ledger_reference}
${draft.source_gl ? `Source GL Account:           ${draft.source_gl}` : ''}
${draft.target_gl ? `Target GL Account:           ${draft.target_gl}` : ''}

Audit Hash (SHA-256):
${draft.audit_hash}

${draft.intent_hash ? `Intent Hash (SHA-256):\n${draft.intent_hash}` : ''}

Intent Hash Calculation:
SHA256(source_gl + target_gl + amount + timestamp)
${draft.source_gl && draft.target_gl ? `SHA256("${draft.source_gl}" + "${draft.target_gl}" + "${draft.amount}" + "${draft.created_on}")` : 'N/A - Missing GL accounts'}

═══════════════════════════════════════════════════════════════════
${draft.status === 'canceled' ? `                  CANCELLATION DETAILS
═══════════════════════════════════════════════════════════════════

Cancellation Date:           ${draft.canceled_on}
Reason:                      ${draft.cancellation_reason}
${draft.reversal_event ? `Reversal Event ID:           ${draft.reversal_event}` : ''}

${reversalEvent ? `
Reversal Event Details:
  Type:                      ${reversalEvent.type}
  Timestamp:                 ${reversalEvent.timestamp}
  Initiated By:              ${reversalEvent.initiated_by}
  Total Amount Reversed:     ${formatCurrency(reversalEvent.amount_reversed)}
  Affected Drafts:           ${reversalEvent.affected_drafts.join(', ')}
  Verification Hash:         ${reversalEvent.verification_hash}
  
  Full Reason:
  ${reversalEvent.reason}
` : ''}
═══════════════════════════════════════════════════════════════════
` : `═══════════════════════════════════════════════════════════════════`}
                    REGULATORY COMPLIANCE
═══════════════════════════════════════════════════════════════════

✓ UCC Article 4 - Bank Deposits and Collections
✓ Federal Reserve Regulation CC - Funds Availability
✓ Regulation E - Electronic Fund Transfers
✓ NACHA Operating Rules - ACH Network
✓ OCC Examination Handbook - Transaction Processing
✓ Immutable audit trail maintained
✓ Cryptographic verification enabled

═══════════════════════════════════════════════════════════════════
                        ATTESTATION
═══════════════════════════════════════════════════════════════════

This bank draft report is generated by the Sigma Banking Platform's
automated draft management system. All transactions are recorded in
an append-only ledger with cryptographic hash verification.

${draft.status === 'canceled' ? 'This draft has been CANCELED and will not settle. All associated\nledger entries have been reversed with full audit trail preservation.' : ''}

Report ID: ${Math.random().toString(36).substr(2, 9).toUpperCase()}
Generated By: Sigma Draft Management v1.0
Timestamp: ${new Date().toISOString()}

═══════════════════════════════════════════════════════════════════
                        END OF REPORT
═══════════════════════════════════════════════════════════════════
    `.trim();

    const blob = new Blob([report], { type: 'text/plain' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `Bank_Draft_${draft.draft_id}_Report.txt`;
    a.click();
    URL.revokeObjectURL(url);
  };

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.6 }}
      className="space-y-6"
    >
      {/* Header */}
      <div className="bg-gradient-to-r from-indigo-900 via-purple-900 to-pink-900 rounded-xl p-6">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="p-3 bg-white/10 rounded-lg">
              <FileText className="w-8 h-8 text-white" />
            </div>
            <div>
              <h2 className="text-white text-2xl font-bold">Bank Draft Management</h2>
              <p className="text-slate-300 text-sm">Draft tracking, cancellations, and intent hash verification</p>
            </div>
          </div>
          <div className="text-right text-white">
            <div className="text-white/70 text-xs">Total Drafts</div>
            <div className="text-3xl font-bold">{drafts.length}</div>
          </div>
        </div>
      </div>

      {/* Intent Hash Formula */}
      <div className="bg-slate-900 rounded-xl p-6 text-white">
        <div className="flex items-center gap-3 mb-4">
          <Hash className="w-6 h-6 text-purple-400" />
          <h3 className="text-xl font-bold">Intent Hash Verification</h3>
        </div>
        
        <div className="bg-slate-800 rounded-lg p-4 font-mono text-sm">
          <div className="text-purple-300 mb-2">Intent Hash Calculation Formula:</div>
          <div className="text-green-400">
            intent_hash = SHA256(source_gl + target_gl + amount + timestamp)
          </div>
          
          <div className="mt-4 text-slate-400 text-xs">
            This cryptographic hash ensures draft integrity and prevents tampering.
            Any modification to source GL, target GL, amount, or timestamp will
            produce a completely different hash value.
          </div>
        </div>
      </div>

      {/* Draft List */}
      <div className="space-y-3">
        {drafts.map((draft, index) => {
          const reversalEvent = draft.reversal_event 
            ? reversalEvents.find(e => e.id === draft.reversal_event)
            : null;

          return (
            <motion.div
              key={draft.draft_id}
              initial={{ opacity: 0, x: -20 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ delay: index * 0.1 }}
              className={`bg-white rounded-xl border-2 overflow-hidden ${
                selectedDraft?.draft_id === draft.draft_id 
                  ? 'border-purple-500 shadow-lg' 
                  : 'border-slate-200'
              }`}
            >
              {/* Draft Header */}
              <div 
                className={`p-4 cursor-pointer ${
                  draft.status === 'canceled' 
                    ? 'bg-gradient-to-r from-red-50 to-orange-50'
                    : draft.status === 'cleared'
                    ? 'bg-gradient-to-r from-green-50 to-emerald-50'
                    : 'bg-gradient-to-r from-blue-50 to-indigo-50'
                }`}
                onClick={() => setSelectedDraft(
                  selectedDraft?.draft_id === draft.draft_id ? null : draft
                )}
              >
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-3">
                    <div className={`p-2 rounded-lg ${getStatusColor(draft.status)}`}>
                      {getStatusIcon(draft.status)}
                    </div>
                    <div>
                      <div className="font-mono font-bold text-slate-900">{draft.draft_id}</div>
                      <div className="text-slate-600 text-sm">{draft.issuer}</div>
                    </div>
                  </div>
                  
                  <div className="text-right">
                    <div className="text-2xl font-bold text-slate-900">
                      {formatCurrency(draft.amount)}
                    </div>
                    <div className="text-slate-500 text-xs font-mono">
                      {formatScientific(draft.amount)}
                    </div>
                  </div>
                </div>

                {draft.status === 'canceled' && (
                  <div className="mt-3 bg-white/80 rounded-lg p-3 border border-red-200">
                    <div className="flex items-start gap-2">
                      <AlertTriangle className="w-4 h-4 text-red-600 mt-0.5" />
                      <div className="flex-1">
                        <div className="text-red-900 font-bold text-sm">Cancellation Notice</div>
                        <div className="text-red-700 text-xs mt-1">
                          {draft.cancellation_reason}
                        </div>
                        <div className="text-red-600 text-xs mt-1">
                          Canceled on {draft.canceled_on}
                        </div>
                      </div>
                    </div>
                  </div>
                )}
              </div>

              {/* Draft Details (Expanded) */}
              {selectedDraft?.draft_id === draft.draft_id && (
                <motion.div
                  initial={{ opacity: 0, height: 0 }}
                  animate={{ opacity: 1, height: 'auto' }}
                  transition={{ duration: 0.3 }}
                  className="border-t border-slate-200"
                >
                  <div className="p-6 space-y-4">
                    {/* Basic Information */}
                    <div>
                      <h4 className="text-slate-900 font-bold mb-3 flex items-center gap-2">
                        <Info className="w-4 h-4" />
                        Draft Information
                      </h4>
                      <div className="grid grid-cols-2 gap-3">
                        <div className="bg-slate-50 rounded p-3">
                          <div className="text-slate-600 text-xs mb-1">Routing Number</div>
                          <div className="text-slate-900 font-mono font-bold">{draft.routing}</div>
                        </div>
                        <div className="bg-slate-50 rounded p-3">
                          <div className="text-slate-600 text-xs mb-1">Currency</div>
                          <div className="text-slate-900 font-bold">{draft.currency}</div>
                        </div>
                        <div className="bg-slate-50 rounded p-3">
                          <div className="text-slate-600 text-xs mb-1">Created</div>
                          <div className="text-slate-900 font-mono text-sm">{draft.created_on}</div>
                        </div>
                        {draft.cleared_on && (
                          <div className="bg-green-50 rounded p-3">
                            <div className="text-green-700 text-xs mb-1">Cleared</div>
                            <div className="text-green-900 font-mono text-sm">{draft.cleared_on}</div>
                          </div>
                        )}
                        {draft.canceled_on && (
                          <div className="bg-red-50 rounded p-3">
                            <div className="text-red-700 text-xs mb-1">Canceled</div>
                            <div className="text-red-900 font-mono text-sm">{draft.canceled_on}</div>
                          </div>
                        )}
                      </div>
                    </div>

                    {/* Ledger Information */}
                    <div>
                      <h4 className="text-slate-900 font-bold mb-3 flex items-center gap-2">
                        <Building2 className="w-4 h-4" />
                        Ledger References
                      </h4>
                      <div className="space-y-2">
                        <div className="bg-purple-50 rounded p-3">
                          <div className="text-purple-700 text-xs mb-1">Ledger Reference</div>
                          <div className="text-purple-900 font-mono font-bold">{draft.ledger_reference}</div>
                        </div>
                        {draft.source_gl && (
                          <div className="bg-blue-50 rounded p-3">
                            <div className="text-blue-700 text-xs mb-1">Source GL Account</div>
                            <div className="text-blue-900 font-mono font-bold">{draft.source_gl}</div>
                          </div>
                        )}
                        {draft.target_gl && (
                          <div className="bg-indigo-50 rounded p-3">
                            <div className="text-indigo-700 text-xs mb-1">Target GL Account</div>
                            <div className="text-indigo-900 font-mono font-bold">{draft.target_gl}</div>
                          </div>
                        )}
                      </div>
                    </div>

                    {/* Cryptographic Hashes */}
                    <div>
                      <h4 className="text-slate-900 font-bold mb-3 flex items-center gap-2">
                        <Shield className="w-4 h-4" />
                        Cryptographic Verification
                      </h4>
                      <div className="space-y-2">
                        <div className="bg-slate-50 rounded p-3">
                          <div className="text-slate-600 text-xs mb-1">Audit Hash (SHA-256)</div>
                          <div className="text-slate-900 font-mono text-xs break-all">
                            {draft.audit_hash}
                          </div>
                        </div>
                        {draft.intent_hash && (
                          <div className="bg-green-50 rounded p-3">
                            <div className="text-green-700 text-xs mb-1">Intent Hash (SHA-256)</div>
                            <div className="text-green-900 font-mono text-xs break-all">
                              {draft.intent_hash}
                            </div>
                            <div className="mt-2 text-green-600 text-xs">
                              ✓ Calculated from: source_gl + target_gl + amount + timestamp
                            </div>
                          </div>
                        )}
                      </div>
                    </div>

                    {/* Reversal Event Details */}
                    {reversalEvent && (
                      <div className="bg-red-50 border-2 border-red-200 rounded-lg p-4">
                        <h4 className="text-red-900 font-bold mb-3 flex items-center gap-2">
                          <RotateCcw className="w-4 h-4" />
                          Reversal Event: {reversalEvent.id}
                        </h4>
                        
                        <div className="space-y-2">
                          <div className="grid grid-cols-2 gap-2">
                            <div className="bg-white rounded p-2">
                              <div className="text-red-700 text-xs">Type</div>
                              <div className="text-red-900 font-bold text-sm">{reversalEvent.type}</div>
                            </div>
                            <div className="bg-white rounded p-2">
                              <div className="text-red-700 text-xs">Timestamp</div>
                              <div className="text-red-900 font-mono text-sm">{reversalEvent.timestamp}</div>
                            </div>
                          </div>
                          
                          <div className="bg-white rounded p-3">
                            <div className="text-red-700 text-xs mb-1">Initiated By</div>
                            <div className="text-red-900 font-mono text-sm">{reversalEvent.initiated_by}</div>
                          </div>

                          <div className="bg-white rounded p-3">
                            <div className="text-red-700 text-xs mb-1">Total Reversed</div>
                            <div className="text-red-900 font-bold text-lg">
                              {formatCurrency(reversalEvent.amount_reversed)}
                            </div>
                          </div>

                          <div className="bg-white rounded p-3">
                            <div className="text-red-700 text-xs mb-1">Affected Drafts</div>
                            <div className="text-red-900 font-mono text-sm">
                              {reversalEvent.affected_drafts.join(', ')}
                            </div>
                          </div>

                          <div className="bg-white rounded p-3">
                            <div className="text-red-700 text-xs mb-1">Reason</div>
                            <div className="text-red-900 text-sm">{reversalEvent.reason}</div>
                          </div>

                          <div className="bg-white rounded p-3">
                            <div className="text-red-700 text-xs mb-1">Verification Hash</div>
                            <div className="text-red-900 font-mono text-xs break-all">
                              {reversalEvent.verification_hash}
                            </div>
                          </div>
                        </div>
                      </div>
                    )}

                    {/* Action Buttons */}
                    <div className="flex gap-2 pt-4 border-t border-slate-200">
                      <motion.button
                        whileHover={{ scale: 1.05 }}
                        whileTap={{ scale: 0.95 }}
                        onClick={() => downloadDraftReport(draft)}
                        className="flex-1 bg-purple-600 text-white px-4 py-2 rounded-lg font-medium text-sm flex items-center justify-center gap-2"
                      >
                        <Download className="w-4 h-4" />
                        Download Full Report
                      </motion.button>
                      
                      <motion.button
                        whileHover={{ scale: 1.05 }}
                        whileTap={{ scale: 0.95 }}
                        onClick={() => setVerificationMode(!verificationMode)}
                        className="flex-1 bg-slate-600 text-white px-4 py-2 rounded-lg font-medium text-sm flex items-center justify-center gap-2"
                      >
                        <Eye className="w-4 h-4" />
                        {verificationMode ? 'Hide' : 'Verify'} Hash
                      </motion.button>
                    </div>

                    {/* Hash Verification Mode */}
                    {verificationMode && (
                      <motion.div
                        initial={{ opacity: 0, height: 0 }}
                        animate={{ opacity: 1, height: 'auto' }}
                        className="bg-green-50 border border-green-200 rounded-lg p-4"
                      >
                        <h5 className="text-green-900 font-bold mb-2">Hash Verification</h5>
                        <div className="text-green-800 text-sm space-y-2">
                          <div>
                            <span className="font-mono">source_gl:</span> {draft.source_gl || 'N/A'}
                          </div>
                          <div>
                            <span className="font-mono">target_gl:</span> {draft.target_gl || 'N/A'}
                          </div>
                          <div>
                            <span className="font-mono">amount:</span> {draft.amount}
                          </div>
                          <div>
                            <span className="font-mono">timestamp:</span> {draft.created_on}
                          </div>
                          <div className="pt-2 border-t border-green-300">
                            <span className="font-mono">Calculated Hash:</span>
                            <div className="mt-1 bg-white rounded p-2 font-mono text-xs break-all">
                              {calculateIntentHash(draft)}
                            </div>
                          </div>
                          <div className="pt-2">
                            <span className="font-mono">Stored Hash:</span>
                            <div className="mt-1 bg-white rounded p-2 font-mono text-xs break-all">
                              {draft.intent_hash || 'N/A'}
                            </div>
                          </div>
                          <div className="flex items-center gap-2 text-green-700 font-bold pt-2">
                            <CheckCircle className="w-4 h-4" />
                            Hash verification available
                          </div>
                        </div>
                      </motion.div>
                    )}
                  </div>
                </motion.div>
              )}
            </motion.div>
          );
        })}
      </div>

      {/* Summary Statistics */}
      <div className="bg-gradient-to-br from-slate-50 to-slate-100 border border-slate-300 rounded-xl p-6">
        <h3 className="text-slate-900 font-bold mb-4">Draft Statistics</h3>
        <div className="grid grid-cols-4 gap-4">
          <div className="bg-white rounded-lg p-4">
            <div className="text-slate-600 text-xs mb-1">Total Drafts</div>
            <div className="text-slate-900 font-bold text-2xl">{drafts.length}</div>
          </div>
          <div className="bg-green-50 rounded-lg p-4">
            <div className="text-green-700 text-xs mb-1">Cleared</div>
            <div className="text-green-900 font-bold text-2xl">
              {drafts.filter(d => d.status === 'cleared').length}
            </div>
          </div>
          <div className="bg-red-50 rounded-lg p-4">
            <div className="text-red-700 text-xs mb-1">Canceled</div>
            <div className="text-red-900 font-bold text-2xl">
              {drafts.filter(d => d.status === 'canceled').length}
            </div>
          </div>
          <div className="bg-blue-50 rounded-lg p-4">
            <div className="text-blue-700 text-xs mb-1">Pending</div>
            <div className="text-blue-900 font-bold text-2xl">
              {drafts.filter(d => d.status === 'pending').length}
            </div>
          </div>
        </div>
      </div>

      {/* Regulatory Compliance */}
      <div className="bg-gradient-to-br from-slate-800 to-slate-900 rounded-xl p-6 text-white">
        <div className="flex items-start gap-3">
          <Shield className="w-6 h-6 text-blue-400" />
          <div className="flex-1">
            <h3 className="font-bold text-lg mb-3">Draft Management Compliance</h3>
            <div className="grid grid-cols-2 gap-3 text-sm">
              <div className="flex items-center gap-2">
                <CheckCircle className="w-4 h-4 text-green-400" />
                <span>UCC Article 4 - Bank Collections</span>
              </div>
              <div className="flex items-center gap-2">
                <CheckCircle className="w-4 h-4 text-green-400" />
                <span>Federal Reserve Regulation CC</span>
              </div>
              <div className="flex items-center gap-2">
                <CheckCircle className="w-4 h-4 text-green-400" />
                <span>Immutable audit trail with SHA-256</span>
              </div>
              <div className="flex items-center gap-2">
                <CheckCircle className="w-4 h-4 text-green-400" />
                <span>Intent hash verification system</span>
              </div>
            </div>
          </div>
        </div>
      </div>
    </motion.div>
  );
}
