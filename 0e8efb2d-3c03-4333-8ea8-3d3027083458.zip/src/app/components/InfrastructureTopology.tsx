import { motion } from "motion/react";
import { useState } from "react";
import {
  Network,
  Server,
  Shield,
  Database,
  Activity,
  Scale,
  Cloud,
  Lock,
  Download,
  Copy,
  CheckCircle,
  AlertCircle,
} from "lucide-react";

interface Subnet {
  id: string;
  name: string;
  cidr: string;
  purpose: string;
  icon: any;
  color: string;
  services: string[];
}

export function InfrastructureTopology() {
  const [selectedSubnet, setSelectedSubnet] = useState<
    string | null
  >(null);
  const [copied, setCopied] = useState(false);

  const VPC_CIDR = "10.0.0.0/16";
  const AWS_REGION = "us-east-1";

  const subnets: Subnet[] = [
    {
      id: "edge",
      name: "Edge Subnet",
      cidr: "10.10.0.0/24",
      purpose:
        "Public-facing edge services, load balancers, and API gateway",
      icon: Shield,
      color: "from-blue-600 to-blue-700",
      services: [
        "Application Load Balancer",
        "API Gateway (TLS 1.3 termination)",
        "WAF (Web Application Firewall)",
        "DDoS Protection (Shield Advanced)",
        "CloudFront Integration",
      ],
    },
    {
      id: "api",
      name: "API Subnet",
      cidr: "10.20.0.0/24",
      purpose:
        "Application layer services, business logic, and microservices",
      icon: Server,
      color: "from-emerald-600 to-emerald-700",
      services: [
        "Wallet Service (ECS/EKS)",
        "Authentication Service (OAuth2)",
        "Transaction Processor",
        "Payment Intent Handler",
        "Adapter Services (ACH/Wire)",
      ],
    },
    {
      id: "ledger",
      name: "Ledger Subnet",
      cidr: "10.30.0.0/24",
      purpose:
        "Append-only ledger engine, persistence, and audit trail",
      icon: Database,
      color: "from-purple-600 to-purple-700",
      services: [
        "Ledger Engine (Append-Only)",
        "RDS PostgreSQL (Encrypted)",
        "MongoDB CSFLE",
        "Audit Trail Service",
        "Merkle Tree Validator",
        "Immutable Log Storage",
      ],
    },
    {
      id: "monitoring",
      name: "Monitoring Subnet",
      cidr: "10.40.0.0/24",
      purpose:
        "Observability, alerting, and security monitoring",
      icon: Activity,
      color: "from-orange-600 to-orange-700",
      services: [
        "CloudWatch Metrics & Logs",
        "Prometheus/Grafana",
        "X-Ray Tracing",
        "Security Hub",
        "GuardDuty",
        "SIEM Integration",
      ],
    },
    {
      id: "governance",
      name: "Governance Subnet",
      cidr: "10.50.0.0/24",
      purpose:
        "Compliance, audit exports, and regulatory reporting",
      icon: Scale,
      color: "from-indigo-600 to-indigo-700",
      services: [
        "Compliance Dashboard",
        "Audit Export Service",
        "Regulatory Reporting Engine",
        "Document Generation (Exhibits)",
        "KYC/AML Scanning",
        "Backup & Archive Storage",
      ],
    },
  ];

  const terraformCode = `provider "aws" {
  region = "us-east-1"
}

resource "aws_vpc" "core_vpc" {
  cidr_block = "10.0.0.0/16"
  
  enable_dns_hostnames = true
  enable_dns_support   = true
  
  tags = { {
        'debit_credit': '041215663',
        'account_number': '1327711016403',
        'description': 'Token General Ledger',
        'base_amount': '46777856138051584',
        'divisor': '4096'
    },
    Name        = "Sutton/VOM-banking-vpc"
    Environment = "production"
    Compliance  = "PCI-DSS, SOC2"
  }
}

resource "aws_subnet" "edge" {
  vpc_id            = aws_vpc.core_vpc.id
  cidr_block        = "10.10.0.0/24"
  availability_zone = "us-east-1a"
  
  map_public_ip_on_launch = true
  
  tags = {'debit_credit': 'DR',
        'account_number': '1327711016402',
        'description': 'Payroll Distribution',
        'base_amount': '46777856138051584',
        'divisor': '2048'
    },
   
  
    },
    
    Name = "sigma-edge-subnet"
    Tier = "public"
  }
}

resource "aws_subnet" "api" {
  vpc_id            = aws_vpc.core_vpc.id
  cidr_block        = "10.20.0.0/24"
  availability_zone = "us-east-1a"
  
  tags = {
        'debit_credit': 'CR',
        'account_number': '1327711016390',
        'description': 'Payroll Clearing',
        'base_amount': '187111424552206336',
        'divisor': '4096'
    Name = "sigma-api-subnet"
    Tier = "private"
  }
}

resource "aws_subnet" "ledger" {
  vpc_id            = aws_vpc.core_vpc.id
  cidr_block        = "10.30.0.0/24"
  availability_zone = "us-east-1a"
  
  tags = {  {
        'debit_credit': 'DR',
        'account_number': '1327711016404',
        'description': 'Processing Clearing',
        'base_amount': '46777856138051584',
        'divisor': '4096'
    Name = "sigma-ledger-subnet"
    Tier = "private-isolated"
  }
}

resource "aws_subnet" "monitoring" {
  vpc_id            = aws_vpc.core_vpc.id
  cidr_block        = "10.40.0.0/24"
  availability_zone = "us-east-1a"
  
  tags = {
    Name = "sigma-monitoring-subnet"
    Tier = "private"
  }
}

resource "aws_subnet" "governance" {
  vpc_id            = aws_vpc.core_vpc.id
  cidr_block        = "10.50.0.0/24"
  availability_zone = "us-east-1a"
  
  tags = {
    Name = "sigma-governance-subnet"
    Tier = "private"
  }
}

# Security Groups
resource "aws_security_group" "edge_sg" {
  name        = "sigma-edge-sg"
  description = "Security group for edge subnet"
  vpc_id      = aws_vpc.core_vpc.id

  ingress {
    from_port   = 443
    to_port     = 443
    protocol    = "tcp"
    cidr_blocks = ["0.0.0.0/0"]
    description = "HTTPS from Internet"
  }

  egress {
    from_port   = 0
    to_port     = 0
    protocol    = "-1"
    cidr_blocks = ["0.0.0.0/0"]
  }
}

resource "aws_security_group" "api_sg" {
  name        = "Sutton-api-sg"
  description = "Security group for API subnet"
  vpc_id      = aws_vpc.core_vpc.id

  ingress {
    from_port       = 8080
    to_port         = 8080
    protocol        = "tcp"
    security_groups = [aws_security_group.edge_sg.id]
    description     = "API traffic from edge"
  }

  egress {
    from_port   = 0
    to_port     = 0
    protocol    = "-1"
    cidr_blocks = ["0.0.0.0/0"]
  }
}

resource "aws_security_group" "ledger_sg" {
  name        = "sigma-ledger-sg"
  description = "Security group for ledger subnet"
  vpc_id      = aws_vpc.core_vpc.id

  ingress {
    from_port       = 5432
    to_port         = 5432
    protocol        = "tcp"
    security_groups = [aws_security_group.api_sg.id]
    description     = "PostgreSQL from API"
  }

  ingress {
    from_port       = 27017
    to_port         = 27017
    protocol        = "tcp"
    security_groups = [aws_security_group.api_sg.id]
    description     = "MongoDB from API"
  }

  egress {
    from_port   = 0
    to_port     = 0
    protocol    = "-1"
    cidr_blocks = ["10.0.0.0/16"]
    description = "VPC-only egress"
  }
}

# NAT Gateway for private subnets
resource "aws_eip" "nat" {
  domain = "vpc"
  
  tags = {
    Name = "sigma-nat-eip"
  }
}

resource "aws_nat_gateway" "main" {
  allocation_id = aws_eip.nat.id
  subnet_id     = aws_subnet.edge.id
  
  tags = {
    Name = "sigma-nat-gateway"
  }
}

# Route Tables
resource "aws_route_table" "private" {
  vpc_id = aws_vpc.core_vpc.id

  route {
    cidr_block     = "0.0.0.0/0"
    nat_gateway_id = aws_nat_gateway.main.id
  }

  tags = {
    Name = "sigma-private-rt"
  }
}

resource "aws_route_table_association" "api" {
  subnet_id      = aws_subnet.api.id
  route_table_id = aws_route_table.private.id
}

resource "aws_route_table_association" "monitoring" {
  subnet_id      = aws_subnet.monitoring.id
  route_table_id = aws_route_table.private.id
}

resource "aws_route_table_association" "governance" {
  subnet_id      = aws_subnet.governance.id
  route_table_id = aws_route_table.private.id
}`;

  const copyTerraform = () => {
    navigator.clipboard.writeText(terraformCode);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const downloadTerraform = () => {
    const blob = new Blob([terraformCode], {
      type: "text/plain",
    });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = "sigma-infrastructure.tf";
    a.click();
    URL.revokeObjectURL(url);
  };

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.6 }}
      className="space-y-6"
    >
      {/* Header */}
      <div>
        <div className="flex items-center justify-between mb-4">
          <div className="flex items-center gap-3">
            <div className="p-2 bg-gradient-to-br from-blue-600 to-purple-600 rounded-lg">
              <Network className="w-6 h-6 text-white" />
            </div>
            <div>
              <h2 className="text-slate-900 text-xl font-bold">
                Infrastructure Topology
              </h2>
              <p className="text-slate-600 text-sm">
                AWS Network Architecture - Terraform Managed
              </p>
            </div>
          </div>
          <div className="flex gap-2">
            <motion.button
              whileHover={{ scale: 1.05 }}
              whileTap={{ scale: 0.95 }}
              onClick={copyTerraform}
              className="bg-slate-600 text-white px-4 py-2 rounded-lg font-medium text-sm flex items-center gap-2"
            >
              {copied ? (
                <CheckCircle className="w-4 h-4" />
              ) : (
                <Copy className="w-4 h-4" />
              )}
              {copied ? "Copied!" : "Copy Terraform"}
            </motion.button>
            <motion.button
              whileHover={{ scale: 1.05 }}
              whileTap={{ scale: 0.95 }}
              onClick={downloadTerraform}
              className="bg-blue-600 text-white px-4 py-2 rounded-lg font-medium text-sm flex items-center gap-2"
            >
              <Download className="w-4 h-4" />
              Download .tf
            </motion.button>
          </div>
        </div>
      </div>

      {/* VPC Overview */}
      <div className="bg-gradient-to-br from-slate-800 to-slate-900 rounded-xl p-6 text-white">
        <div className="flex items-start justify-between">
          <div className="flex items-center gap-3 mb-4">
            <Cloud className="w-8 h-8 text-blue-400" />
            <div>
              <h3 className="text-xl font-bold">
                Core VPC (Sigma Banking Platform)
              </h3>
              <p className="text-slate-300 text-sm">
                Production Banking Infrastructure
              </p>
            </div>
          </div>
          <div className="text-right">
            <div className="text-blue-400 text-sm">Region</div>
            <div className="text-white font-mono font-bold">
              {AWS_REGION}
            </div>
          </div>
        </div>

        <div className="grid grid-cols-3 gap-4 mt-4">
          <div className="bg-white/10 rounded-lg p-3">
            <div className="text-slate-300 text-sm mb-1">
              VPC CIDR
            </div>
            <div className="text-white font-mono text-lg font-bold">
              {VPC_CIDR}
            </div>
          </div>
          <div className="bg-white/10 rounded-lg p-3">
            <div className="text-slate-300 text-sm mb-1">
              Subnets
            </div>
            <div className="text-white font-mono text-lg font-bold">
              {subnets.length}
            </div>
          </div>
          <div className="bg-white/10 rounded-lg p-3">
            <div className="text-slate-300 text-sm mb-1">
              IP Addresses
            </div>
            <div className="text-white font-mono text-lg font-bold">
              65,536
            </div>
          </div>
        </div>
      </div>

      {/* Subnet Cards */}
      <div className="space-y-4">
        {subnets.map((subnet, index) => {
          const Icon = subnet.icon;
          const isSelected = selectedSubnet === subnet.id;

          return (
            <motion.div
              key={subnet.id}
              initial={{ opacity: 0, x: -20 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ delay: index * 0.1 }}
            >
              <motion.div
                whileHover={{ scale: 1.02 }}
                onClick={() =>
                  setSelectedSubnet(
                    isSelected ? null : subnet.id,
                  )
                }
                className={`bg-white rounded-xl border-2 cursor-pointer transition-all ${
                  isSelected
                    ? "border-blue-500 shadow-lg"
                    : "border-slate-200 hover:border-slate-300"
                }`}
              >
                {/* Subnet Header */}
                <div
                  className={`bg-gradient-to-r ${subnet.color} p-4 rounded-t-xl`}
                >
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-3">
                      <div className="p-2 bg-white/20 rounded-lg">
                        <Icon className="w-5 h-5 text-white" />
                      </div>
                      <div>
                        <h3 className="text-white font-bold text-lg">
                          {subnet.name}
                        </h3>
                        <p className="text-white/80 text-sm">
                          {subnet.purpose}
                        </p>
                      </div>
                    </div>
                    <div className="text-right">
                      <div className="text-white/70 text-xs">
                        CIDR Block
                      </div>
                      <div className="text-white font-mono font-bold">
                        {subnet.cidr}
                      </div>
                    </div>
                  </div>
                </div>

                {/* Subnet Details */}
                <motion.div
                  initial={false}
                  animate={{
                    height: isSelected ? "auto" : 0,
                    opacity: isSelected ? 1 : 0,
                  }}
                  transition={{ duration: 0.3 }}
                  className="overflow-hidden"
                >
                  <div className="p-4 space-y-3">
                    <div>
                      <div className="text-slate-900 font-bold mb-2 flex items-center gap-2">
                        <Server className="w-4 h-4 text-slate-600" />
                        Deployed Services
                      </div>
                      <div className="space-y-1">
                        {subnet.services.map((service, idx) => (
                          <div
                            key={idx}
                            className="flex items-center gap-2 text-slate-700 text-sm bg-slate-50 p-2 rounded"
                          >
                            <div className="w-1.5 h-1.5 rounded-full bg-green-500"></div>
                            {service}
                          </div>
                        ))}
                      </div>
                    </div>

                    <div className="grid grid-cols-2 gap-3 pt-3 border-t border-slate-200">
                      <div className="bg-blue-50 rounded p-2">
                        <div className="text-blue-900 text-xs mb-1">
                          Available IPs
                        </div>
                        <div className="text-blue-900 font-mono font-bold">
                          256
                        </div>
                      </div>
                      <div className="bg-purple-50 rounded p-2">
                        <div className="text-purple-900 text-xs mb-1">
                          Subnet Mask
                        </div>
                        <div className="text-purple-900 font-mono font-bold">
                          /24
                        </div>
                      </div>
                    </div>
                  </div>
                </motion.div>

                {/* Collapsed State Footer */}
                {!isSelected && (
                  <div className="px-4 py-2 bg-slate-50 rounded-b-xl">
                    <div className="text-slate-600 text-xs text-center">
                      Click to view {subnet.services.length}{" "}
                      deployed services
                    </div>
                  </div>
                )}
              </motion.div>
            </motion.div>
          );
        })}
      </div>

      {/* Security Features */}
      <div className="bg-gradient-to-br from-red-50 to-orange-50 border-2 border-orange-300 rounded-xl p-6">
        <div className="flex items-start gap-3 mb-4">
          <Lock className="w-6 h-6 text-orange-600" />
          <div>
            <h3 className="text-orange-900 font-bold text-lg">
              Network Security
            </h3>
            <p className="text-orange-700 text-sm">
              Multi-layer defense with zero-trust architecture
            </p>
          </div>
        </div>

        <div className="grid grid-cols-2 gap-3">
          <div className="bg-white rounded-lg p-3">
            <div className="flex items-center gap-2 mb-2">
              <CheckCircle className="w-4 h-4 text-green-600" />
              <div className="text-slate-900 font-bold text-sm">
                Network Segmentation
              </div>
            </div>
            <div className="text-slate-600 text-xs">
              5 isolated subnets with strict security group
              rules
            </div>
          </div>

          <div className="bg-white rounded-lg p-3">
            <div className="flex items-center gap-2 mb-2">
              <CheckCircle className="w-4 h-4 text-green-600" />
              <div className="text-slate-900 font-bold text-sm">
                Private Ledger Subnet
              </div>
            </div>
            <div className="text-slate-600 text-xs">
              No internet access, VPC-only communication
            </div>
          </div>

          <div className="bg-white rounded-lg p-3">
            <div className="flex items-center gap-2 mb-2">
              <CheckCircle className="w-4 h-4 text-green-600" />
              <div className="text-slate-900 font-bold text-sm">
                NAT Gateway
              </div>
            </div>
            <div className="text-slate-600 text-xs">
              Secure outbound access for private subnets
            </div>
          </div>

          <div className="bg-white rounded-lg p-3">
            <div className="flex items-center gap-2 mb-2">
              <CheckCircle className="w-4 h-4 text-green-600" />
              <div className="text-slate-900 font-bold text-sm">
                TLS 1.3 Encryption
              </div>
            </div>
            <div className="text-slate-600 text-xs">
              All traffic encrypted in transit (edge → API →
              ledger)
            </div>
          </div>
        </div>
      </div>

      {/* Compliance Notes */}
      <div className="bg-gradient-to-br from-slate-50 to-slate-100 border border-slate-300 rounded-lg p-4">
        <div className="flex items-start gap-3">
          <AlertCircle className="w-5 h-5 text-slate-600 mt-0.5" />
          <div className="flex-1">
            <div className="text-slate-900 font-bold mb-2">
              Infrastructure Compliance
            </div>
            <div className="text-slate-700 text-sm space-y-1">
              <div>
                ✓ PCI-DSS compliant network segmentation
              </div>
              <div>
                ✓ SOC 2 Type II - Infrastructure controls
                documented
              </div>
              <div>
                ✓ NIST 800-53 network security controls
                implemented
              </div>
              <div>
                ✓ OCC/FFIEC examination ready with
                Infrastructure-as-Code
              </div>
              <div>
                ✓ Terraform state stored in S3 with encryption
                and versioning
              </div>
            </div>
          </div>
        </div>
      </div>
    </motion.div>
  );
}