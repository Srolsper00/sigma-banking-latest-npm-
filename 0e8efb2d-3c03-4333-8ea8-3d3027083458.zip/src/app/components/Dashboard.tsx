import { useState } from 'react';
import { useLedger } from '../hooks/useLedger';
import { Wallet, ArrowDownCircle, ArrowUpCircle, Shield, TrendingUp } from 'lucide-react';

export function Dashboard() {
  const { accounts, wallets, transactions } = useLedger();

  const totalDDABalance = accounts.reduce((sum, acc) => sum + acc.balance, 0);
  const totalWalletBalance = wallets.reduce((sum, w) => sum + w.balance, 0);
  const todayTransactions = transactions.filter(t => {
    const today = new Date();
    const txDate = new Date(t.timestamp);
    return txDate.toDateString() === today.toDateString();
  });

  return (
    <div className="space-y-6">
      {/* Stats Overview */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        <div className="bg-white rounded-lg p-6 shadow-sm border border-slate-200">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-slate-600">Total DDA Balance</p>
              <p className="text-slate-900 mt-2">${totalDDABalance.toLocaleString('en-US', { minimumFractionDigits: 2 })}</p>
            </div>
            <div className="bg-blue-100 p-3 rounded-lg">
              <Wallet className="w-6 h-6 text-blue-600" />
            </div>
          </div>
        </div>

        <div className="bg-white rounded-lg p-6 shadow-sm border border-slate-200">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-slate-600">Wallet Balance</p>
              <p className="text-slate-900 mt-2">${totalWalletBalance.toLocaleString('en-US', { minimumFractionDigits: 2 })}</p>
            </div>
            <div className="bg-green-100 p-3 rounded-lg">
              <TrendingUp className="w-6 h-6 text-green-600" />
            </div>
          </div>
        </div>

        <div className="bg-white rounded-lg p-6 shadow-sm border border-slate-200">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-slate-600">Today's Transactions</p>
              <p className="text-slate-900 mt-2">{todayTransactions.length}</p>
            </div>
            <div className="bg-purple-100 p-3 rounded-lg">
              <ArrowUpCircle className="w-6 h-6 text-purple-600" />
            </div>
          </div>
        </div>

        <div className="bg-white rounded-lg p-6 shadow-sm border border-slate-200">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-slate-600">Encrypted Transactions</p>
              <p className="text-slate-900 mt-2">{transactions.filter(t => t.encrypted).length}</p>
            </div>
            <div className="bg-amber-100 p-3 rounded-lg">
              <Shield className="w-6 h-6 text-amber-600" />
            </div>
          </div>
        </div>
      </div>

      {/* DDA Accounts */}
      <div className="bg-white rounded-lg p-6 shadow-sm border border-slate-200">
        <h2 className="text-slate-900 mb-4">DDA Accounts</h2>
        <div className="space-y-4">
          {accounts.map(account => (
            <div key={account.accountNumber} className="flex items-center justify-between p-4 bg-slate-50 rounded-lg">
              <div className="flex-1">
                <p className="text-slate-900">{account.accountName}</p>
                <p className="text-slate-600">Account: ****{account.accountNumber.slice(-4)}</p>
              </div>
              <div className="text-right">
                <p className="text-slate-900">${account.balance.toLocaleString('en-US', { minimumFractionDigits: 2 })}</p>
                <span className={`inline-block px-2 py-1 rounded text-xs ${
                  account.status === 'active' ? 'bg-green-100 text-green-800' : 'bg-red-100 text-red-800'
                }`}>
                  {account.status}
                </span>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Wallets */}
      <div className="bg-white rounded-lg p-6 shadow-sm border border-slate-200">
        <h2 className="text-slate-900 mb-4">Active Wallets</h2>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {wallets.map(wallet => (
            <div key={wallet.id} className="p-4 bg-slate-50 rounded-lg border border-slate-200">
              <div className="flex items-start justify-between mb-3">
                <div>
                  <p className="text-slate-900">{wallet.name}</p>
                  <p className="text-slate-600">{wallet.type}</p>
                </div>
                {wallet.encrypted && (
                  <Shield className="w-5 h-5 text-green-600" />
                )}
              </div>
              <p className="text-slate-900 mb-2">${wallet.balance.toLocaleString('en-US', { minimumFractionDigits: 2 })}</p>
              <p className="text-slate-500 break-all">{wallet.address}</p>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}