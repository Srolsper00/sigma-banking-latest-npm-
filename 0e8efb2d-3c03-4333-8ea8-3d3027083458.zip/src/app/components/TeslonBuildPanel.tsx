import { motion } from 'motion/react';
import { Code2, Server, Cpu, FileCode } from 'lucide-react';

export function TeslonBuildPanel() {
  const teslonConfig = {
    version: "3.0",
    builders: [
      {
        language: "python",
        role: "core_application",
        spdx: "python-app.spdx.json",
        icon: "🐍",
        color: "blue",
        description: "Primary application logic and API services"
      },
      {
        language: "perl",
        role: "operations",
        spdx: "perl-ops.spdx.json",
        icon: "🐫",
        color: "purple",
        description: "Operational tooling and automation scripts"
      },
      {
        platform: "centos",
        role: "ml_compute",
        spdx: "centos-ml.spdx.json",
        icon: "🖥️",
        color: "green",
        description: "Machine learning compute infrastructure"
      }
    ]
  };

  const getColorClasses = (color: string) => {
    const colors = {
      blue: { 
        bg: 'bg-blue-500', 
        light: 'bg-blue-50', 
        border: 'border-blue-300', 
        text: 'text-blue-700',
        gradient: 'from-blue-600 to-blue-700'
      },
      purple: { 
        bg: 'bg-purple-500', 
        light: 'bg-purple-50', 
        border: 'border-purple-300', 
        text: 'text-purple-700',
        gradient: 'from-purple-600 to-purple-700'
      },
      green: { 
        bg: 'bg-green-500', 
        light: 'bg-green-50', 
        border: 'border-green-300', 
        text: 'text-green-700',
        gradient: 'from-green-600 to-green-700'
      }
    };
    return colors[color as keyof typeof colors];
  };

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.6 }}
      className="mt-8"
    >
      <div className="bg-white rounded-xl shadow-lg border border-slate-200 overflow-hidden">
        {/* Header */}
        <div className="bg-gradient-to-r from-slate-900 to-slate-800 p-6">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <div className="p-2 bg-white/10 rounded-lg">
                <Code2 className="w-6 h-6 text-white" />
              </div>
              <div>
                <h2 className="text-white">Teslon Build System</h2>
                <p className="text-slate-300 text-sm">Multi-language production stack v{teslonConfig.version}</p>
              </div>
            </div>
            <div className="bg-gradient-to-r from-blue-600 to-purple-600 text-white px-4 py-2 rounded-lg">
              <span className="text-sm font-medium">{teslonConfig.builders.length} Builders</span>
            </div>
          </div>
        </div>

        {/* Builders */}
        <div className="p-6 space-y-4">
          {teslonConfig.builders.map((builder, index) => {
            const colors = getColorClasses(builder.color);
            const title = builder.language || builder.platform;
            
            return (
              <motion.div
                key={index}
                initial={{ opacity: 0, x: -20 }}
                animate={{ opacity: 1, x: 0 }}
                transition={{ delay: index * 0.1 }}
                className={`${colors.light} border-2 ${colors.border} rounded-lg overflow-hidden`}
              >
                {/* Builder Header */}
                <div className={`bg-gradient-to-r ${colors.gradient} p-4`}>
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-3">
                      <span className="text-3xl">{builder.icon}</span>
                      <div>
                        <h3 className="text-white font-medium uppercase tracking-wide">{title}</h3>
                        <p className="text-white/80 text-sm">{builder.role.replace(/_/g, ' ')}</p>
                      </div>
                    </div>
                    <div className="bg-white/20 text-white px-3 py-1 rounded text-xs font-mono">
                      {builder.spdx}
                    </div>
                  </div>
                </div>

                {/* Builder Details */}
                <div className="p-4">
                  <p className={`${colors.text} text-sm mb-3`}>{builder.description}</p>
                  
                  {/* Technical Specs */}
                  <div className="grid grid-cols-3 gap-2">
                    <div className="bg-white border border-slate-200 rounded p-2">
                      <div className="text-xs text-slate-500 mb-1">Type</div>
                      <div className={`${colors.text} text-sm font-medium`}>
                        {builder.language ? 'Language' : 'Platform'}
                      </div>
                    </div>
                    <div className="bg-white border border-slate-200 rounded p-2">
                      <div className="text-xs text-slate-500 mb-1">Role</div>
                      <div className={`${colors.text} text-sm font-medium`}>
                        {builder.role.split('_')[0]}
                      </div>
                    </div>
                    <div className="bg-white border border-slate-200 rounded p-2">
                      <div className="text-xs text-slate-500 mb-1">SPDX</div>
                      <div className={`${colors.text} text-sm font-medium`}>✓</div>
                    </div>
                  </div>
                </div>
              </motion.div>
            );
          })}
        </div>

        {/* Build Pipeline Visualization */}
        <div className="px-6 pb-6">
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ delay: 0.4 }}
            className="bg-slate-50 rounded-lg p-4 border border-slate-200"
          >
            <h4 className="text-slate-700 mb-3 flex items-center gap-2">
              <Server className="w-4 h-4" />
              Build Pipeline Flow
            </h4>
            <div className="flex items-center justify-between">
              {teslonConfig.builders.map((builder, i) => (
                <div key={i} className="flex items-center">
                  <div className="text-center">
                    <div className={`w-12 h-12 bg-gradient-to-br ${getColorClasses(builder.color).gradient} rounded-lg flex items-center justify-center mb-1`}>
                      <span className="text-2xl">{builder.icon}</span>
                    </div>
                    <div className="text-xs text-slate-600">{(builder.language || builder.platform).toUpperCase()}</div>
                  </div>
                  {i < teslonConfig.builders.length - 1 && (
                    <div className="mx-2 flex-1 h-0.5 bg-gradient-to-r from-slate-300 to-slate-400 w-16"></div>
                  )}
                </div>
              ))}
            </div>
          </motion.div>
        </div>

        {/* SBOM Info */}
        <div className="px-6 pb-6">
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ delay: 0.5 }}
            className="bg-gradient-to-r from-amber-50 to-orange-50 border border-amber-300 rounded-lg p-4"
          >
            <div className="flex items-start gap-3">
              <FileCode className="w-5 h-5 text-amber-700 mt-0.5" />
              <div>
                <h4 className="text-amber-900 font-medium mb-1">Software Bill of Materials (SBOM)</h4>
                <p className="text-amber-800 text-sm">
                  All components tracked with SPDX-compliant manifests for supply chain security and compliance
                </p>
              </div>
            </div>
          </motion.div>
        </div>
      </div>
    </motion.div>
  );
}
