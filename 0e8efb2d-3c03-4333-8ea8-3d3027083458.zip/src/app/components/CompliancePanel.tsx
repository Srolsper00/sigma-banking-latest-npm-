import { motion } from 'motion/react';
import { AlertTriangle, Shield, FileText, CheckCircle } from 'lucide-react';

export function CompliancePanel() {
  const regulations = [
    {
      id: 'reg-e',
      title: 'Regulation E',
      icon: FileText,
      color: 'blue',
      requirements: [
        'Employee must have given consent for direct deposit',
        'Provide statement at least quarterly or monthly if EFT occurred',
        'Ensure employee notification mechanism is in place',
        'Maintain audit evidence of consent and notifications'
      ]
    },
    {
      id: 'insider',
      title: 'Insider Lending / §215',
      icon: AlertTriangle,
      color: 'amber',
      requirements: [
        'Board approvals required for preferential credit to insiders',
        'Prior approval and abstention rules must be followed',
        'Monitor payroll benefits or housing allocations',
        'Document compliance with limits and approval procedures'
      ]
    },
    {
      id: 'work-hours',
      title: '24-Hour Work Flags',
      icon: Shield,
      color: 'red',
      requirements: [
        'Document safety justification if actual 24-hour shift',
        'Flag suspicious continuous work periods for review',
        'Correct timesheet errors before payroll processing',
        'Re-run payroll calculation after corrections'
      ]
    }
  ];

  const getColorClasses = (color: string) => {
    const colors = {
      blue: {
        bg: 'bg-blue-50',
        border: 'border-blue-300',
        text: 'text-blue-900',
        iconBg: 'bg-blue-500',
        badge: 'bg-blue-100 text-blue-700'
      },
      amber: {
        bg: 'bg-amber-50',
        border: 'border-amber-300',
        text: 'text-amber-900',
        iconBg: 'bg-amber-500',
        badge: 'bg-amber-100 text-amber-700'
      },
      red: {
        bg: 'bg-red-50',
        border: 'border-red-300',
        text: 'text-red-900',
        iconBg: 'bg-red-500',
        badge: 'bg-red-100 text-red-700'
      }
    };
    return colors[color as keyof typeof colors];
  };

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.6 }}
      className="mt-8"
    >
      <div className="bg-white rounded-lg shadow-lg border border-slate-200 p-6">
        <div className="flex items-center gap-3 mb-6">
          <div className="p-2 bg-slate-900 rounded-lg">
            <Shield className="w-6 h-6 text-white" />
          </div>
          <div>
            <h2 className="text-slate-900">Compliance & Examiner Notes</h2>
            <p className="text-slate-600 text-sm">Regulatory requirements for payroll processing</p>
          </div>
        </div>

        <div className="space-y-4">
          {regulations.map((reg, index) => {
            const colors = getColorClasses(reg.color);
            const Icon = reg.icon;
            
            return (
              <motion.div
                key={reg.id}
                initial={{ opacity: 0, x: -20 }}
                animate={{ opacity: 1, x: 0 }}
                transition={{ delay: index * 0.1 }}
                className={`${colors.bg} border-2 ${colors.border} rounded-lg p-5`}
              >
                <div className="flex items-start gap-3 mb-3">
                  <div className={`p-2 ${colors.iconBg} rounded-lg`}>
                    <Icon className="w-5 h-5 text-white" />
                  </div>
                  <div className="flex-1">
                    <h3 className={`${colors.text} mb-1`}>{reg.title}</h3>
                    <div className="space-y-2 mt-3">
                      {reg.requirements.map((req, reqIndex) => (
                        <div key={reqIndex} className="flex items-start gap-2">
                          <CheckCircle className={`w-4 h-4 mt-0.5 flex-shrink-0 ${colors.text}`} />
                          <span className={`text-sm ${colors.text}`}>{req}</span>
                        </div>
                      ))}
                    </div>
                  </div>
                </div>
              </motion.div>
            );
          })}
        </div>

        {/* Compliance Status */}
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 0.4 }}
          className="mt-6 pt-6 border-t border-slate-200"
        >
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <CheckCircle className="w-5 h-5 text-green-600" />
              <span className="text-slate-700">Compliance Checks Active</span>
            </div>
            <span className="text-xs text-slate-500 font-mono">Last audit: 2025-09-14 12:51 UTC</span>
          </div>
        </motion.div>
      </div>
    </motion.div>
  );
}
