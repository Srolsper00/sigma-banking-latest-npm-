import { useState } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from './ui/card';
import { Tabs, TabsContent, TabsList, TabsTrigger } from './ui/tabs';
import { Badge } from './ui/badge';
import { Button } from './ui/button';
import { LiquidityManagement } from './LiquidityManagement';
import { GeneralLedgerExhibit } from './GeneralLedgerExhibit';
import { BankActivationPanel } from './BankActivationPanel';
import { EmbeddedBankUI } from './EmbeddedBankUI';
import { CompliancePanel } from './CompliancePanel';
import { RunbookPanel } from './RunbookPanel';
import { SystemDossierPanel } from './SystemDossierPanel';
import { TeslonBuildPanel } from './TeslonBuildPanel';
import { ProcessingModelPanel } from './ProcessingModelPanel';
import { SecurityTopographicArray } from './SecurityTopographicArray';
import { ATMSecurityCenter } from './ATMSecurityCenter';
import { AlertCircle, CheckCircle2, TrendingUp, DollarSign } from 'lucide-react';

export function GenesisClearing() {
  const [activePool, setActivePool] = useState<string>('genesis');
  const [bankActivated, setBankActivated] = useState<boolean>(false);

  const genesisPool = {
    totalLiquidity: 125000000000,
    assets: [
      { symbol: 'ETH', balance: 50000000000, allocation: 40 },
      { symbol: 'WBTC', balance: 37500000000, allocation: 30 },
      { symbol: 'BTC', balance: 25000000000, allocation: 20 },
      { symbol: 'USDC', balance: 12500000000, allocation: 10 }
    ],
    status: 'ACTIVE',
    clearingPartner: 'UMB NA'
  };

  const clearingStats = [
    { label: 'Daily Volume', value: '$2.4B', status: 'up' },
    { label: 'Pending Settlements', value: '142', status: 'normal' },
    { label: 'Success Rate', value: '99.97%', status: 'up' },
    { label: 'Avg. Settlement Time', value: '2.3s', status: 'normal' }
  ];

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-3xl font-bold text-slate-800">Genesis Clearing Banking</h2>
          <p className="text-slate-600 mt-1">Crypto Asset Integration & Liquidity Management</p>
        </div>
        <Badge variant="outline" className="bg-green-50 text-green-700 border-green-300">
          <CheckCircle2 className="w-4 h-4 mr-1" />
          UMB NA Active
        </Badge>
      </div>

      {/* Stats Grid */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        {clearingStats.map((stat, idx) => (
          <Card key={idx}>
            <CardContent className="pt-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-slate-600">{stat.label}</p>
                  <p className="text-2xl font-bold text-slate-800 mt-1">{stat.value}</p>
                </div>
                {stat.status === 'up' && <TrendingUp className="w-5 h-5 text-green-600" />}
                {stat.status === 'normal' && <DollarSign className="w-5 h-5 text-blue-600" />}
              </div>
            </CardContent>
          </Card>
        ))}
      </div>

      {/* Genesis Pool Overview */}
      <Card className="border-2 border-purple-200 bg-gradient-to-br from-purple-50 to-white">
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <span className="text-2xl">💎</span>
            Genesis Pool Overview
          </CardTitle>
          <CardDescription>
            Total Liquidity: ${(genesisPool.totalLiquidity / 1000000000).toFixed(1)}B
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            {genesisPool.assets.map((asset) => (
              <div key={asset.symbol} className="flex items-center justify-between p-4 bg-white rounded-lg border">
                <div className="flex items-center gap-4">
                  <div className="text-lg font-bold text-slate-700">{asset.symbol}</div>
                  <div className="text-sm text-slate-600">
                    ${(asset.balance / 1000000000).toFixed(1)}B
                  </div>
                </div>
                <div className="flex items-center gap-4">
                  <div className="w-32 bg-slate-200 rounded-full h-2">
                    <div 
                      className="bg-purple-600 h-2 rounded-full"
                      style={{ width: `${asset.allocation}%` }}
                    />
                  </div>
                  <div className="text-sm font-semibold text-slate-700 w-12 text-right">
                    {asset.allocation}%
                  </div>
                </div>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>

      {/* Main Tabs */}
      <Tabs defaultValue="liquidity" className="w-full">
        <TabsList className="grid w-full grid-cols-5 mb-4">
          <TabsTrigger value="liquidity">Liquidity</TabsTrigger>
          <TabsTrigger value="ledger">Ledger</TabsTrigger>
          <TabsTrigger value="compliance">Compliance</TabsTrigger>
          <TabsTrigger value="operations">Operations</TabsTrigger>
          <TabsTrigger value="security">Security</TabsTrigger>
        </TabsList>

        <TabsContent value="liquidity" className="mt-6">
          <LiquidityManagement />
        </TabsContent>

        <TabsContent value="ledger" className="mt-6">
          <GeneralLedgerExhibit />
        </TabsContent>

        <TabsContent value="compliance" className="mt-6 space-y-6">
          <CompliancePanel />
          <RunbookPanel />
        </TabsContent>

        <TabsContent value="operations" className="mt-6 space-y-6">
          <BankActivationPanel 
            onActivate={() => setBankActivated(true)}
            isActivated={bankActivated}
          />
          {bankActivated && <EmbeddedBankUI />}
          <SystemDossierPanel />
          <TeslonBuildPanel />
          <ProcessingModelPanel />
        </TabsContent>

        <TabsContent value="security" className="mt-6 space-y-6">
          <SecurityTopographicArray />
          <ATMSecurityCenter />
        </TabsContent>
      </Tabs>
    </div>
  );
}