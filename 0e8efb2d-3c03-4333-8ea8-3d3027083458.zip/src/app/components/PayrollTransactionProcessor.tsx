import { motion } from 'motion/react';
import { useState, useEffect } from 'react';
import { 
  DollarSign, 
  Building2, 
  Shield, 
  CheckCircle, 
  AlertTriangle,
  Clock,
  Hash,
  Lock,
  ArrowRight,
  FileCheck,
  Database
} from 'lucide-react';

interface PayrollTransaction {
  idempotency_key: string;
  event_type: string;
  description: string;
  effective_at: string;
  amount: {
    total: number;
    currency: string;
    precision: number;
  };
  destination: {
    bank_name: string;
    routing_number: string;
    account_number: string;
    account_type: string;
  };
  controls: {
    idempotent: boolean;
    replay_protection: string;
    settlement_type: string;
    posting_mode: string;
  };
  audit: {
    requested_by: string;
    source_system: string;
    trace_id: string;
    hash_algorithm: string;
  };
}

export function PayrollTransactionProcessor() {
  const [transaction, setTransaction] = useState<PayrollTransaction | null>(null);
  const [processingStage, setProcessingStage] = useState<number>(0);
  const [validations, setValidations] = useState<{[key: string]: boolean}>({});
  const [showDetails, setShowDetails] = useState(false);

  // Sample transaction from the payload
  const sampleTransaction: PayrollTransaction = {
    idempotency_key: "a329c411-2464-4ce0-a490-068c68661c27",
    event_type: "payroll_deposit",
    description: "Payroll deposits to UMB NA Bank checking account",
    effective_at: "2025-09-14T12:51:00Z",
    amount: {
      total: 50000000,
      currency: "USD",
      precision: 2
    },
    destination: {
      bank_name: "UMB NA",
      routing_number: "101205681",
      account_number: "39900000585459050",
      account_type: "checking"
    },
    controls: {
      idempotent: true,
      replay_protection: "nonce-bound",
      settlement_type: "ACH",
      posting_mode: "credit"
    },
    audit: {
      requested_by: "payroll_system",
      source_system: "internal-payroll-ledger",
      trace_id: "trace-7f2c9d8e31",
      hash_algorithm: "SHA-256"
    }
  };

  const formatAmount = (amount: number, precision: number) => {
    const divisor = Math.pow(10, precision);
    return (amount / divisor).toLocaleString('en-US', {
      minimumFractionDigits: precision,
      maximumFractionDigits: precision
    });
  };

  const maskAccountNumber = (account: string) => {
    if (account.length <= 4) return account;
    return '*'.repeat(account.length - 4) + account.slice(-4);
  };

  const processingStages = [
    { id: 'intake', name: 'Transaction Intake', icon: FileCheck, color: 'blue' },
    { id: 'validation', name: 'Schema Validation', icon: CheckCircle, color: 'purple' },
    { id: 'idempotency', name: 'Idempotency Check', icon: Shield, color: 'indigo' },
    { id: 'routing', name: 'Routing Verification', icon: Building2, color: 'green' },
    { id: 'ledger', name: 'Ledger Posting', icon: Database, color: 'amber' },
    { id: 'settlement', name: 'ACH Settlement Queue', icon: ArrowRight, color: 'emerald' },
    { id: 'audit', name: 'Audit Trail Commit', icon: Lock, color: 'red' }
  ];

  const validationChecks = [
    { id: 'schema', label: 'JSON Schema Valid', field: 'Schema integrity' },
    { id: 'idempotency', label: 'Unique Idempotency Key', field: 'Replay protection' },
    { id: 'routing', label: 'Valid ABA Routing Number', field: '101205681 (UMB NA)' },
    { id: 'amount', label: 'Amount > 0 and ≤ Daily Limit', field: '$500,000.00' },
    { id: 'timestamp', label: 'Effective Date Valid', field: '2025-09-14' },
    { id: 'settlement', label: 'ACH Settlement Enabled', field: 'Same-day ACH' },
    { id: 'audit', label: 'Audit Fields Complete', field: 'trace-7f2c9d8e31' }
  ];

  const handleLoadTransaction = () => {
    setTransaction(sampleTransaction);
    setProcessingStage(0);
    setValidations({});
    
    // Simulate validation checks
    validationChecks.forEach((check, index) => {
      setTimeout(() => {
        setValidations(prev => ({ ...prev, [check.id]: true }));
      }, (index + 1) * 300);
    });

    // Simulate processing stages
    processingStages.forEach((_, index) => {
      setTimeout(() => {
        setProcessingStage(index + 1);
      }, (index + 1) * 500);
    });
  };

  const getStageColor = (color: string) => {
    const colors: any = {
      blue: { bg: 'bg-blue-500', light: 'bg-blue-50', border: 'border-blue-300', text: 'text-blue-700' },
      purple: { bg: 'bg-purple-500', light: 'bg-purple-50', border: 'border-purple-300', text: 'text-purple-700' },
      indigo: { bg: 'bg-indigo-500', light: 'bg-indigo-50', border: 'border-indigo-300', text: 'text-indigo-700' },
      green: { bg: 'bg-green-500', light: 'bg-green-50', border: 'border-green-300', text: 'text-green-700' },
      amber: { bg: 'bg-amber-500', light: 'bg-amber-50', border: 'border-amber-300', text: 'text-amber-700' },
      emerald: { bg: 'bg-emerald-500', light: 'bg-emerald-50', border: 'border-emerald-300', text: 'text-emerald-700' },
      red: { bg: 'bg-red-500', light: 'bg-red-50', border: 'border-red-300', text: 'text-red-700' }
    };
    return colors[color];
  };

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.6 }}
      className="bg-white rounded-xl shadow-lg border border-slate-200 overflow-hidden"
    >
      {/* Header */}
      <div className="bg-gradient-to-r from-emerald-900 via-green-900 to-emerald-900 p-6">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="p-2 bg-white/10 rounded-lg">
              <DollarSign className="w-6 h-6 text-white" />
            </div>
            <div>
              <h2 className="text-white text-xl">Payroll Transaction Processor</h2>
              <p className="text-slate-300 text-sm">ACH Settlement with Double-Entry Ledger Posting</p>
            </div>
          </div>
          {transaction && (
            <div className="text-right">
              <div className="text-white text-2xl font-bold">
                ${formatAmount(transaction.amount.total, transaction.amount.precision)}
              </div>
              <div className="text-slate-300 text-xs">{transaction.amount.currency}</div>
            </div>
          )}
        </div>
      </div>

      {/* Content */}
      <div className="p-6">
        {/* Load Transaction Button */}
        {!transaction && (
          <div className="text-center py-12">
            <div className="mb-4">
              <FileCheck className="w-16 h-16 text-slate-300 mx-auto" />
            </div>
            <h3 className="text-slate-700 font-medium mb-2">Ready to Process Payroll Transaction</h3>
            <p className="text-slate-500 text-sm mb-6">
              UMB NA Bank • $500,000.00 • ACH Settlement
            </p>
            <motion.button
              whileHover={{ scale: 1.05 }}
              whileTap={{ scale: 0.95 }}
              onClick={handleLoadTransaction}
              className="bg-gradient-to-r from-emerald-600 to-green-600 text-white px-6 py-3 rounded-lg font-medium shadow-lg"
            >
              Load & Process Transaction
            </motion.button>
          </div>
        )}

        {/* Transaction Overview */}
        {transaction && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ delay: 0.2 }}
          >
            {/* Transaction Header */}
            <div className="bg-emerald-50 border-2 border-emerald-300 rounded-lg p-4 mb-6">
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <div className="text-emerald-700 text-xs font-medium mb-1">EVENT TYPE</div>
                  <div className="text-emerald-900 font-bold">{transaction.event_type.toUpperCase()}</div>
                </div>
                <div>
                  <div className="text-emerald-700 text-xs font-medium mb-1">EFFECTIVE DATE</div>
                  <div className="text-emerald-900 font-bold">
                    {new Date(transaction.effective_at).toLocaleString()}
                  </div>
                </div>
                <div className="col-span-2">
                  <div className="text-emerald-700 text-xs font-medium mb-1">DESCRIPTION</div>
                  <div className="text-emerald-900">{transaction.description}</div>
                </div>
              </div>
            </div>

            {/* Validation Checks */}
            <div className="mb-6">
              <h3 className="text-slate-900 font-medium mb-3 flex items-center gap-2">
                <CheckCircle className="w-5 h-5 text-purple-600" />
                Pre-Flight Validation Checks
              </h3>
              <div className="space-y-2">
                {validationChecks.map((check, index) => (
                  <motion.div
                    key={check.id}
                    initial={{ opacity: 0, x: -20 }}
                    animate={{ opacity: 1, x: 0 }}
                    transition={{ delay: index * 0.1 }}
                    className={`
                      flex items-center justify-between p-3 rounded-lg border-2
                      ${validations[check.id] 
                        ? 'bg-green-50 border-green-300' 
                        : 'bg-slate-50 border-slate-200'
                      }
                    `}
                  >
                    <div className="flex items-center gap-3">
                      {validations[check.id] ? (
                        <CheckCircle className="w-5 h-5 text-green-600" />
                      ) : (
                        <Clock className="w-5 h-5 text-slate-400 animate-pulse" />
                      )}
                      <div>
                        <div className={`font-medium text-sm ${validations[check.id] ? 'text-green-900' : 'text-slate-600'}`}>
                          {check.label}
                        </div>
                        <div className="text-xs text-slate-500">{check.field}</div>
                      </div>
                    </div>
                    {validations[check.id] && (
                      <span className="bg-green-100 text-green-700 px-2 py-1 rounded text-xs font-medium">
                        PASS
                      </span>
                    )}
                  </motion.div>
                ))}
              </div>
            </div>

            {/* Processing Pipeline */}
            <div className="mb-6">
              <h3 className="text-slate-900 font-medium mb-3 flex items-center gap-2">
                <ArrowRight className="w-5 h-5 text-blue-600" />
                Processing Pipeline
              </h3>
              <div className="space-y-3">
                {processingStages.map((stage, index) => {
                  const Icon = stage.icon;
                  const colors = getStageColor(stage.color);
                  const isActive = index < processingStage;
                  const isCurrent = index === processingStage - 1;

                  return (
                    <motion.div
                      key={stage.id}
                      initial={{ opacity: 0, x: -20 }}
                      animate={{ opacity: 1, x: 0 }}
                      transition={{ delay: index * 0.15 }}
                    >
                      <div
                        className={`
                          flex items-center gap-4 p-4 rounded-lg border-2 transition-all
                          ${isActive ? `${colors.light} ${colors.border}` : 'bg-slate-50 border-slate-200'}
                          ${isCurrent ? 'ring-2 ring-offset-2 ring-blue-500' : ''}
                        `}
                      >
                        <div className={`
                          p-2 rounded-lg
                          ${isActive ? colors.bg : 'bg-slate-300'}
                        `}>
                          <Icon className="w-5 h-5 text-white" />
                        </div>
                        <div className="flex-1">
                          <div className={`font-medium ${isActive ? colors.text : 'text-slate-500'}`}>
                            {stage.name}
                          </div>
                          {isCurrent && (
                            <div className="text-xs text-blue-600 mt-1 flex items-center gap-1">
                              <div className="w-1.5 h-1.5 bg-blue-600 rounded-full animate-pulse"></div>
                              Processing...
                            </div>
                          )}
                        </div>
                        {isActive && (
                          <CheckCircle className={`w-6 h-6 ${colors.text}`} />
                        )}
                      </div>
                    </motion.div>
                  );
                })}
              </div>
            </div>

            {/* Destination Details */}
            <div className="mb-6">
              <h3 className="text-slate-900 font-medium mb-3 flex items-center gap-2">
                <Building2 className="w-5 h-5 text-green-600" />
                Destination Bank Account
              </h3>
              <div className="bg-green-50 border-2 border-green-300 rounded-lg p-4">
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <div className="text-green-700 text-xs font-medium mb-1">BANK NAME</div>
                    <div className="text-green-900 font-bold">{transaction.destination.bank_name}</div>
                  </div>
                  <div>
                    <div className="text-green-700 text-xs font-medium mb-1">ACCOUNT TYPE</div>
                    <div className="text-green-900 font-bold">{transaction.destination.account_type.toUpperCase()}</div>
                  </div>
                  <div>
                    <div className="text-green-700 text-xs font-medium mb-1">ROUTING NUMBER</div>
                    <div className="text-green-900 font-mono">{transaction.destination.routing_number}</div>
                  </div>
                  <div>
                    <div className="text-green-700 text-xs font-medium mb-1">ACCOUNT NUMBER</div>
                    <div className="text-green-900 font-mono">
                      {maskAccountNumber(transaction.destination.account_number)}
                    </div>
                  </div>
                </div>
              </div>
            </div>

            {/* Controls & Audit */}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-6">
              {/* Transaction Controls */}
              <div>
                <h3 className="text-slate-900 font-medium mb-3 flex items-center gap-2">
                  <Shield className="w-5 h-5 text-indigo-600" />
                  Transaction Controls
                </h3>
                <div className="bg-indigo-50 border-2 border-indigo-300 rounded-lg p-4 space-y-3">
                  <div>
                    <div className="text-indigo-700 text-xs font-medium mb-1">IDEMPOTENCY</div>
                    <div className="flex items-center gap-2">
                      {transaction.controls.idempotent && (
                        <CheckCircle className="w-4 h-4 text-indigo-700" />
                      )}
                      <span className="text-indigo-900 text-sm">
                        {transaction.controls.idempotent ? 'Enabled' : 'Disabled'}
                      </span>
                    </div>
                  </div>
                  <div>
                    <div className="text-indigo-700 text-xs font-medium mb-1">REPLAY PROTECTION</div>
                    <div className="text-indigo-900 text-sm font-mono">{transaction.controls.replay_protection}</div>
                  </div>
                  <div>
                    <div className="text-indigo-700 text-xs font-medium mb-1">SETTLEMENT TYPE</div>
                    <div className="text-indigo-900 text-sm font-bold">{transaction.controls.settlement_type}</div>
                  </div>
                  <div>
                    <div className="text-indigo-700 text-xs font-medium mb-1">POSTING MODE</div>
                    <div className="text-indigo-900 text-sm uppercase">{transaction.controls.posting_mode}</div>
                  </div>
                </div>
              </div>

              {/* Audit Trail */}
              <div>
                <h3 className="text-slate-900 font-medium mb-3 flex items-center gap-2">
                  <Lock className="w-5 h-5 text-red-600" />
                  Audit Trail
                </h3>
                <div className="bg-red-50 border-2 border-red-300 rounded-lg p-4 space-y-3">
                  <div>
                    <div className="text-red-700 text-xs font-medium mb-1">REQUESTED BY</div>
                    <div className="text-red-900 text-sm">{transaction.audit.requested_by}</div>
                  </div>
                  <div>
                    <div className="text-red-700 text-xs font-medium mb-1">SOURCE SYSTEM</div>
                    <div className="text-red-900 text-sm">{transaction.audit.source_system}</div>
                  </div>
                  <div>
                    <div className="text-red-700 text-xs font-medium mb-1">TRACE ID</div>
                    <div className="text-red-900 text-sm font-mono">{transaction.audit.trace_id}</div>
                  </div>
                  <div>
                    <div className="text-red-700 text-xs font-medium mb-1">HASH ALGORITHM</div>
                    <div className="text-red-900 text-sm">{transaction.audit.hash_algorithm}</div>
                  </div>
                </div>
              </div>
            </div>

            {/* Idempotency Key Display */}
            <div className="bg-slate-900 rounded-lg p-4 mb-6">
              <div className="flex items-center gap-2 mb-2">
                <Hash className="w-4 h-4 text-green-400" />
                <span className="text-green-400 text-xs font-medium">IDEMPOTENCY KEY</span>
              </div>
              <div className="text-white font-mono text-sm break-all">
                {transaction.idempotency_key}
              </div>
            </div>

            {/* JSON Payload Toggle */}
            <div className="border-t-2 border-slate-200 pt-4">
              <button
                onClick={() => setShowDetails(!showDetails)}
                className="text-slate-600 hover:text-slate-900 text-sm font-medium flex items-center gap-2"
              >
                <FileCheck className="w-4 h-4" />
                {showDetails ? 'Hide' : 'Show'} Raw JSON Payload
              </button>
              
              {showDetails && (
                <motion.div
                  initial={{ opacity: 0, height: 0 }}
                  animate={{ opacity: 1, height: 'auto' }}
                  className="mt-4 bg-slate-900 rounded-lg p-4 overflow-x-auto"
                >
                  <pre className="text-green-400 text-xs font-mono">
                    {JSON.stringify(transaction, null, 2)}
                  </pre>
                </motion.div>
              )}
            </div>

            {/* Processing Complete */}
            {processingStage === processingStages.length && (
              <motion.div
                initial={{ opacity: 0, scale: 0.9 }}
                animate={{ opacity: 1, scale: 1 }}
                transition={{ delay: 0.3 }}
                className="mt-6 bg-gradient-to-r from-green-600 to-emerald-600 text-white p-6 rounded-lg text-center"
              >
                <CheckCircle className="w-12 h-12 mx-auto mb-3" />
                <h3 className="text-xl font-bold mb-2">Transaction Processed Successfully</h3>
                <p className="text-green-100 mb-4">
                  ACH settlement queued • Ledger posted • Audit trail committed
                </p>
                <div className="bg-white/20 rounded px-4 py-2 inline-block">
                  <span className="text-xs">Settlement ETA: Same-Day ACH (5:00 PM ET)</span>
                </div>
              </motion.div>
            )}
          </motion.div>
        )}
      </div>
    </motion.div>
  );
}
