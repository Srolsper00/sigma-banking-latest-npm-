import { useState, useEffect } from 'react';
import { motion } from 'motion/react';
import { Card } from './ui/card';
import { Button } from './ui/button';
import { 
  Terminal, 
  Package, 
  FileArchive, 
  CheckCircle2, 
  AlertCircle,
  Shield,
  Network,
  Lock,
  Server,
  Activity,
  FileText,
  Hash,
  Play,
  RefreshCw,
  Eye,
  Download,
  Code
} from 'lucide-react';

interface LedgerEntry {
  timestamp: string;
  batch_id: string;
  file_count: number;
  total_bytes: number;
  batch_hash: string;
  verification_status: 'verified' | 'pending' | 'failed';
}

interface DeploymentStatus {
  stage: string;
  status: 'running' | 'completed' | 'pending' | 'failed';
  duration?: number;
}

export function InfrastructureOperationsPanel() {
  const [activeTab, setActiveTab] = useState<'deployment' | 'ledger' | 'vpn'>('deployment');
  const [isRunning, setIsRunning] = useState(false);
  const [deploymentStages, setDeploymentStages] = useState<DeploymentStatus[]>([
    { stage: 'Setup directories', status: 'pending' },
    { stage: 'Set permissions', status: 'pending' },
    { stage: 'Copy scripts', status: 'pending' },
    { stage: 'Execute paced zip', status: 'pending' },
    { stage: 'Verify package', status: 'pending' },
    { stage: 'Hash validation', status: 'pending' }
  ]);

  const [ledgerEntries, setLedgerEntries] = useState<LedgerEntry[]>([
    {
      timestamp: '2026-03-17T14:28:45Z',
      batch_id: 'batch_20260317_142845',
      file_count: 247,
      total_bytes: 45829384,
      batch_hash: '9f86d081884c7d659a2feaa0c55ad015a3bf4f1b2b0b822cd15d6c15b0f00a08',
      verification_status: 'verified'
    },
    {
      timestamp: '2026-03-17T14:30:12Z',
      batch_id: 'batch_20260317_143012',
      file_count: 189,
      total_bytes: 38472923,
      batch_hash: '7f83b1657ff1fc53b92dc18148a1d65dfc2d4b1fa3d677284addd200126d9069',
      verification_status: 'verified'
    },
    {
      timestamp: '2026-03-17T14:31:58Z',
      batch_id: 'batch_20260317_143158',
      file_count: 312,
      total_bytes: 52938474,
      batch_hash: 'e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855',
      verification_status: 'pending'
    }
  ]);

  const runDeployment = () => {
    setIsRunning(true);
    let currentStage = 0;

    const interval = setInterval(() => {
      if (currentStage < deploymentStages.length) {
        setDeploymentStages(prev => 
          prev.map((stage, idx) => {
            if (idx === currentStage) {
              return { ...stage, status: 'completed' as const, duration: Math.random() * 2 + 0.5 };
            } else if (idx === currentStage + 1) {
              return { ...stage, status: 'running' as const };
            }
            return stage;
          })
        );
        currentStage++;
      } else {
        clearInterval(interval);
        setIsRunning(false);
      }
    }, 1500);
  };

  const getStatusIcon = (status: string) => {
    switch (status) {
      case 'completed':
        return <CheckCircle2 className="w-5 h-5 text-green-500" />;
      case 'running':
        return <RefreshCw className="w-5 h-5 text-blue-500 animate-spin" />;
      case 'failed':
        return <AlertCircle className="w-5 h-5 text-red-500" />;
      default:
        return <div className="w-5 h-5 rounded-full border-2 border-slate-300" />;
    }
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <motion.div
        initial={{ opacity: 0, y: -20 }}
        animate={{ opacity: 1, y: 0 }}
        className="bg-gradient-to-r from-indigo-600 to-purple-600 rounded-lg p-6 text-white"
      >
        <div className="flex items-center gap-3 mb-2">
          <Server className="w-8 h-8" />
          <h2 className="text-2xl font-bold">Infrastructure Operations Center</h2>
        </div>
        <p className="text-indigo-100">
          Deployment Monitoring • Batch Processing • Ledger Verification • VPN Configuration
        </p>
      </motion.div>

      {/* Tab Navigation */}
      <Card className="p-2">
        <div className="flex gap-2">
          <Button
            variant={activeTab === 'deployment' ? 'default' : 'ghost'}
            className="flex-1"
            onClick={() => setActiveTab('deployment')}
          >
            <Package className="w-4 h-4 mr-2" />
            Deployment Monitor
          </Button>
          <Button
            variant={activeTab === 'ledger' ? 'default' : 'ghost'}
            className="flex-1"
            onClick={() => setActiveTab('ledger')}
          >
            <FileText className="w-4 h-4 mr-2" />
            Ledger Verification
          </Button>
          <Button
            variant={activeTab === 'vpn' ? 'default' : 'ghost'}
            className="flex-1"
            onClick={() => setActiveTab('vpn')}
          >
            <Lock className="w-4 h-4 mr-2" />
            VPN Configuration
          </Button>
        </div>
      </Card>

      {/* Deployment Monitor Tab */}
      {activeTab === 'deployment' && (
        <motion.div
          initial={{ opacity: 0, x: -20 }}
          animate={{ opacity: 1, x: 0 }}
          className="space-y-6"
        >
          {/* Command Execution Panel */}
          <Card className="p-6">
            <div className="flex items-center justify-between mb-4">
              <h3 className="text-lg font-semibold flex items-center gap-2">
                <Terminal className="w-5 h-5 text-indigo-600" />
                Deployment Script Execution
              </h3>
              <Button
                onClick={runDeployment}
                disabled={isRunning}
                className="gap-2"
              >
                {isRunning ? (
                  <>
                    <RefreshCw className="w-4 h-4 animate-spin" />
                    Running...
                  </>
                ) : (
                  <>
                    <Play className="w-4 h-4" />
                    Execute Deployment
                  </>
                )}
              </Button>
            </div>

            {/* Command Script */}
            <div className="bg-slate-900 text-green-400 p-4 rounded-lg font-mono text-sm mb-4 overflow-x-auto">
              <div className="mb-2 text-slate-500"># Setup agent tools directory</div>
              <div>sudo mkdir -p /opt/agent/tools</div>
              <div>sudo chown agentuser:agentuser /opt/agent /opt/agent/tools</div>
              <div className="mb-2 mt-3 text-slate-500"># Copy and set permissions</div>
              <div>sudo chmod 750 /opt/agent/tools/paced_zip_and_clear.py</div>
              <div className="mb-2 mt-3 text-slate-500"># Execute deployment package creation</div>
              <div>sudo -u agentuser /usr/bin/python3 /opt/agent/tools/paced_zip_and_clear.py</div>
              <div className="mb-2 mt-3 text-slate-500"># Verify output</div>
              <div>ls -lh /mnt/data/deployment_monitoring_redesign_package.zip</div>
              <div>tail -n 50 /var/log/agent/ledger_batched_hashes.ndjson</div>
            </div>

            {/* Deployment Stages */}
            <div className="space-y-3">
              {deploymentStages.map((stage, index) => (
                <motion.div
                  key={index}
                  initial={{ opacity: 0, x: -20 }}
                  animate={{ opacity: 1, x: 0 }}
                  transition={{ delay: index * 0.1 }}
                  className={`flex items-center gap-3 p-3 rounded-lg border ${
                    stage.status === 'running' 
                      ? 'border-blue-300 bg-blue-50' 
                      : stage.status === 'completed'
                      ? 'border-green-300 bg-green-50'
                      : 'border-slate-200 bg-white'
                  }`}
                >
                  {getStatusIcon(stage.status)}
                  <div className="flex-1">
                    <div className="font-semibold">{stage.stage}</div>
                    {stage.duration && (
                      <div className="text-xs text-slate-500">
                        Completed in {stage.duration.toFixed(2)}s
                      </div>
                    )}
                  </div>
                  {stage.status === 'completed' && (
                    <span className="text-xs font-semibold text-green-600">SUCCESS</span>
                  )}
                  {stage.status === 'running' && (
                    <span className="text-xs font-semibold text-blue-600">RUNNING</span>
                  )}
                </motion.div>
              ))}
            </div>
          </Card>

          {/* Output Verification */}
          <Card className="p-6">
            <h3 className="text-lg font-semibold mb-4 flex items-center gap-2">
              <FileArchive className="w-5 h-5 text-purple-600" />
              Package Verification
            </h3>

            <div className="grid grid-cols-2 gap-4 mb-4">
              <div className="bg-gradient-to-br from-blue-50 to-blue-100 p-4 rounded-lg">
                <div className="text-sm text-slate-600 mb-1">Package Size</div>
                <div className="text-2xl font-bold text-blue-600">43.7 MB</div>
                <div className="text-xs text-slate-500 mt-1">deployment_monitoring_redesign_package.zip</div>
              </div>

              <div className="bg-gradient-to-br from-purple-50 to-purple-100 p-4 rounded-lg">
                <div className="text-sm text-slate-600 mb-1">Files Archived</div>
                <div className="text-2xl font-bold text-purple-600">247</div>
                <div className="text-xs text-slate-500 mt-1">Compressed with verification</div>
              </div>
            </div>

            <div className="bg-slate-900 text-green-400 p-4 rounded-lg font-mono text-sm">
              <div className="mb-2 text-slate-500"># SHA-256 Verification</div>
              <div>$ sha256sum /mnt/data/deployment_monitoring_redesign_package.zip</div>
              <div className="text-yellow-400 break-all">
                9f86d081884c7d659a2feaa0c55ad015a3bf4f1b2b0b822cd15d6c15b0f00a08
              </div>
              <div className="mt-3 mb-2 text-slate-500"># Ledger Hash Match</div>
              <div>$ tail -n1 /var/log/agent/ledger_batched_hashes.ndjson | jq -r .batch_hash</div>
              <div className="text-yellow-400 break-all">
                9f86d081884c7d659a2feaa0c55ad015a3bf4f1b2b0b822cd15d6c15b0f00a08
              </div>
              <div className="mt-3 text-green-400">✓ Hash verification: MATCH</div>
            </div>
          </Card>
        </motion.div>
      )}

      {/* Ledger Verification Tab */}
      {activeTab === 'ledger' && (
        <motion.div
          initial={{ opacity: 0, x: -20 }}
          animate={{ opacity: 1, x: 0 }}
          className="space-y-6"
        >
          <Card className="p-6">
            <div className="flex items-center justify-between mb-4">
              <h3 className="text-lg font-semibold flex items-center gap-2">
                <Hash className="w-5 h-5 text-purple-600" />
                Batched Hash Ledger (NDJSON)
              </h3>
              <div className="flex gap-2">
                <Button variant="outline" size="sm">
                  <Eye className="w-4 h-4 mr-2" />
                  Tail -F
                </Button>
                <Button variant="outline" size="sm">
                  <Download className="w-4 h-4 mr-2" />
                  Export
                </Button>
              </div>
            </div>

            <div className="space-y-3">
              {ledgerEntries.map((entry, index) => (
                <motion.div
                  key={entry.batch_id}
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: index * 0.1 }}
                  className="border border-slate-200 rounded-lg p-4 bg-white hover:shadow-md transition-shadow"
                >
                  <div className="flex items-start justify-between mb-3">
                    <div>
                      <div className="font-semibold text-sm mb-1">{entry.batch_id}</div>
                      <div className="text-xs text-slate-500">
                        {new Date(entry.timestamp).toLocaleString()}
                      </div>
                    </div>
                    <div className={`px-2 py-1 rounded-full text-xs font-semibold ${
                      entry.verification_status === 'verified'
                        ? 'bg-green-100 text-green-700'
                        : entry.verification_status === 'pending'
                        ? 'bg-yellow-100 text-yellow-700'
                        : 'bg-red-100 text-red-700'
                    }`}>
                      {entry.verification_status.toUpperCase()}
                    </div>
                  </div>

                  <div className="grid grid-cols-2 gap-4 mb-3">
                    <div>
                      <div className="text-xs text-slate-500">File Count</div>
                      <div className="font-semibold">{entry.file_count.toLocaleString()}</div>
                    </div>
                    <div>
                      <div className="text-xs text-slate-500">Total Bytes</div>
                      <div className="font-semibold">
                        {(entry.total_bytes / 1024 / 1024).toFixed(2)} MB
                      </div>
                    </div>
                  </div>

                  <div className="bg-slate-100 p-3 rounded font-mono text-xs break-all">
                    <div className="text-slate-500 mb-1">SHA-256 Batch Hash:</div>
                    <div className="text-slate-800">{entry.batch_hash}</div>
                  </div>
                </motion.div>
              ))}
            </div>

            {/* Ledger Log Path */}
            <div className="mt-4 p-4 bg-blue-50 rounded-lg">
              <div className="text-sm font-semibold text-blue-900 mb-2">Ledger Location:</div>
              <code className="text-sm text-blue-700">/var/log/agent/ledger_batched_hashes.ndjson</code>
              <div className="mt-2 text-xs text-blue-600">
                Real-time monitoring: journalctl -u agent-pacer -n 200
              </div>
            </div>
          </Card>

          {/* Type-Safe Tool Executor */}
          <Card className="p-6">
            <h3 className="text-lg font-semibold mb-4 flex items-center gap-2">
              <Code className="w-5 h-5 text-indigo-600" />
              Type-Safe Tool Executor
            </h3>

            <div className="bg-slate-900 text-white p-4 rounded-lg font-mono text-sm overflow-x-auto">
              <pre className="text-purple-400">{`type Tool =
  | { type: "readFile"; path: string }
  | { type: "readdir"; path: string }
  | { type: "exec"; command: "ls" | "git status" | "nginx -t" };

async function toolExecutor(tool: Tool) {
  switch (tool.type) {
    case "readFile":
      return fs.promises.readFile(tool.path, "utf-8");

    case "readdir":
      return fs.promises.readdir(tool.path, { withFileTypes: true });
 
    case "exec":
      if (!["ls", "git status", "nginx -t"].includes(tool.command)) {
        throw new Error("Command not allowed");
      }
      return exec(tool.command);
  }
}`}</pre>
            </div>

            <div className="mt-4 p-3 bg-amber-50 border border-amber-200 rounded-lg">
              <div className="flex items-start gap-2">
                <Shield className="w-5 h-5 text-amber-600 flex-shrink-0 mt-0.5" />
                <div className="text-sm text-amber-800">
                  <div className="font-semibold mb-1">Security: Command Allowlist</div>
                  <div>Only pre-approved commands (ls, git status, nginx -t) can be executed. All other commands are rejected by type system and runtime validation.</div>
                </div>
              </div>
            </div>
          </Card>
        </motion.div>
      )}

      {/* VPN Configuration Tab */}
      {activeTab === 'vpn' && (
        <motion.div
          initial={{ opacity: 0, x: -20 }}
          animate={{ opacity: 1, x: 0 }}
          className="space-y-6"
        >
          <Card className="p-6">
            <h3 className="text-lg font-semibold mb-4 flex items-center gap-2">
              <Network className="w-5 h-5 text-blue-600" />
              IPsec/IKEv2 Tunnel Configuration
            </h3>

            {/* Tunnel Status */}
            <div className="grid grid-cols-3 gap-4 mb-6">
              <div className="bg-green-50 p-4 rounded-lg border border-green-200">
                <div className="flex items-center gap-2 mb-2">
                  <CheckCircle2 className="w-5 h-5 text-green-600" />
                  <div className="font-semibold text-sm">Tunnel Status</div>
                </div>
                <div className="text-xl font-bold text-green-600">ACTIVE</div>
              </div>

              <div className="bg-blue-50 p-4 rounded-lg border border-blue-200">
                <div className="flex items-center gap-2 mb-2">
                  <Lock className="w-5 h-5 text-blue-600" />
                  <div className="font-semibold text-sm">Encryption</div>
                </div>
                <div className="text-sm font-semibold text-blue-600">AES-CBC-256</div>
              </div>

              <div className="bg-purple-50 p-4 rounded-lg border border-purple-200">
                <div className="flex items-center gap-2 mb-2">
                  <Activity className="w-5 h-5 text-purple-600" />
                  <div className="font-semibold text-sm">Integrity</div>
                </div>
                <div className="text-sm font-semibold text-purple-600">SHA-256</div>
              </div>
            </div>

            {/* IKEv2 Configuration */}
            <div className="mb-6">
              <h4 className="font-semibold mb-3 flex items-center gap-2">
                <Lock className="w-4 h-4 text-indigo-600" />
                IKEv2 Proposal Configuration
              </h4>
              <div className="bg-slate-900 text-green-400 p-4 rounded-lg font-mono text-sm overflow-x-auto">
                <pre>{`crypto ikev2 proposal P1
 encryption aes-cbc-256
 integrity sha256
 group 21

crypto ikev2 keyring KR-REMOTE
 peer UPSTREAM
  address 198.51.100.1
  pre-shared-key local MyPresharedSecret`}</pre>
              </div>
            </div>

            {/* IPsec Transform Set */}
            <div className="mb-6">
              <h4 className="font-semibold mb-3 flex items-center gap-2">
                <Shield className="w-4 h-4 text-purple-600" />
                IPsec Transform Set
              </h4>
              <div className="bg-slate-900 text-green-400 p-4 rounded-lg font-mono text-sm overflow-x-auto">
                <pre>{`crypto ipsec transform-set TS esp-aes 256 esp-sha256-hmac
mode tunnel

crypto ipsec profile P-IPSEC
 set transform-set TS
 set ikev2-profile P1`}</pre>
              </div>
            </div>

            {/* Tunnel Interface */}
            <div>
              <h4 className="font-semibold mb-3 flex items-center gap-2">
                <Network className="w-4 h-4 text-blue-600" />
                Tunnel Interface Configuration
              </h4>
              <div className="bg-slate-900 text-green-400 p-4 rounded-lg font-mono text-sm overflow-x-auto">
                <pre>{`interface Tunnel100
 ip address 169.254.100.2 255.255.255.252
 tunnel source 203.0.113.10
 tunnel destination 198.51.100.1
 tunnel protection ipsec profile P-IPSEC`}</pre>
              </div>
            </div>

            {/* Connection Details */}
            <div className="mt-6 grid grid-cols-2 gap-4">
              <div className="bg-slate-50 p-4 rounded-lg border border-slate-200">
                <div className="text-sm text-slate-600 mb-2">Local Endpoint</div>
                <div className="font-mono text-sm font-semibold">203.0.113.10</div>
                <div className="text-xs text-slate-500 mt-1">Tunnel Source</div>
              </div>

              <div className="bg-slate-50 p-4 rounded-lg border border-slate-200">
                <div className="text-sm text-slate-600 mb-2">Remote Endpoint</div>
                <div className="font-mono text-sm font-semibold">198.51.100.1</div>
                <div className="text-xs text-slate-500 mt-1">Tunnel Destination</div>
              </div>

              <div className="bg-slate-50 p-4 rounded-lg border border-slate-200">
                <div className="text-sm text-slate-600 mb-2">Tunnel IP</div>
                <div className="font-mono text-sm font-semibold">169.254.100.2/30</div>
                <div className="text-xs text-slate-500 mt-1">Link-Local Address</div>
              </div>

              <div className="bg-slate-50 p-4 rounded-lg border border-slate-200">
                <div className="text-sm text-slate-600 mb-2">DH Group</div>
                <div className="font-mono text-sm font-semibold">Group 21</div>
                <div className="text-xs text-slate-500 mt-1">521-bit ECP</div>
              </div>
            </div>
          </Card>

          {/* Security Parameters */}
          <Card className="p-6 bg-gradient-to-br from-blue-50 to-purple-50 border-blue-200">
            <h3 className="text-lg font-semibold mb-4 flex items-center gap-2">
              <Shield className="w-5 h-5 text-blue-600" />
              Security Parameters Summary
            </h3>

            <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
              <div className="bg-white p-3 rounded-lg shadow-sm">
                <div className="text-xs text-slate-500 mb-1">Encryption</div>
                <div className="font-semibold text-sm">AES-CBC-256</div>
              </div>

              <div className="bg-white p-3 rounded-lg shadow-sm">
                <div className="text-xs text-slate-500 mb-1">Integrity</div>
                <div className="font-semibold text-sm">SHA-256-HMAC</div>
              </div>

              <div className="bg-white p-3 rounded-lg shadow-sm">
                <div className="text-xs text-slate-500 mb-1">Mode</div>
                <div className="font-semibold text-sm">Tunnel</div>
              </div>

              <div className="bg-white p-3 rounded-lg shadow-sm">
                <div className="text-xs text-slate-500 mb-1">Protocol</div>
                <div className="font-semibold text-sm">ESP</div>
              </div>
            </div>

            <div className="mt-4 p-3 bg-green-100 border border-green-300 rounded-lg">
              <div className="flex items-center gap-2">
                <CheckCircle2 className="w-5 h-5 text-green-600" />
                <div className="text-sm text-green-800 font-semibold">
                  VPN tunnel secured with NIST-recommended cryptographic parameters
                </div>
              </div>
            </div>
          </Card>
        </motion.div>
      )}

      {/* System Status Footer */}
      <Card className="p-4 bg-gradient-to-r from-green-50 to-blue-50 border-green-200">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-3 h-3 bg-green-500 rounded-full animate-pulse"></div>
            <div>
              <div className="font-semibold text-sm">Infrastructure Systems Operational</div>
              <div className="text-xs text-slate-600">
                Agent pacer running • Ledger verified • VPN tunnel active
              </div>
            </div>
          </div>
          <Button variant="outline" size="sm">
            <Activity className="w-4 h-4 mr-2" />
            View Logs
          </Button>
        </div>
      </Card>
    </div>
  );
}
