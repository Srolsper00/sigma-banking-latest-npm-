import { motion } from 'motion/react';
import { useState, useEffect } from 'react';
import {
  Droplets,
  TrendingUp,
  TrendingDown,
  AlertTriangle,
  CheckCircle,
  Activity,
  DollarSign,
  Shield,
  BarChart3,
  RefreshCw,
  Download,
  Info
} from 'lucide-react';

interface LiquidityMetrics {
  grossOutboundCredits: number;
  sameDayEligibleOffsets: number;
  stressMultiplier: number;
  dynamicReturnReserve: number;
  microDepositSettlementExposure: number;
  operationalBuffer: number;
}

interface LiquidityStatus {
  erl: number;
  availableLiquidity: number;
  utilizationRate: number;
  surplus: number;
  status: 'healthy' | 'warning' | 'critical';
}

export function LiquidityManagement() {
  const [metrics, setMetrics] = useState<LiquidityMetrics>({
    grossOutboundCredits: 2500000000, // $2.5B
    sameDayEligibleOffsets: 450000000, // $450M
    stressMultiplier: 1.15, // 115% stress scenario
    dynamicReturnReserve: 75000000, // $75M
    microDepositSettlementExposure: 12500000, // $12.5M
    operationalBuffer: 100000000 // $100M
  });

  const [availableLiquidity, setAvailableLiquidity] = useState(3200000000); // $3.2B
  const [isCalculating, setIsCalculating] = useState(false);
  const [showBreakdown, setShowBreakdown] = useState(true);

  // Calculate ERL based on formula
  const calculateERL = (): number => {
    const {
      grossOutboundCredits,
      sameDayEligibleOffsets,
      stressMultiplier,
      dynamicReturnReserve,
      microDepositSettlementExposure,
      operationalBuffer
    } = metrics;

    // ERL = (Gross Outbound Credits – Same-Day Eligible Offsets) × Stress Multiplier
    //       + Dynamic Return Reserve
    //       + Micro-Deposit Settlement Exposure
    //       + Operational Buffer

    const netOutbound = grossOutboundCredits - sameDayEligibleOffsets;
    const stressedOutbound = netOutbound * stressMultiplier;
    
    const erl = stressedOutbound 
                + dynamicReturnReserve 
                + microDepositSettlementExposure 
                + operationalBuffer;

    return erl;
  };

  const getLiquidityStatus = (): LiquidityStatus => {
    const erl = calculateERL();
    const surplus = availableLiquidity - erl;
    const utilizationRate = (erl / availableLiquidity) * 100;

    let status: 'healthy' | 'warning' | 'critical';
    if (utilizationRate < 75) {
      status = 'healthy';
    } else if (utilizationRate < 90) {
      status = 'warning';
    } else {
      status = 'critical';
    }

    return {
      erl,
      availableLiquidity,
      utilizationRate,
      surplus,
      status
    };
  };

  const status = getLiquidityStatus();

  const formatCurrency = (amount: number): string => {
    if (amount >= 1000000000) {
      return `$${(amount / 1000000000).toFixed(2)}B`;
    } else if (amount >= 1000000) {
      return `$${(amount / 1000000).toFixed(2)}M`;
    } else {
      return `$${(amount / 1000).toFixed(2)}K`;
    }
  };

  const refreshMetrics = async () => {
    setIsCalculating(true);
    // Simulate API call to fetch real-time metrics
    await new Promise(resolve => setTimeout(resolve, 1000));
    
    // Simulate some variance in metrics
    setMetrics(prev => ({
      ...prev,
      grossOutboundCredits: prev.grossOutboundCredits + (Math.random() - 0.5) * 100000000,
      sameDayEligibleOffsets: prev.sameDayEligibleOffsets + (Math.random() - 0.5) * 50000000,
      dynamicReturnReserve: prev.dynamicReturnReserve + (Math.random() - 0.5) * 10000000
    }));
    
    setIsCalculating(false);
  };

  const downloadReport = () => {
    const status = getLiquidityStatus();
    const timestamp = new Date().toISOString();
    
    const report = `
═══════════════════════════════════════════════════════════════════
              SIGMA BANKING PLATFORM
         Effective Required Liquidity (ERL) Report
═══════════════════════════════════════════════════════════════════

Generated: ${timestamp}
Banking Partner: UMB NA / Sutton Bank (041215663)
Regulatory Framework: Federal Reserve Regulation D, OCC Liquidity Risk
Entity: OBLMFGJE – Scherer Enterprises Inc.

═══════════════════════════════════════════════════════════════════
                    ERL CALCULATION FORMULA
═══════════════════════════════════════════════════════════════════

ERL = (Gross Outbound Credits – Same-Day Eligible Offsets) 
      × Stress Multiplier
      + Dynamic Return Reserve
      + Micro-Deposit Settlement Exposure
      + Operational Buffer

═══════════════════════════════════════════════════════════════════
                      INPUT METRICS
═══════════════════════════════════════════════════════════════════

Gross Outbound Credits:              ${formatCurrency(metrics.grossOutboundCredits)}
Same-Day Eligible Offsets:           ${formatCurrency(metrics.sameDayEligibleOffsets)}
Net Outbound:                         ${formatCurrency(metrics.grossOutboundCredits - metrics.sameDayEligibleOffsets)}

Stress Multiplier:                   ${(metrics.stressMultiplier * 100)}%
Dynamic Return Reserve:               ${formatCurrency(metrics.dynamicReturnReserve)}
Micro-Deposit Settlement Exposure:    ${formatCurrency(metrics.microDepositSettlementExposure)}
Operational Buffer:                   ${formatCurrency(metrics.operationalBuffer)}

═══════════════════════════════════════════════════════════════════
                    CALCULATED RESULTS
═══════════════════════════════════════════════════════════════════

Effective Required Liquidity (ERL):  ${formatCurrency(status.erl)}
Available Liquidity:                  ${formatCurrency(status.availableLiquidity)}
Liquidity Surplus / (Deficit):       ${formatCurrency(status.surplus)}
Utilization Rate:                     ${status.utilizationRate.toFixed(2)}%

Status: ${status.status.toUpperCase()}

═══════════════════════════════════════════════════════════════════
                    COMPONENT BREAKDOWN
═══════════════════════════════════════════════════════════════════

1. Stressed Outbound Credits:
   ${formatCurrency((metrics.grossOutboundCredits - metrics.sameDayEligibleOffsets) * metrics.stressMultiplier)}
   
2. Dynamic Return Reserve:
   ${formatCurrency(metrics.dynamicReturnReserve)}
   
3. Micro-Deposit Settlement:
   ${formatCurrency(metrics.microDepositSettlementExposure)}
   
4. Operational Buffer:
   ${formatCurrency(metrics.operationalBuffer)}

═══════════════════════════════════════════════════════════════════
                    REGULATORY COMPLIANCE
═══════════════════════════════════════════════════════════════════

✓ Federal Reserve Regulation D compliance
✓ OCC Liquidity Risk Management guidelines
✓ FFIEC Cash Management examination standards
✓ Basel III Liquidity Coverage Ratio (LCR) principles
✓ Real-time liquidity monitoring and stress testing

═══════════════════════════════════════════════════════════════════
                        RISK ASSESSMENT
═══════════════════════════════════════════════════════════════════

Liquidity Risk Level: ${status.status === 'healthy' ? 'LOW' : status.status === 'warning' ? 'MODERATE' : 'HIGH'}

Recommended Actions:
${status.status === 'healthy' 
  ? '• Maintain current liquidity position\n• Continue monitoring intraday flows\n• No immediate action required'
  : status.status === 'warning'
  ? '• Monitor liquidity position closely\n• Consider reducing outbound credit exposure\n• Prepare contingency funding plan\n• Alert treasury operations'
  : '• IMMEDIATE ACTION REQUIRED\n• Reduce outbound credit exposure\n• Activate contingency funding sources\n• Escalate to CFO and Board Risk Committee\n• Consider temporary payment holds'
}

═══════════════════════════════════════════════════════════════════
                          ATTESTATION
═══════════════════════════════════════════════════════════════════

This report is generated by the Sigma Banking Platform's automated
liquidity management system. All calculations follow OCC and Federal
Reserve guidelines for liquidity risk management.

Report ID: ${Math.random().toString(36).substr(2, 9).toUpperCase()}
Generated By: Sigma Liquidity Engine v1.0
Timestamp: ${timestamp}

═══════════════════════════════════════════════════════════════════
                        END OF REPORT
═══════════════════════════════════════════════════════════════════
    `.trim();

    const blob = new Blob([report], { type: 'text/plain' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `ERL_Report_${new Date().toISOString().split('T')[0]}.txt`;
    a.click();
    URL.revokeObjectURL(url);
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'healthy': return 'from-green-600 to-emerald-600';
      case 'warning': return 'from-yellow-600 to-orange-600';
      case 'critical': return 'from-red-600 to-rose-600';
      default: return 'from-slate-600 to-slate-700';
    }
  };

  const getStatusIcon = (status: string) => {
    switch (status) {
      case 'healthy': return <CheckCircle className="w-6 h-6" />;
      case 'warning': return <AlertTriangle className="w-6 h-6" />;
      case 'critical': return <AlertTriangle className="w-6 h-6" />;
      default: return <Activity className="w-6 h-6" />;
    }
  };

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.6 }}
      className="space-y-6"
    >
      {/* Header */}
      <div className="bg-gradient-to-r from-blue-900 via-indigo-900 to-purple-900 rounded-xl p-6">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="p-3 bg-white/10 rounded-lg">
              <Droplets className="w-8 h-8 text-white" />
            </div>
            <div>
              <h2 className="text-white text-2xl font-bold">Liquidity Management</h2>
              <p className="text-slate-300 text-sm">Effective Required Liquidity (ERL) Calculation Engine</p>
            </div>
          </div>
          <div className="flex gap-2">
            <motion.button
              whileHover={{ scale: 1.05 }}
              whileTap={{ scale: 0.95 }}
              onClick={refreshMetrics}
              disabled={isCalculating}
              className="bg-white/10 hover:bg-white/20 text-white px-4 py-2 rounded-lg font-medium text-sm flex items-center gap-2"
            >
              <RefreshCw className={`w-4 h-4 ${isCalculating ? 'animate-spin' : ''}`} />
              Refresh
            </motion.button>
            <motion.button
              whileHover={{ scale: 1.05 }}
              whileTap={{ scale: 0.95 }}
              onClick={downloadReport}
              className="bg-white text-blue-900 px-4 py-2 rounded-lg font-medium text-sm flex items-center gap-2"
            >
              <Download className="w-4 h-4" />
              Export Report
            </motion.button>
          </div>
        </div>
      </div>

      {/* Status Dashboard */}
      <div className={`bg-gradient-to-r ${getStatusColor(status.status)} rounded-xl p-6 text-white`}>
        <div className="flex items-center justify-between mb-4">
          <div className="flex items-center gap-3">
            {getStatusIcon(status.status)}
            <div>
              <h3 className="text-xl font-bold">Liquidity Status: {status.status.toUpperCase()}</h3>
              <p className="text-white/80 text-sm">Real-time ERL monitoring and compliance</p>
            </div>
          </div>
          <div className="text-right">
            <div className="text-white/70 text-xs">Last Updated</div>
            <div className="text-white font-mono text-sm">{new Date().toLocaleTimeString()}</div>
          </div>
        </div>

        <div className="grid grid-cols-4 gap-4">
          <div className="bg-white/10 rounded-lg p-4">
            <div className="text-white/70 text-xs mb-1">Required Liquidity (ERL)</div>
            <div className="text-white font-bold text-2xl">{formatCurrency(status.erl)}</div>
          </div>
          <div className="bg-white/10 rounded-lg p-4">
            <div className="text-white/70 text-xs mb-1">Available Liquidity</div>
            <div className="text-white font-bold text-2xl">{formatCurrency(status.availableLiquidity)}</div>
          </div>
          <div className="bg-white/10 rounded-lg p-4">
            <div className="text-white/70 text-xs mb-1">Surplus / (Deficit)</div>
            <div className={`font-bold text-2xl ${status.surplus >= 0 ? 'text-green-300' : 'text-red-300'}`}>
              {formatCurrency(status.surplus)}
            </div>
          </div>
          <div className="bg-white/10 rounded-lg p-4">
            <div className="text-white/70 text-xs mb-1">Utilization Rate</div>
            <div className="text-white font-bold text-2xl">{status.utilizationRate.toFixed(1)}%</div>
          </div>
        </div>
      </div>

      {/* ERL Formula */}
      <div className="bg-slate-900 rounded-xl p-6 text-white">
        <div className="flex items-center gap-3 mb-4">
          <BarChart3 className="w-6 h-6 text-blue-400" />
          <h3 className="text-xl font-bold">ERL Calculation Formula</h3>
        </div>
        
        <div className="bg-slate-800 rounded-lg p-4 font-mono text-sm">
          <div className="text-blue-300">ERL =</div>
          <div className="ml-6 mt-2 space-y-1">
            <div className="text-slate-300">
              <span className="text-yellow-400">(</span>
              <span className="text-green-400">Gross Outbound Credits</span>
              <span className="text-yellow-400"> – </span>
              <span className="text-green-400">Same-Day Eligible Offsets</span>
              <span className="text-yellow-400">)</span>
            </div>
            <div className="text-slate-300">
              <span className="text-yellow-400">× </span>
              <span className="text-purple-400">Stress Multiplier</span>
            </div>
            <div className="text-slate-300">
              <span className="text-yellow-400">+ </span>
              <span className="text-orange-400">Dynamic Return Reserve</span>
            </div>
            <div className="text-slate-300">
              <span className="text-yellow-400">+ </span>
              <span className="text-pink-400">Micro-Deposit Settlement Exposure</span>
            </div>
            <div className="text-slate-300">
              <span className="text-yellow-400">+ </span>
              <span className="text-cyan-400">Operational Buffer</span>
            </div>
          </div>
        </div>
      </div>

      {/* Component Breakdown */}
      {showBreakdown && (
        <div className="bg-white rounded-xl border border-slate-200 overflow-hidden">
          <div className="bg-gradient-to-r from-slate-700 to-slate-800 p-4">
            <div className="flex items-center justify-between">
              <h3 className="text-white font-bold text-lg">ERL Component Breakdown</h3>
              <button
                onClick={() => setShowBreakdown(false)}
                className="text-white/70 hover:text-white text-sm"
              >
                Collapse
              </button>
            </div>
          </div>

          <div className="p-6 space-y-4">
            {/* Net Outbound Credits */}
            <div className="border-l-4 border-green-500 bg-green-50 p-4 rounded">
              <div className="flex items-start justify-between mb-2">
                <div>
                  <div className="text-green-900 font-bold">1. Net Outbound Credits</div>
                  <div className="text-green-700 text-sm mt-1">
                    Gross Outbound – Same-Day Offsets
                  </div>
                </div>
                <div className="text-right">
                  <div className="text-green-900 font-mono font-bold text-lg">
                    {formatCurrency(metrics.grossOutboundCredits - metrics.sameDayEligibleOffsets)}
                  </div>
                </div>
              </div>
              <div className="grid grid-cols-2 gap-3 mt-3">
                <div className="bg-white rounded p-2">
                  <div className="text-green-700 text-xs">Gross Outbound</div>
                  <div className="text-green-900 font-mono font-bold">{formatCurrency(metrics.grossOutboundCredits)}</div>
                </div>
                <div className="bg-white rounded p-2">
                  <div className="text-green-700 text-xs">Same-Day Offsets</div>
                  <div className="text-green-900 font-mono font-bold">-{formatCurrency(metrics.sameDayEligibleOffsets)}</div>
                </div>
              </div>
            </div>

            {/* Stressed Amount */}
            <div className="border-l-4 border-purple-500 bg-purple-50 p-4 rounded">
              <div className="flex items-start justify-between mb-2">
                <div>
                  <div className="text-purple-900 font-bold">2. Stressed Outbound Credits</div>
                  <div className="text-purple-700 text-sm mt-1">
                    Net Outbound × Stress Multiplier ({(metrics.stressMultiplier * 100)}%)
                  </div>
                </div>
                <div className="text-right">
                  <div className="text-purple-900 font-mono font-bold text-lg">
                    {formatCurrency((metrics.grossOutboundCredits - metrics.sameDayEligibleOffsets) * metrics.stressMultiplier)}
                  </div>
                </div>
              </div>
              <div className="bg-white rounded p-2 mt-2">
                <div className="text-purple-700 text-xs mb-1">Stress Scenario</div>
                <div className="text-purple-900 text-sm">
                  Simulates {((metrics.stressMultiplier - 1) * 100).toFixed(0)}% increase in outbound payment volume
                </div>
              </div>
            </div>

            {/* Dynamic Return Reserve */}
            <div className="border-l-4 border-orange-500 bg-orange-50 p-4 rounded">
              <div className="flex items-start justify-between">
                <div>
                  <div className="text-orange-900 font-bold">3. Dynamic Return Reserve</div>
                  <div className="text-orange-700 text-sm mt-1">
                    Buffer for ACH returns and chargebacks
                  </div>
                </div>
                <div className="text-right">
                  <div className="text-orange-900 font-mono font-bold text-lg">
                    {formatCurrency(metrics.dynamicReturnReserve)}
                  </div>
                </div>
              </div>
            </div>

            {/* Micro-Deposit Settlement */}
            <div className="border-l-4 border-pink-500 bg-pink-50 p-4 rounded">
              <div className="flex items-start justify-between">
                <div>
                  <div className="text-pink-900 font-bold">4. Micro-Deposit Settlement Exposure</div>
                  <div className="text-pink-700 text-sm mt-1">
                    Pending verification micro-deposits
                  </div>
                </div>
                <div className="text-right">
                  <div className="text-pink-900 font-mono font-bold text-lg">
                    {formatCurrency(metrics.microDepositSettlementExposure)}
                  </div>
                </div>
              </div>
            </div>

            {/* Operational Buffer */}
            <div className="border-l-4 border-cyan-500 bg-cyan-50 p-4 rounded">
              <div className="flex items-start justify-between">
                <div>
                  <div className="text-cyan-900 font-bold">5. Operational Buffer</div>
                  <div className="text-cyan-700 text-sm mt-1">
                    Minimum operational liquidity cushion
                  </div>
                </div>
                <div className="text-right">
                  <div className="text-cyan-900 font-mono font-bold text-lg">
                    {formatCurrency(metrics.operationalBuffer)}
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Regulatory Compliance */}
      <div className="bg-gradient-to-br from-slate-50 to-slate-100 border border-slate-300 rounded-xl p-6">
        <div className="flex items-start gap-3">
          <Shield className="w-6 h-6 text-slate-700" />
          <div className="flex-1">
            <h3 className="text-slate-900 font-bold mb-3">Regulatory Compliance Framework</h3>
            <div className="grid grid-cols-2 gap-3">
              <div className="bg-white rounded-lg p-3">
                <div className="flex items-center gap-2 mb-1">
                  <CheckCircle className="w-4 h-4 text-green-600" />
                  <div className="text-slate-900 font-bold text-sm">Federal Reserve Reg D</div>
                </div>
                <div className="text-slate-600 text-xs">
                  Reserve requirements and liquidity ratios
                </div>
              </div>
              
              <div className="bg-white rounded-lg p-3">
                <div className="flex items-center gap-2 mb-1">
                  <CheckCircle className="w-4 h-4 text-green-600" />
                  <div className="text-slate-900 font-bold text-sm">OCC Liquidity Risk</div>
                </div>
                <div className="text-slate-600 text-xs">
                  Liquidity stress testing and monitoring
                </div>
              </div>
              
              <div className="bg-white rounded-lg p-3">
                <div className="flex items-center gap-2 mb-1">
                  <CheckCircle className="w-4 h-4 text-green-600" />
                  <div className="text-slate-900 font-bold text-sm">Basel III LCR</div>
                </div>
                <div className="text-slate-600 text-xs">
                  Liquidity Coverage Ratio principles
                </div>
              </div>
              
              <div className="bg-white rounded-lg p-3">
                <div className="flex items-center gap-2 mb-1">
                  <CheckCircle className="w-4 h-4 text-green-600" />
                  <div className="text-slate-900 font-bold text-sm">FFIEC Standards</div>
                </div>
                <div className="text-slate-600 text-xs">
                  Cash management examination readiness
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Risk Alerts */}
      {status.status !== 'healthy' && (
        <motion.div
          initial={{ opacity: 0, scale: 0.95 }}
          animate={{ opacity: 1, scale: 1 }}
          className={`border-2 rounded-xl p-6 ${
            status.status === 'warning' 
              ? 'bg-yellow-50 border-yellow-400' 
              : 'bg-red-50 border-red-400'
          }`}
        >
          <div className="flex items-start gap-3">
            <AlertTriangle className={`w-6 h-6 mt-0.5 ${
              status.status === 'warning' ? 'text-yellow-600' : 'text-red-600'
            }`} />
            <div className="flex-1">
              <h3 className={`font-bold text-lg mb-2 ${
                status.status === 'warning' ? 'text-yellow-900' : 'text-red-900'
              }`}>
                {status.status === 'warning' ? 'Liquidity Warning' : 'CRITICAL: Liquidity Shortfall'}
              </h3>
              <div className={`text-sm mb-3 ${
                status.status === 'warning' ? 'text-yellow-800' : 'text-red-800'
              }`}>
                {status.status === 'warning' 
                  ? 'Liquidity utilization is approaching warning thresholds. Monitor position closely.'
                  : 'IMMEDIATE ACTION REQUIRED: Liquidity reserves are critically low. Activate contingency funding plan.'}
              </div>
              
              <div className={`text-sm space-y-1 ${
                status.status === 'warning' ? 'text-yellow-800' : 'text-red-800'
              }`}>
                <div className="font-bold mb-2">Recommended Actions:</div>
                {status.status === 'warning' ? (
                  <>
                    <div>• Monitor intraday liquidity flows every 15 minutes</div>
                    <div>• Consider reducing same-day ACH origination volume</div>
                    <div>• Prepare contingency funding sources for activation</div>
                    <div>• Alert treasury operations and risk management</div>
                    <div>• Review large outbound payment schedule</div>
                  </>
                ) : (
                  <>
                    <div>• HALT all non-essential outbound payments immediately</div>
                    <div>• Activate emergency credit facilities with banking partners</div>
                    <div>• Escalate to CFO, CEO, and Board Risk Committee</div>
                    <div>• Implement emergency liquidity preservation protocols</div>
                    <div>• Prepare regulatory notification (if required)</div>
                  </>
                )}
              </div>
            </div>
          </div>
        </motion.div>
      )}
    </motion.div>
  );
}
