/**
 * Athena Lifetime Analytics - Real-Time Financial Intelligence
 * Powered by AWS Athena on 3xpres5 Express Infrastructure
 *
 * Provides lifetime transaction analytics, query interface, and real-time insights
 */

import React, { useState } from 'react';
import { motion } from 'motion/react';
import {
  Database,
  TrendingUp,
  DollarSign,
  Activity,
  BarChart3,
  Clock,
  Server,
  Zap,
  CheckCircle,
  AlertCircle,
  Search,
  Download
} from 'lucide-react';

interface QueryResult {
  query_id: string;
  status: 'QUEUED' | 'RUNNING' | 'SUCCEEDED' | 'FAILED';
  execution_time_ms: number;
  data_scanned_mb: number;
  rows_returned: number;
}

interface LifetimeMetric {
  label: string;
  value: string;
  change: string;
  trend: 'up' | 'down' | 'neutral';
}

export function AthenaLifetimeAnalytics() {
  const [activeQuery, setActiveQuery] = useState<string>('lifetime-overview');
  const [queryStatus, setQueryStatus] = useState<QueryResult | null>(null);
  const [isQuerying, setIsQuerying] = useState(false);

  // Simulate query execution
  const executeQuery = (queryType: string) => {
    setIsQuerying(true);
    setActiveQuery(queryType);

    setTimeout(() => {
      setQueryStatus({
        query_id: `athena-${Date.now()}`,
        status: 'SUCCEEDED',
        execution_time_ms: Math.floor(Math.random() * 2000) + 500,
        data_scanned_mb: Math.floor(Math.random() * 500) + 100,
        rows_returned: Math.floor(Math.random() * 10000) + 1000
      });
      setIsQuerying(false);
    }, 1500);
  };

  // Lifetime metrics
  const lifetimeMetrics: LifetimeMetric[] = [
    {
      label: 'Total Transaction Volume',
      value: '$847.3B',
      change: '+12.4%',
      trend: 'up'
    },
    {
      label: 'Lifetime Transactions',
      value: '24.8M',
      change: '+8.7%',
      trend: 'up'
    },
    {
      label: 'Average Transaction Size',
      value: '$34,187',
      change: '+3.2%',
      trend: 'up'
    },
    {
      label: 'Platform Uptime',
      value: '99.98%',
      change: '0.0%',
      trend: 'neutral'
    },
    {
      label: 'Active Accounts',
      value: '2,847',
      change: '+15.3%',
      trend: 'up'
    },
    {
      label: 'Settlement Success Rate',
      value: '99.94%',
      change: '+0.02%',
      trend: 'up'
    }
  ];

  // Predefined query templates
  const queryTemplates = [
    {
      id: 'lifetime-overview',
      name: 'Lifetime Overview',
      description: 'Aggregate statistics across all time',
      icon: TrendingUp
    },
    {
      id: 'daily-breakdown',
      name: 'Daily Breakdown',
      description: 'Transaction volume by day (last 90 days)',
      icon: BarChart3
    },
    {
      id: 'settlement-analysis',
      name: 'Settlement Analysis',
      description: 'ACH/Wire/RTP settlement patterns',
      icon: Activity
    },
    {
      id: 'liquidity-trends',
      name: 'Liquidity Trends',
      description: 'Historical liquidity utilization',
      icon: DollarSign
    }
  ];

  // Sample transaction data
  const recentTransactions = [
    { id: 'TXN-847293', timestamp: '2026-05-12 14:23:47', amount: 847293.42, type: 'ACH', status: 'SETTLED' },
    { id: 'TXN-847294', timestamp: '2026-05-12 14:24:12', amount: 234789.12, type: 'WIRE', status: 'SETTLED' },
    { id: 'TXN-847295', timestamp: '2026-05-12 14:24:38', amount: 567234.89, type: 'RTP', status: 'SETTLED' },
    { id: 'TXN-847296', timestamp: '2026-05-12 14:25:04', amount: 123456.78, type: 'ACH', status: 'PENDING' },
    { id: 'TXN-847297', timestamp: '2026-05-12 14:25:29', amount: 987654.32, type: 'WIRE', status: 'SETTLED' }
  ];

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="bg-gradient-to-r from-purple-900 to-indigo-900 rounded-xl p-6 border border-purple-500">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-4">
            <div className="bg-purple-500/20 p-3 rounded-lg">
              <Database className="w-8 h-8 text-purple-300" />
            </div>
            <div>
              <h1 className="text-2xl font-bold text-white">
                Athena Lifetime Analytics
              </h1>
              <p className="text-purple-200 mt-1">
                Real-Time Financial Intelligence • 3xpres5 Express Infrastructure
              </p>
            </div>
          </div>
          <div className="text-right">
            <div className="flex items-center gap-2 text-green-300">
              <Zap className="w-5 h-5" />
              <span className="font-semibold">LIVE</span>
            </div>
            <div className="text-sm text-purple-300 mt-1">
              Datacenter: 3xpres5 • Region: US-EAST
            </div>
          </div>
        </div>
      </div>

      {/* Infrastructure Status */}
      <div className="bg-slate-800 rounded-xl p-4 border border-slate-600">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-3">
            <Server className="w-5 h-5 text-blue-400" />
            <span className="text-white font-semibold">AWS Athena Query Engine</span>
          </div>
          <div className="flex items-center gap-6 text-sm">
            <div className="flex items-center gap-2">
              <div className="w-2 h-2 bg-green-500 rounded-full animate-pulse"></div>
              <span className="text-gray-300">S3 Bucket: sigma-banking-analytics</span>
            </div>
            <div className="flex items-center gap-2">
              <div className="w-2 h-2 bg-green-500 rounded-full animate-pulse"></div>
              <span className="text-gray-300">Database: production_ledger</span>
            </div>
            <div className="flex items-center gap-2">
              <CheckCircle className="w-4 h-4 text-green-500" />
              <span className="text-gray-300">Query Capacity: Available</span>
            </div>
          </div>
        </div>
      </div>

      {/* Lifetime Metrics Grid */}
      <div className="grid grid-cols-3 gap-4">
        {lifetimeMetrics.map((metric, index) => (
          <motion.div
            key={metric.label}
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: index * 0.1 }}
            className="bg-gradient-to-br from-slate-800 to-slate-900 rounded-lg p-6 border border-slate-600"
          >
            <div className="flex items-start justify-between">
              <div>
                <div className="text-sm text-gray-400 mb-1">{metric.label}</div>
                <div className="text-3xl font-bold text-white">{metric.value}</div>
              </div>
              <div className={`flex items-center gap-1 text-sm font-semibold ${
                metric.trend === 'up' ? 'text-green-400' :
                metric.trend === 'down' ? 'text-red-400' :
                'text-gray-400'
              }`}>
                {metric.trend === 'up' && <TrendingUp className="w-4 h-4" />}
                {metric.change}
              </div>
            </div>
            <div className="mt-3 h-1 bg-slate-700 rounded-full overflow-hidden">
              <motion.div
                initial={{ width: 0 }}
                animate={{ width: '100%' }}
                transition={{ delay: index * 0.1 + 0.3, duration: 1 }}
                className="h-full bg-gradient-to-r from-purple-500 to-blue-500"
              />
            </div>
          </motion.div>
        ))}
      </div>

      {/* Query Interface */}
      <div className="grid grid-cols-3 gap-6">
        {/* Query Templates */}
        <div className="col-span-1 space-y-3">
          <h3 className="text-lg font-bold text-white mb-3">Query Templates</h3>
          {queryTemplates.map((template) => {
            const Icon = template.icon;
            return (
              <motion.button
                key={template.id}
                onClick={() => executeQuery(template.id)}
                whileHover={{ scale: 1.02 }}
                whileTap={{ scale: 0.98 }}
                className={`w-full text-left p-4 rounded-lg border transition-all ${
                  activeQuery === template.id
                    ? 'bg-purple-900/40 border-purple-500'
                    : 'bg-slate-800 border-slate-600 hover:border-purple-500/50'
                }`}
              >
                <div className="flex items-start gap-3">
                  <Icon className={`w-5 h-5 mt-0.5 ${
                    activeQuery === template.id ? 'text-purple-400' : 'text-gray-400'
                  }`} />
                  <div>
                    <div className="text-white font-semibold">{template.name}</div>
                    <div className="text-sm text-gray-400 mt-1">{template.description}</div>
                  </div>
                </div>
              </motion.button>
            );
          })}
        </div>

        {/* Query Results */}
        <div className="col-span-2 bg-slate-800 rounded-xl p-6 border border-slate-600">
          <div className="flex items-center justify-between mb-4">
            <h3 className="text-lg font-bold text-white">Query Results</h3>
            {queryStatus && (
              <div className="flex items-center gap-4 text-sm">
                <div className="flex items-center gap-2">
                  <Clock className="w-4 h-4 text-blue-400" />
                  <span className="text-gray-300">{queryStatus.execution_time_ms}ms</span>
                </div>
                <div className="flex items-center gap-2">
                  <Database className="w-4 h-4 text-purple-400" />
                  <span className="text-gray-300">{queryStatus.data_scanned_mb}MB scanned</span>
                </div>
                <div className="flex items-center gap-2">
                  <CheckCircle className="w-4 h-4 text-green-400" />
                  <span className="text-gray-300">{queryStatus.rows_returned.toLocaleString()} rows</span>
                </div>
              </div>
            )}
          </div>

          {isQuerying ? (
            <div className="flex items-center justify-center py-12">
              <div className="text-center">
                <div className="inline-block animate-spin rounded-full h-12 w-12 border-4 border-purple-500 border-t-transparent mb-4"></div>
                <div className="text-gray-400">Executing Athena query...</div>
              </div>
            </div>
          ) : queryStatus ? (
            <div className="space-y-4">
              {/* Query Status Banner */}
              <div className="bg-green-900/30 border border-green-500 rounded-lg p-3 flex items-center gap-2">
                <CheckCircle className="w-5 h-5 text-green-400" />
                <span className="text-green-300 font-semibold">Query executed successfully</span>
                <span className="text-green-400 text-sm ml-auto">ID: {queryStatus.query_id}</span>
              </div>

              {/* Sample Data Table */}
              <div className="overflow-x-auto">
                <table className="w-full">
                  <thead>
                    <tr className="border-b border-slate-600">
                      <th className="text-left text-gray-400 font-semibold py-3 px-4">Transaction ID</th>
                      <th className="text-left text-gray-400 font-semibold py-3 px-4">Timestamp</th>
                      <th className="text-right text-gray-400 font-semibold py-3 px-4">Amount</th>
                      <th className="text-center text-gray-400 font-semibold py-3 px-4">Type</th>
                      <th className="text-center text-gray-400 font-semibold py-3 px-4">Status</th>
                    </tr>
                  </thead>
                  <tbody>
                    {recentTransactions.map((txn, idx) => (
                      <motion.tr
                        key={txn.id}
                        initial={{ opacity: 0, x: -20 }}
                        animate={{ opacity: 1, x: 0 }}
                        transition={{ delay: idx * 0.1 }}
                        className="border-b border-slate-700/50 hover:bg-slate-700/30 transition-colors"
                      >
                        <td className="py-3 px-4 font-mono text-purple-400">{txn.id}</td>
                        <td className="py-3 px-4 text-gray-300">{txn.timestamp}</td>
                        <td className="py-3 px-4 text-right text-white font-semibold">
                          ${txn.amount.toLocaleString('en-US', { minimumFractionDigits: 2 })}
                        </td>
                        <td className="py-3 px-4 text-center">
                          <span className={`px-2 py-1 rounded text-xs font-semibold ${
                            txn.type === 'ACH' ? 'bg-blue-900/50 text-blue-300' :
                            txn.type === 'WIRE' ? 'bg-green-900/50 text-green-300' :
                            'bg-purple-900/50 text-purple-300'
                          }`}>
                            {txn.type}
                          </span>
                        </td>
                        <td className="py-3 px-4 text-center">
                          <span className={`px-2 py-1 rounded text-xs font-semibold ${
                            txn.status === 'SETTLED' ? 'bg-green-900/50 text-green-300' :
                            'bg-yellow-900/50 text-yellow-300'
                          }`}>
                            {txn.status}
                          </span>
                        </td>
                      </motion.tr>
                    ))}
                  </tbody>
                </table>
              </div>

              {/* Export Actions */}
              <div className="flex justify-end gap-3 pt-4">
                <button className="flex items-center gap-2 px-4 py-2 bg-slate-700 hover:bg-slate-600 text-white rounded-lg transition-colors">
                  <Download className="w-4 h-4" />
                  Export CSV
                </button>
                <button className="flex items-center gap-2 px-4 py-2 bg-purple-600 hover:bg-purple-700 text-white rounded-lg transition-colors">
                  <Search className="w-4 h-4" />
                  Run Custom Query
                </button>
              </div>
            </div>
          ) : (
            <div className="flex items-center justify-center py-12">
              <div className="text-center text-gray-400">
                <Database className="w-16 h-16 mx-auto mb-4 opacity-50" />
                <div>Select a query template to begin</div>
              </div>
            </div>
          )}
        </div>
      </div>

      {/* 3xpres5 Infrastructure Info */}
      <div className="bg-gradient-to-r from-slate-800 to-slate-900 rounded-xl p-6 border border-slate-600">
        <div className="grid grid-cols-4 gap-6">
          <div>
            <div className="text-sm text-gray-400 mb-1">Infrastructure</div>
            <div className="text-white font-semibold">3xpres5 Datacenter</div>
            <div className="text-xs text-gray-500 mt-1">Rack 2 • Compute Nodes</div>
          </div>
          <div>
            <div className="text-sm text-gray-400 mb-1">Storage Layer</div>
            <div className="text-white font-semibold">S3 + Athena</div>
            <div className="text-xs text-gray-500 mt-1">Serverless Analytics</div>
          </div>
          <div>
            <div className="text-sm text-gray-400 mb-1">Data Retention</div>
            <div className="text-white font-semibold">7 Years</div>
            <div className="text-xs text-gray-500 mt-1">Regulatory Compliance</div>
          </div>
          <div>
            <div className="text-sm text-gray-400 mb-1">Query Throughput</div>
            <div className="text-white font-semibold">10,000 QPS</div>
            <div className="text-xs text-gray-500 mt-1">Express Performance</div>
          </div>
        </div>
      </div>
    </div>
  );
}
