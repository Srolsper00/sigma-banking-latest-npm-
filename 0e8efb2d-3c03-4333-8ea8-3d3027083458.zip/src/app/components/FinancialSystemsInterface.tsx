import { useState } from 'react';
import { motion } from 'motion/react';
import { Card } from './ui/card';
import { Button } from './ui/button';
import { 
  CreditCard, 
  Building2, 
  Network, 
  Database, 
  Shield, 
  Workflow,
  CheckCircle2,
  AlertCircle,
  RefreshCw,
  ArrowRight,
  Zap,
  Lock,
  Activity,
  FileText,
  Settings,
  Globe
} from 'lucide-react';

interface SystemStatus {
  name: string;
  status: 'connected' | 'disconnected' | 'syncing';
  lastSync: string;
}

export function FinancialSystemsInterface() {
  const [activeSystem, setActiveSystem] = useState<string | null>(null);
  const [topologyView, setTopologyView] = useState<'logical' | 'physical' | 'network'>('logical');
  
  const [systemStatuses, setSystemStatuses] = useState<Record<string, SystemStatus>>({
    intuit: {
      name: 'Intuit Pay Builder',
      status: 'connected',
      lastSync: '2026-03-17T14:28:00Z'
    },
    umb: {
      name: 'UMB Bank NA',
      status: 'connected',
      lastSync: '2026-03-17T14:30:00Z'
    },
    nacha: {
      name: 'NACHA ACH Network',
      status: 'connected',
      lastSync: '2026-03-17T14:25:00Z'
    },
    fedwire: {
      name: 'Fedwire Real-time',
      status: 'connected',
      lastSync: '2026-03-17T14:29:00Z'
    },
    apisix: {
      name: 'APISIX Gateway',
      status: 'connected',
      lastSync: '2026-03-17T14:31:00Z'
    },
    clearing: {
      name: '3xpres5 Clearing',
      status: 'connected',
      lastSync: '2026-03-17T14:28:30Z'
    }
  });

  const connectSystem = (systemKey: string) => {
    setSystemStatuses(prev => ({
      ...prev,
      [systemKey]: {
        ...prev[systemKey],
        status: 'syncing'
      }
    }));

    setTimeout(() => {
      setSystemStatuses(prev => ({
        ...prev,
        [systemKey]: {
          ...prev[systemKey],
          status: 'connected',
          lastSync: new Date().toISOString()
        }
      }));
    }, 2000);
  };

  const topologyMaps = {
    logical: {
      title: 'Logical Topology',
      description: 'Application layer architecture',
      nodes: [
        { id: 1, name: 'Intuit Pay Builder API', layer: 'Integration' },
        { id: 2, name: 'Payment Gateway', layer: 'Processing' },
        { id: 3, name: 'Ledger Engine', layer: 'Core' },
        { id: 4, name: 'Settlement Rails', layer: 'Banking' }
      ]
    },
    physical: {
      title: 'Physical Topology',
      description: '3xpres5 datacenter infrastructure',
      nodes: [
        { id: 1, name: 'Rack 1: Edge Control', layer: 'DMZ' },
        { id: 2, name: 'Rack 2: Compute Cluster', layer: 'Processing' },
        { id: 3, name: 'Rack 3: HSM + Storage', layer: 'Security' }
      ]
    },
    network: {
      title: 'Network Topology',
      description: 'Network routing and security zones',
      nodes: [
        { id: 1, name: 'APISIX Gateway (titaniumite5)', layer: 'Edge' },
        { id: 2, name: 'VNet (mathieu_et_favvarrow)', layer: 'Internal' },
        { id: 3, name: 'UMB NA Connection', layer: 'External' }
      ]
    }
  };

  const getStatusIcon = (status: string) => {
    switch (status) {
      case 'connected':
        return <CheckCircle2 className="w-4 h-4 text-green-500" />;
      case 'syncing':
        return <RefreshCw className="w-4 h-4 text-blue-500 animate-spin" />;
      case 'disconnected':
        return <AlertCircle className="w-4 h-4 text-red-500" />;
      default:
        return null;
    }
  };

  const getStatusBadge = (status: string) => {
    const baseClasses = "px-2 py-1 rounded-full text-xs font-semibold";
    switch (status) {
      case 'connected':
        return `${baseClasses} bg-green-100 text-green-700`;
      case 'syncing':
        return `${baseClasses} bg-blue-100 text-blue-700`;
      case 'disconnected':
        return `${baseClasses} bg-red-100 text-red-700`;
      default:
        return baseClasses;
    }
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <motion.div
        initial={{ opacity: 0, y: -20 }}
        animate={{ opacity: 1, y: 0 }}
        className="bg-gradient-to-r from-blue-600 to-purple-600 rounded-lg p-6 text-white"
      >
        <div className="flex items-center gap-3 mb-2">
          <Network className="w-8 h-8" />
          <h2 className="text-2xl font-bold">Financial Systems Interface</h2>
        </div>
        <p className="text-blue-100">
          Intuit Pay Builder • UMB Bank NA • NACHA ACH • 3xpres5 Clearing Platform
        </p>
      </motion.div>

      {/* System Integration Buttons */}
      <Card className="p-6">
        <h3 className="text-lg font-semibold mb-4 flex items-center gap-2">
          <Zap className="w-5 h-5 text-blue-600" />
          System Integrations
        </h3>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {/* Intuit Pay Builder */}
          <motion.div
            whileHover={{ scale: 1.02 }}
            className={`border rounded-lg p-4 cursor-pointer transition-all ${
              activeSystem === 'intuit' 
                ? 'border-blue-500 bg-blue-50 shadow-md' 
                : 'border-slate-200 hover:border-blue-300'
            }`}
            onClick={() => setActiveSystem(activeSystem === 'intuit' ? null : 'intuit')}
          >
            <div className="flex items-start justify-between mb-3">
              <div className="flex items-center gap-2">
                <div className="bg-blue-600 p-2 rounded">
                  <CreditCard className="w-5 h-5 text-white" />
                </div>
                <div>
                  <div className="font-semibold text-sm">Intuit Pay Builder</div>
                  <div className="text-xs text-slate-500">Payment Processing</div>
                </div>
              </div>
              {getStatusIcon(systemStatuses.intuit.status)}
            </div>

            <div className="space-y-2">
              <div className={getStatusBadge(systemStatuses.intuit.status)}>
                {systemStatuses.intuit.status.toUpperCase()}
              </div>
              
              {activeSystem === 'intuit' && (
                <motion.div
                  initial={{ opacity: 0, height: 0 }}
                  animate={{ opacity: 1, height: 'auto' }}
                  className="space-y-2 pt-2 border-t"
                >
                  <div className="text-xs text-slate-600">
                    Last sync: {new Date(systemStatuses.intuit.lastSync).toLocaleString()}
                  </div>
                  <div className="flex gap-2">
                    <Button 
                      size="sm" 
                      className="flex-1 text-xs"
                      onClick={(e) => {
                        e.stopPropagation();
                        connectSystem('intuit');
                      }}
                    >
                      <RefreshCw className="w-3 h-3 mr-1" />
                      Sync
                    </Button>
                    <Button 
                      size="sm" 
                      variant="outline" 
                      className="flex-1 text-xs"
                      onClick={(e) => e.stopPropagation()}
                    >
                      <Settings className="w-3 h-3 mr-1" />
                      Config
                    </Button>
                  </div>
                  <div className="bg-blue-100 p-2 rounded text-xs">
                    <div className="font-semibold mb-1">API Endpoint:</div>
                    <code className="text-xs">https://api.intuit.com/v1/payments</code>
                  </div>
                </motion.div>
              )}
            </div>
          </motion.div>

          {/* UMB Bank NA */}
          <motion.div
            whileHover={{ scale: 1.02 }}
            className={`border rounded-lg p-4 cursor-pointer transition-all ${
              activeSystem === 'umb' 
                ? 'border-green-500 bg-green-50 shadow-md' 
                : 'border-slate-200 hover:border-green-300'
            }`}
            onClick={() => setActiveSystem(activeSystem === 'umb' ? null : 'umb')}
          >
            <div className="flex items-start justify-between mb-3">
              <div className="flex items-center gap-2">
                <div className="bg-green-600 p-2 rounded">
                  <Building2 className="w-5 h-5 text-white" />
                </div>
                <div>
                  <div className="font-semibold text-sm">UMB Bank NA</div>
                  <div className="text-xs text-slate-500">Core Banking</div>
                </div>
              </div>
              {getStatusIcon(systemStatuses.umb.status)}
            </div>

            <div className="space-y-2">
              <div className={getStatusBadge(systemStatuses.umb.status)}>
                {systemStatuses.umb.status.toUpperCase()}
              </div>
              
              {activeSystem === 'umb' && (
                <motion.div
                  initial={{ opacity: 0, height: 0 }}
                  animate={{ opacity: 1, height: 'auto' }}
                  className="space-y-2 pt-2 border-t"
                >
                  <div className="text-xs text-slate-600">
                    Last sync: {new Date(systemStatuses.umb.lastSync).toLocaleString()}
                  </div>
                  <div className="flex gap-2">
                    <Button 
                      size="sm" 
                      className="flex-1 text-xs"
                      onClick={(e) => {
                        e.stopPropagation();
                        connectSystem('umb');
                      }}
                    >
                      <RefreshCw className="w-3 h-3 mr-1" />
                      Sync
                    </Button>
                    <Button 
                      size="sm" 
                      variant="outline" 
                      className="flex-1 text-xs"
                    >
                      <Settings className="w-3 h-3 mr-1" />
                      Config
                    </Button>
                  </div>
                  <div className="bg-green-100 p-2 rounded text-xs">
                    <div className="font-semibold mb-1">Banking Rails:</div>
                    <div>• ACH • Wire • RTP • FedNow</div>
                  </div>
                </motion.div>
              )}
            </div>
          </motion.div>

          {/* NACHA ACH */}
          <motion.div
            whileHover={{ scale: 1.02 }}
            className={`border rounded-lg p-4 cursor-pointer transition-all ${
              activeSystem === 'nacha' 
                ? 'border-purple-500 bg-purple-50 shadow-md' 
                : 'border-slate-200 hover:border-purple-300'
            }`}
            onClick={() => setActiveSystem(activeSystem === 'nacha' ? null : 'nacha')}
          >
            <div className="flex items-start justify-between mb-3">
              <div className="flex items-center gap-2">
                <div className="bg-purple-600 p-2 rounded">
                  <Workflow className="w-5 h-5 text-white" />
                </div>
                <div>
                  <div className="font-semibold text-sm">NACHA ACH</div>
                  <div className="text-xs text-slate-500">Batch Processing</div>
                </div>
              </div>
              {getStatusIcon(systemStatuses.nacha.status)}
            </div>

            <div className="space-y-2">
              <div className={getStatusBadge(systemStatuses.nacha.status)}>
                {systemStatuses.nacha.status.toUpperCase()}
              </div>
              
              {activeSystem === 'nacha' && (
                <motion.div
                  initial={{ opacity: 0, height: 0 }}
                  animate={{ opacity: 1, height: 'auto' }}
                  className="space-y-2 pt-2 border-t"
                >
                  <div className="text-xs text-slate-600">
                    Last sync: {new Date(systemStatuses.nacha.lastSync).toLocaleString()}
                  </div>
                  <div className="flex gap-2">
                    <Button 
                      size="sm" 
                      className="flex-1 text-xs"
                      onClick={(e) => {
                        e.stopPropagation();
                        connectSystem('nacha');
                      }}
                    >
                      <RefreshCw className="w-3 h-3 mr-1" />
                      Sync
                    </Button>
                    <Button 
                      size="sm" 
                      variant="outline" 
                      className="flex-1 text-xs"
                    >
                      <Settings className="w-3 h-3 mr-1" />
                      Config
                    </Button>
                  </div>
                  <div className="bg-purple-100 p-2 rounded text-xs">
                    <div className="font-semibold mb-1">Formats:</div>
                    <div>• CCD • PPD • CTX • WEB</div>
                  </div>
                </motion.div>
              )}
            </div>
          </motion.div>

          {/* Fedwire */}
          <motion.div
            whileHover={{ scale: 1.02 }}
            className={`border rounded-lg p-4 cursor-pointer transition-all ${
              activeSystem === 'fedwire' 
                ? 'border-orange-500 bg-orange-50 shadow-md' 
                : 'border-slate-200 hover:border-orange-300'
            }`}
            onClick={() => setActiveSystem(activeSystem === 'fedwire' ? null : 'fedwire')}
          >
            <div className="flex items-start justify-between mb-3">
              <div className="flex items-center gap-2">
                <div className="bg-orange-600 p-2 rounded">
                  <Zap className="w-5 h-5 text-white" />
                </div>
                <div>
                  <div className="font-semibold text-sm">Fedwire RTP</div>
                  <div className="text-xs text-slate-500">Real-time Payments</div>
                </div>
              </div>
              {getStatusIcon(systemStatuses.fedwire.status)}
            </div>

            <div className="space-y-2">
              <div className={getStatusBadge(systemStatuses.fedwire.status)}>
                {systemStatuses.fedwire.status.toUpperCase()}
              </div>
              
              {activeSystem === 'fedwire' && (
                <motion.div
                  initial={{ opacity: 0, height: 0 }}
                  animate={{ opacity: 1, height: 'auto' }}
                  className="space-y-2 pt-2 border-t"
                >
                  <div className="text-xs text-slate-600">
                    Last sync: {new Date(systemStatuses.fedwire.lastSync).toLocaleString()}
                  </div>
                  <div className="flex gap-2">
                    <Button 
                      size="sm" 
                      className="flex-1 text-xs"
                      onClick={(e) => {
                        e.stopPropagation();
                        connectSystem('fedwire');
                      }}
                    >
                      <RefreshCw className="w-3 h-3 mr-1" />
                      Sync
                    </Button>
                    <Button 
                      size="sm" 
                      variant="outline" 
                      className="flex-1 text-xs"
                    >
                      <Settings className="w-3 h-3 mr-1" />
                      Config
                    </Button>
                  </div>
                  <div className="bg-orange-100 p-2 rounded text-xs">
                    <div className="font-semibold mb-1">Settlement:</div>
                    <div>Real-time gross settlement (RTGS)</div>
                  </div>
                </motion.div>
              )}
            </div>
          </motion.div>

          {/* APISIX Gateway */}
          <motion.div
            whileHover={{ scale: 1.02 }}
            className={`border rounded-lg p-4 cursor-pointer transition-all ${
              activeSystem === 'apisix' 
                ? 'border-indigo-500 bg-indigo-50 shadow-md' 
                : 'border-slate-200 hover:border-indigo-300'
            }`}
            onClick={() => setActiveSystem(activeSystem === 'apisix' ? null : 'apisix')}
          >
            <div className="flex items-start justify-between mb-3">
              <div className="flex items-center gap-2">
                <div className="bg-indigo-600 p-2 rounded">
                  <Shield className="w-5 h-5 text-white" />
                </div>
                <div>
                  <div className="font-semibold text-sm">APISIX Gateway</div>
                  <div className="text-xs text-slate-500">API Management</div>
                </div>
              </div>
              {getStatusIcon(systemStatuses.apisix.status)}
            </div>

            <div className="space-y-2">
              <div className={getStatusBadge(systemStatuses.apisix.status)}>
                {systemStatuses.apisix.status.toUpperCase()}
              </div>
              
              {activeSystem === 'apisix' && (
                <motion.div
                  initial={{ opacity: 0, height: 0 }}
                  animate={{ opacity: 1, height: 'auto' }}
                  className="space-y-2 pt-2 border-t"
                >
                  <div className="text-xs text-slate-600">
                    Last sync: {new Date(systemStatuses.apisix.lastSync).toLocaleString()}
                  </div>
                  <div className="flex gap-2">
                    <Button 
                      size="sm" 
                      className="flex-1 text-xs"
                      onClick={(e) => {
                        e.stopPropagation();
                        connectSystem('apisix');
                      }}
                    >
                      <RefreshCw className="w-3 h-3 mr-1" />
                      Sync
                    </Button>
                    <Button 
                      size="sm" 
                      variant="outline" 
                      className="flex-1 text-xs"
                    >
                      <Settings className="w-3 h-3 mr-1" />
                      Config
                    </Button>
                  </div>
                  <div className="bg-indigo-100 p-2 rounded text-xs">
                    <div className="font-semibold mb-1">Public IP:</div>
                    <code>titaniumite5</code>
                  </div>
                </motion.div>
              )}
            </div>
          </motion.div>

          {/* 3xpres5 Clearing */}
          <motion.div
            whileHover={{ scale: 1.02 }}
            className={`border rounded-lg p-4 cursor-pointer transition-all ${
              activeSystem === 'clearing' 
                ? 'border-teal-500 bg-teal-50 shadow-md' 
                : 'border-slate-200 hover:border-teal-300'
            }`}
            onClick={() => setActiveSystem(activeSystem === 'clearing' ? null : 'clearing')}
          >
            <div className="flex items-start justify-between mb-3">
              <div className="flex items-center gap-2">
                <div className="bg-teal-600 p-2 rounded">
                  <Database className="w-5 h-5 text-white" />
                </div>
                <div>
                  <div className="font-semibold text-sm">3xpres5 Clearing</div>
                  <div className="text-xs text-slate-500">Settlement Platform</div>
                </div>
              </div>
              {getStatusIcon(systemStatuses.clearing.status)}
            </div>

            <div className="space-y-2">
              <div className={getStatusBadge(systemStatuses.clearing.status)}>
                {systemStatuses.clearing.status.toUpperCase()}
              </div>
              
              {activeSystem === 'clearing' && (
                <motion.div
                  initial={{ opacity: 0, height: 0 }}
                  animate={{ opacity: 1, height: 'auto' }}
                  className="space-y-2 pt-2 border-t"
                >
                  <div className="text-xs text-slate-600">
                    Last sync: {new Date(systemStatuses.clearing.lastSync).toLocaleString()}
                  </div>
                  <div className="flex gap-2">
                    <Button 
                      size="sm" 
                      className="flex-1 text-xs"
                      onClick={(e) => {
                        e.stopPropagation();
                        connectSystem('clearing');
                      }}
                    >
                      <RefreshCw className="w-3 h-3 mr-1" />
                      Sync
                    </Button>
                    <Button 
                      size="sm" 
                      variant="outline" 
                      className="flex-1 text-xs"
                    >
                      <Settings className="w-3 h-3 mr-1" />
                      Config
                    </Button>
                  </div>
                  <div className="bg-teal-100 p-2 rounded text-xs">
                    <div className="font-semibold mb-1">Capacity:</div>
                    <div>$42B operational ceiling</div>
                  </div>
                </motion.div>
              )}
            </div>
          </motion.div>
        </div>
      </Card>

      {/* Topology Reference Panel */}
      <Card className="p-6">
        <div className="flex items-center justify-between mb-4">
          <h3 className="text-lg font-semibold flex items-center gap-2">
            <Globe className="w-5 h-5 text-purple-600" />
            System Topology Reference
          </h3>
          
          <div className="flex gap-2">
            <Button
              size="sm"
              variant={topologyView === 'logical' ? 'default' : 'outline'}
              onClick={() => setTopologyView('logical')}
            >
              Logical
            </Button>
            <Button
              size="sm"
              variant={topologyView === 'physical' ? 'default' : 'outline'}
              onClick={() => setTopologyView('physical')}
            >
              Physical
            </Button>
            <Button
              size="sm"
              variant={topologyView === 'network' ? 'default' : 'outline'}
              onClick={() => setTopologyView('network')}
            >
              Network
            </Button>
          </div>
        </div>

        <motion.div
          key={topologyView}
          initial={{ opacity: 0, x: -20 }}
          animate={{ opacity: 1, x: 0 }}
          transition={{ duration: 0.3 }}
        >
          <div className="bg-gradient-to-br from-slate-50 to-slate-100 rounded-lg p-6 border border-slate-200">
            <div className="mb-4">
              <h4 className="font-semibold text-lg">{topologyMaps[topologyView].title}</h4>
              <p className="text-sm text-slate-600">{topologyMaps[topologyView].description}</p>
            </div>

            <div className="space-y-3">
              {topologyMaps[topologyView].nodes.map((node, index) => (
                <motion.div
                  key={node.id}
                  initial={{ opacity: 0, x: -20 }}
                  animate={{ opacity: 1, x: 0 }}
                  transition={{ delay: index * 0.1 }}
                  className="flex items-center gap-4 bg-white p-4 rounded-lg shadow-sm"
                >
                  <div className="flex-shrink-0 w-12 h-12 bg-gradient-to-br from-blue-500 to-purple-500 rounded-lg flex items-center justify-center text-white font-bold">
                    {node.id}
                  </div>
                  <div className="flex-1">
                    <div className="font-semibold">{node.name}</div>
                    <div className="text-xs text-slate-500">Layer: {node.layer}</div>
                  </div>
                  {index < topologyMaps[topologyView].nodes.length - 1 && (
                    <ArrowRight className="w-5 h-5 text-slate-400" />
                  )}
                </motion.div>
              ))}
            </div>

            {/* Topology Details */}
            <div className="mt-6 grid grid-cols-2 gap-4">
              <div className="bg-blue-50 p-4 rounded-lg">
                <div className="flex items-center gap-2 mb-2">
                  <Activity className="w-4 h-4 text-blue-600" />
                  <div className="font-semibold text-sm">Active Nodes</div>
                </div>
                <div className="text-2xl font-bold text-blue-600">
                  {topologyMaps[topologyView].nodes.length}
                </div>
              </div>

              <div className="bg-green-50 p-4 rounded-lg">
                <div className="flex items-center gap-2 mb-2">
                  <Lock className="w-4 h-4 text-green-600" />
                  <div className="font-semibold text-sm">Security Status</div>
                </div>
                <div className="text-sm font-semibold text-green-600">
                  All Systems Secure
                </div>
              </div>
            </div>
          </div>
        </motion.div>
      </Card>

      {/* Quick Actions */}
      <Card className="p-6 bg-gradient-to-r from-slate-50 to-slate-100">
        <h3 className="text-lg font-semibold mb-4 flex items-center gap-2">
          <FileText className="w-5 h-5 text-slate-600" />
          Quick Actions
        </h3>

        <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
          <Button variant="outline" className="w-full">
            <Database className="w-4 h-4 mr-2" />
            View Topology
          </Button>
          <Button variant="outline" className="w-full">
            <Activity className="w-4 h-4 mr-2" />
            Health Check
          </Button>
          <Button variant="outline" className="w-full">
            <FileText className="w-4 h-4 mr-2" />
            Export Config
          </Button>
          <Button variant="outline" className="w-full">
            <Shield className="w-4 h-4 mr-2" />
            Security Audit
          </Button>
        </div>
      </Card>

      {/* Connection Status Summary */}
      <Card className="p-4 bg-green-50 border-green-200">
        <div className="flex items-center gap-3">
          <CheckCircle2 className="w-6 h-6 text-green-600" />
          <div>
            <div className="font-semibold text-green-900">All Systems Operational</div>
            <div className="text-sm text-green-700">
              6/6 financial systems connected • Last updated: {new Date().toLocaleTimeString()}
            </div>
          </div>
        </div>
      </Card>
    </div>
  );
}
