import { motion } from 'motion/react';
import { useState } from 'react';
import { 
  FileDigit, 
  Search, 
  DollarSign, 
  CheckSquare, 
  Lock, 
  Send, 
  FileCheck,
  ChevronRight,
  Clock
} from 'lucide-react';

export function RunbookPanel() {
  const [completedSteps, setCompletedSteps] = useState<number[]>([]);

  const steps = [
    {
      id: 1,
      title: 'Snapshot & Hash',
      description: 'Create canonical PayrollIntent JSON and compute SHA-256. Persist in audit store.',
      icon: FileDigit,
      color: 'blue',
      action: 'Generate Hash'
    },
    {
      id: 2,
      title: 'Auto-Reconciliation',
      description: 'Run script to detect duplicate/overlap timestamps and mark suspicious 24-hour shifts for manual review.',
      icon: Search,
      color: 'purple',
      action: 'Run Check'
    },
    {
      id: 3,
      title: 'Confirm Pay Rates',
      description: 'For final dollar amounts, attach pay rates for each job code. Ensure accuracy before approval.',
      icon: DollarSign,
      color: 'green',
      action: 'Verify Rates'
    },
    {
      id: 4,
      title: 'Approval',
      description: 'Create the envelope_id and circulate to required approvers (PayrollOps → Treasury → Compliance).',
      icon: CheckSquare,
      color: 'amber',
      action: 'Start Approval'
    },
    {
      id: 5,
      title: 'Pre-fund Check',
      description: 'Reserve funds on DDA once Treasurer approves (create ledger reservation; do not move money).',
      icon: Lock,
      color: 'indigo',
      action: 'Reserve Funds'
    },
    {
      id: 6,
      title: 'Release',
      description: 'On final approval, generate NACHA file, sign with HSM, and push to ODFI. Persist PayrollReleaseEvent with idempotency key.',
      icon: Send,
      color: 'red',
      action: 'Execute Release'
    },
    {
      id: 7,
      title: 'Post-audit',
      description: 'Produce statement (Reg E) for employee and attach to audit log.',
      icon: FileCheck,
      color: 'emerald',
      action: 'Generate Statement'
    }
  ];

  const getColorClasses = (color: string) => {
    const colors = {
      blue: { bg: 'bg-blue-500', light: 'bg-blue-50', text: 'text-blue-700', border: 'border-blue-200' },
      purple: { bg: 'bg-purple-500', light: 'bg-purple-50', text: 'text-purple-700', border: 'border-purple-200' },
      green: { bg: 'bg-green-500', light: 'bg-green-50', text: 'text-green-700', border: 'border-green-200' },
      amber: { bg: 'bg-amber-500', light: 'bg-amber-50', text: 'text-amber-700', border: 'border-amber-200' },
      indigo: { bg: 'bg-indigo-500', light: 'bg-indigo-50', text: 'text-indigo-700', border: 'border-indigo-200' },
      red: { bg: 'bg-red-500', light: 'bg-red-50', text: 'text-red-700', border: 'border-red-200' },
      emerald: { bg: 'bg-emerald-500', light: 'bg-emerald-50', text: 'text-emerald-700', border: 'border-emerald-200' }
    };
    return colors[color as keyof typeof colors];
  };

  const toggleStep = (stepId: number) => {
    if (completedSteps.includes(stepId)) {
      setCompletedSteps(completedSteps.filter(id => id !== stepId));
    } else {
      setCompletedSteps([...completedSteps, stepId]);
    }
  };

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.6 }}
      className="mt-8"
    >
      <div className="bg-white rounded-lg shadow-lg border border-slate-200 p-6">
        <div className="flex items-center justify-between mb-6">
          <div className="flex items-center gap-3">
            <div className="p-2 bg-slate-900 rounded-lg">
              <Clock className="w-6 h-6 text-white" />
            </div>
            <div>
              <h2 className="text-slate-900">Immediate Runbook</h2>
              <p className="text-slate-600 text-sm">Concrete steps — execute these now</p>
            </div>
          </div>
          <div className="text-right">
            <div className="text-2xl font-bold text-slate-900">{completedSteps.length}/7</div>
            <div className="text-xs text-slate-500">Completed</div>
          </div>
        </div>

        {/* Progress Bar */}
        <div className="mb-6">
          <div className="w-full bg-slate-200 rounded-full h-2">
            <motion.div
              initial={{ width: 0 }}
              animate={{ width: `${(completedSteps.length / steps.length) * 100}%` }}
              transition={{ duration: 0.5 }}
              className="bg-gradient-to-r from-blue-600 to-purple-600 h-2 rounded-full"
            />
          </div>
        </div>

        {/* Steps */}
        <div className="space-y-3">
          {steps.map((step, index) => {
            const colors = getColorClasses(step.color);
            const Icon = step.icon;
            const isCompleted = completedSteps.includes(step.id);
            const isNext = completedSteps.length === step.id - 1;

            return (
              <motion.div
                key={step.id}
                initial={{ opacity: 0, x: -20 }}
                animate={{ opacity: 1, x: 0 }}
                transition={{ delay: index * 0.05 }}
                className={`
                  ${colors.light} 
                  border-2 ${colors.border}
                  rounded-lg p-4
                  ${isNext ? 'ring-2 ring-blue-400' : ''}
                  ${isCompleted ? 'opacity-60' : ''}
                  transition-all
                `}
              >
                <div className="flex items-start gap-4">
                  {/* Step Number & Icon */}
                  <div className="flex flex-col items-center gap-2">
                    <div className={`w-10 h-10 ${colors.bg} rounded-full flex items-center justify-center text-white font-bold`}>
                      {step.id}
                    </div>
                    <div className={`p-2 ${colors.light} rounded-lg border ${colors.border}`}>
                      <Icon className={`w-5 h-5 ${colors.text}`} />
                    </div>
                  </div>

                  {/* Content */}
                  <div className="flex-1">
                    <div className="flex items-start justify-between mb-2">
                      <h3 className={`${colors.text} font-medium`}>{step.title}</h3>
                      {isCompleted && (
                        <span className="bg-green-100 text-green-700 text-xs px-2 py-1 rounded-full">
                          ✓ Done
                        </span>
                      )}
                      {isNext && !isCompleted && (
                        <span className="bg-blue-100 text-blue-700 text-xs px-2 py-1 rounded-full animate-pulse">
                          → Next
                        </span>
                      )}
                    </div>
                    <p className="text-slate-600 text-sm mb-3">{step.description}</p>
                    
                    {/* Action Button */}
                    <motion.button
                      whileHover={{ scale: 1.02 }}
                      whileTap={{ scale: 0.98 }}
                      onClick={() => toggleStep(step.id)}
                      className={`
                        ${isCompleted ? 'bg-slate-300 text-slate-600' : colors.bg + ' text-white'}
                        px-4 py-2 rounded-lg text-sm flex items-center gap-2
                        transition-colors hover:opacity-90
                      `}
                    >
                      {isCompleted ? 'Undo' : step.action}
                      <ChevronRight className="w-4 h-4" />
                    </motion.button>
                  </div>
                </div>

                {/* Connector Line */}
                {index < steps.length - 1 && (
                  <div className="ml-5 mt-2 mb-0">
                    <div className="w-0.5 h-4 bg-slate-300"></div>
                  </div>
                )}
              </motion.div>
            );
          })}
        </div>

        {/* Completion Message */}
        {completedSteps.length === steps.length && (
          <motion.div
            initial={{ opacity: 0, scale: 0.9 }}
            animate={{ opacity: 1, scale: 1 }}
            className="mt-6 bg-gradient-to-r from-green-600 to-emerald-600 text-white rounded-lg p-4 text-center"
          >
            <CheckSquare className="w-8 h-8 mx-auto mb-2" />
            <div className="font-medium">All steps completed!</div>
            <div className="text-sm opacity-90">Payroll processing ready for final release</div>
          </motion.div>
        )}
      </div>
    </motion.div>
  );
}
