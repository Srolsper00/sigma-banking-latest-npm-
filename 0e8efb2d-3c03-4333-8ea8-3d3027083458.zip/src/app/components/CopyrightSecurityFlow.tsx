import { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from './ui/card';
import { Tabs, TabsContent, TabsList, TabsTrigger } from './ui/tabs';
import { Badge } from './ui/badge';
import { Button } from './ui/button';
import {
  Shield,
  Lock,
  Globe,
  CheckCircle,
  AlertTriangle,
  Activity,
  Eye,
  Key,
  Server,
  Zap,
  Network,
  FileCheck,
  ArrowRight,
  GitBranch,
  Radio,
  Layers
} from 'lucide-react';

interface SecurityZone {
  id: string;
  name: string;
  cidr: string;
  description: string;
  icon: string;
  status: 'active' | 'monitoring' | 'restricted';
  threatLevel: 'low' | 'medium' | 'high';
}

interface SecurityLayer {
  id: string;
  name: string;
  description: string;
  controls: string[];
  status: 'active' | 'verifying';
}

interface TrustValidation {
  step: string;
  validation: string;
  status: 'pending' | 'verified' | 'active';
  timestamp: string;
}

export function CopyrightSecurityFlow() {
  const [selectedTab, setSelectedTab] = useState<'flow' | 'zones' | 'validation' | 'monitoring'>('flow');
  const [animateFlow, setAnimateFlow] = useState(true);
  const [selectedLayer, setSelectedLayer] = useState<string | null>(null);

  // Security Zones
  const securityZones: SecurityZone[] = [
    {
      id: 'external',
      name: 'External Clients',
      cidr: '/24',
      description: 'Broad access, tightly monitored',
      icon: '🌐',
      status: 'monitoring',
      threatLevel: 'medium'
    },
    {
      id: 'partners',
      name: 'Partner Banks',
      cidr: '/26',
      description: 'Privileged, but controlled',
      icon: '🏦',
      status: 'active',
      threatLevel: 'low'
    },
    {
      id: 'internal',
      name: 'Internal Services',
      cidr: '10.0.10.255/28',
      description: 'Highly restricted, mission-critical',
      icon: '🔒',
      status: 'restricted',ʼactiveʼ,
      threatLevel: 'low'
    }
  ];

  // Security Layers
  const securityLayers: SecurityLayer[] = [
    {
      id: 'gatekeeper',
      name: 'API Gateway / WAF',
      description: 'Every request meets a hardened perimeter',
      controls: [
        'Mutual TLS certificate verification',
        'OAuth2 token validation',
        'JWT signature inspection',
        'CIDR range allowlisting',
        'IP-to-cell zone mapping',
        'Rate limiting & DDoS shielding'
      ],
      status: 'active'
    },
    {
      id: 'zerotrust',
      name: 'Zero Trust Network',
      description: 'No service trusts another by default',
      controls: [
        'Service-to-service authentication',
        'Path verification on every call',
        'Surgical network segmentation',
        'Observable security cells',
        'Continuous validation',
        'Least privilege enforcement'
      ],
      status: 'active'
    },
    {
      id: 'identity',
      name: 'Identity Enforcement',
      description: 'Cryptographic identity at every layer',
      controls: [
        'Client certificate validation',
        'Service account verification',
        'API key rotation',
        'Multi-factor authentication',
        'Session integrity checks',
        'Identity token refresh'
      ],
      status: 'active'
    },
    {
      id: 'processing',
      name: 'Transaction Processing',
      description: 'Deterministic access control',
      controls: [
        'Idempotency protection',
        'Atomic operations',
        'Balance verification',
        'Ledger integrity',
        'Merkle tree validation',
        'HSM signature'
      ],
      status: 'verifying'
    }
  ];

  // Trust Validation Flow
  const trustValidations: TrustValidation[] = [
    {
      step: 'Identity',
      validation: 'Client certificates verified via mutual TLS',
      status: 'verified',
      timestamp: new Date(Date.now() - 3000).toISOString()
    },
    {
      step: 'Authorization',
      validation: 'OAuth2 tokens validated against authorization server',
      status: 'verified',
      timestamp: new Date(Date.now() - 2500).toISOString()
    },
    {
      step: 'Segmentation',
      validation: 'Network zone assignment based on CIDR classification',
      status: 'verified',
      timestamp: new Date(Date.now() - 2000).toISOString()
    },
    {
      step: 'Protection',
      validation: 'DDoS mitigation and rate limiting applied',
      status: 'active',
      timestamp: new Date(Date.now() - 1500).toISOString()
    }
  ];

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'active':
      case 'verified':
        return 'bg-green-100 text-green-800 border-green-300';
      case 'monitoring':
      case 'verifying':
      case 'pending':
        return 'bg-blue-100 text-blue-800 border-blue-300';
      case 'restricted':
        return 'bg-amber-100 text-amber-800 border-amber-300';
      default:
        return 'bg-slate-100 text-slate-800 border-slate-300';
    }
  };

  const getThreatColor = (level: string) => {
    switch (level) {
      case 'low':
        return 'text-green-600';
      case 'medium':
        return 'text-amber-600';
      case 'high':
        return 'text-red-600';
      default:
        return 'text-slate-600';
    }
  };

  return (
    <div className="space-y-6">
      {/* Header with Branding */}
      <motion.div
        initial={{ opacity: 0, y: -20 }}
        animate={{ opacity: 1, y: 0 }}
        className="relative overflow-hidden rounded-xl bg-gradient-to-br from-indigo-600 via-blue-600 to-purple-600 p-8 text-white"
      >
        <div className="relative z-10">
          <div className="flex items-center gap-3 mb-3">
            <Shield className="w-10 h-10" />
            <h1 className="text-4xl font-bold">Where Every Transaction Earns Trust</h1>
          </div>
          <p className="text-xl text-blue-100 mb-6">
            Secure by architecture. Trusted by design. Ready for every transaction.
          </p>
          <div className="flex items-center gap-4">
            <Badge variant="outline" className="bg-white/20 text-white border-white/40 backdrop-blur-sm px-4 py-2">
              <Lock className="w-4 h-4 mr-2" />
              Zero Trust Architecture
            </Badge>
            <Badge variant="outline" className="bg-white/20 text-white border-white/40 backdrop-blur-sm px-4 py-2">
              <Key className="w-4 h-4 mr-2" />
              Cryptographic Identity
            </Badge>
            <Badge variant="outline" className="bg-white/20 text-white border-white/40 backdrop-blur-sm px-4 py-2">
              <Layers className="w-4 h-4 mr-2" />
              Telecom-Grade Segmentation
            </Badge>
          </div>
        </div>
        
        {/* Background decoration */}
        <div className="absolute top-0 right-0 w-96 h-96 bg-white/10 rounded-full blur-3xl" />
        <div className="absolute bottom-0 left-0 w-64 h-64 bg-purple-400/20 rounded-full blur-2xl" />
      </motion.div>

      {/* Main Tabs */}
      <Tabs value={selectedTab} onValueChange={(value) => setSelectedTab(value as any)} className="w-full">
        <TabsList className="grid w-full grid-cols-4">
          <TabsTrigger value="flow">Security Flow</TabsTrigger>
          <TabsTrigger value="zones">Network Zones</TabsTrigger>
          <TabsTrigger value="validation">Trust Validation</TabsTrigger>
          <TabsTrigger value="monitoring">Live Monitoring</TabsTrigger>
        </TabsList>

        {/* Security Flow Tab */}
        <TabsContent value="flow" className="space-y-6">
          <Card>
            <CardHeader>
              <div className="flex items-center justify-between">
                <div>
                  <CardTitle className="flex items-center gap-2">
                    <GitBranch className="w-5 h-5 text-blue-600" />
                    Enterprise Security Flow
                  </CardTitle>
                  <CardDescription>
                    Multi-layered protection from edge to transaction processing
                  </CardDescription>
                </div>
                <Button
                  onClick={() => setAnimateFlow(!animateFlow)}
                  variant="outline"
                  size="sm"
                >
                  <Activity className={`w-4 h-4 mr-2 ${animateFlow ? 'animate-pulse' : ''}`} />
                  {animateFlow ? 'Pause' : 'Animate'}
                </Button>
              </div>
            </CardHeader>
            <CardContent>
              <div className="space-y-6">
                {/* The Edge */}
                <motion.div
                  initial={{ opacity: 0, x: -20 }}
                  animate={{ opacity: 1, x: 0 }}
                  className="border-2 border-slate-300 rounded-lg p-6 bg-slate-50"
                >
                  <div className="flex items-start gap-4">
                    <div className="w-12 h-12 bg-slate-600 rounded-full flex items-center justify-center flex-shrink-0">
                      <Globe className="w-6 h-6 text-white" />
                    </div>
                    <div className="flex-1">
                      <h3 className="text-xl font-bold text-slate-900 mb-2">It begins at the edge.</h3>
                      <div className="space-y-2 text-slate-700">
                        <p className="font-semibold">Client APIs. Partner Banks. Fintech Integrators.</p>
                        <p>They initiate the request—fast, global, and unforgiving.</p>
                        <div className="mt-3 p-3 bg-amber-50 border-l-4 border-amber-500 rounded">
                          <p className="text-sm font-semibold text-amber-900">
                            But before anything moves forward… <span className="underline">trust must be established.</span>
                          </p>
                        </div>
                      </div>
                    </div>
                  </div>
                </motion.div>

                <div className="flex justify-center">
                  <motion.div
                    animate={animateFlow ? {
                      y: [0, 10, 0],
                      opacity: [0.5, 1, 0.5]
                    } : {}}
                    transition={{
                      duration: 2,
                      repeat: Infinity,
                      ease: "easeInOut"
                    }}
                  >
                    <ArrowRight className="w-6 h-6 text-blue-600 rotate-90" />
                  </motion.div>
                </div>

                {/* Security Layers */}
                {securityLayers.map((layer, index) => (
                  <div key={layer.id}>
                    <motion.div
                      initial={{ opacity: 0, x: -20 }}
                      animate={{ 
                        opacity: 1, 
                        x: 0,
                        backgroundColor: animateFlow && selectedLayer === layer.id
                          ? ['#f1f5f9', '#dbeafe', '#f1f5f9']
                          : '#f1f5f9'
                      }}
                      transition={{ 
                        delay: index * 0.1,
                        backgroundColor: {
                          duration: 2,
                          repeat: Infinity
                        }
                      }}
                      className="border-2 border-blue-300 rounded-lg p-6 cursor-pointer hover:shadow-lg transition-shadow"
                      onClick={() => setSelectedLayer(selectedLayer === layer.id ? null : layer.id)}
                    >
                      <div className="flex items-start justify-between mb-4">
                        <div className="flex items-start gap-4 flex-1">
                          <div className="w-12 h-12 bg-blue-600 rounded-full flex items-center justify-center flex-shrink-0">
                            {index === 0 && <Shield className="w-6 h-6 text-white" />}
                            {index === 1 && <Network className="w-6 h-6 text-white" />}
                            {index === 2 && <Key className="w-6 h-6 text-white" />}
                            {index === 3 && <Zap className="w-6 h-6 text-white" />}
                          </div>
                          <div className="flex-1">
                            <div className="flex items-center gap-3 mb-2">
                              <h3 className="text-xl font-bold text-slate-900">{layer.name}</h3>
                              <Badge variant="outline" className={getStatusColor(layer.status)}>
                                {layer.status.toUpperCase()}
                              </Badge>
                            </div>
                            <p className="text-slate-600 italic mb-3">"{layer.description}"</p>
                          </div>
                        </div>
                      </div>

                      <AnimatePresence>
                        {selectedLayer === layer.id && (
                          <motion.div
                            initial={{ opacity: 0, height: 0 }}
                            animate={{ opacity: 1, height: 'auto' }}
                            exit={{ opacity: 0, height: 0 }}
                            className="border-t-2 border-blue-200 pt-4 mt-4"
                          >
                            <p className="text-sm font-semibold text-slate-700 mb-3">Security Controls:</p>
                            <div className="grid grid-cols-1 md:grid-cols-2 gap-2">
                              {layer.controls.map((control, idx) => (
                                <motion.div
                                  key={idx}
                                  initial={{ opacity: 0, x: -10 }}
                                  animate={{ opacity: 1, x: 0 }}
                                  transition={{ delay: idx * 0.05 }}
                                  className="flex items-center gap-2 text-sm"
                                >
                                  <CheckCircle className="w-4 h-4 text-green-600 flex-shrink-0" />
                                  <span className="text-slate-700">{control}</span>
                                </motion.div>
                              ))}
                            </div>
                          </motion.div>
                        )}
                      </AnimatePresence>
                    </motion.div>

                    {index < securityLayers.length - 1 && (
                      <div className="flex justify-center py-3">
                        <motion.div
                          animate={animateFlow ? {
                            y: [0, 10, 0],
                            opacity: [0.5, 1, 0.5]
                          } : {}}
                          transition={{
                            duration: 2,
                            repeat: Infinity,
                            ease: "easeInOut",
                            delay: index * 0.5
                          }}
                        >
                          <ArrowRight className="w-6 h-6 text-blue-600 rotate-90" />
                        </motion.div>
                      </div>
                    )}
                  </div>
                ))}

                {/* Final Result */}
                <motion.div
                  initial={{ opacity: 0, scale: 0.95 }}
                  animate={{ opacity: 1, scale: 1 }}
                  transition={{ delay: 0.6 }}
                  className="border-2 border-green-300 rounded-lg p-6 bg-gradient-to-br from-green-50 to-blue-50"
                >
                  <div className="flex items-start gap-4">
                    <div className="w-12 h-12 bg-green-600 rounded-full flex items-center justify-center flex-shrink-0">
                      <CheckCircle className="w-6 h-6 text-white" />
                    </div>
                    <div className="flex-1">
                      <h3 className="text-xl font-bold text-green-900 mb-3">The Result</h3>
                      <p className="text-slate-700 mb-4">
                        Before a transaction is even processed… it has already passed through:
                      </p>
                      <div className="flex items-center gap-3 flex-wrap">
                        <Badge className="bg-green-600 text-white">Identity</Badge>
                        <ArrowRight className="w-4 h-4 text-slate-400" />
                        <Badge className="bg-blue-600 text-white">Authorization</Badge>
                        <ArrowRight className="w-4 h-4 text-slate-400" />
                        <Badge className="bg-purple-600 text-white">Segmentation</Badge>
                        <ArrowRight className="w-4 h-4 text-slate-400" />
                        <Badge className="bg-indigo-600 text-white">Protection</Badge>
                      </div>
                      <p className="text-green-800 font-semibold mt-4">
                        Only then does it earn the right to move forward.
                      </p>
                    </div>
                  </div>
                </motion.div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        {/* Network Zones Tab */}
        <TabsContent value="zones" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Network className="w-5 h-5 text-purple-600" />
                Telecom-Grade Network Segmentation
              </CardTitle>
              <CardDescription>
                Each CIDR block becomes its own security cell—isolated, observable, and enforceable
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {securityZones.map((zone, index) => (
                  <motion.div
                    key={zone.id}
                    initial={{ opacity: 0, y: 20 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ delay: index * 0.1 }}
                    className="border-2 border-purple-200 rounded-lg p-6 hover:shadow-lg transition-shadow"
                  >
                    <div className="flex items-start justify-between mb-4">
                      <div className="flex items-center gap-4">
                        <div className="text-4xl">{zone.icon}</div>
                        <div>
                          <div className="flex items-center gap-3 mb-2">
                            <h3 className="text-xl font-bold text-slate-900">{zone.name}</h3>
                            <Badge className="font-mono bg-purple-600 text-white">{zone.cidr}</Badge>
                          </div>
                          <p className="text-slate-600">{zone.description}</p>
                        </div>
                      </div>
                      <div className="flex flex-col items-end gap-2">
                        <Badge variant="outline" className={getStatusColor(zone.status)}>
                          {zone.status.toUpperCase()}
                        </Badge>
                        <div className="flex items-center gap-2 text-sm">
                          <span className="text-slate-600">Threat Level:</span>
                          <span className={`font-bold ${getThreatColor(zone.threatLevel)}`}>
                            {zone.threatLevel.toUpperCase()}
                          </span>
                        </div>
                      </div>
                    </div>

                    <div className="grid grid-cols-1 md:grid-cols-3 gap-4 pt-4 border-t border-purple-200">
                      <div className="flex items-center gap-2">
                        <Eye className="w-4 h-4 text-purple-600" />
                        <span className="text-sm text-slate-700">Continuous Monitoring</span>
                      </div>
                      <div className="flex items-center gap-2">
                        <Lock className="w-4 h-4 text-purple-600" />
                        <span className="text-sm text-slate-700">Strict Access Control</span>
                      </div>
                      <div className="flex items-center gap-2">
                        <Radio className="w-4 h-4 text-purple-600" />
                        <span className="text-sm text-slate-700">Real-Time Alerts</span>
                      </div>
                    </div>
                  </motion.div>
                ))}
              </div>

              <div className="mt-6 p-6 bg-gradient-to-r from-purple-50 to-indigo-50 border-2 border-purple-200 rounded-lg">
                <div className="flex items-start gap-3">
                  <Shield className="w-6 h-6 text-purple-600 mt-1" />
                  <div>
                    <h4 className="font-bold text-slate-900 mb-2">Why This Matters</h4>
                    <p className="text-slate-700 mb-3">Because in financial systems:</p>
                    <div className="space-y-2 text-sm text-slate-700">
                      <div className="flex items-start gap-2">
                        <AlertTriangle className="w-4 h-4 text-red-600 mt-0.5 flex-shrink-0" />
                        <span>One weak endpoint = systemic risk</span>
                      </div>
                      <div className="flex items-start gap-2">
                        <AlertTriangle className="w-4 h-4 text-red-600 mt-0.5 flex-shrink-0" />
                        <span>One unauthorized request = regulatory failure</span>
                      </div>
                      <div className="flex items-start gap-2">
                        <AlertTriangle className="w-4 h-4 text-red-600 mt-0.5 flex-shrink-0" />
                        <span>One delay = liquidity exposure</span>
                      </div>
                    </div>
                    <div className="mt-4 pt-4 border-t border-purple-200">
                      <p className="font-semibold text-slate-900 mb-2">So instead, you get:</p>
                      <div className="grid grid-cols-2 gap-2">
                        <div className="flex items-center gap-2">
                          <CheckCircle className="w-4 h-4 text-green-600" />
                          <span className="text-sm">Deterministic access control</span>
                        </div>
                        <div className="flex items-center gap-2">
                          <CheckCircle className="w-4 h-4 text-green-600" />
                          <span className="text-sm">Telecom-grade segmentation</span>
                        </div>
                        <div className="flex items-center gap-2">
                          <CheckCircle className="w-4 h-4 text-green-600" />
                          <span className="text-sm">Cryptographic identity enforcement</span>
                        </div>
                        <div className="flex items-center gap-2">
                          <CheckCircle className="w-4 h-4 text-green-600" />
                          <span className="text-sm">Real-time threat mitigation</span>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        {/* Trust Validation Tab */}
        <TabsContent value="validation" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <FileCheck className="w-5 h-5 text-green-600" />
                Trust Validation Pipeline
              </CardTitle>
              <CardDescription>
                Identity → Authorization → Segmentation → Protection
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {trustValidations.map((validation, index) => (
                  <motion.div
                    key={index}
                    initial={{ opacity: 0, x: -20 }}
                    animate={{ opacity: 1, x: 0 }}
                    transition={{ delay: index * 0.15 }}
                    className="border-2 border-slate-200 rounded-lg p-4 hover:shadow-md transition-shadow"
                  >
                    <div className="flex items-start justify-between mb-3">
                      <div className="flex items-center gap-3">
                        <div className={`w-10 h-10 rounded-full flex items-center justify-center ${
                          validation.status === 'verified' ? 'bg-green-600' :
                          validation.status === 'active' ? 'bg-blue-600' :
                          'bg-amber-600'
                        }`}>
                          {validation.status === 'verified' && <CheckCircle className="w-5 h-5 text-white" />}
                          {validation.status === 'active' && <Activity className="w-5 h-5 text-white" />}
                          {validation.status === 'pending' && <AlertTriangle className="w-5 h-5 text-white" />}
                        </div>
                        <div>
                          <div className="font-bold text-slate-900">{validation.step}</div>
                          <div className="text-sm text-slate-600">{validation.validation}</div>
                        </div>
                      </div>
                      <Badge variant="outline" className={getStatusColor(validation.status)}>
                        {validation.status.toUpperCase()}
                      </Badge>
                    </div>
                    <div className="flex items-center gap-2 text-xs text-slate-500 pl-13">
                      <Activity className="w-3 h-3" />
                      <span>{new Date(validation.timestamp).toLocaleString()}</span>
                    </div>
                  </motion.div>
                ))}
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        {/* Live Monitoring Tab */}
        <TabsContent value="monitoring" className="space-y-6">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            <motion.div
              initial={{ opacity: 0, scale: 0.95 }}
              animate={{ opacity: 1, scale: 1 }}
            >
              <Card className="border-2 border-green-200">
                <CardHeader>
                  <CardTitle className="text-lg flex items-center gap-2">
                    <CheckCircle className="w-5 h-5 text-green-600" />
                    Verified Requests
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="text-center">
                    <div className="text-4xl font-bold text-green-600">99.97%</div>
                    <div className="text-sm text-slate-600 mt-2">Last 24 hours</div>
                    <div className="mt-4 text-xs text-slate-500">
                      2,450,382 / 2,451,115 requests
                    </div>
                  </div>
                </CardContent>
              </Card>
            </motion.div>

            <motion.div
              initial={{ opacity: 0, scale: 0.95 }}
              animate={{ opacity: 1, scale: 1 }}
              transition={{ delay: 0.1 }}
            >
              <Card className="border-2 border-red-200">
                <CardHeader>
                  <CardTitle className="text-lg flex items-center gap-2">
                    <AlertTriangle className="w-5 h-5 text-red-600" />
                    Blocked Threats
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="text-center">
                    <div className="text-4xl font-bold text-red-600">733</div>
                    <div className="text-sm text-slate-600 mt-2">Last 24 hours</div>
                    <div className="mt-4 text-xs text-slate-500">
                      DDoS, malformed tokens, bad certs
                    </div>
                  </div>
                </CardContent>
              </Card>
            </motion.div>

            <motion.div
              initial={{ opacity: 0, scale: 0.95 }}
              animate={{ opacity: 1, scale: 1 }}
              transition={{ delay: 0.2 }}
            >
              <Card className="border-2 border-blue-200">
                <CardHeader>
                  <CardTitle className="text-lg flex items-center gap-2">
                    <Server className="w-5 h-5 text-blue-600" />
                    Active Zones
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="text-center">
                    <div className="text-4xl font-bold text-blue-600">{securityZones.length}</div>
                    <div className="text-sm text-slate-600 mt-2">Network segments</div>
                    <div className="mt-4 text-xs text-slate-500">
                      All monitored in real-time
                    </div>
                  </div>
                </CardContent>
              </Card>
            </motion.div>
          </div>

          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Activity className="w-5 h-5 text-blue-600" />
                Real-Time Security Events
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-2">
                {[
                  { type: 'success', msg: 'TLS handshake verified for partner bank connection', time: '2s ago' },
                  { type: 'success', msg: 'OAuth2 token validated for API client', time: '5s ago' },
                  { type: 'warning', msg: 'Rate limit applied to external client (429)', time: '12s ago' },
                  { type: 'success', msg: 'JWT signature verified and session created', time: '18s ago' },
                  { type: 'blocked', msg: 'Malformed certificate rejected at gateway', time: '24s ago' },
                  { type: 'success', msg: 'Internal service authenticated via mTLS', time: '31s ago' }
                ].map((event, index) => (
                  <motion.div
                    key={index}
                    initial={{ opacity: 0, x: -20 }}
                    animate={{ opacity: 1, x: 0 }}
                    transition={{ delay: index * 0.05 }}
                    className={`border-l-4 p-3 rounded ${
                      event.type === 'success' ? 'border-green-500 bg-green-50' :
                      event.type === 'warning' ? 'border-amber-500 bg-amber-50' :
                      'border-red-500 bg-red-50'
                    }`}
                  >
                    <div className="flex items-center justify-between">
                      <span className="text-sm text-slate-800">{event.msg}</span>
                      <span className="text-xs text-slate-500">{event.time}</span>
                    </div>
                  </motion.div>
                ))}
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>

      {/* Footer Branding */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.4 }}
      >
        <Card className="border-2 border-indigo-200 bg-gradient-to-br from-indigo-50 to-purple-50">
          <CardContent className="pt-6">
            <div className="text-center">
              <p className="text-2xl font-bold text-transparent bg-clip-text bg-gradient-to-r from-indigo-600 to-purple-600 mb-2">
                "Secure by architecture. Trusted by design. Ready for every transaction."
              </p>
              <p className="text-sm text-slate-600">
                Copyright © 2026 Sigma Banking Platform • Enterprise Fintech Security Framework
              </p>
            </div>
          </CardContent>
        </Card>
      </motion.div>
    </div>
  );
}
