/**
 * Asset Management & Business Environment Control Module
 * NIST Cybersecurity Framework - IDENTIFY Function
 * Copyright © 2026 VOM Services Corporation
 * Matthew James Sauls - OCIO, CCO, CEO, CFO, CTO
 * EIN: 83-1427324 | FCC FRN: 0033213463
 *
 * Implements ID.AM-1 through ID.AM-6 and ID.BE-1 through ID.BE-4
 * Banking Partner: UMB Bank NA
 * NIST SP 800-57 Cryptographic Guidelines
 */

import { useState, useEffect } from "react";
import { motion, AnimatePresence } from "motion/react";
import { Card } from "./ui/card";
import { Button } from "./ui/button";
import { Badge } from "./ui/badge";
import {
  Tabs,
  TabsContent,
  TabsList,
  TabsTrigger,
} from "./ui/tabs";
import {
  Shield,
  Server,
  Lock,
  Eye,
  EyeOff,
  Download,
  Settings,
  AlertTriangle,
  CheckCircle2,
  Database,
  Cloud,
  Network,
  Users,
  Building2,
  FileText,
  ArrowRight,
  Layers,
  Package,
  Target,
  GitBranch,
  Clock,
  DollarSign,
  Filter,
} from "lucide-react";
import { toast } from "sonner";

interface AuditLog {
  timestamp: string;
  user: string;
  action: string;
  resource: string;
}

interface PhysicalAsset {
  id: string;
  name: string;
  type: string;
  criticality: "Critical" | "High" | "Medium" | "Low";
  status: "Active" | "Inactive" | "Maintenance";
  location: string;
  owner: string;
  lastUpdated: string;
}

interface SoftwarePlatform {
  id: string;
  name: string;
  vendor: string;
  version: string;
  licenseType: string;
  criticality: "Critical" | "High" | "Medium";
  status: "Active" | "Deprecated";
}

interface DataFlow {
  id: string;
  source: string;
  destination: string;
  protocol: string;
  encryption: string;
  sensitivity: string;
  dataType: string;
}

interface ExternalSystem {
  id: string;
  name: string;
  provider: string;
  connectionType: string;
  sla: string;
  purpose: string;
}

interface ResourcePriority {
  id: string;
  name: string;
  tier: "Tier-1 Critical" | "Tier-2 High";
  rto: string;
  rpo: string;
  businessValue: string;
}

interface CybersecurityRole {
  id: string;
  title: string;
  department: string;
  owner: string;
  responsibilities: string[];
  frameworks: string[];
}

export function AssetManagementControlModule() {
  const [secureMode, setSecureMode] = useState(false);
  const [showDetails, setShowDetails] = useState(true);
  const [criticalityFilter, setCriticalityFilter] =
    useState<string>("All");
  const [auditLog, setAuditLog] = useState<AuditLog[]>([]);

  // Physical Assets (ID.AM-1)
  const physicalAssets: PhysicalAsset[] = [
    {
      id: "PA-001",
      name: "Core Banking Server Cluster",
      type: "Server Infrastructure",
      criticality: "Critical",
      status: "Active",
      location: "3xpres5 Datacenter - Seattle, WA",
      owner: "Infrastructure Team",
      lastUpdated: "2026-04-15",
    },
    {
      id: "PA-002",
      name: "Payment Gateway Server",
      type: "Payment Processing",
      criticality: "Critical",
      status: "Active",
      location: "3xpres5 Datacenter - Seattle, WA",
      owner: "Payment Operations",
      lastUpdated: "2026-04-15",
    },
    {
      id: "PA-003",
      name: "Tokenization Vault Appliance",
      type: "Security Infrastructure",
      criticality: "Critical",
      status: "Active",
      location: "3xpres5 Datacenter - Seattle, WA",
      owner: "Security Team",
      lastUpdated: "2026-04-15",
    },
    {
      id: "PA-004",
      name: "ATM Network Controllers",
      type: "Banking Infrastructure",
      criticality: "High",
      status: "Active",
      location: "Distributed - Multi-Region",
      owner: "ATM Operations",
      lastUpdated: "2026-04-14",
    },
    {
      id: "PA-005",
      name: "Backup Storage Array",
      type: "Storage Infrastructure",
      criticality: "High",
      status: "Active",
      location: "AWS us-west-2",
      owner: "Infrastructure Team",
      lastUpdated: "2026-04-15",
    },
    {
      id: "PA-006",
      name: "Compliance Workstations",
      type: "Workstation",
      criticality: "Medium",
      status: "Active",
      location: "VOM Corporate Office",
      owner: "Compliance Department",
      lastUpdated: "2026-04-13",
    },
  ];

  // Software Platforms (ID.AM-2)
  const softwarePlatforms: SoftwarePlatform[] = [
    {
      id: "SW-001",
      name: "Core Banking Platform",
      vendor: "Jack Henry & Associates",
      version: "2024.1",
      licenseType: "Enterprise",
      criticality: "Critical",
      status: "Active",
    },
    {
      id: "SW-002",
      name: "DDA Tokenization Service",
      vendor: "HashiCorp Vault",
      version: "1.15.x",
      licenseType: "Enterprise",
      criticality: "Critical",
      status: "Active",
    },
    {
      id: "SW-003",
      name: "Payment Rails Gateway",
      vendor: "The Clearing House",
      version: "RTP v3.2",
      licenseType: "Commercial",
      criticality: "Critical",
      status: "Active",
    },
    {
      id: "SW-004",
      name: "NULS Blockchain Integration",
      vendor: "NULS Foundation",
      version: "v2.8.0",
      licenseType: "Open Source",
      criticality: "High",
      status: "Active",
    },
    {
      id: "SW-005",
      name: "Fraud Detection Engine",
      vendor: "FICO",
      version: "10.2",
      licenseType: "Enterprise",
      criticality: "Critical",
      status: "Active",
    },
    {
      id: "SW-006",
      name: "MongoDB Atlas Ledger",
      vendor: "MongoDB Inc.",
      version: "v7.0",
      licenseType: "Enterprise",
      criticality: "Critical",
      status: "Active",
    },
  ];

  // Data Flows (ID.AM-3)
  const dataFlows: DataFlow[] = [
    {
      id: "DF-001",
      source: "Customer Portal",
      destination: "Core Banking",
      protocol: "HTTPS",
      encryption: "TLS 1.3",
      sensitivity: "PII/PCI",
      dataType: "Transaction Data",
    },
    {
      id: "DF-002",
      source: "DDA Service",
      destination: "Tokenization Vault",
      protocol: "mTLS",
      encryption: "AES-256-GCM",
      sensitivity: "Highly Sensitive",
      dataType: "Account Tokens",
    },
    {
      id: "DF-003",
      source: "Payment Gateway",
      destination: "ACH Network",
      protocol: "SFTP",
      encryption: "TLS 1.3",
      sensitivity: "PCI",
      dataType: "Payment Instructions",
    },
    {
      id: "DF-004",
      source: "Audit System",
      destination: "Immutable Ledger",
      protocol: "HTTPS",
      encryption: "TLS 1.3",
      sensitivity: "Compliance",
      dataType: "Audit Logs",
    },
    {
      id: "DF-005",
      source: "NULS Blockchain",
      destination: "Architecture Nodes",
      protocol: "P2P",
      encryption: "ECDSA Encrypted",
      sensitivity: "Public",
      dataType: "Blockchain Data",
    },
  ];

  // External Systems (ID.AM-4)
  const externalSystems: ExternalSystem[] = [
    {
      id: "ES-001",
      name: "UMB Bank NA Core System",
      provider: "UMB Financial Corporation",
      connectionType: "Dedicated Link",
      sla: "99.99%",
      purpose: "Primary Banking Partner",
    },
    {
      id: "ES-002",
      name: "Federal Reserve FedNow",
      provider: "Federal Reserve",
      connectionType: "Secure Gateway",
      sla: "99.95%",
      purpose: "Real-Time Payments",
    },
    {
      id: "ES-003",
      name: "The Clearing House RTP",
      provider: "The Clearing House",
      connectionType: "Direct API",
      sla: "99.98%",
      purpose: "RTP Network Access",
    },
    {
      id: "ES-004",
      name: "NULS Blockchain Network",
      provider: "NULS Foundation",
      connectionType: "P2P Network",
      sla: "Best Effort",
      purpose: "Blockchain Integration",
    },
    {
      id: "ES-005",
      name: "AWS Infrastructure",
      provider: "Amazon Web Services",
      connectionType: "VPC Peering",
      sla: "99.99%",
      purpose: "Cloud Infrastructure",
    },
  ];

  // Resource Priorities (ID.AM-5)
  const resourcePriorities: ResourcePriority[] = [
    {
      id: "RP-001",
      name: "Core Banking Platform",
      tier: "Tier-1 Critical",
      rto: "1 hour",
      rpo: "15 minutes",
      businessValue: "$10B+ daily transactions",
    },
    {
      id: "RP-002",
      name: "Tokenization Vault",
      tier: "Tier-1 Critical",
      rto: "30 minutes",
      rpo: "0 (hot standby)",
      businessValue: "Security foundation",
    },
    {
      id: "RP-003",
      name: "Payment Rails",
      tier: "Tier-1 Critical",
      rto: "2 hours",
      rpo: "30 minutes",
      businessValue: "$5M+ settlements/day",
    },
    {
      id: "RP-004",
      name: "Fraud Detection",
      tier: "Tier-2 High",
      rto: "4 hours",
      rpo: "1 hour",
      businessValue: "Risk mitigation",
    },
    {
      id: "RP-005",
      name: "Compliance Reporting",
      tier: "Tier-2 High",
      rto: "8 hours",
      rpo: "4 hours",
      businessValue: "Regulatory compliance",
    },
    {
      id: "RP-006",
      name: "Customer Portal",
      tier: "Tier-2 High",
      rto: "4 hours",
      rpo: "2 hours",
      businessValue: "Customer experience",
    },
  ];

  // Cybersecurity Roles (ID.AM-6)
  const cybersecurityRoles: CybersecurityRole[] = [
    {
      id: "CR-001",
      title: "Chief Information Security Officer (CISO)",
      department: "C-SUITE IT Executive Leadership",
      owner: "Matthew James Sauls",
      responsibilities: [
        "Strategic cybersecurity leadership",
        "Risk management oversight",
        "Board-level security reporting",
        "Compliance program direction",
        "Security budget allocation",
      ],
      frameworks: ["NIST CSF", "ISO 27001", "FFIEC"],
    },
    {
      id: "CR-002",
      title: "Security Operations Center (SOC) Team",
      department: "Security Department",
      owner: "SOC Manager",
      responsibilities: [
        "24/7 security monitoring",
        "Incident detection and response",
        "Threat intelligence analysis",
        "SIEM management",
        "Security alert triage",
      ],
      frameworks: [
        "NIST SP 800-61",
        "CIS Controls",
        "MITRE ATT&CK",
      ],
    },
    {
      id: "CR-003",
      title: "Vault Administrator",
      department: "Infrastructure Security",
      owner: "OBLMFGJE Security Infrastructure Team ",
      responsibilities: [
        "HashiCorp Vault management",
        "Tokenization service oversight",
        "Cryptographic key lifecycle",
        "Secret rotation policies",
        "Access control enforcement",
      ],
      frameworks: ["NIST SP 800-57", "PCI DSS", "FIPS 140-2"],
    },
    {
      id: "CR-004",
      title: "Third-Party Risk Manager",
      department: "Compliance",
      owner: "OBLMFGJE Risk Management",
      responsibilities: [
        "Vendor security assessments",
        "Third-party due diligence",
        "Contract security review",
        "Ongoing vendor monitoring",
        "Supply chain risk management",
      ],
      frameworks: [
        "FFIEC Guidelines",
        "NIST SP 800-161",
        "ISO 27036",
      ],
    },
    {
      id: "CR-005",
      title: "DDA Service Owner",
      department: "Banking Operations",
      owner: "VOM Banking Operations Manager",
      responsibilities: [
        "DDA platform security",
        "Account tokenization oversight",
        "Banking operations compliance",
        "System access management",
        "Change control approval",
      ],
      frameworks: ["FFIEC", "Regulation E", "UCC Article 4A"],
    },
  ];

  const addAuditLog = (action: string, resource: string) => {
    const log: AuditLog = {
      timestamp: new Date().toISOString(),
      user: "OBLMFGJE ADMINISTRATOR",
      action,
      resource,
    };
    setAuditLog((prev) => [log, ...prev.slice(0, 49)]);
    console.log("Audit Log:", log);
  };

  const toggleSecureMode = () => {
    const newMode = !secureMode;
    setSecureMode(newMode);
    addAuditLog(
      newMode ? "ENABLED_SECURE_MODE" : "DISABLED_SECURE_MODE",
      "Asset Management Module",
    );
    toast.success(
      newMode ? "Secure Mode Enabled" : "Secure Mode Disabled",
    );
  };

  const exportData = (dataType: string, data: any) => {
    addAuditLog("EXPORTED_DATA", dataType);
    const json = JSON.stringify(data, null, 2);
    const blob = new Blob([json], { type: "application/json" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = `${dataType.toLowerCase().replace(/\s+/g, "-")}-${Date.now()}.json`;
    a.click();
    toast.success(`Exported ${dataType}`);
  };

  const getCriticalityColor = (criticality: string) => {
    switch (criticality) {
      case "Critical":
        return "bg-red-600 text-white";
      case "High":
        return "bg-orange-600 text-white";
      case "Medium":
        return "bg-yellow-600 text-white";
      case "Low":
        return "bg-blue-600 text-white";
      default:
        return "bg-gray-600 text-white";
    }
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case "Active":
        return "text-green-400";
      case "Inactive":
        return "text-red-400";
      case "Maintenance":
        return "text-yellow-400";
      case "Deprecated":
        return "text-orange-400";
      default:
        return "text-gray-400";
    }
  };

  const filteredAssets =
    criticalityFilter === "All"
      ? physicalAssets
      : physicalAssets.filter(
          (asset) => asset.criticality === criticalityFilter,
        );

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-900 via-blue-900 to-slate-900 p-8">
      <div className="max-w-7xl mx-auto space-y-6">
        {/* Header */}
        <motion.div
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          className="text-center space-y-3"
        >
          <div className="flex items-center justify-center gap-3 mb-4">
            <Shield className="w-10 h-10 text-blue-400" />
            <h1 className="text-4xl font-bold text-white">
              Asset Management & Business Environment
            </h1>
          </div>
          <p className="text-blue-200">
            NIST Cybersecurity Framework - IDENTIFY Function
          </p>
          <div className="flex items-center justify-center gap-4 text-sm">
            <Badge
              variant="outline"
              className="border-blue-400 text-blue-300"
            >
              <Building2 className="w-3 h-3 mr-1" />
              UMB Bank NA Partner
            </Badge>
            <Badge
              variant="outline"
              className="border-green-400 text-green-300"
            >
              <Shield className="w-3 h-3 mr-1" />
              NIST SP 800-57
            </Badge>
            <Badge
              variant="outline"
              className="border-purple-400 text-purple-300"
            >
              <CheckCircle2 className="w-3 h-3 mr-1" />
              10 Controls Implemented
            </Badge>
          </div>

          {/* Security Controls */}
          <div className="flex items-center justify-center gap-4 mt-4">
            <Button
              onClick={toggleSecureMode}
              className={
                secureMode
                  ? "bg-green-600 hover:bg-green-700"
                  : "bg-red-600 hover:bg-red-700"
              }
            >
              {secureMode ? (
                <>
                  <Lock className="w-4 h-4 mr-2" />
                  Secure Mode Enabled
                </>
              ) : (
                <>
                  <EyeOff className="w-4 h-4 mr-2" />
                  Secure Mode Disabled
                </>
              )}
            </Button>
            <Button
              onClick={() => setShowDetails(!showDetails)}
              variant="outline"
              className="border-blue-500 text-blue-300"
            >
              {showDetails ? (
                <>
                  <Eye className="w-4 h-4 mr-2" />
                  Show Details
                </>
              ) : (
                <>
                  <EyeOff className="w-4 h-4 mr-2" />
                  Hide Details
                </>
              )}
            </Button>
          </div>
        </motion.div>

        {/* Main Tabs */}
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 0.2 }}
        >
          <Tabs defaultValue="devices" className="w-full">
            <TabsList className="grid w-full grid-cols-7 bg-gray-900/50 border border-blue-500/30">
              <TabsTrigger
                value="devices"
                className="data-[state=active]:bg-blue-600"
              >
                <Server className="w-4 h-4 mr-2" />
                Devices
              </TabsTrigger>
              <TabsTrigger
                value="software"
                className="data-[state=active]:bg-blue-600"
              >
                <Package className="w-4 h-4 mr-2" />
                Software
              </TabsTrigger>
              <TabsTrigger
                value="dataflows"
                className="data-[state=active]:bg-blue-600"
              >
                <GitBranch className="w-4 h-4 mr-2" />
                Data Flows
              </TabsTrigger>
              <TabsTrigger
                value="external"
                className="data-[state=active]:bg-blue-600"
              >
                <Cloud className="w-4 h-4 mr-2" />
                External
              </TabsTrigger>
              <TabsTrigger
                value="resources"
                className="data-[state=active]:bg-blue-600"
              >
                <Layers className="w-4 h-4 mr-2" />
                Resources
              </TabsTrigger>
              <TabsTrigger
                value="roles"
                className="data-[state=active]:bg-blue-600"
              >
                <Users className="w-4 h-4 mr-2" />
                Roles
              </TabsTrigger>
              <TabsTrigger
                value="business"
                className="data-[state=active]:bg-blue-600"
              >
                <Target className="w-4 h-4 mr-2" />
                Business
              </TabsTrigger>
            </TabsList>

            {/* Tab 1: Physical Devices (ID.AM-1) */}
            <TabsContent value="devices" className="space-y-4">
              <Card className="bg-gray-900/80 border-blue-500/30 p-6">
                <div className="flex items-center justify-between mb-6">
                  <div>
                    <h2 className="text-2xl font-bold text-white flex items-center gap-2">
                      <Server className="w-6 h-6 text-blue-400" />
                      Physical Devices and Systems Inventory
                      (ID.AM-1)
                    </h2>
                    <p className="text-gray-400 mt-1">
                      {filteredAssets.length} assets inventoried
                    </p>
                  </div>
                  <Button
                    onClick={() =>
                      exportData(
                        "Physical Assets",
                        physicalAssets,
                      )
                    }
                    variant="outline"
                    className="border-green-500 text-green-300"
                  >
                    <Download className="w-4 h-4 mr-2" />
                    Export JSON
                  </Button>
                </div>

                {/* Criticality Filter */}
                <div className="flex items-center gap-2 mb-6">
                  <Filter className="w-4 h-4 text-gray-400" />
                  <span className="text-gray-400 mr-2">
                    Filter:
                  </span>
                  {[
                    "All",
                    "Critical",
                    "High",
                    "Medium",
                    "Low",
                  ].map((level) => (
                    <Button
                      key={level}
                      onClick={() =>
                        setCriticalityFilter(level)
                      }
                      variant={
                        criticalityFilter === level
                          ? "default"
                          : "outline"
                      }
                      size="sm"
                      className={
                        criticalityFilter === level
                          ? "bg-blue-600"
                          : "border-gray-600 text-gray-300"
                      }
                    >
                      {level}
                    </Button>
                  ))}
                </div>

                {/* Asset Cards */}
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                  <AnimatePresence mode="popLayout">
                    {filteredAssets.map((asset) => (
                      <motion.div
                        key={asset.id}
                        initial={{ opacity: 0, scale: 0.9 }}
                        animate={{ opacity: 1, scale: 1 }}
                        exit={{ opacity: 0, scale: 0.9 }}
                        whileHover={{ scale: 1.02 }}
                        className="bg-gradient-to-br from-blue-900/30 to-purple-900/30 border border-blue-500/30 rounded-lg p-4"
                      >
                        <div className="flex items-start justify-between mb-3">
                          <div className="flex-1">
                            <h3 className="text-white font-semibold text-lg">
                              {asset.name}
                            </h3>
                            <p className="text-gray-400 text-sm">
                              {asset.id}
                            </p>
                          </div>
                          <Badge
                            className={getCriticalityColor(
                              asset.criticality,
                            )}
                          >
                            {asset.criticality}
                          </Badge>
                        </div>

                        {showDetails && (
                          <div className="space-y-2 text-sm">
                            <div className="flex items-center gap-2">
                              <CheckCircle2
                                className={`w-4 h-4 ${getStatusColor(asset.status)}`}
                              />
                              <span
                                className={getStatusColor(
                                  asset.status,
                                )}
                              >
                                {asset.status}
                              </span>
                            </div>
                            <div className="text-gray-300">
                              <span className="text-gray-500">
                                Type:
                              </span>{" "}
                              {asset.type}
                            </div>
                            <div className="text-gray-300">
                              <span className="text-gray-500">
                                Location:
                              </span>{" "}
                              {asset.location}
                            </div>
                            <div className="text-gray-300">
                              <span className="text-gray-500">
                                Owner:
                              </span>{" "}
                              {asset.owner}
                            </div>
                            <div className="text-gray-400 text-xs">
                              Updated: {asset.lastUpdated}
                            </div>
                          </div>
                        )}

                        <Button
                          onClick={() => {
                            addAuditLog(
                              "VIEWED_ASSET",
                              asset.name,
                            );
                            toast.info(`Viewing ${asset.name}`);
                          }}
                          variant="outline"
                          size="sm"
                          className="w-full mt-3 border-blue-500/50 text-blue-300"
                        >
                          View Details
                        </Button>
                      </motion.div>
                    ))}
                  </AnimatePresence>
                </div>
              </Card>
            </TabsContent>

            {/* Tab 2: Software Platforms (ID.AM-2) */}
            <TabsContent value="software" className="space-y-4">
              <Card className="bg-gray-900/80 border-blue-500/30 p-6">
                <div className="flex items-center justify-between mb-6">
                  <div>
                    <h2 className="text-2xl font-bold text-white flex items-center gap-2">
                      <Package className="w-6 h-6 text-purple-400" />
                      Software Platforms and Applications
                      (ID.AM-2)
                    </h2>
                    <p className="text-gray-400 mt-1">
                      {softwarePlatforms.length} software
                      platforms tracked
                    </p>
                  </div>
                  <Button
                    onClick={() =>
                      exportData(
                        "Software Platforms",
                        softwarePlatforms,
                      )
                    }
                    variant="outline"
                    className="border-green-500 text-green-300"
                  >
                    <Download className="w-4 h-4 mr-2" />
                    Export JSON
                  </Button>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                  {softwarePlatforms.map((software) => (
                    <motion.div
                      key={software.id}
                      whileHover={{ scale: 1.02 }}
                      className="bg-gradient-to-br from-purple-900/30 to-pink-900/30 border border-purple-500/30 rounded-lg p-5"
                    >
                      <div className="flex items-start justify-between mb-3">
                        <div className="flex-1">
                          <h3 className="text-white font-semibold text-lg">
                            {software.name}
                          </h3>
                          <p className="text-purple-300 text-sm">
                            {software.vendor}
                          </p>
                        </div>
                        <Badge
                          className={getCriticalityColor(
                            software.criticality,
                          )}
                        >
                          {software.criticality}
                        </Badge>
                      </div>

                      {showDetails && (
                        <div className="space-y-2 text-sm">
                          <div className="flex items-center justify-between">
                            <span className="text-gray-400">
                              Version:
                            </span>
                            <span className="text-white font-mono">
                              {software.version}
                            </span>
                          </div>
                          <div className="flex items-center justify-between">
                            <span className="text-gray-400">
                              License:
                            </span>
                            <span className="text-gray-300">
                              {software.licenseType}
                            </span>
                          </div>
                          <div className="flex items-center gap-2">
                            <CheckCircle2
                              className={`w-4 h-4 ${getStatusColor(software.status)}`}
                            />
                            <span
                              className={getStatusColor(
                                software.status,
                              )}
                            >
                              {software.status}
                            </span>
                          </div>
                        </div>
                      )}

                      <div className="flex gap-2 mt-4">
                        <Button
                          onClick={() => {
                            addAuditLog(
                              "VIEWED_SOFTWARE",
                              software.name,
                            );
                            toast.info(
                              `Viewing ${software.name}`,
                            );
                          }}
                          variant="outline"
                          size="sm"
                          className="flex-1 border-purple-500/50 text-purple-300"
                        >
                          View
                        </Button>
                        <Button
                          onClick={() => {
                            addAuditLog(
                              "CONFIGURED_SOFTWARE",
                              software.name,
                            );
                            toast.success("Settings opened");
                          }}
                          variant="outline"
                          size="sm"
                          className="border-blue-500/50 text-blue-300"
                        >
                          <Settings className="w-4 h-4" />
                        </Button>
                      </div>
                    </motion.div>
                  ))}
                </div>
              </Card>
            </TabsContent>

            {/* Tab 3: Data Flows (ID.AM-3) */}
            <TabsContent
              value="dataflows"
              className="space-y-4"
            >
              <Card className="bg-gray-900/80 border-blue-500/30 p-6">
                <div className="flex items-center justify-between mb-6">
                  <div>
                    <h2 className="text-2xl font-bold text-white flex items-center gap-2">
                      <GitBranch className="w-6 h-6 text-green-400" />
                      Communication and Data Flow Mapping
                      (ID.AM-3)
                    </h2>
                    <p className="text-gray-400 mt-1">
                      {dataFlows.length} critical data flows
                      mapped
                    </p>
                  </div>
                  <Button
                    onClick={() =>
                      exportData("Data Flows", dataFlows)
                    }
                    variant="outline"
                    className="border-green-500 text-green-300"
                  >
                    <Download className="w-4 h-4 mr-2" />
                    Export Map
                  </Button>
                </div>

                <div className="space-y-4">
                  {dataFlows.map((flow) => (
                    <motion.div
                      key={flow.id}
                      whileHover={{ scale: 1.01 }}
                      className="bg-gradient-to-r from-green-900/20 to-blue-900/20 border border-green-500/30 rounded-lg p-5"
                    >
                      <div className="flex items-center justify-between mb-3">
                        <div className="flex items-center gap-3 flex-1">
                          <div className="text-center">
                            <div className="text-white font-semibold">
                              {flow.source}
                            </div>
                            <div className="text-xs text-gray-400">
                              {flow.id}
                            </div>
                          </div>
                          <ArrowRight className="w-6 h-6 text-green-400 flex-shrink-0" />
                          <div className="text-center">
                            <div className="text-white font-semibold">
                              {flow.destination}
                            </div>
                          </div>
                        </div>
                        <Badge className="bg-purple-600 text-white ml-4">
                          {flow.sensitivity}
                        </Badge>
                      </div>

                      {showDetails && (
                        <div className="grid grid-cols-2 md:grid-cols-4 gap-4 text-sm">
                          <div>
                            <span className="text-gray-400">
                              Protocol:
                            </span>
                            <div className="text-white font-mono">
                              {flow.protocol}
                            </div>
                          </div>
                          <div>
                            <span className="text-gray-400">
                              Encryption:
                            </span>
                            <div className="text-green-300">
                              {flow.encryption}
                            </div>
                          </div>
                          <div>
                            <span className="text-gray-400">
                              Data Type:
                            </span>
                            <div className="text-blue-300">
                              {flow.dataType}
                            </div>
                          </div>
                          <div>
                            <span className="text-gray-400">
                              Sensitivity:
                            </span>
                            <div className="text-red-300">
                              {flow.sensitivity}
                            </div>
                          </div>
                        </div>
                      )}
                    </motion.div>
                  ))}
                </div>
              </Card>
            </TabsContent>

            {/* Tab 4: External Systems (ID.AM-4) */}
            <TabsContent value="external" className="space-y-4">
              <Card className="bg-gray-900/80 border-blue-500/30 p-6">
                <div className="flex items-center justify-between mb-6">
                  <div>
                    <h2 className="text-2xl font-bold text-white flex items-center gap-2">
                      <Cloud className="w-6 h-6 text-cyan-400" />
                      External Information Systems (ID.AM-4)
                    </h2>
                    <p className="text-gray-400 mt-1">
                      {externalSystems.length} external systems
                      catalogued
                    </p>
                  </div>
                  <Button
                    onClick={() =>
                      exportData(
                        "External Systems",
                        externalSystems,
                      )
                    }
                    variant="outline"
                    className="border-green-500 text-green-300"
                  >
                    <Download className="w-4 h-4 mr-2" />
                    Export Catalog
                  </Button>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  {externalSystems.map((system) => (
                    <motion.div
                      key={system.id}
                      whileHover={{ scale: 1.02 }}
                      className="bg-gradient-to-br from-cyan-900/30 to-blue-900/30 border border-cyan-500/30 rounded-lg p-5"
                    >
                      <div className="flex items-start justify-between mb-3">
                        <div className="flex-1">
                          <h3 className="text-white font-semibold text-lg">
                            {system.name}
                          </h3>
                          <p className="text-cyan-300 text-sm">
                            {system.provider}
                          </p>
                        </div>
                        <Badge className="bg-green-600 text-white">
                          SLA: {system.sla}
                        </Badge>
                      </div>

                      {showDetails && (
                        <div className="space-y-2 text-sm">
                          <div className="flex items-center justify-between">
                            <span className="text-gray-400">
                              Connection:
                            </span>
                            <span className="text-white">
                              {system.connectionType}
                            </span>
                          </div>
                          <div className="flex items-center justify-between">
                            <span className="text-gray-400">
                              Purpose:
                            </span>
                            <span className="text-gray-300">
                              {system.purpose}
                            </span>
                          </div>
                          <div className="flex items-center gap-2 mt-3">
                            <Network className="w-4 h-4 text-green-400" />
                            <span className="text-green-300 text-xs">
                              Connected
                            </span>
                          </div>
                        </div>
                      )}

                      <Button
                        onClick={() => {
                          addAuditLog(
                            "VIEWED_EXTERNAL_SYSTEM",
                            system.name,
                          );
                          toast.info(`Viewing ${system.name}`);
                        }}
                        variant="outline"
                        size="sm"
                        className="w-full mt-3 border-cyan-500/50 text-cyan-300"
                      >
                        View Connection
                      </Button>
                    </motion.div>
                  ))}
                </div>
              </Card>
            </TabsContent>

            {/* Tab 5: Resource Priorities (ID.AM-5) */}
            <TabsContent
              value="resources"
              className="space-y-4"
            >
              <Card className="bg-gray-900/80 border-blue-500/30 p-6">
                <div className="flex items-center justify-between mb-6">
                  <div>
                    <h2 className="text-2xl font-bold text-white flex items-center gap-2">
                      <Layers className="w-6 h-6 text-orange-400" />
                      Resource Prioritization (ID.AM-5)
                    </h2>
                    <p className="text-gray-400 mt-1">
                      Recovery objectives and business value
                    </p>
                  </div>
                  <Button
                    onClick={() =>
                      exportData(
                        "Resource Priorities",
                        resourcePriorities,
                      )
                    }
                    variant="outline"
                    className="border-green-500 text-green-300"
                  >
                    <Download className="w-4 h-4 mr-2" />
                    Export
                  </Button>
                </div>

                {/* Legend */}
                <div className="flex gap-4 mb-6 p-4 bg-blue-900/20 rounded-lg border border-blue-500/30">
                  <div className="flex items-center gap-2">
                    <Clock className="w-4 h-4 text-blue-400" />
                    <span className="text-gray-300 text-sm">
                      <strong>RTO:</strong> Recovery Time
                      Objective
                    </span>
                  </div>
                  <div className="flex items-center gap-2">
                    <Database className="w-4 h-4 text-green-400" />
                    <span className="text-gray-300 text-sm">
                      <strong>RPO:</strong> Recovery Point
                      Objective
                    </span>
                  </div>
                </div>

                <div className="overflow-x-auto">
                  <table className="w-full">
                    <thead>
                      <tr className="border-b border-blue-500/30">
                        <th className="text-left text-white py-3 px-4">
                          Resource
                        </th>
                        <th className="text-left text-white py-3 px-4">
                          Tier
                        </th>
                        <th className="text-left text-white py-3 px-4">
                          RTO
                        </th>
                        <th className="text-left text-white py-3 px-4">
                          RPO
                        </th>
                        <th className="text-left text-white py-3 px-4">
                          Business Value
                        </th>
                      </tr>
                    </thead>
                    <tbody>
                      {resourcePriorities.map((resource) => (
                        <motion.tr
                          key={resource.id}
                          whileHover={{
                            backgroundColor:
                              "rgba(59, 130, 246, 0.1)",
                          }}
                          className="border-b border-gray-700"
                        >
                          <td className="py-4 px-4">
                            <div className="text-white font-semibold">
                              {resource.name}
                            </div>
                            <div className="text-gray-400 text-xs">
                              {resource.id}
                            </div>
                          </td>
                          <td className="py-4 px-4">
                            <Badge
                              className={
                                resource.tier ===
                                "Tier-1 Critical"
                                  ? "bg-red-600 text-white"
                                  : "bg-orange-600 text-white"
                              }
                            >
                              {resource.tier}
                            </Badge>
                          </td>
                          <td className="py-4 px-4">
                            <div className="flex items-center gap-2">
                              <Clock className="w-4 h-4 text-blue-400" />
                              <span className="text-blue-300 font-mono">
                                {resource.rto}
                              </span>
                            </div>
                          </td>
                          <td className="py-4 px-4">
                            <div className="flex items-center gap-2">
                              <Database className="w-4 h-4 text-green-400" />
                              <span className="text-green-300 font-mono">
                                {resource.rpo}
                              </span>
                            </div>
                          </td>
                          <td className="py-4 px-4">
                            <div className="flex items-center gap-2">
                              <DollarSign className="w-4 h-4 text-yellow-400" />
                              <span className="text-gray-300">
                                {resource.businessValue}
                              </span>
                            </div>
                          </td>
                        </motion.tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </Card>
            </TabsContent>

            {/* Tab 6: Cybersecurity Roles (ID.AM-6) */}
            <TabsContent value="roles" className="space-y-4">
              <Card className="bg-gray-900/80 border-blue-500/30 p-6">
                <div className="flex items-center justify-between mb-6">
                  <div>
                    <h2 className="text-2xl font-bold text-white flex items-center gap-2">
                      <Users className="w-6 h-6 text-pink-400" />
                      Cybersecurity Roles and Responsibilities
                      (ID.AM-6)
                    </h2>
                    <p className="text-gray-400 mt-1">
                      {cybersecurityRoles.length} key roles
                      defined
                    </p>
                  </div>
                  <Button
                    onClick={() =>
                      exportData(
                        "Cybersecurity Roles",
                        cybersecurityRoles,
                      )
                    }
                    variant="outline"
                    className="border-green-500 text-green-300"
                  >
                    <Download className="w-4 h-4 mr-2" />
                    Export
                  </Button>
                </div>

                <div className="space-y-4">
                  {cybersecurityRoles.map((role) => (
                    <motion.div
                      key={role.id}
                      whileHover={{ scale: 1.01 }}
                      className="bg-gradient-to-r from-pink-900/20 to-purple-900/20 border border-pink-500/30 rounded-lg p-6"
                    >
                      <div className="flex items-start justify-between mb-4">
                        <div className="flex-1">
                          <h3 className="text-white font-bold text-xl">
                            {role.title}
                          </h3>
                          <p className="text-pink-300">
                            {role.department}
                          </p>
                          <p className="text-gray-400 text-sm mt-1">
                            Owner: {role.owner}
                          </p>
                        </div>
                        <Badge className="bg-blue-600 text-white">
                          {role.id}
                        </Badge>
                      </div>

                      {showDetails && (
                        <div className="grid md:grid-cols-2 gap-6">
                          <div>
                            <h4 className="text-gray-300 font-semibold mb-2 flex items-center gap-2">
                              <CheckCircle2 className="w-4 h-4 text-green-400" />
                              Responsibilities
                            </h4>
                            <ul className="space-y-1">
                              {role.responsibilities.map(
                                (resp, idx) => (
                                  <li
                                    key={idx}
                                    className="text-gray-300 text-sm flex items-start gap-2"
                                  >
                                    <span className="text-blue-400 mt-1">
                                      •
                                    </span>
                                    <span>{resp}</span>
                                  </li>
                                ),
                              )}
                            </ul>
                          </div>
                          <div>
                            <h4 className="text-gray-300 font-semibold mb-2 flex items-center gap-2">
                              <Shield className="w-4 h-4 text-purple-400" />
                              Framework Compliance
                            </h4>
                            <div className="flex flex-wrap gap-2">
                              {role.frameworks.map(
                                (framework, idx) => (
                                  <Badge
                                    key={idx}
                                    variant="outline"
                                    className="border-purple-500/50 text-purple-300"
                                  >
                                    {framework}
                                  </Badge>
                                ),
                              )}
                            </div>
                          </div>
                        </div>
                      )}
                    </motion.div>
                  ))}
                </div>
              </Card>
            </TabsContent>

            {/* Tab 7: Business Environment (ID.BE) */}
            <TabsContent value="business" className="space-y-4">
              <Card className="bg-gray-900/80 border-blue-500/30 p-6">
                <div className="flex items-center justify-between mb-6">
                  <div>
                    <h2 className="text-2xl font-bold text-white flex items-center gap-2">
                      <Target className="w-6 h-6 text-yellow-400" />
                      Business Environment Controls (ID.BE)
                    </h2>
                    <p className="text-gray-400 mt-1">
                      4 business environment controls
                      implemented
                    </p>
                  </div>
                </div>

                <div className="space-y-6">
                  {/* ID.BE-1: Supply Chain Role */}
                  <motion.div
                    whileHover={{ scale: 1.01 }}
                    className="bg-gradient-to-r from-yellow-900/20 to-orange-900/20 border border-yellow-500/30 rounded-lg p-6"
                  >
                    <h3 className="text-white font-bold text-lg mb-3 flex items-center gap-2">
                      <Package className="w-5 h-5 text-yellow-400" />
                      ID.BE-1: Supply Chain Role Identification
                    </h3>
                    {showDetails && (
                      <div className="space-y-3 text-gray-300">
                        <div>
                          <span className="text-gray-400 font-semibold">
                            Role:
                          </span>
                          <p className="mt-1">
                            Financial services provider with
                            integrated payment processing and
                            blockchain capabilities
                          </p>
                        </div>
                        <div>
                          <span className="text-gray-400 font-semibold">
                            Key Partners:
                          </span>
                          <div className="flex flex-wrap gap-2 mt-2">
                            <Badge className="bg-blue-600">
                              UMB Bank NA
                            </Badge>
                            <Badge className="bg-green-600">
                              Federal Reserve FedNow
                            </Badge>
                            <Badge className="bg-purple-600">
                              The Clearing House RTP
                            </Badge>
                            <Badge className="bg-orange-600">
                              HashiCorp Vault
                            </Badge>
                          </div>
                        </div>
                        <div>
                          <span className="text-gray-400 font-semibold">
                            Supply Chain Position:
                          </span>
                          <p className="mt-1">
                            Payment integrator connecting
                            banking services to end customers
                          </p>
                        </div>
                      </div>
                    )}
                  </motion.div>

                  {/* ID.BE-2: Critical Infrastructure Sector */}
                  <motion.div
                    whileHover={{ scale: 1.01 }}
                    className="bg-gradient-to-r from-red-900/20 to-pink-900/20 border border-red-500/30 rounded-lg p-6"
                  >
                    <h3 className="text-white font-bold text-lg mb-3 flex items-center gap-2">
                      <Shield className="w-5 h-5 text-red-400" />
                      ID.BE-2: Critical Infrastructure Sector
                    </h3>
                    {showDetails && (
                      <div className="space-y-3 text-gray-300">
                        <div>
                          <span className="text-gray-400 font-semibold">
                            Sector:
                          </span>
                          <p className="mt-1">
                            Financial Services Sector (Critical
                            Infrastructure)
                          </p>
                        </div>
                        <div>
                          <span className="text-gray-400 font-semibold">
                            Regulatory Oversight:
                          </span>
                          <div className="flex flex-wrap gap-2 mt-2">
                            <Badge
                              variant="outline"
                              className="border-red-500 text-red-300"
                            >
                              FFIEC
                            </Badge>
                            <Badge
                              variant="outline"
                              className="border-red-500 text-red-300"
                            >
                              OCC
                            </Badge>
                            <Badge
                              variant="outline"
                              className="border-red-500 text-red-300"
                            >
                              Federal Reserve
                            </Badge>
                            <Badge
                              variant="outline"
                              className="border-red-500 text-red-300"
                            >
                              FinCEN
                            </Badge>
                          </div>
                        </div>
                        <div>
                          <span className="text-gray-400 font-semibold">
                            Critical Functions:
                          </span>
                          <p className="mt-1">
                            Payment processing, account
                            management, fraud detection,
                            compliance reporting
                          </p>
                        </div>
                      </div>
                    )}
                  </motion.div>

                  {/* ID.BE-3: Organizational Mission */}
                  <motion.div
                    whileHover={{ scale: 1.01 }}
                    className="bg-gradient-to-r from-green-900/20 to-teal-900/20 border border-green-500/30 rounded-lg p-6"
                  >
                    <h3 className="text-white font-bold text-lg mb-3 flex items-center gap-2">
                      <Target className="w-5 h-5 text-green-400" />
                      ID.BE-3: Organizational Mission &
                      Objectives
                    </h3>
                    {showDetails && (
                      <div className="space-y-3 text-gray-300">
                        <div>
                          <span className="text-gray-400 font-semibold">
                            Mission:
                          </span>
                          <p className="mt-1 text-lg">
                            Provide secure, compliant, and
                            innovative banking services with
                            real-time payment capabilities
                          </p>
                        </div>
                        <div>
                          <span className="text-gray-400 font-semibold">
                            Key Objectives:
                          </span>
                          <ul className="mt-2 space-y-1">
                            <li className="flex items-start gap-2">
                              <CheckCircle2 className="w-4 h-4 text-green-400 mt-1" />
                              <span>
                                Maintain 99.99% uptime for core
                                banking services
                              </span>
                            </li>
                            <li className="flex items-start gap-2">
                              <CheckCircle2 className="w-4 h-4 text-green-400 mt-1" />
                              <span>
                                Process real-time payments
                                within 2 seconds
                              </span>
                            </li>
                            <li className="flex items-start gap-2">
                              <CheckCircle2 className="w-4 h-4 text-green-400 mt-1" />
                              <span>
                                Zero data breaches with
                                comprehensive security controls
                              </span>
                            </li>
                            <li className="flex items-start gap-2">
                              <CheckCircle2 className="w-4 h-4 text-green-400 mt-1" />
                              <span>
                                Full regulatory compliance
                                (FFIEC, Reg E, PCI DSS)
                              </span>
                            </li>
                          </ul>
                        </div>
                      </div>
                    )}
                  </motion.div>

                  {/* ID.BE-4: Dependencies & Critical Functions */}
                  <motion.div
                    whileHover={{ scale: 1.01 }}
                    className="bg-gradient-to-r from-blue-900/20 to-indigo-900/20 border border-blue-500/30 rounded-lg p-6"
                  >
                    <h3 className="text-white font-bold text-lg mb-3 flex items-center gap-2">
                      <GitBranch className="w-5 h-5 text-blue-400" />
                      ID.BE-4: Dependencies & Critical Functions
                    </h3>
                    {showDetails && (
                      <div className="grid md:grid-cols-2 gap-6">
                        <div>
                          <span className="text-gray-400 font-semibold">
                            Critical Dependencies:
                          </span>
                          <ul className="mt-2 space-y-2">
                            <li className="flex items-start gap-2 text-gray-300">
                              <Building2 className="w-4 h-4 text-blue-400 mt-1" />
                              <div>
                                <div className="font-semibold">
                                  UMB Bank NA Core System
                                </div>
                                <div className="text-xs text-gray-400">
                                  Primary banking partner
                                </div>
                              </div>
                            </li>
                            <li className="flex items-start gap-2 text-gray-300">
                              <Network className="w-4 h-4 text-green-400 mt-1" />
                              <div>
                                <div className="font-semibold">
                                  FedNow & RTP Networks
                                </div>
                                <div className="text-xs text-gray-400">
                                  Real-time payment rails
                                </div>
                              </div>
                            </li>
                            <li className="flex items-start gap-2 text-gray-300">
                              <Lock className="w-4 h-4 text-purple-400 mt-1" />
                              <div>
                                <div className="font-semibold">
                                  HashiCorp Vault
                                </div>
                                <div className="text-xs text-gray-400">
                                  Tokenization infrastructure
                                </div>
                              </div>
                            </li>
                            <li className="flex items-start gap-2 text-gray-300">
                              <Cloud className="w-4 h-4 text-orange-400 mt-1" />
                              <div>
                                <div className="font-semibold">
                                  AWS Infrastructure
                                </div>
                                <div className="text-xs text-gray-400">
                                  Cloud hosting platform
                                </div>
                              </div>
                            </li>
                          </ul>
                        </div>
                        <div>
                          <span className="text-gray-400 font-semibold">
                            Critical Functions:
                          </span>
                          <ul className="mt-2 space-y-2">
                            <li className="flex items-start gap-2 text-gray-300">
                              <DollarSign className="w-4 h-4 text-green-400 mt-1" />
                              <span>
                                Payment processing & settlement
                              </span>
                            </li>
                            <li className="flex items-start gap-2 text-gray-300">
                              <Database className="w-4 h-4 text-blue-400 mt-1" />
                              <span>
                                Account management & DDA
                                services
                              </span>
                            </li>
                            <li className="flex items-start gap-2 text-gray-300">
                              <Shield className="w-4 h-4 text-red-400 mt-1" />
                              <span>
                                Fraud detection & prevention
                              </span>
                            </li>
                            <li className="flex items-start gap-2 text-gray-300">
                              <FileText className="w-4 h-4 text-yellow-400 mt-1" />
                              <span>
                                Compliance reporting & audit
                              </span>
                            </li>
                          </ul>
                        </div>
                      </div>
                    )}
                  </motion.div>
                </div>

                {/* Framework Compliance */}
                <div className="mt-6 p-6 bg-gradient-to-r from-purple-900/20 to-blue-900/20 border border-purple-500/30 rounded-lg">
                  <h3 className="text-white font-bold text-lg mb-4 flex items-center gap-2">
                    <Shield className="w-5 h-5 text-purple-400" />
                    Framework Compliance - All 10 Controls
                    Implemented
                  </h3>
                  <div className="grid grid-cols-2 md:grid-cols-3 gap-3">
                    {[
                      "CIS CSC",
                      "COBIT 5",
                      "ISA 62443",
                      "ISO/IEC 27001:2013",
                      "NIST SP 800-53 Rev. 4",
                      "NIST CSF",
                    ].map((framework, idx) => (
                      <Badge
                        key={idx}
                        variant="outline"
                        className="border-purple-500/50 text-purple-300 justify-center py-2"
                      >
                        <CheckCircle2 className="w-3 h-3 mr-2 text-green-400" />
                        {framework}
                      </Badge>
                    ))}
                  </div>
                </div>
              </Card>
            </TabsContent>
          </Tabs>
        </motion.div>

        {/* Audit Log Summary */}
        {auditLog.length > 0 && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ delay: 0.3 }}
          >
            <Card className="bg-gray-900/50 border-green-500/30 p-4">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <FileText className="w-5 h-5 text-green-400" />
                  <h3 className="text-white font-semibold">
                    Recent Audit Trail
                  </h3>
                </div>
                <Badge className="bg-green-600 text-white">
                  {auditLog.length} Events
                </Badge>
              </div>
              <div className="mt-3 space-y-1 max-h-32 overflow-y-auto">
                {auditLog.slice(0, 5).map((log, idx) => (
                  <div
                    key={idx}
                    className="text-xs text-gray-400 font-mono"
                  >
                    [
                    {new Date(
                      log.timestamp,
                    ).toLocaleTimeString()}
                    ] {log.user}: {log.action} - {log.resource}
                  </div>
                ))}
              </div>
            </Card>
          </motion.div>
        )}
      </div>
    </div>
  );
}