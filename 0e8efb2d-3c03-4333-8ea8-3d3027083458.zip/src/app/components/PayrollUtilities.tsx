import { motion } from 'motion/react';
import { useState } from 'react';
import { Hash, Copy, CheckCircle, Code, Play } from 'lucide-react';

export function PayrollUtilities() {
  const [generatedHash, setGeneratedHash] = useState<string>('');
  const [copied, setCopied] = useState(false);

  const examplePayload = {
    idempotency_key: "a329c411-2464-4ce0-a490-068c68661c27",
    description: "Payroll deposits to UMB NA Bank checking account",
    effective_at: "2025-09-14T12:51:00Z",
    total_amount: 50000000,
    currency: "USD",
    bank: "UMB NA",
    routing_number: "101205681",
    account_number: "39900000585459050"
  };

  const computeHash = async () => {
    const jsonString = JSON.stringify(examplePayload, null, 2);
    const encoder = new TextEncoder();
    const data = encoder.encode(jsonString);
    const hashBuffer = await crypto.subtle.digest('SHA-256', data);
    const hashArray = Array.from(new Uint8Array(hashBuffer));
    const hashHex = hashArray.map(b => b.toString(16).padStart(2, '0')).join('');
    setGeneratedHash(hashHex);
  };

  const copyToClipboard = () => {
    navigator.clipboard.writeText(generatedHash);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const utilityScripts = [
    {
      id: 'hash',
      title: 'Compute PayrollIntent Hash',
      description: 'SHA-256 hash for audit trail',
      code: `const hash = crypto.createHash('sha256')
  .update(JSON.stringify(payrollIntent))
  .digest('hex');
console.log('Audit Hash:', hash);`
    },
    {
      id: 'reconcile',
      title: 'Auto-Reconciliation Script',
      description: 'Detect duplicate timestamps',
      code: `const duplicates = entries.filter((e, i, arr) => 
  arr.findIndex(x => 
    x.timestamp === e.timestamp && 
    x.employee_id === e.employee_id
  ) !== i
);
console.log('Duplicates found:', duplicates.length);`
    },
    {
      id: 'nacha',
      title: 'Generate NACHA File',
      description: 'ACH batch file creation',
      code: `const nacha = {
  header: '101 ' + routing + company_id + date,
  batch: entries.map(e => 
    '6' + e.account_type + e.routing + 
    e.account + e.amount.toString().padStart(10, '0')
  ).join('\\n')
};
fs.writeFileSync('payroll.ach', nacha);`
    }
  ];

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.6 }}
      className="mt-8"
    >
      <div className="bg-white rounded-lg shadow-lg border border-slate-200 p-6">
        <div className="flex items-center gap-3 mb-6">
          <div className="p-2 bg-slate-900 rounded-lg">
            <Code className="w-6 h-6 text-white" />
          </div>
          <div>
            <h2 className="text-slate-900">Quick Utilities</h2>
            <p className="text-slate-600 text-sm">Copy/paste utilities for production operations</p>
          </div>
        </div>

        {/* Live Hash Generator */}
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          className="bg-gradient-to-br from-blue-900 to-indigo-900 rounded-lg p-6 mb-6"
        >
          <div className="flex items-center gap-2 mb-4">
            <Hash className="w-5 h-5 text-blue-300" />
            <h3 className="text-white">Live Hash Generator</h3>
          </div>

          {/* Example Payload */}
          <div className="bg-slate-950 rounded p-4 mb-4 overflow-x-auto">
            <pre className="text-slate-300 text-xs">
              <code>{JSON.stringify(examplePayload, null, 2)}</code>
            </pre>
          </div>

          {/* Generate Button */}
          <motion.button
            whileHover={{ scale: 1.02 }}
            whileTap={{ scale: 0.98 }}
            onClick={computeHash}
            className="flex items-center gap-2 bg-blue-600 text-white px-4 py-2 rounded-lg hover:bg-blue-700 transition-colors mb-4"
          >
            <Play className="w-4 h-4" />
            Compute SHA-256
          </motion.button>

          {/* Hash Result */}
          {generatedHash && (
            <motion.div
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              className="bg-slate-950 rounded p-4"
            >
              <div className="flex items-center justify-between mb-2">
                <span className="text-blue-300 text-sm">SHA-256 Hash:</span>
                <button
                  onClick={copyToClipboard}
                  className="flex items-center gap-1 text-blue-400 hover:text-blue-300 text-sm"
                >
                  {copied ? (
                    <>
                      <CheckCircle className="w-4 h-4" />
                      Copied!
                    </>
                  ) : (
                    <>
                      <Copy className="w-4 h-4" />
                      Copy
                    </>
                  )}
                </button>
              </div>
              <div className="text-green-400 text-xs font-mono break-all">
                {generatedHash}
              </div>
            </motion.div>
          )}
        </motion.div>

        {/* Utility Scripts */}
        <div className="space-y-4">
          {utilityScripts.map((script, index) => (
            <motion.div
              key={script.id}
              initial={{ opacity: 0, x: -20 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ delay: index * 0.1 }}
              className="bg-slate-50 rounded-lg p-4 border border-slate-200"
            >
              <div className="flex items-start justify-between mb-2">
                <div>
                  <h4 className="text-slate-900 font-medium">{script.title}</h4>
                  <p className="text-slate-600 text-sm">{script.description}</p>
                </div>
                <button
                  onClick={() => {
                    navigator.clipboard.writeText(script.code);
                    setCopied(true);
                    setTimeout(() => setCopied(false), 2000);
                  }}
                  className="text-slate-500 hover:text-slate-700"
                >
                  <Copy className="w-4 h-4" />
                </button>
              </div>
              <div className="bg-slate-900 rounded p-3 mt-3 overflow-x-auto">
                <pre className="text-slate-300 text-xs">
                  <code>{script.code}</code>
                </pre>
              </div>
            </motion.div>
          ))}
        </div>

        {/* Additional Tools */}
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 0.4 }}
          className="mt-6 pt-6 border-t border-slate-200 grid grid-cols-3 gap-4"
        >
          <div className="text-center">
            <div className="text-2xl font-bold text-blue-600">SHA-256</div>
            <div className="text-xs text-slate-600">Hash Algorithm</div>
          </div>
          <div className="text-center">
            <div className="text-2xl font-bold text-purple-600">NACHA</div>
            <div className="text-xs text-slate-600">ACH Format</div>
          </div>
          <div className="text-center">
            <div className="text-2xl font-bold text-green-600">HSM</div>
            <div className="text-xs text-slate-600">Signature</div>
          </div>
        </motion.div>
      </div>
    </motion.div>
  );
}