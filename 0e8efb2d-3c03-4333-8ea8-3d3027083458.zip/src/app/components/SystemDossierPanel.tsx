import { motion } from 'motion/react';
import { FileText, Shield, Layers, CheckCircle2, BookOpen } from 'lucide-react';

export function SystemDossierPanel() {
  const dossier = {
    version: "1.2",
    title: "Pipeline Enablement Through Oversight Continuity",
    domain: ["Financial Infrastructure", "Banking Technology", "Payment Rails"],
    objective: "Normalize complex transaction topology through embedded oversight while preserving scalability, resilience, and innovation.",
    oversightModel: {
      type: "Continuous",
      integration: "Inline with execution pipeline",
      properties: [
        "Deterministic execution",
        "Immutable auditability",
        "Real-time observability",
        "Graceful degradation"
      ]
    },
    scienceTechnologyArts: {
      science: {
        title: "Science",
        icon: "🔬",
        color: "blue",
        principles: [
          "Deterministic data",
          "Reproducible financial computation",
          "Explainable models"
        ]
      },
      technology: {
        title: "Technology",
        icon: "⚙️",
        color: "purple",
        principles: [
          "Resilient system design",
          "Topology normalization",
          "Fault isolation",
          "Operational continuity"
        ]
      },
      arts: {
        title: "Arts",
        icon: "🎨",
        color: "pink",
        principles: [
          "Human-centered design",
          "Visual transparency",
          "Cognitive clarity",
          "Expressive system interfaces"
        ]
      }
    },
    deploymentContext: [
      "dossier.pdf",
      "architecture flowchart",
      "marketing presentations",
      "compliance documentation"
    ],
    complianceAlignment: ["CIS IG1", "CIS IG2", "CIS IG3"],
    status: "Production-ready"
  };

  const getColorClasses = (color: string) => {
    const colors = {
      blue: { bg: 'bg-blue-500', light: 'bg-blue-50', border: 'border-blue-300', text: 'text-blue-700' },
      purple: { bg: 'bg-purple-500', light: 'bg-purple-50', border: 'border-purple-300', text: 'text-purple-700' },
      pink: { bg: 'bg-pink-500', light: 'bg-pink-50', border: 'border-pink-300', text: 'text-pink-700' }
    };
    return colors[color as keyof typeof colors];
  };

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.6 }}
      className="mt-8"
    >
      <div className="bg-gradient-to-br from-slate-900 to-slate-800 rounded-xl shadow-2xl border border-slate-700 overflow-hidden">
        {/* Header */}
        <div className="bg-gradient-to-r from-blue-600 to-purple-600 p-6">
          <div className="flex items-start justify-between">
            <div className="flex items-start gap-4">
              <div className="p-3 bg-white/20 rounded-lg backdrop-blur-sm">
                <FileText className="w-8 h-8 text-white" />
              </div>
              <div>
                <div className="flex items-center gap-2 mb-2">
                  <h2 className="text-white text-xl">{dossier.title}</h2>
                  <span className="bg-white/20 text-white text-xs px-2 py-1 rounded">v{dossier.version}</span>
                </div>
                <p className="text-blue-100 text-sm max-w-2xl">{dossier.objective}</p>
                <div className="flex gap-2 mt-3">
                  {dossier.domain.map((d, i) => (
                    <span key={i} className="bg-white/10 text-white text-xs px-3 py-1 rounded-full">
                      {d}
                    </span>
                  ))}
                </div>
              </div>
            </div>
            <div className="bg-green-500 text-white px-4 py-2 rounded-lg flex items-center gap-2">
              <CheckCircle2 className="w-5 h-5" />
              <span className="text-sm font-medium">{dossier.status}</span>
            </div>
          </div>
        </div>

        {/* Content */}
        <div className="p-6 space-y-6">
          {/* Oversight Model */}
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ delay: 0.2 }}
            className="bg-slate-800 rounded-lg p-5 border border-slate-700"
          >
            <div className="flex items-center gap-3 mb-4">
              <Shield className="w-6 h-6 text-blue-400" />
              <div>
                <h3 className="text-white">Oversight Model</h3>
                <p className="text-slate-400 text-sm">{dossier.oversightModel.type} • {dossier.oversightModel.integration}</p>
              </div>
            </div>
            <div className="grid grid-cols-2 gap-3">
              {dossier.oversightModel.properties.map((prop, i) => (
                <motion.div
                  key={i}
                  initial={{ opacity: 0, x: -10 }}
                  animate={{ opacity: 1, x: 0 }}
                  transition={{ delay: 0.3 + i * 0.05 }}
                  className="bg-slate-700/50 rounded p-3 border border-slate-600"
                >
                  <div className="flex items-center gap-2">
                    <div className="w-2 h-2 bg-green-400 rounded-full"></div>
                    <span className="text-slate-200 text-sm">{prop}</span>
                  </div>
                </motion.div>
              ))}
            </div>
          </motion.div>

          {/* Science, Technology, Arts */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            {Object.entries(dossier.scienceTechnologyArts).map(([key, section], index) => {
              const colors = getColorClasses(section.color);
              return (
                <motion.div
                  key={key}
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: 0.4 + index * 0.1 }}
                  className={`${colors.light} border-2 ${colors.border} rounded-lg p-4`}
                >
                  <div className="flex items-center gap-2 mb-3">
                    <span className="text-2xl">{section.icon}</span>
                    <h4 className={`${colors.text} font-medium`}>{section.title}</h4>
                  </div>
                  <div className="space-y-2">
                    {section.principles.map((principle: string, i: number) => (
                      <div key={i} className="flex items-start gap-2">
                        <div className={`w-1.5 h-1.5 ${colors.bg} rounded-full mt-1.5`}></div>
                        <span className={`${colors.text} text-sm`}>{principle}</span>
                      </div>
                    ))}
                  </div>
                </motion.div>
              );
            })}
          </div>

          {/* Deployment Context & Compliance */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {/* Deployment Context */}
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              transition={{ delay: 0.7 }}
              className="bg-slate-800 rounded-lg p-4 border border-slate-700"
            >
              <div className="flex items-center gap-2 mb-3">
                <BookOpen className="w-5 h-5 text-amber-400" />
                <h4 className="text-white">Deployment Context</h4>
              </div>
              <div className="space-y-2">
                {dossier.deploymentContext.map((context, i) => (
                  <div key={i} className="flex items-center gap-2 text-slate-300 text-sm">
                    <div className="w-1.5 h-1.5 bg-amber-400 rounded-full"></div>
                    {context}
                  </div>
                ))}
              </div>
            </motion.div>

            {/* Compliance Alignment */}
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              transition={{ delay: 0.8 }}
              className="bg-slate-800 rounded-lg p-4 border border-slate-700"
            >
              <div className="flex items-center gap-2 mb-3">
                <Layers className="w-5 h-5 text-green-400" />
                <h4 className="text-white">Compliance Alignment</h4>
              </div>
              <div className="flex gap-2">
                {dossier.complianceAlignment.map((cis, i) => (
                  <div key={i} className="bg-green-500/20 border border-green-500 text-green-400 px-3 py-2 rounded text-sm font-medium">
                    {cis}
                  </div>
                ))}
              </div>
            </motion.div>
          </div>
        </div>
      </div>
    </motion.div>
  );
}
