import { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from './ui/card';
import { Tabs, TabsContent, TabsList, TabsTrigger } from './ui/tabs';
import { Badge } from './ui/badge';
import { Button } from './ui/button';
import { Input } from './ui/input';
import { Label } from './ui/label';
import {
  Shield,
  Lock,
  CreditCard,
  DollarSign,
  CheckCircle,
  AlertTriangle,
  Activity,
  ArrowUpCircle,
  ArrowDownCircle,
  RefreshCw,
  Zap,
  Key,
  Fingerprint,
  Smartphone,
  Eye,
  Network,
  Server,
  Building2,
  TrendingUp,
  FileCheck,
  ArrowRight,
  AlertCircle,
  Award,
  Radio
} from 'lucide-react';
import licenseImage from 'figma:asset/56d31762badadd8a4903af773c9ae2bfdd9ed6a1.png';
import networkImage from 'figma:asset/a6126219f7c88105091874a9616ea96debb4cf34.png';

interface Account {
  id: string;
  accountNumber: string;
  accountType: 'checking' | 'savings' | 'debit';
  balance: number;
  availableBalance: number;
  insuredAmount: number;
  status: 'active' | 'restricted' | 'frozen';
  riskLevel: 'low' | 'medium' | 'high';
}

interface Transaction {
  id: string;
  type: 'deposit' | 'withdrawal' | 'reload' | 'transfer';
  amount: number;
  accountId: string;
  timestamp: string;
  status: 'pending' | 'processing' | 'completed' | 'failed';
  riskAssessment: 'low' | 'high';
  scaRequired: boolean;
  scaMethod?: 'otp' | 'biometric' | 'app';
  encryptionHash?: string;
}

interface RiskAnalysis {
  transactionId: string;
  riskScore: number;
  riskLevel: 'low' | 'high';
  factors: string[];
  requiresSCA: boolean;
  authenticationType: 'frictionless' | 'challenge';
}

export function InsuredIntradayDepartment() {
  const [selectedTab, setSelectedTab] = useState<'accounts' | 'transactions' | 'rba' | 'admin' | 'infrastructure'>('accounts');
  const [selectedAccount, setSelectedAccount] = useState<string | null>(null);
  const [transactionAmount, setTransactionAmount] = useState('');
  const [transactionType, setTransactionType] = useState<'deposit' | 'withdrawal' | 'reload'>('deposit');
  const [showRiskFlow, setShowRiskFlow] = useState(false);
  const [currentRisk, setCurrentRisk] = useState<RiskAnalysis | null>(null);
  const [otpCode, setOtpCode] = useState('');
  const [showOtpInput, setShowOtpInput] = useState(false);

  // Accounts
  const [accounts] = useState<Account[]>([
    {
      id: 'acc-001',
      accountNumber: 'VOMOBIL7S-0001-DDA',
      accountType: 'checking',
      balance: 1250000.00,
      availableBalance: 1250000.00,
      insuredAmount: 250000.00,
      status: 'active',
      riskLevel: 'low'
    },
    {
      id: 'acc-002',
      accountNumber: 'VOMOBIL7S-0002-SAV',
      accountType: 'savings',
      balance: 850000.00,
      availableBalance: 850000.00,
      insuredAmount: 250000.00,
      status: 'active',
      riskLevel: 'low'
    },
    {
      id: 'acc-003',
      accountNumber: 'VOMOBIL7S-0003-DEB',
      accountType: 'debit',
      balance: 45000.00,
      availableBalance: 45000.00,
      insuredAmount: 45000.00,
      status: 'active',
      riskLevel: 'low'
    }
  ]);

  // Recent Transactions
  const [transactions, setTransactions] = useState<Transaction[]>([
    {
      id: 'txn-001',
      type: 'deposit',
      amount: 50000.00,
      accountId: 'acc-001',
      timestamp: new Date(Date.now() - 3600000).toISOString(),
      status: 'completed',
      riskAssessment: 'low',
      scaRequired: false,
      encryptionHash: 'a7f3c9e1d2b4a8f6c3e9d1a5b7f2c8e4'
    },
    {
      id: 'txn-002',
      type: 'withdrawal',
      amount: 15000.00,
      accountId: 'acc-002',
      timestamp: new Date(Date.now() - 7200000).toISOString(),
      status: 'completed',
      riskAssessment: 'low',
      scaRequired: false,
      encryptionHash: 'b8f4d0e2c3a5b9f7d4e0a1c6b8f3d9e5'
    },
    {
      id: 'txn-003',
      type: 'reload',
      amount: 25000.00,
      accountId: 'acc-003',
      timestamp: new Date(Date.now() - 10800000).toISOString(),
      status: 'completed',
      riskAssessment: 'high',
      scaRequired: true,
      scaMethod: 'app',
      encryptionHash: 'c9f5e1a3d4b6c0f8e5a2b1d7c9f4e0a6'
    }
  ]);

  // Risk Analysis Engine
  const analyzeRisk = (amount: number, type: string, accountId: string): RiskAnalysis => {
    const account = accounts.find(a => a.id === accountId);
    let riskScore = 0;
    const factors: string[] = [];

    // Amount-based risk
    if (amount > 50000) {
      riskScore += 40;
      factors.push('High transaction amount (>$50,000)');
    } else if (amount > 25000) {
      riskScore += 20;
      factors.push('Moderate transaction amount (>$25,000)');
    }

    // Withdrawal risk
    if (type === 'withdrawal') {
      riskScore += 15;
      factors.push('Withdrawal transaction type');
    }

    // Account balance risk
    if (account && amount > account.availableBalance * 0.5) {
      riskScore += 25;
      factors.push('Transaction exceeds 50% of available balance');
    }

    // Time-based risk (simplified)
    const hour = new Date().getHours();
    if (hour < 6 || hour > 22) {
      riskScore += 15;
      factors.push('Unusual transaction time (outside business hours)');
    }

    const riskLevel = riskScore >= 50 ? 'high' : 'low';
    const requiresSCA = riskLevel === 'high';

    return {
      transactionId: `txn-${Date.now()}`,
      riskScore,
      riskLevel,
      factors,
      requiresSCA,
      authenticationType: requiresSCA ? 'challenge' : 'frictionless'
    };
  };

  // Process Transaction
  const processTransaction = () => {
    if (!selectedAccount || !transactionAmount) return;

    const amount = parseFloat(transactionAmount);
    if (isNaN(amount) || amount <= 0) return;

    const risk = analyzeRisk(amount, transactionType, selectedAccount);
    setCurrentRisk(risk);
    setShowRiskFlow(true);

    if (risk.requiresSCA) {
      setShowOtpInput(true);
    } else {
      // Process frictionless transaction
      completeFrictionlessTransaction(risk);
    }
  };

  const completeFrictionlessTransaction = (risk: RiskAnalysis) => {
    const newTransaction: Transaction = {
      id: risk.transactionId,
      type: transactionType,
      amount: parseFloat(transactionAmount),
      accountId: selectedAccount!,
      timestamp: new Date().toISOString(),
      status: 'completed',
      riskAssessment: 'low',
      scaRequired: false,
      encryptionHash: generateHash()
    };

    setTransactions([newTransaction, ...transactions]);
    resetTransaction();
  };

  const verifyOtpAndComplete = () => {
    if (otpCode.length === 6 && currentRisk) {
      const newTransaction: Transaction = {
        id: currentRisk.transactionId,
        type: transactionType,
        amount: parseFloat(transactionAmount),
        accountId: selectedAccount!,
        timestamp: new Date().toISOString(),
        status: 'completed',
        riskAssessment: 'high',
        scaRequired: true,
        scaMethod: 'otp',
        encryptionHash: generateHash()
      };

      setTransactions([newTransaction, ...transactions]);
      resetTransaction();
    }
  };

  const resetTransaction = () => {
    setShowRiskFlow(false);
    setShowOtpInput(false);
    setCurrentRisk(null);
    setOtpCode('');
    setTransactionAmount('');
  };

  const generateHash = (): string => {
    return Array.from({ length: 32 }, () => 
      Math.floor(Math.random() * 16).toString(16)
    ).join('');
  };

  const formatCurrency = (amount: number): string => {
    return new Intl.NumberFormat('en-US', {
      style: 'currency',
      currency: 'USD',
      minimumFractionDigits: 2
    }).format(amount);
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'active':
      case 'completed':
        return 'bg-green-100 text-green-800 border-green-300';
      case 'processing':
      case 'pending':
        return 'bg-blue-100 text-blue-800 border-blue-300';
      case 'restricted':
        return 'bg-amber-100 text-amber-800 border-amber-300';
      case 'frozen':
      case 'failed':
        return 'bg-red-100 text-red-800 border-red-300';
      default:
        return 'bg-slate-100 text-slate-800 border-slate-300';
    }
  };

  const getRiskColor = (level: string) => {
    switch (level) {
      case 'low':
        return 'text-green-600';
      case 'medium':
        return 'text-amber-600';
      case 'high':
        return 'text-red-600';
      default:
        return 'text-slate-600';
    }
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <motion.div
        initial={{ opacity: 0, y: -20 }}
        animate={{ opacity: 1, y: 0 }}
        className="relative overflow-hidden rounded-xl bg-gradient-to-br from-blue-600 via-indigo-600 to-purple-600 p-8 text-white"
      >
        <div className="relative z-10">
          <div className="flex items-center justify-between">
            <div className="flex-1">
              <div className="flex items-center gap-3 mb-3">
                <Shield className="w-10 h-10" />
                <h1 className="text-4xl font-bold">Insured Intraday Department</h1>
              </div>
              <p className="text-xl text-blue-100 mb-4">
                Deposit • Withdrawal • Reload • Top-Up Processing
              </p>
              <div className="flex items-center gap-3 flex-wrap">
                <Badge variant="outline" className="bg-white/20 text-white border-white/40 backdrop-blur-sm px-4 py-2">
                  <Lock className="w-4 h-4 mr-2" />
                  FDIC Insured
                </Badge>
                <Badge variant="outline" className="bg-white/20 text-white border-white/40 backdrop-blur-sm px-4 py-2">
                  <Zap className="w-4 h-4 mr-2" />
                  Real-Time RBA
                </Badge>
                <Badge variant="outline" className="bg-white/20 text-white border-white/40 backdrop-blur-sm px-4 py-2">
                  <Key className="w-4 h-4 mr-2" />
                  SCA Protected
                </Badge>
                <Badge variant="outline" className="bg-white/20 text-white border-white/40 backdrop-blur-sm px-4 py-2">
                  <Network className="w-4 h-4 mr-2" />
                  UMB NA Partner
                </Badge>
              </div>
            </div>
            <div className="hidden md:block">
              <img src={licenseImage} alt="VOM Services License" className="w-48 h-48 rounded-lg shadow-2xl" />
            </div>
          </div>
        </div>
        
        {/* Background decoration */}
        <div className="absolute top-0 right-0 w-96 h-96 bg-white/10 rounded-full blur-3xl" />
        <div className="absolute bottom-0 left-0 w-64 h-64 bg-purple-400/20 rounded-full blur-2xl" />
      </motion.div>

      {/* Corporate Identity */}
      <Card className="border-2 border-indigo-200">
        <CardContent className="pt-6">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <div>
              <div className="text-xs text-slate-600 mb-1">Corporate Entity</div>
              <div className="font-bold text-slate-900">VOM Services Corporation</div>
              <div className="text-xs text-slate-600">OBLMFGJE • VOMOBIL7S</div>
            </div>
            <div>
              <div className="text-xs text-slate-600 mb-1">Principal Officer</div>
              <div className="font-bold text-slate-900">Matthew James Sauls</div>
              <div className="text-xs text-slate-600">CEO, CFO, CTO, OCIO, CCO</div>
            </div>
            <div>
              <div className="text-xs text-slate-600 mb-1">Regulatory IDs</div>
              <div className="font-mono text-xs text-slate-900">EIN: 83-1427324</div>
              <div className="font-mono text-xs text-slate-900">FCC FRN: 0033213463</div>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Main Tabs */}
      <Tabs value={selectedTab} onValueChange={(value) => setSelectedTab(value as any)} className="w-full">
        <TabsList className="grid w-full grid-cols-5">
          <TabsTrigger value="accounts">Accounts</TabsTrigger>
          <TabsTrigger value="transactions">Transactions</TabsTrigger>
          <TabsTrigger value="rba">Risk Analysis (RBA)</TabsTrigger>
          <TabsTrigger value="admin">Super Admin</TabsTrigger>
          <TabsTrigger value="infrastructure">Infrastructure</TabsTrigger>
        </TabsList>

        {/* Accounts Tab */}
        <TabsContent value="accounts" className="space-y-6">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            {accounts.map((account, index) => (
              <motion.div
                key={account.id}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: index * 0.1 }}
              >
                <Card 
                  className={`cursor-pointer transition-all hover:shadow-lg ${
                    selectedAccount === account.id ? 'border-2 border-blue-500 shadow-lg' : 'border-2 border-slate-200'
                  }`}
                  onClick={() => setSelectedAccount(account.id)}
                >
                  <CardHeader>
                    <div className="flex items-center justify-between mb-2">
                      <CardTitle className="text-lg flex items-center gap-2">
                        <CreditCard className="w-5 h-5 text-blue-600" />
                        {account.accountType.toUpperCase()}
                      </CardTitle>
                      <Badge variant="outline" className={getStatusColor(account.status)}>
                        {account.status.toUpperCase()}
                      </Badge>
                    </div>
                    <CardDescription className="font-mono text-xs">
                      {account.accountNumber}
                    </CardDescription>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-3">
                      <div>
                        <div className="text-xs text-slate-600">Total Balance</div>
                        <div className="text-2xl font-bold text-slate-900">{formatCurrency(account.balance)}</div>
                      </div>
                      <div className="grid grid-cols-2 gap-2 text-sm">
                        <div>
                          <div className="text-xs text-slate-600">Available</div>
                          <div className="font-semibold text-green-600">{formatCurrency(account.availableBalance)}</div>
                        </div>
                        <div>
                          <div className="text-xs text-slate-600">FDIC Insured</div>
                          <div className="font-semibold text-blue-600">{formatCurrency(account.insuredAmount)}</div>
                        </div>
                      </div>
                      <div className="flex items-center justify-between pt-2 border-t border-slate-200">
                        <span className="text-xs text-slate-600">Risk Level</span>
                        <span className={`text-xs font-bold ${getRiskColor(account.riskLevel)}`}>
                          {account.riskLevel.toUpperCase()}
                        </span>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              </motion.div>
            ))}
          </div>

          {/* Transaction Form */}
          {selectedAccount && (
            <motion.div
              initial={{ opacity: 0, height: 0 }}
              animate={{ opacity: 1, height: 'auto' }}
            >
              <Card className="border-2 border-blue-200">
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <Zap className="w-5 h-5 text-blue-600" />
                    New Transaction
                  </CardTitle>
                  <CardDescription>
                    Initiate deposit, withdrawal, or reload with automatic RBA screening
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    <div className="grid grid-cols-2 gap-4">
                      <div>
                        <Label>Transaction Type</Label>
                        <div className="flex gap-2 mt-2">
                          <Button
                            variant={transactionType === 'deposit' ? 'default' : 'outline'}
                            size="sm"
                            onClick={() => setTransactionType('deposit')}
                            className={transactionType === 'deposit' ? 'bg-green-600' : ''}
                          >
                            <ArrowDownCircle className="w-4 h-4 mr-2" />
                            Deposit
                          </Button>
                          <Button
                            variant={transactionType === 'withdrawal' ? 'default' : 'outline'}
                            size="sm"
                            onClick={() => setTransactionType('withdrawal')}
                            className={transactionType === 'withdrawal' ? 'bg-red-600' : ''}
                          >
                            <ArrowUpCircle className="w-4 h-4 mr-2" />
                            Withdrawal
                          </Button>
                          <Button
                            variant={transactionType === 'reload' ? 'default' : 'outline'}
                            size="sm"
                            onClick={() => setTransactionType('reload')}
                            className={transactionType === 'reload' ? 'bg-blue-600' : ''}
                          >
                            <RefreshCw className="w-4 h-4 mr-2" />
                            Reload
                          </Button>
                        </div>
                      </div>
                      <div>
                        <Label htmlFor="amount">Amount</Label>
                        <Input
                          id="amount"
                          type="number"
                          placeholder="0.00"
                          value={transactionAmount}
                          onChange={(e) => setTransactionAmount(e.target.value)}
                          className="mt-2"
                        />
                      </div>
                    </div>
                    <Button 
                      onClick={processTransaction}
                      disabled={!transactionAmount}
                      className="w-full bg-gradient-to-r from-blue-600 to-purple-600"
                    >
                      <Zap className="w-4 h-4 mr-2" />
                      Process Transaction
                    </Button>
                  </div>
                </CardContent>
              </Card>
            </motion.div>
          )}
        </TabsContent>

        {/* Transactions Tab */}
        <TabsContent value="transactions" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Activity className="w-5 h-5 text-blue-600" />
                Recent Transactions
              </CardTitle>
              <CardDescription>
                Encrypted, compartmented forward processing with balance management
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-3">
                {transactions.map((txn, index) => (
                  <motion.div
                    key={txn.id}
                    initial={{ opacity: 0, x: -20 }}
                    animate={{ opacity: 1, x: 0 }}
                    transition={{ delay: index * 0.05 }}
                    className="border-2 border-slate-200 rounded-lg p-4 hover:shadow-md transition-shadow"
                  >
                    <div className="flex items-start justify-between mb-3">
                      <div className="flex items-center gap-3">
                        <div className={`w-10 h-10 rounded-full flex items-center justify-center ${
                          txn.type === 'deposit' ? 'bg-green-100' :
                          txn.type === 'withdrawal' ? 'bg-red-100' :
                          'bg-blue-100'
                        }`}>
                          {txn.type === 'deposit' && <ArrowDownCircle className="w-5 h-5 text-green-600" />}
                          {txn.type === 'withdrawal' && <ArrowUpCircle className="w-5 h-5 text-red-600" />}
                          {txn.type === 'reload' && <RefreshCw className="w-5 h-5 text-blue-600" />}
                        </div>
                        <div>
                          <div className="font-bold text-slate-900 capitalize">{txn.type}</div>
                          <div className="text-xs text-slate-600">{new Date(txn.timestamp).toLocaleString()}</div>
                        </div>
                      </div>
                      <div className="text-right">
                        <div className={`text-xl font-bold ${
                          txn.type === 'deposit' ? 'text-green-600' :
                          txn.type === 'withdrawal' ? 'text-red-600' :
                          'text-blue-600'
                        }`}>
                          {txn.type === 'deposit' ? '+' : '-'}{formatCurrency(txn.amount)}
                        </div>
                        <Badge variant="outline" className={getStatusColor(txn.status)}>
                          {txn.status.toUpperCase()}
                        </Badge>
                      </div>
                    </div>
                    <div className="grid grid-cols-2 md:grid-cols-4 gap-2 pt-3 border-t border-slate-200 text-xs">
                      <div>
                        <span className="text-slate-600">Risk:</span>
                        <span className={`ml-2 font-bold ${getRiskColor(txn.riskAssessment)}`}>
                          {txn.riskAssessment.toUpperCase()}
                        </span>
                      </div>
                      <div>
                        <span className="text-slate-600">SCA:</span>
                        <span className="ml-2 font-semibold">
                          {txn.scaRequired ? `Yes (${txn.scaMethod?.toUpperCase()})` : 'No'}
                        </span>
                      </div>
                      <div className="col-span-2">
                        <span className="text-slate-600">Hash:</span>
                        <span className="ml-2 font-mono text-purple-600">{txn.encryptionHash?.slice(0, 16)}...</span>
                      </div>
                    </div>
                  </motion.div>
                ))}
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        {/* RBA Tab */}
        <TabsContent value="rba" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Eye className="w-5 h-5 text-purple-600" />
                Risk-Based Authentication Flow
              </CardTitle>
              <CardDescription>
                Real-time transaction risk analysis with adaptive authentication
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-6">
                {/* RBA Flow Diagram */}
                <div className="bg-gradient-to-br from-purple-50 to-blue-50 border-2 border-purple-200 rounded-lg p-6">
                  <div className="space-y-4">
                    {/* Transaction Starts */}
                    <motion.div
                      initial={{ opacity: 0, y: 20 }}
                      animate={{ opacity: 1, y: 0 }}
                      className="text-center"
                    >
                      <div className="inline-flex items-center gap-3 bg-white px-6 py-3 rounded-lg shadow-md border-2 border-blue-300">
                        <Zap className="w-6 h-6 text-blue-600" />
                        <span className="font-bold text-slate-900 text-lg">Transaction Starts</span>
                      </div>
                    </motion.div>

                    <div className="flex justify-center">
                      <ArrowRight className="w-6 h-6 text-slate-400 rotate-90" />
                    </div>

                    {/* Risk Analysis */}
                    <motion.div
                      initial={{ opacity: 0, y: 20 }}
                      animate={{ opacity: 1, y: 0 }}
                      transition={{ delay: 0.2 }}
                      className="text-center"
                    >
                      <div className="inline-flex items-center gap-3 bg-purple-600 text-white px-6 py-3 rounded-lg shadow-md">
                        <Eye className="w-6 h-6" />
                        <span className="font-bold text-lg">Risk Analysis (RBA)</span>
                      </div>
                    </motion.div>

                    <div className="flex justify-center">
                      <ArrowRight className="w-6 h-6 text-slate-400 rotate-90" />
                    </div>

                    {/* Split */}
                    <div className="grid grid-cols-2 gap-8">
                      {/* Low Risk Path */}
                      <motion.div
                        initial={{ opacity: 0, x: -20 }}
                        animate={{ opacity: 1, x: 0 }}
                        transition={{ delay: 0.4 }}
                        className="space-y-4"
                      >
                        <div className="text-center">
                          <div className="inline-flex items-center gap-2 bg-green-100 text-green-800 px-4 py-2 rounded-lg border-2 border-green-300">
                            <CheckCircle className="w-5 h-5" />
                            <span className="font-bold">Low Risk</span>
                          </div>
                        </div>
                        <div className="flex justify-center">
                          <ArrowRight className="w-5 h-5 text-green-600 rotate-90" />
                        </div>
                        <div className="bg-green-600 text-white px-6 py-4 rounded-lg text-center shadow-lg">
                          <Zap className="w-6 h-6 mx-auto mb-2" />
                          <div className="font-bold">Frictionless</div>
                          <div className="text-sm text-green-100 mt-1">Instant Processing</div>
                        </div>
                      </motion.div>

                      {/* High Risk Path */}
                      <motion.div
                        initial={{ opacity: 0, x: 20 }}
                        animate={{ opacity: 1, x: 0 }}
                        transition={{ delay: 0.4 }}
                        className="space-y-4"
                      >
                        <div className="text-center">
                          <div className="inline-flex items-center gap-2 bg-red-100 text-red-800 px-4 py-2 rounded-lg border-2 border-red-300">
                            <AlertTriangle className="w-5 h-5" />
                            <span className="font-bold">High Risk</span>
                          </div>
                        </div>
                        <div className="flex justify-center">
                          <ArrowRight className="w-5 h-5 text-red-600 rotate-90" />
                        </div>
                        <div className="bg-red-600 text-white px-6 py-4 rounded-lg text-center shadow-lg">
                          <Shield className="w-6 h-6 mx-auto mb-2" />
                          <div className="font-bold">Challenge Required</div>
                          <div className="text-sm text-red-100 mt-1">SCA Verification</div>
                        </div>
                        <div className="flex justify-center">
                          <ArrowRight className="w-5 h-5 text-red-600 rotate-90" />
                        </div>
                        <div className="bg-white border-2 border-red-300 rounded-lg p-4">
                          <div className="text-center font-bold text-slate-900 mb-3">
                            SCA Methods
                          </div>
                          <div className="space-y-2">
                            <div className="flex items-center gap-2 text-sm">
                              <Key className="w-4 h-4 text-blue-600" />
                              <span>OTP (One-Time Password)</span>
                            </div>
                            <div className="flex items-center gap-2 text-sm">
                              <Fingerprint className="w-4 h-4 text-purple-600" />
                              <span>Biometrics (Fingerprint/Face)</span>
                            </div>
                            <div className="flex items-center gap-2 text-sm">
                              <Smartphone className="w-4 h-4 text-green-600" />
                              <span>App Authentication</span>
                            </div>
                          </div>
                        </div>
                      </motion.div>
                    </div>
                  </div>
                </div>

                {/* Risk Factors */}
                <Card className="border-2 border-amber-200">
                  <CardHeader>
                    <CardTitle className="text-lg flex items-center gap-2">
                      <AlertCircle className="w-5 h-5 text-amber-600" />
                      Risk Assessment Factors
                    </CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="grid grid-cols-2 gap-3 text-sm">
                      <div className="flex items-start gap-2">
                        <CheckCircle className="w-4 h-4 text-blue-600 mt-0.5" />
                        <span>Transaction amount threshold</span>
                      </div>
                      <div className="flex items-start gap-2">
                        <CheckCircle className="w-4 h-4 text-blue-600 mt-0.5" />
                        <span>Transaction type (deposit/withdrawal)</span>
                      </div>
                      <div className="flex items-start gap-2">
                        <CheckCircle className="w-4 h-4 text-blue-600 mt-0.5" />
                        <span>Account balance percentage</span>
                      </div>
                      <div className="flex items-start gap-2">
                        <CheckCircle className="w-4 h-4 text-blue-600 mt-0.5" />
                        <span>Time of transaction</span>
                      </div>
                      <div className="flex items-start gap-2">
                        <CheckCircle className="w-4 h-4 text-blue-600 mt-0.5" />
                        <span>Geographic location</span>
                      </div>
                      <div className="flex items-start gap-2">
                        <CheckCircle className="w-4 h-4 text-blue-600 mt-0.5" />
                        <span>Device fingerprint</span>
                      </div>
                      <div className="flex items-start gap-2">
                        <CheckCircle className="w-4 h-4 text-blue-600 mt-0.5" />
                        <span>Historical behavior patterns</span>
                      </div>
                      <div className="flex items-start gap-2">
                        <CheckCircle className="w-4 h-4 text-blue-600 mt-0.5" />
                        <span>Velocity checks (frequency)</span>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        {/* Super Admin Tab */}
        <TabsContent value="admin" className="space-y-6">
          <Card className="border-2 border-purple-200">
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Award className="w-5 h-5 text-purple-600" />
                Super Administrator Suite
              </CardTitle>
              <CardDescription>
                FINRA SAA Designated • Matthew James Sauls • Executive Branch Authority
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-6">
                {/* Admin Identity */}
                <div className="bg-gradient-to-br from-purple-50 to-indigo-50 border-2 border-purple-200 rounded-lg p-6">
                  <div className="flex items-start gap-4">
                    <div className="w-16 h-16 bg-purple-600 rounded-full flex items-center justify-center flex-shrink-0">
                      <Award className="w-8 h-8 text-white" />
                    </div>
                    <div className="flex-1">
                      <h3 className="text-xl font-bold text-slate-900 mb-2">Super Account Administrator (SAA)</h3>
                      <div className="grid grid-cols-2 gap-4 text-sm">
                        <div>
                          <div className="text-xs text-slate-600">Name</div>
                          <div className="font-bold text-slate-900">Matthew James Sauls</div>
                        </div>
                        <div>
                          <div className="text-xs text-slate-600">Titles</div>
                          <div className="font-semibold text-slate-900">OCIO, CCO, CEO, CFO, CTO</div>
                        </div>
                        <div>
                          <div className="text-xs text-slate-600">Organization</div>
                          <div className="font-mono text-xs text-slate-900">VOMOBIL7S - OBLMFGJE</div>
                        </div>
                        <div>
                          <div className="text-xs text-slate-600">FINRA Status</div>
                          <Badge className="bg-green-600">Authorized SAA</Badge>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>

                {/* Admin Capabilities */}
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <Card className="border-2 border-blue-200">
                    <CardHeader>
                      <CardTitle className="text-lg flex items-center gap-2">
                        <Shield className="w-5 h-5 text-blue-600" />
                        Security Controls
                      </CardTitle>
                    </CardHeader>
                    <CardContent>
                      <div className="space-y-2 text-sm">
                        <div className="flex items-center gap-2">
                          <CheckCircle className="w-4 h-4 text-green-600" />
                          <span>Account freeze/unfreeze authority</span>
                        </div>
                        <div className="flex items-center gap-2">
                          <CheckCircle className="w-4 h-4 text-green-600" />
                          <span>Transaction reversal capability</span>
                        </div>
                        <div className="flex items-center gap-2">
                          <CheckCircle className="w-4 h-4 text-green-600" />
                          <span>Risk threshold configuration</span>
                        </div>
                        <div className="flex items-center gap-2">
                          <CheckCircle className="w-4 h-4 text-green-600" />
                          <span>SCA policy management</span>
                        </div>
                        <div className="flex items-center gap-2">
                          <CheckCircle className="w-4 h-4 text-green-600" />
                          <span>Encryption key rotation</span>
                        </div>
                      </div>
                    </CardContent>
                  </Card>

                  <Card className="border-2 border-green-200">
                    <CardHeader>
                      <CardTitle className="text-lg flex items-center gap-2">
                        <FileCheck className="w-5 h-5 text-green-600" />
                        Compliance Access
                      </CardTitle>
                    </CardHeader>
                    <CardContent>
                      <div className="space-y-2 text-sm">
                        <div className="flex items-center gap-2">
                          <CheckCircle className="w-4 h-4 text-green-600" />
                          <span>Audit trail full access</span>
                        </div>
                        <div className="flex items-center gap-2">
                          <CheckCircle className="w-4 h-4 text-green-600" />
                          <span>Regulatory report generation</span>
                        </div>
                        <div className="flex items-center gap-2">
                          <CheckCircle className="w-4 h-4 text-green-600" />
                          <span>FINRA system entitlement</span>
                        </div>
                        <div className="flex items-center gap-2">
                          <CheckCircle className="w-4 h-4 text-green-600" />
                          <span>FinCEN AML/KYC oversight</span>
                        </div>
                        <div className="flex items-center gap-2">
                          <CheckCircle className="w-4 h-4 text-green-600" />
                          <span>Multi-agency coordination</span>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                </div>

                {/* Regulatory Authorities */}
                <Card className="border-2 border-indigo-200">
                  <CardHeader>
                    <CardTitle className="text-lg">Regulatory Oversight Authorities</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="grid grid-cols-2 md:grid-cols-3 gap-3 text-sm">
                      <div className="flex items-center gap-2">
                        <Radio className="w-4 h-4 text-blue-600" />
                        <span>WA Secretary of State</span>
                      </div>
                      <div className="flex items-center gap-2">
                        <Radio className="w-4 h-4 text-blue-600" />
                        <span>IRS (EIN 83-1427324)</span>
                      </div>
                      <div className="flex items-center gap-2">
                        <Radio className="w-4 h-4 text-blue-600" />
                        <span>FCC (FRN 0033213463)</span>
                      </div>
                      <div className="flex items-center gap-2">
                        <Radio className="w-4 h-4 text-blue-600" />
                        <span>FINRA (SAA)</span>
                      </div>
                      <div className="flex items-center gap-2">
                        <Radio className="w-4 h-4 text-blue-600" />
                        <span>FinCEN (AML/KYC)</span>
                      </div>
                      <div className="flex items-center gap-2">
                        <Radio className="w-4 h-4 text-blue-600" />
                        <span>State Dept. of Revenue</span>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        {/* Infrastructure Tab */}
        <TabsContent value="infrastructure" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Network className="w-5 h-5 text-blue-600" />
                Network Infrastructure & Security Suites
              </CardTitle>
              <CardDescription>
                VLAN segmentation • Power monitoring • TLS encryption • Treasury ledger integration
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-6">
                {/* Network Diagram */}
                <div className="bg-white rounded-lg border-2 border-blue-200 overflow-hidden">
                  <img src={networkImage} alt="Network Infrastructure" className="w-full" />
                </div>

                {/* Network Zones */}
                <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                  <Card className="border-2 border-green-200">
                    <CardHeader>
                      <CardTitle className="text-lg flex items-center gap-2">
                        <Server className="w-5 h-5 text-green-600" />
                        VLAN 1 (Public)
                      </CardTitle>
                    </CardHeader>
                    <CardContent>
                      <div className="space-y-2 text-sm">
                        <div className="font-mono text-xs text-slate-700">52.35.210.146/32</div>
                        <div className="text-slate-600">High-Voltage Power</div>
                        <div className="text-slate-600">Voltage Power Plines</div>
                        <div className="text-slate-600">208/120V 3Ø feeds</div>
                      </div>
                    </CardContent>
                  </Card>

                  <Card className="border-2 border-blue-200">
                    <CardHeader>
                      <CardTitle className="text-lg flex items-center gap-2">
                        <Server className="w-5 h-5 text-blue-600" />
                        VLAN 2 (IBM MQ)
                      </CardTitle>
                    </CardHeader>
                    <CardContent>
                      <div className="space-y-2 text-sm">
                        <div className="font-mono text-xs text-slate-700">55.162.115.65/32</div>
                        <div className="text-slate-600">Disbursement Queue</div>
                        <div className="text-slate-600">Allocation Queue</div>
                        <div className="text-slate-600">Settlement Result</div>
                      </div>
                    </CardContent>
                  </Card>

                  <Card className="border-2 border-purple-200">
                    <CardHeader>
                      <CardTitle className="text-lg flex items-center gap-2">
                        <Server className="w-5 h-5 text-purple-600" />
                        VLAN 3 (Settlement)
                      </CardTitle>
                    </CardHeader>
                    <CardContent>
                      <div className="space-y-2 text-sm">
                        <div className="font-mono text-xs text-slate-700">104.249.162.0/24</div>
                        <div className="text-slate-600">Settlement Engine</div>
                        <div className="text-slate-600">Treasury Ledger</div>
                        <div className="text-slate-600">TLS Encrypted</div>
                      </div>
                    </CardContent>
                  </Card>
                </div>

                {/* Security Features */}
                <Card className="border-2 border-indigo-200">
                  <CardHeader>
                    <CardTitle className="text-lg">Infrastructure Security Features</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="grid grid-cols-2 md:grid-cols-4 gap-3 text-sm">
                      <div className="flex items-center gap-2">
                        <Lock className="w-4 h-4 text-blue-600" />
                        <span>TLS Encryption</span>
                      </div>
                      <div className="flex items-center gap-2">
                        <Shield className="w-4 h-4 text-blue-600" />
                        <span>Isolation Transformer</span>
                      </div>
                      <div className="flex items-center gap-2">
                        <Zap className="w-4 h-4 text-blue-600" />
                        <span>Surge Protectors</span>
                      </div>
                      <div className="flex items-center gap-2">
                        <Activity className="w-4 h-4 text-blue-600" />
                        <span>Power Monitoring</span>
                      </div>
                      <div className="flex items-center gap-2">
                        <Network className="w-4 h-4 text-blue-600" />
                        <span>Network Zones</span>
                      </div>
                      <div className="flex items-center gap-2">
                        <Server className="w-4 h-4 text-blue-600" />
                        <span>Rack Ground Bar</span>
                      </div>
                      <div className="flex items-center gap-2">
                        <Building2 className="w-4 h-4 text-blue-600" />
                        <span>UPS/Genset Backup</span>
                      </div>
                      <div className="flex items-center gap-2">
                        <Eye className="w-4 h-4 text-blue-600" />
                        <span>Testing/Monitoring</span>
                      </div>
                    </div>
                  </CardContent>
                </Card>

                {/* Banking Partners */}
                <Card className="border-2 border-green-200">
                  <CardHeader>
                    <CardTitle className="text-lg flex items-center gap-2">
                      <Building2 className="w-5 h-5 text-green-600" />
                      Banking & Treasury Partners
                    </CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-3">
                      <div className="flex items-center justify-between p-3 bg-green-50 rounded-lg">
                        <div>
                          <div className="font-bold text-slate-900">UMB Bank NA</div>
                          <div className="text-xs text-slate-600">Primary Banking Partner</div>
                        </div>
                        <Badge className="bg-green-600">Active</Badge>
                      </div>
                      <div className="flex items-center justify-between p-3 bg-blue-50 rounded-lg">
                        <div>
                          <div className="font-bold text-slate-900">Fidelity Investments</div>
                          <div className="text-xs text-slate-600">Brokerage & Custodian</div>
                        </div>
                        <Badge className="bg-blue-600">Active</Badge>
                      </div>
                      <div className="flex items-center justify-between p-3 bg-purple-50 rounded-lg">
                        <div>
                          <div className="font-bold text-slate-900">ACH / Fedwire / Blockchain</div>
                          <div className="text-xs text-slate-600">Payment Networks</div>
                        </div>
                        <Badge className="bg-purple-600">Integrated</Badge>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>

      {/* Risk Flow Modal */}
      <AnimatePresence>
        {showRiskFlow && currentRisk && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4"
            onClick={() => !showOtpInput && resetTransaction()}
          >
            <motion.div
              initial={{ scale: 0.9, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 0.9, opacity: 0 }}
              className="bg-white rounded-xl max-w-md w-full p-6"
              onClick={(e) => e.stopPropagation()}
            >
              <div className="text-center mb-6">
                <div className={`w-16 h-16 rounded-full mx-auto mb-4 flex items-center justify-center ${
                  currentRisk.riskLevel === 'low' ? 'bg-green-100' : 'bg-red-100'
                }`}>
                  {currentRisk.riskLevel === 'low' ? (
                    <CheckCircle className="w-8 h-8 text-green-600" />
                  ) : (
                    <AlertTriangle className="w-8 h-8 text-red-600" />
                  )}
                </div>
                <h3 className="text-2xl font-bold text-slate-900 mb-2">
                  {currentRisk.riskLevel === 'low' ? 'Low Risk Transaction' : 'High Risk Transaction'}
                </h3>
                <p className="text-slate-600">
                  {currentRisk.authenticationType === 'frictionless' 
                    ? 'Processing instantly...' 
                    : 'Additional verification required'}
                </p>
              </div>

              <div className="bg-slate-50 rounded-lg p-4 mb-6">
                <div className="text-sm font-semibold text-slate-700 mb-2">Risk Score: {currentRisk.riskScore}/100</div>
                <div className="w-full bg-slate-200 rounded-full h-2 mb-3">
                  <div
                    className={`h-2 rounded-full ${currentRisk.riskLevel === 'low' ? 'bg-green-500' : 'bg-red-500'}`}
                    style={{ width: `${currentRisk.riskScore}%` }}
                  />
                </div>
                <div className="space-y-1">
                  {currentRisk.factors.map((factor, index) => (
                    <div key={index} className="text-xs text-slate-600 flex items-start gap-2">
                      <AlertCircle className="w-3 h-3 mt-0.5 flex-shrink-0" />
                      <span>{factor}</span>
                    </div>
                  ))}
                </div>
              </div>

              {showOtpInput && (
                <div className="space-y-4">
                  <div>
                    <Label htmlFor="otp">Enter OTP Code</Label>
                    <Input
                      id="otp"
                      type="text"
                      maxLength={6}
                      placeholder="000000"
                      value={otpCode}
                      onChange={(e) => setOtpCode(e.target.value.replace(/\D/g, ''))}
                      className="mt-2 text-center text-2xl tracking-widest font-mono"
                    />
                  </div>
                  <Button
                    onClick={verifyOtpAndComplete}
                    disabled={otpCode.length !== 6}
                    className="w-full bg-green-600"
                  >
                    <CheckCircle className="w-4 h-4 mr-2" />
                    Verify & Complete
                  </Button>
                  <Button
                    onClick={resetTransaction}
                    variant="outline"
                    className="w-full"
                  >
                    Cancel
                  </Button>
                </div>
              )}

              {!showOtpInput && currentRisk.riskLevel === 'low' && (
                <div className="text-center text-sm text-green-600 font-semibold">
                  ✓ Transaction completed successfully
                </div>
              )}
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}
