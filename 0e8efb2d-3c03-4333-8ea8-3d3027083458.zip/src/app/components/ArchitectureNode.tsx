import { motion, AnimatePresence } from 'motion/react';

interface ArchitectureNodeProps {
  id: string;
  title: string;
  subtitle: string | null;
  details: string;
  color: string;
  isSelected: boolean;
  onClick: () => void;
  hasCode?: boolean;
  isLedger?: boolean;
  hasActivation?: boolean;
}

/**
 * Network Topology Reference:
 * 
 *                            INTERNET
 *                               |
 *                          titaniumite5 (Public IP)
 *                               |
 *                           [DMZ Load Balancer]
 *                               |
 *                       3xpres5.crt (Firewall / WAF)
 *                               |
 *                +--------------+--------------+
 *                |                             |
 *          node 3xpres5 (Policy)        IDS / SIEM / Logging
 *                |
 *         mathieu_et_favvarrow (VNet)
 *     +---------+---------+------------------+
 *     |                   |                  |
 *  Invoice API       Matching Engine   Settlement/OGFI (Datav v0.34.3)
 *  (IPP connector)    (3-way/4-way)      GL Writer / PAM/SPS Adapter
 *     |                   |                  |
 *   VendorBot         FinanceBot           AuditBot (immutable logs)
 */

export function ArchitectureNode({ 
  title, 
  subtitle, 
  details, 
  color, 
  isSelected, 
  onClick,
  hasCode,
  isLedger,
  hasActivation
}: ArchitectureNodeProps) {
  return (
    <motion.div
      onClick={onClick}
      whileHover={{ scale: 1.02, boxShadow: "0 10px 25px -5px rgba(0, 0, 0, 0.1)" }}
      whileTap={{ scale: 0.98 }}
      animate={isSelected ? { 
        scale: 1.02,
        boxShadow: "0 20px 40px -10px rgba(59, 130, 246, 0.3)"
      } : {}}
      transition={{ type: "spring", stiffness: 300, damping: 20 }}
      className={`
        ${color} 
        border-2 border-slate-300
        rounded-lg p-6 
        cursor-pointer 
        transition-colors duration-200
        ${isSelected ? 'ring-4 ring-blue-400' : 'hover:border-slate-400'}
        ${hasCode || isLedger || hasActivation ? 'relative' : ''}
      `}
    >
      {hasCode && (
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          className="absolute top-2 right-2 bg-amber-500 text-white text-xs px-2 py-1 rounded"
        >
          &lt;/&gt;
        </motion.div>
      )}
      
      {isLedger && (
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          className="absolute top-2 right-2 bg-purple-500 text-white text-xs px-2 py-1 rounded"
        >
          TX
        </motion.div>
      )}

      {hasActivation && (
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          className="absolute top-2 right-2 bg-green-500 text-white text-xs px-2 py-1 rounded"
        >
          ⚡
        </motion.div>
      )}
      
      <div className="text-center">
        <div className="text-slate-800 mb-1">{title}</div>
        {subtitle && (
          <div className="text-slate-600 text-sm mb-3">{subtitle}</div>
        )}
        
        <AnimatePresence>
          {isSelected && (
            <motion.div 
              initial={{ opacity: 0, height: 0 }}
              animate={{ opacity: 1, height: 'auto' }}
              exit={{ opacity: 0, height: 0 }}
              transition={{ duration: 0.3 }}
              className="mt-3 pt-3 border-t border-slate-300 overflow-hidden"
            >
              {details.split('•').map((detail, index) => (
                <motion.div 
                  key={index}
                  initial={{ opacity: 0, x: -10 }}
                  animate={{ opacity: 1, x: 0 }}
                  transition={{ delay: index * 0.1 }}
                  className="text-slate-700 text-sm py-1"
                >
                  {detail.trim() && `• ${detail.trim()}`}
                </motion.div>
              ))}
            </motion.div>
          )}
        </AnimatePresence>
      </div>
    </motion.div>
  );
}