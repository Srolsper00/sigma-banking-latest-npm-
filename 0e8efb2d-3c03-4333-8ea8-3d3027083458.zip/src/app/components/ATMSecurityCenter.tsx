import { motion } from 'motion/react';
import { useState } from 'react';
import { 
  Shield, 
  AlertTriangle, 
  Power,
  CheckCircle,
  XCircle,
  Download,
  FileText,
  WifiOff,
  Wifi,
  Hash,
  QrCode,
  Lock,
  Unlock,
  Building2,
  MapPin,
  Clock,
  Key,
  AlertOctagon
} from 'lucide-react';

interface ATMDevice {
  id: string;
  location: string;
  branch: string;
  status: 'online' | 'offline' | 'revoked';
  certificate: string;
  lastSeen: string;
  nonceRange: string;
  transactions24h: number;
}

interface Transaction {
  id: string;
  atmId: string;
  amount: number;
  timestamp: string;
  hash: string;
  nonce: string;
  signature: string;
  deviceFingerprint: string;
  status: 'completed' | 'pending_validation' | 'offline_sealed';
}

export function ATMSecurityCenter() {
  const [selectedTab, setSelectedTab] = useState<'kill-switch' | 'receipts' | 'offline' | 'appendix'>('kill-switch');
  const [atmDevices, setAtmDevices] = useState<ATMDevice[]>([
    {
      id: 'ATM-UMB Bank,N.A. Kansas City,MO -001',
      location: 'UMB Bank, N.A. Kansas City, MO',
      branch: 'UMB Bank, N.A. NETWORK GL',
      status: 'online',
      certificate: 'cert-e7f8a9b0c1d2',
      lastSeen: new Date().toISOString(),
      nonceRange: '1000000-19999999',
      transactions24h: 847
    },
    {
      id: 'ATM-Sutton-002',
      location: '5678 Oak Ave, Kansas City, MO',
      branch: 'Westport Branch',
      status: 'online',
      certificate: 'cert-d3e4f5g6h7i8',
      lastSeen: new Date().toISOString(),
      nonceRange: '2000009000-299999999',
      transactions24h: 612
    },
    {
      id: 'ATM-UMB-003',
      location: '9012 Elm St, Overland Park, KS',
      branch: 'Plaza Branch',
      status: 'offline',
      certificate: 'cert-j9k0l1m2n3o4',
      lastSeen: new Date(Date.now() - 3600000).toISOString(),
      nonceRange: '300000-399999',
      transactions24h: 423
    }
  ]);

  const [sampleReceipt, setSampleReceipt] = useState<Transaction>({
    id: 'TXN-2026-02-03-847291',
    atmId: 'ATM-UMB-001',
    amount: 20000, // $200.00
    timestamp: new Date().toISOString(),
    hash: 'b4d8c9f2e7a6b3d1c8f5e2a9b6d3c0f7e4a1b8d5c2f9e6a3b0d7c4f1e8a5b2d9',
    nonce: '156742',
    signature: 'sig_3xpres5_mtls_a7b9c4d2e8f1',
    deviceFingerprint: 'fp_cert_e7f8a9b0c1d2',
    status: 'completed'
  });

  const [offlineTransactions, setOfflineTransactions] = useState<Transaction[]>([
    {
      id: 'TXN-OFFLINE-001',
      atmId: 'ATM-UMB-003',
      amount: 10000,
      timestamp: new Date(Date.now() - 1800000).toISOString(),
      hash: 'a1b2c3d4e5f6g7h8i9j0k1l2m3n4o5p6q7r8s9t0u1v2w3x4y5z6a7b8c9d0e1f2',
      nonce: '356892',
      signature: 'sig_offline_sealed_f8e7d6c5',
      deviceFingerprint: 'fp_cert_j9k0l1m2n3o4',
      status: 'offline_sealed'
    }
  ]);

  const revokeATM = (atmId: string, scope: 'single' | 'branch' | 'fleet') => {
    setAtmDevices(prev => prev.map(atm => {
      if (scope === 'single' && atm.id === atmId) {
        return { ...atm, status: 'revoked' as const };
      } else if (scope === 'branch') {
        const targetBranch = prev.find(a => a.id === atmId)?.branch;
        if (atm.branch === targetBranch) {
          return { ...atm, status: 'revoked' as const };
        }
      } else if (scope === 'fleet') {
        return { ...atm, status: 'revoked' as const };
      }
      return atm;
    }));
  };

  const restoreATM = (atmId: string) => {
    setAtmDevices(prev => prev.map(atm => 
      atm.id === atmId ? { ...atm, status: 'online' as const } : atm
    ));
  };

  const generateReceipt = () => {
    const newReceipt: Transaction = {
      id: `TXN-${Date.now()}`,
      atmId: 'ATM-UMB-001',
      amount: Math.floor(Math.random() * 50000) + 2000,
      timestamp: new Date().toISOString(),
      hash: Array.from({ length: 64 }, () => Math.floor(Math.random() * 16).toString(16)).join(''),
      nonce: Math.floor(Math.random() * 900000 + 100000).toString(),
      signature: `sig_3xpres5_mtls_${Math.random().toString(36).substring(7)}`,
      deviceFingerprint: 'fp_cert_e7f8a9b0c1d2',
      status: 'completed'
    };
    setSampleReceipt(newReceipt);
  };

  const validateOfflineTransactions = () => {
    setOfflineTransactions(prev => prev.map(txn => ({
      ...txn,
      status: 'completed' as const
    })));
  };

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.6 }}
      className="bg-white rounded-xl shadow-lg border border-slate-200 overflow-hidden"
    >
      {/* Header */}
      <div className="bg-gradient-to-r from-red-900 via-orange-900 to-red-900 p-6">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="p-2 bg-white/10 rounded-lg">
              <Shield className="w-6 h-6 text-white" />
            </div>
            <div>
              <h2 className="text-white text-xl">ATM Security Operations Center</h2>
              <p className="text-slate-300 text-sm">Certificate revocation • Cryptographic receipts • Offline survivability</p>
            </div>
          </div>
          <div className="text-right">
            <div className="text-white text-2xl font-bold">{atmDevices.length}</div>
            <div className="text-slate-300 text-xs">Active ATMs</div>
          </div>
        </div>
      </div>

      {/* Navigation Tabs */}
      <div className="border-b border-slate-200 bg-slate-50">
        <div className="flex">
          {[
            { id: 'kill-switch', label: 'Certificate Kill-Switch', icon: AlertOctagon },
            { id: 'receipts', label: 'Cryptographic Receipts', icon: FileText },
            { id: 'offline', label: 'Offline Mode', icon: WifiOff },
            { id: 'appendix', label: 'Security Appendix', icon: Download }
          ].map(tab => {
            const Icon = tab.icon;
            return (
              <button
                key={tab.id}
                onClick={() => setSelectedTab(tab.id as any)}
                className={`
                  flex items-center gap-2 px-6 py-3 font-medium text-sm transition-colors
                  ${selectedTab === tab.id 
                    ? 'text-red-700 border-b-2 border-red-600 bg-white' 
                    : 'text-slate-600 hover:text-slate-900 hover:bg-slate-100'
                  }
                `}
              >
                <Icon className="w-4 h-4" />
                {tab.label}
              </button>
            );
          })}
        </div>
      </div>

      {/* Content */}
      <div className="p-6">
        {/* Tab 1: Kill-Switch */}
        {selectedTab === 'kill-switch' && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ duration: 0.3 }}
          >
            <div className="mb-6">
              <h3 className="text-slate-900 font-bold text-lg mb-2">🔒 Instant ATM Kill-Switch — Certificate Revocation</h3>
              <p className="text-slate-600 text-sm mb-4">
                Cryptographic power-off switch: immediate, provable, examiner-clean. 
                Every ATM bound to Bank Root CA with mTLS handshake enforcement.
              </p>
              
              <div className="bg-red-50 border-2 border-red-300 rounded-lg p-4 mb-4">
                <div className="flex items-start gap-3">
                  <AlertTriangle className="w-5 h-5 text-red-600 mt-0.5" />
                  <div>
                    <div className="text-red-900 font-medium mb-1">Revocation Triggers</div>
                    <ul className="text-red-800 text-sm space-y-1">
                      <li>• mTLS handshake failure → Immediate disconnect</li>
                      <li>• Secret access denial → Ledger commit rejection</li>
                      <li>• No network rule changes required</li>
                    </ul>
                  </div>
                </div>
              </div>

              <div className="grid grid-cols-3 gap-4 mb-6">
                <div className="bg-slate-50 border border-slate-200 rounded-lg p-4 text-center">
                  <Power className="w-8 h-8 text-red-600 mx-auto mb-2" />
                  <div className="text-slate-900 font-medium">Single ATM</div>
                  <div className="text-slate-600 text-xs">Surgical revocation</div>
                </div>
                <div className="bg-slate-50 border border-slate-200 rounded-lg p-4 text-center">
                  <Building2 className="w-8 h-8 text-orange-600 mx-auto mb-2" />
                  <div className="text-slate-900 font-medium">Single Branch</div>
                  <div className="text-slate-600 text-xs">Location-wide</div>
                </div>
                <div className="bg-slate-50 border border-slate-200 rounded-lg p-4 text-center">
                  <AlertOctagon className="w-8 h-8 text-red-700 mx-auto mb-2" />
                  <div className="text-slate-900 font-medium">Fleet-Wide</div>
                  <div className="text-slate-600 text-xs">Root revocation</div>
                </div>
              </div>
            </div>

            {/* ATM Fleet Status */}
            <div className="space-y-3">
              <h4 className="text-slate-900 font-medium">ATM Fleet Status</h4>
              {atmDevices.map((atm, index) => (
                <motion.div
                  key={atm.id}
                  initial={{ opacity: 0, x: -20 }}
                  animate={{ opacity: 1, x: 0 }}
                  transition={{ delay: index * 0.1 }}
                  className={`
                    border-2 rounded-lg p-4
                    ${atm.status === 'online' ? 'bg-green-50 border-green-300' : ''}
                    ${atm.status === 'offline' ? 'bg-yellow-50 border-yellow-300' : ''}
                    ${atm.status === 'revoked' ? 'bg-red-50 border-red-300' : ''}
                  `}
                >
                  <div className="flex items-start justify-between">
                    <div className="flex-1">
                      <div className="flex items-center gap-3 mb-2">
                        {atm.status === 'online' && <CheckCircle className="w-5 h-5 text-green-600" />}
                        {atm.status === 'offline' && <WifiOff className="w-5 h-5 text-yellow-600" />}
                        {atm.status === 'revoked' && <XCircle className="w-5 h-5 text-red-600" />}
                        <div>
                          <div className="text-slate-900 font-bold">{atm.id}</div>
                          <div className="text-slate-600 text-sm">{atm.branch}</div>
                        </div>
                      </div>
                      
                      <div className="grid grid-cols-2 gap-3 text-xs">
                        <div>
                          <span className="text-slate-500">Location:</span>
                          <div className="text-slate-700 font-medium">{atm.location}</div>
                        </div>
                        <div>
                          <span className="text-slate-500">Certificate:</span>
                          <div className="text-slate-700 font-mono text-xs">{atm.certificate}</div>
                        </div>
                        <div>
                          <span className="text-slate-500">Nonce Range:</span>
                          <div className="text-slate-700 font-mono">{atm.nonceRange}</div>
                        </div>
                        <div>
                          <span className="text-slate-500">24h Transactions:</span>
                          <div className="text-slate-700 font-bold">{atm.transactions24h}</div>
                        </div>
                      </div>
                    </div>

                    <div className="ml-4 flex flex-col gap-2">
                      {atm.status !== 'revoked' && (
                        <>
                          <motion.button
                            whileHover={{ scale: 1.05 }}
                            whileTap={{ scale: 0.95 }}
                            onClick={() => revokeATM(atm.id, 'single')}
                            className="bg-red-600 text-white px-3 py-1 rounded text-xs font-medium flex items-center gap-1"
                          >
                            <Power className="w-3 h-3" />
                            Revoke Single
                          </motion.button>
                          <motion.button
                            whileHover={{ scale: 1.05 }}
                            whileTap={{ scale: 0.95 }}
                            onClick={() => revokeATM(atm.id, 'branch')}
                            className="bg-orange-600 text-white px-3 py-1 rounded text-xs font-medium flex items-center gap-1"
                          >
                            <Building2 className="w-3 h-3" />
                            Revoke Branch
                          </motion.button>
                        </>
                      )}
                      {atm.status === 'revoked' && (
                        <motion.button
                          whileHover={{ scale: 1.05 }}
                          whileTap={{ scale: 0.95 }}
                          onClick={() => restoreATM(atm.id)}
                          className="bg-green-600 text-white px-3 py-1 rounded text-xs font-medium flex items-center gap-1"
                        >
                          <Unlock className="w-3 h-3" />
                          Restore
                        </motion.button>
                      )}
                    </div>
                  </div>

                  {atm.status === 'revoked' && (
                    <motion.div
                      initial={{ opacity: 0, height: 0 }}
                      animate={{ opacity: 1, height: 'auto' }}
                      className="mt-3 pt-3 border-t border-red-300 bg-red-100 -m-4 mt-3 p-3 rounded-b-lg"
                    >
                      <div className="text-red-900 text-xs font-bold">⛔ CERTIFICATE REVOKED</div>
                      <div className="text-red-800 text-xs">All operations disabled: mTLS handshake failure • Secret access denied • Ledger commits rejected</div>
                    </motion.div>
                  )}
                </motion.div>
              ))}
            </div>

            {/* Fleet-Wide Control */}
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              transition={{ delay: 0.4 }}
              className="mt-6 bg-slate-900 rounded-lg p-4"
            >
              <div className="flex items-center justify-between">
                <div>
                  <div className="text-white font-bold mb-1">⚠️ Fleet-Wide Emergency Revocation</div>
                  <div className="text-slate-400 text-xs">Revokes root CA certificate — disables entire ATM fleet</div>
                </div>
                <motion.button
                  whileHover={{ scale: 1.05 }}
                  whileTap={{ scale: 0.95 }}
                  onClick={() => revokeATM('', 'fleet')}
                  className="bg-red-600 text-white px-4 py-2 rounded font-medium flex items-center gap-2"
                >
                  <AlertOctagon className="w-5 h-5" />
                  REVOKE ALL
                </motion.button>
              </div>
            </motion.div>
          </motion.div>
        )}

        {/* Tab 2: Cryptographic Receipts */}
        {selectedTab === 'receipts' && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ duration: 0.3 }}
          >
            <div className="mb-6">
              <h3 className="text-slate-900 font-bold text-lg mb-2">🧾 Customer-Visible Cryptographic Receipt</h3>
              <p className="text-slate-600 text-sm mb-4">
                Each completed transaction issues a receipt artifact with transaction hash, rebalance nonce, 
                ledger commit signature, timestamp, and device certificate fingerprint.
              </p>
              
              <div className="bg-blue-50 border-2 border-blue-300 rounded-lg p-4 mb-6">
                <div className="flex items-start gap-3">
                  <CheckCircle className="w-5 h-5 text-blue-600 mt-0.5" />
                  <div>
                    <div className="text-blue-900 font-medium mb-1">Receipt Properties</div>
                    <ul className="text-blue-800 text-sm space-y-1">
                      <li>✅ Verifiable by the bank</li>
                      <li>✅ Non-repudiable by the institution</li>
                      <li>✅ Consumer protection and dispute resolution</li>
                      <li>✅ Optional QR code for mobile verification</li>
                    </ul>
                  </div>
                </div>
              </div>
            </div>

            {/* Sample Receipt */}
            <div className="bg-white border-2 border-slate-300 rounded-lg shadow-xl max-w-md mx-auto">
              {/* Receipt Header */}
              <div className="bg-gradient-to-r from-blue-600 to-indigo-600 p-4 text-white text-center">
                <div className="text-xl font-bold">UMB NA</div>
                <div className="text-xs text-blue-100">Cryptographic Transaction Receipt</div>
              </div>

              {/* Receipt Body */}
              <div className="p-6 space-y-4">
                <div className="text-center border-b border-slate-200 pb-4">
                  <div className="text-slate-500 text-xs mb-1">AMOUNT</div>
                  <div className="text-4xl font-bold text-slate-900">
                    ${(sampleReceipt.amount / 100).toFixed(2)}
                  </div>
                  <div className="text-slate-600 text-sm mt-1">
                    {new Date(sampleReceipt.timestamp).toLocaleString()}
                  </div>
                </div>

                <div className="space-y-3 text-xs">
                  <div>
                    <div className="text-slate-500 font-medium mb-1">Transaction ID</div>
                    <div className="text-slate-900 font-mono bg-slate-50 p-2 rounded">
                      {sampleReceipt.id}
                    </div>
                  </div>

                  <div>
                    <div className="text-slate-500 font-medium mb-1">ATM Location</div>
                    <div className="text-slate-900">{sampleReceipt.atmId}</div>
                  </div>

                  <div>
                    <div className="text-slate-500 font-medium mb-1 flex items-center gap-1">
                      <Hash className="w-3 h-3" />
                      Transaction Hash (SHA-256)
                    </div>
                    <div className="text-slate-900 font-mono bg-slate-50 p-2 rounded break-all text-[10px]">
                      {sampleReceipt.hash}
                    </div>
                  </div>

                  <div>
                    <div className="text-slate-500 font-medium mb-1">Rebalance Nonce</div>
                    <div className="text-slate-900 font-mono bg-slate-50 p-2 rounded">
                      {sampleReceipt.nonce}
                    </div>
                  </div>

                  <div>
                    <div className="text-slate-500 font-medium mb-1 flex items-center gap-1">
                      <Key className="w-3 h-3" />
                      Ledger Commit Signature
                    </div>
                    <div className="text-slate-900 font-mono bg-slate-50 p-2 rounded text-[10px]">
                      {sampleReceipt.signature}
                    </div>
                  </div>

                  <div>
                    <div className="text-slate-500 font-medium mb-1">Device Certificate Fingerprint</div>
                    <div className="text-slate-900 font-mono bg-slate-50 p-2 rounded text-[10px]">
                      {sampleReceipt.deviceFingerprint}
                    </div>
                  </div>
                </div>

                {/* QR Code Placeholder */}
                <div className="border-t border-slate-200 pt-4 text-center">
                  <div className="bg-slate-100 w-32 h-32 mx-auto rounded flex items-center justify-center">
                    <QrCode className="w-16 h-16 text-slate-400" />
                  </div>
                  <div className="text-slate-500 text-xs mt-2">
                    Scan to verify transaction
                  </div>
                </div>

                <div className="bg-green-50 border border-green-300 rounded p-3">
                  <div className="flex items-center gap-2 text-green-800 text-xs">
                    <CheckCircle className="w-4 h-4" />
                    <span className="font-medium">Transaction Verified & Committed to Ledger</span>
                  </div>
                </div>
              </div>

              {/* Receipt Footer */}
              <div className="bg-slate-50 p-4 text-center border-t border-slate-200">
                <div className="text-slate-600 text-xs">
                  This receipt is cryptographically signed and non-repudiable.
                  <br />
                  Retain for your records.
                </div>
              </div>
            </div>

            <div className="mt-6 text-center">
              <motion.button
                whileHover={{ scale: 1.05 }}
                whileTap={{ scale: 0.95 }}
                onClick={generateReceipt}
                className="bg-blue-600 text-white px-6 py-3 rounded-lg font-medium"
              >
                Generate New Receipt
              </motion.button>
            </div>
          </motion.div>
        )}

        {/* Tab 3: Offline Mode */}
        {selectedTab === 'offline' && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ duration: 0.3 }}
          >
            <div className="mb-6">
              <h3 className="text-slate-900 font-bold text-lg mb-2">🧠 Offline Mode with Deferred Nonce Validation</h3>
              <p className="text-slate-600 text-sm mb-4">
                When connectivity drops, ATMs enter offline-certified mode using pre-issued nonce ranges. 
                Transactions are signed, time-boxed, and locally sealed.
              </p>
              
              <div className="bg-amber-50 border-2 border-amber-300 rounded-lg p-4 mb-6">
                <div className="flex items-start gap-3">
                  <WifiOff className="w-5 h-5 text-amber-600 mt-0.5" />
                  <div>
                    <div className="text-amber-900 font-medium mb-2">Offline Operation Flow</div>
                    <div className="space-y-2">
                      <div className="bg-white rounded p-2">
                        <div className="text-amber-900 text-sm font-medium">When connectivity drops:</div>
                        <ul className="text-amber-800 text-xs space-y-1 mt-1 ml-4">
                          <li>• ATM enters offline-certified mode</li>
                          <li>• Uses pre-issued nonce ranges (validated at boot)</li>
                          <li>• Transactions are signed and time-boxed</li>
                          <li>• Locally sealed in secure storage</li>
                        </ul>
                      </div>
                      <div className="bg-white rounded p-2">
                        <div className="text-green-900 text-sm font-medium">When connectivity returns:</div>
                        <ul className="text-green-800 text-xs space-y-1 mt-1 ml-4">
                          <li>• Nonces validated against ledger</li>
                          <li>• Ledger commits replayed in sequence</li>
                          <li>• Invalid nonce → automatic rejection + alert</li>
                        </ul>
                      </div>
                    </div>
                  </div>
                </div>
              </div>

              <div className="bg-blue-50 border border-blue-300 rounded-lg p-4 mb-6">
                <div className="flex items-start gap-2">
                  <FileText className="w-4 h-4 text-blue-600 mt-0.5" />
                  <div className="text-blue-900 text-sm">
                    <span className="font-bold">Examiner language:</span> "Offline transactions are cryptographically 
                    sealed and only finalized after nonce validation."
                  </div>
                </div>
              </div>
            </div>

            {/* Offline ATM Status */}
            <div className="mb-6">
              <h4 className="text-slate-900 font-medium mb-3">Offline ATM — Pending Validation</h4>
              <div className="bg-yellow-50 border-2 border-yellow-300 rounded-lg p-4">
                <div className="flex items-center gap-3 mb-4">
                  <WifiOff className="w-6 h-6 text-yellow-700" />
                  <div>
                    <div className="text-yellow-900 font-bold">ATM-UMB-003</div>
                    <div className="text-yellow-800 text-sm">Plaza Branch • Offline for 1 hour</div>
                  </div>
                </div>
                
                <div className="grid grid-cols-2 gap-3 text-xs mb-4">
                  <div>
                    <span className="text-yellow-700">Pre-issued Nonce Range:</span>
                    <div className="text-yellow-900 font-mono font-bold">300000-399999</div>
                  </div>
                  <div>
                    <span className="text-yellow-700">Offline Transactions Sealed:</span>
                    <div className="text-yellow-900 font-bold">{offlineTransactions.length}</div>
                  </div>
                </div>

                <div className="bg-white rounded p-3 border border-yellow-300">
                  <div className="text-yellow-900 font-medium text-sm mb-2">Sealed Offline Transactions</div>
                  {offlineTransactions.map((txn, index) => (
                    <div key={txn.id} className="mb-2 last:mb-0">
                      <div className="flex items-start justify-between bg-yellow-50 rounded p-2">
                        <div className="flex-1">
                          <div className="text-yellow-900 text-xs font-mono">{txn.id}</div>
                          <div className="text-yellow-800 text-xs">
                            Amount: ${(txn.amount / 100).toFixed(2)} • Nonce: {txn.nonce}
                          </div>
                          <div className="text-yellow-700 text-[10px] font-mono">{txn.signature}</div>
                        </div>
                        <div className={`
                          ml-2 px-2 py-1 rounded text-xs font-medium
                          ${txn.status === 'offline_sealed' ? 'bg-yellow-200 text-yellow-900' : 'bg-green-200 text-green-900'}
                        `}>
                          {txn.status === 'offline_sealed' ? '🔒 SEALED' : '✅ VALIDATED'}
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            </div>

            {/* Validation Trigger */}
            <div className="bg-slate-900 rounded-lg p-4">
              <div className="flex items-center justify-between">
                <div>
                  <div className="text-white font-bold mb-1">🌐 Connectivity Restored</div>
                  <div className="text-slate-400 text-sm">Validate offline nonces and commit to ledger</div>
                </div>
                <motion.button
                  whileHover={{ scale: 1.05 }}
                  whileTap={{ scale: 0.95 }}
                  onClick={validateOfflineTransactions}
                  disabled={offlineTransactions.every(t => t.status === 'completed')}
                  className={`
                    px-4 py-2 rounded font-medium flex items-center gap-2
                    ${offlineTransactions.every(t => t.status === 'completed')
                      ? 'bg-green-600 text-white cursor-not-allowed'
                      : 'bg-green-600 text-white hover:bg-green-700'
                    }
                  `}
                >
                  {offlineTransactions.every(t => t.status === 'completed') ? (
                    <>
                      <CheckCircle className="w-5 h-5" />
                      Validated
                    </>
                  ) : (
                    <>
                      <Wifi className="w-5 h-5" />
                      Validate Nonces
                    </>
                  )}
                </motion.button>
              </div>
            </div>

            {offlineTransactions.every(t => t.status === 'completed') && (
              <motion.div
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                className="mt-4 bg-green-50 border-2 border-green-300 rounded-lg p-4"
              >
                <div className="flex items-center gap-3">
                  <CheckCircle className="w-6 h-6 text-green-600" />
                  <div>
                    <div className="text-green-900 font-bold">All Offline Transactions Validated</div>
                    <div className="text-green-800 text-sm">
                      Nonces verified • Ledger commits replayed • No invalid nonces detected
                    </div>
                  </div>
                </div>
              </motion.div>
            )}
          </motion.div>
        )}

        {/* Tab 4: Security Appendix */}
        {selectedTab === 'appendix' && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ duration: 0.3 }}
          >
            <div className="mb-6">
              <h3 className="text-slate-900 font-bold text-lg mb-2">📄 ATM Security Appendix (PDF)</h3>
              <p className="text-slate-600 text-sm mb-4">
                Formal appendix document covering certificate-based kill-switches, cryptographic customer receipts, 
                offline operation safeguards, and audit & compliance posture.
              </p>
            </div>

            {/* Document Preview */}
            <div className="bg-white border-2 border-slate-300 rounded-lg shadow-xl overflow-hidden max-w-2xl mx-auto">
              {/* PDF Header */}
              <div className="bg-slate-900 p-6 text-white">
                <div className="flex items-center justify-between mb-4">
                  <div>
                    <div className="text-2xl font-bold">UMB NA</div>
                    <div className="text-slate-400 text-sm">ATM Security Operations</div>
                  </div>
                  <FileText className="w-12 h-12 text-slate-600" />
                </div>
                <div className="text-xl font-bold">ATM Security Appendix</div>
                <div className="text-slate-400 text-sm">Cryptographic Controls & Compliance Framework</div>
              </div>

              {/* PDF Content */}
              <div className="p-6 space-y-6 bg-slate-50">
                {/* Section 1 */}
                <div className="bg-white rounded p-4 border border-slate-200">
                  <div className="text-red-900 font-bold mb-2">1. Certificate-Based Kill-Switch</div>
                  <p className="text-slate-700 text-sm mb-2">
                    Every ATM device is bound to the institutional Root Certificate Authority (CA). 
                    Certificate revocation triggers immediate operational termination through:
                  </p>
                  <ul className="text-slate-700 text-sm space-y-1 ml-4">
                    <li>• mTLS handshake failure (transport layer)</li>
                    <li>• Secret access denial (application layer)</li>
                    <li>• Ledger commit rejection (data layer)</li>
                  </ul>
                  <div className="mt-3 bg-red-50 border border-red-200 rounded p-2">
                    <div className="text-red-900 text-xs font-bold">Blast Radius Control</div>
                    <div className="text-red-800 text-xs">Single device • Branch-level • Fleet-wide emergency</div>
                  </div>
                </div>

                {/* Section 2 */}
                <div className="bg-white rounded p-4 border border-slate-200">
                  <div className="text-blue-900 font-bold mb-2">2. Cryptographic Customer Receipts</div>
                  <p className="text-slate-700 text-sm mb-2">
                    Each transaction generates a cryptographic receipt containing:
                  </p>
                  <ul className="text-slate-700 text-sm space-y-1 ml-4">
                    <li>• SHA-256 transaction hash</li>
                    <li>• Rebalance nonce (idempotency key)</li>
                    <li>• Ledger commit signature (mTLS-derived)</li>
                    <li>• Timestamp + device certificate fingerprint</li>
                  </ul>
                  <div className="mt-3 bg-blue-50 border border-blue-200 rounded p-2">
                    <div className="text-blue-900 text-xs font-bold">Non-Repudiation Properties</div>
                    <div className="text-blue-800 text-xs">
                      ✓ Bank-verifiable • ✓ Cryptographically proven • ✓ Dispute-resolution ready
                    </div>
                  </div>
                </div>

                {/* Section 3 */}
                <div className="bg-white rounded p-4 border border-slate-200">
                  <div className="text-amber-900 font-bold mb-2">3. Offline Operation Safeguards</div>
                  <p className="text-slate-700 text-sm mb-2">
                    ATMs operate in offline-certified mode during connectivity loss:
                  </p>
                  <ul className="text-slate-700 text-sm space-y-1 ml-4">
                    <li>• Pre-issued nonce ranges (validated at boot)</li>
                    <li>• Transactions cryptographically sealed locally</li>
                    <li>• Time-boxed operation window</li>
                    <li>• Deferred validation upon reconnection</li>
                  </ul>
                  <div className="mt-3 bg-amber-50 border border-amber-200 rounded p-2">
                    <div className="text-amber-900 text-xs font-bold">Examiner Statement</div>
                    <div className="text-amber-800 text-xs">
                      "Offline transactions are cryptographically sealed and only finalized after nonce validation."
                    </div>
                  </div>
                </div>

                {/* Section 4 */}
                <div className="bg-white rounded p-4 border border-slate-200">
                  <div className="text-purple-900 font-bold mb-2">4. Audit & Compliance Posture</div>
                  <div className="grid grid-cols-2 gap-3 text-xs">
                    <div className="bg-slate-50 rounded p-2">
                      <div className="text-slate-700 font-medium">FFIEC Guidelines</div>
                      <div className="text-slate-600">IT Examination Handbook</div>
                    </div>
                    <div className="bg-slate-50 rounded p-2">
                      <div className="text-slate-700 font-medium">SOC 2 Type II</div>
                      <div className="text-slate-600">Security & Availability</div>
                    </div>
                    <div className="bg-slate-50 rounded p-2">
                      <div className="text-slate-700 font-medium">Regulation E</div>
                      <div className="text-slate-600">Error Resolution</div>
                    </div>
                    <div className="bg-slate-50 rounded p-2">
                      <div className="text-slate-700 font-medium">CIS Controls</div>
                      <div className="text-slate-600">IG2/IG3 Requirements</div>
                    </div>
                  </div>
                </div>

                {/* Signature Block */}
                <div className="bg-slate-900 text-white rounded p-4">
                  <div className="text-xs text-slate-400 mb-2">Document Version 1.2 • February 2026</div>
                  <div className="text-sm">
                    Suitable for: FFIEC exams • Internal audit • Board risk committees • Bank partner due diligence
                  </div>
                </div>
              </div>
            </div>

            {/* Download Button */}
            <div className="mt-6 text-center">
              <motion.button
                whileHover={{ scale: 1.05 }}
                whileTap={{ scale: 0.95 }}
                className="bg-gradient-to-r from-red-600 to-orange-600 text-white px-8 py-4 rounded-lg font-bold text-lg flex items-center gap-3 mx-auto shadow-xl"
              >
                <Download className="w-6 h-6" />
                Download ATM Security Appendix (PDF)
              </motion.button>
              <div className="text-slate-600 text-sm mt-3">
                Formal documentation suitable for regulatory submission
              </div>
            </div>
          </motion.div>
        )}
      </div>
    </motion.div>
  );
}