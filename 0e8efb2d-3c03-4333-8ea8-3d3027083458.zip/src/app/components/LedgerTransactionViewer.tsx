import { motion } from 'motion/react';
import { ArrowRight, CheckCircle } from 'lucide-react';

export function LedgerTransactionViewer() {
  const transaction = {
    idempotency_key: "a329c411-2464-4ce0-a490-068c68661c27",
    description: "Payroll deposits to UMB NA Bank checking account",
    effective_at: "2025-09-14T12:51:00Z",
    ledger_entries: [
      {
        amount: 25000000,
        direction: "debit",
        ledger_account_id: "payroll_clearing_account",
        metadata: {
          purpose: "Payroll Batch Funding",
          sequence: 0
        }
      },
      {
        amount: 25000000,
        direction: "credit",
        ledger_account_id: "checking_account_umb_na",
        metadata: {
          routing_number: "101205681",
          account_number: "39900000585459050",
          bank: "UMB NA",
          purpose: "Payroll Deposit",
          sequence: 1
        }
      },
      {
        amount: 25000000,
        direction: "credit",
        ledger_account_id: "checking_account_umb_na",
        metadata: {
          routing_number: "101205681",
          account_number: "39900000585459050",
          bank: "UMB NA",
          purpose: "Payroll Deposit",
          sequence: 2
        }
      }
    ],
    metadata: {
      total_amount: 50000000,
      currency: "USD",
      bank: "UMB NA",
      routing_number: "101205681",
      account_number: "39900000585459050",
      allocation_strategy: "250k_per_transaction"
    }
  };

  const formatCurrency = (cents: number) => {
    return `$${(cents / 100).toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}`;
  };

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      exit={{ opacity: 0, y: -20 }}
      transition={{ duration: 0.4 }}
      className="bg-gradient-to-br from-purple-900 to-purple-950 rounded-lg p-6 border border-purple-700 shadow-xl"
    >
      {/* Header */}
      <div className="flex items-center gap-3 mb-4">
        <CheckCircle className="w-6 h-6 text-green-400" />
        <div>
          <h3 className="text-white">Double-Entry Ledger Transaction</h3>
          <p className="text-purple-300 text-sm">{transaction.description}</p>
        </div>
      </div>

      {/* Transaction Metadata */}
      <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ delay: 0.2 }}
        className="grid grid-cols-2 gap-3 mb-6"
      >
        <div className="bg-purple-800/50 rounded p-3 border border-purple-700">
          <div className="text-purple-300 text-xs mb-1">Total Amount</div>
          <div className="text-white">{formatCurrency(transaction.metadata.total_amount)}</div>
        </div>
        <div className="bg-purple-800/50 rounded p-3 border border-purple-700">
          <div className="text-purple-300 text-xs mb-1">Bank</div>
          <div className="text-white text-sm">{transaction.metadata.bank}</div>
        </div>
        <div className="bg-purple-800/50 rounded p-3 border border-purple-700">
          <div className="text-purple-300 text-xs mb-1">Account</div>
          <div className="text-white text-sm font-mono">{transaction.metadata.account_number}</div>
        </div>
        <div className="bg-purple-800/50 rounded p-3 border border-purple-700">
          <div className="text-purple-300 text-xs mb-1">Routing</div>
          <div className="text-white text-sm font-mono">{transaction.metadata.routing_number}</div>
        </div>
      </motion.div>

      {/* Ledger Entries Flow */}
      <div className="space-y-4">
        {/* Debit Entry */}
        <motion.div
          initial={{ opacity: 0, x: -20 }}
          animate={{ opacity: 1, x: 0 }}
          transition={{ delay: 0.3 }}
          className="bg-red-900/30 border-2 border-red-500 rounded-lg p-4"
        >
          <div className="flex items-center justify-between">
            <div>
              <div className="text-red-400 text-xs mb-1">DEBIT</div>
              <div className="text-white">{transaction.ledger_entries[0].ledger_account_id}</div>
              <div className="text-purple-300 text-sm mt-1">{transaction.ledger_entries[0].metadata.purpose}</div>
            </div>
            <div className="text-red-400 text-xl">-{formatCurrency(transaction.ledger_entries[0].amount)}</div>
          </div>
        </motion.div>

        {/* Arrow */}
        <div className="flex justify-center">
          <ArrowRight className="w-6 h-6 text-purple-400" />
        </div>

        {/* Credit Entries */}
        {transaction.ledger_entries.slice(1).map((entry, index) => (
          <motion.div
            key={index}
            initial={{ opacity: 0, x: 20 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ delay: 0.4 + index * 0.1 }}
            className="bg-green-900/30 border-2 border-green-500 rounded-lg p-4"
          >
            <div className="flex items-center justify-between">
              <div className="flex-1">
                <div className="text-green-400 text-xs mb-1">CREDIT #{entry.metadata.sequence}</div>
                <div className="text-white">{entry.ledger_account_id}</div>
                <div className="text-purple-300 text-sm mt-1">{entry.metadata.purpose}</div>
                <div className="text-purple-400 text-xs mt-2 font-mono">
                  {entry.metadata.bank} • {entry.metadata.account_number}
                </div>
              </div>
              <div className="text-green-400 text-xl">+{formatCurrency(entry.amount)}</div>
            </div>
          </motion.div>
        ))}
      </div>

      {/* Balance Check */}
      <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ delay: 0.8 }}
        className="mt-6 bg-purple-800/50 rounded-lg p-4 border border-purple-600"
      >
        <div className="flex items-center justify-between">
          <div className="text-purple-200">Balance Check (Debit = Credits)</div>
          <div className="flex items-center gap-2">
            <CheckCircle className="w-5 h-5 text-green-400" />
            <span className="text-green-400">Balanced</span>
          </div>
        </div>
      </motion.div>

      {/* Idempotency Key */}
      <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ delay: 1 }}
        className="mt-4 text-purple-400 text-xs font-mono text-center"
      >
        Idempotency: {transaction.idempotency_key}
      </motion.div>
    </motion.div>
  );
}