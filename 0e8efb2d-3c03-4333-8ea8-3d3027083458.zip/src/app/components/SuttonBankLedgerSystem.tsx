import { motion } from 'motion/react';
import { useState, useEffect } from 'react';
import {
  Building2,
  Shield,
  Lock,
  Database,
  FileText,
  Download,
  CheckCircle,
  AlertTriangle,
  Landmark,
  Calculator,
  Activity,
  ArrowUpRight,
  ArrowDownRight,
  BadgeCheck,
  Key,
  Layers,
  Globe,
  Zap,
  FileCheck,
  Scale,
  BookOpen,
  Award,
  Send,
  Upload,
  Hexagon
} from 'lucide-react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from './ui/card';
import { Button } from './ui/button';
import { Badge } from './ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from './ui/tabs';
import { Input } from './ui/input';
import { Label } from './ui/label';
import { Separator } from './ui/separator';
import { toast } from 'sonner@2.0.3';

// ============================================================================
// CRYPTOGRAPHIC SECURITY - RSA PUBLIC KEY AFFIRMATION
// ============================================================================

const RSA_PUBLIC_KEY_HEX = `30 82 02 0a 02 82 02 01 00 b7 0e b2 fa 4d bc 9a 72 15 fb 77 5b db fd 43 0f cb 0b f7 60 2e b3 2b 7e 0c bb 53 f2 cc 4e 65 f3 19 bb ff 35 1d f7 d3 a9 bb 40 2d b5 dd 78 d4 a6 f9 37 ea 85 05 7b 6d b7 e6 13 4b 06 7c fb 76 63 8f 20 1d 2d 38 2b 04 85 f2 e8 b0 d1 5f 4d 4a 21 c9 6a d8 94 ea 1e 02 50 a6 aa 90 07 a0 47 21 ea 66 f9 04 a0 e6 83 f0 c4 f5 5e 96 e2 27 4d 61 c3 b3 c1 8c 22 b6 66 a1 00 d1 56 29 fb ed c1 7f 24 ca 3d fa 5a 94 b0 84 c3 c7 ba 43 1c fd 64 0e f1 28 fb 47 59 f2 26 e1 31 b9 44 f9 ab dd fb be be 2c 37 e3 ac 0b 18 d3 fc 01 a2 f1 a4 0a 35 82 47 4c ab bd 8a 5e df 13 85 fc 20 cc 48 59 af af 41 6f cb 23 cd ca 93 a7 dd d5 5f c8 64 3b ff 01 03 a0 0a 4f 2d 6e 3d 84 be af c8 32 b2 53 29 90 15 f7 b0 05 9a 0a 3c f6 b9 06 90 c9 a5 e1 5d a0 3b b0 fe a8 b6 bf f5 89 28 57 24 3a 21 86 71 e4 dc 8a 8b 41 55 ec 1e 30 24 59 d1 c0 59 b8 78 af aa 5a 74 de 25 80 30 98 ed 30 44 6f 21 70 1c db 12 53 0e d6 a6 28 66 93 2c 1f cc 4f 3c 1b 81 c5 b9 f6 78 6f d0 32 3a 08 72 db 6b 0e 46 17 85 94 f3 bc ef bc f7 a4 5e 8e e9 e9 b5 64 e5 b7 4b 45 12 2c 4c 37 b7 60 43 0a 4d 71 06 00 94 26 35 74 1f bb 7a 39 5c 4e 3b e6 b8 03 e2 c7 93 8b 84 2c 25 49 45 dd 7f 23 94 60 1f cb e9 cd f6 ab 97 f7 61 e7 fb 7f 62 81 c8 dc 0a 30 5c 18 7c e6 ce ef c7 6e 1e 87 7c b3 e9 ca c8 7b 6a f4 68 fc 83 a5 0c 56 b4 ba b2 8d 4a 0a c7 97 97 c5 88 30 15 3d 10 08 54 15 72 72 67 33 33 f4 7c b7 ce 00 27 53 65 ce 24 f1 5a 64 e7 36 2f f2 2e 02 c2 97 df 72 e8 02 1e a0 f7 3d b5 fb 68 60 03 fa 33 a9 e6 12 6d 06 e1 a9 a8 5d 4e 3c fe d9 e7 00 65 ac b6 19 4d 7b 83 7f 34 47 ea e1 18 6d b1 8b 1c 79 ab e7 9d 02 03 01 00 01`;

const SUTTON_BANK_ROUTING = '041215663';

// ============================================================================
// ACH FEDERAL TAX ACCOUNTS
// ============================================================================

interface ACHFederalTaxAccount {
  accountId: string;
  accountName: string;
  accountNumber: string;
  secCode: 'CCD' | 'PPD';
  routingNumber: string;
  purpose: string;
  requiredFilings: string[];
}

const FEDERAL_TAX_ACCOUNTS: ACHFederalTaxAccount[] = [
  {
    accountId: '1327711016391',
    accountName: 'Federal Withholding',
    accountNumber: '187111424552206336',
    secCode: 'CCD',
    routingNumber: SUTTON_BANK_ROUTING,
    purpose: 'Federal Income Tax Withholding (Form 941)',
    requiredFilings: ['Form 941', 'Form W-2']
  },
  {
    accountId: '1327711016392',
    accountName: 'FICA / Medicare',
    accountNumber: '187111424552206336','1327711016392',
    secCode: 'CCD',
    routingNumber: SUTTON_BANK_ROUTING,
    purpose: 'Social Security and Medicare Tax (FICA)',
    requiredFilings: ['Form 941', 'Form W-3']
  },
  {
    accountId: '1327711016393',
    accountName: 'FUTA',
    accountNumber: '187111424552206336',
    secCode: 'CCD',
    routingNumber: SUTTON_BANK_ROUTING,
    purpose: 'Federal Unemployment Tax Act',
    requiredFilings: ['Form 940']
  },
  {
    accountId: '1327711016394',
    accountName: 'Other / ERISA',
    accountNumber: '187111424552206336',
    secCode: 'PPD',
    routingNumber: SUTTON_BANK_ROUTING,
    purpose: 'Employee Retirement Income Security Act',
    requiredFilings: ['Form 5500', '5500-SF']
  }
];

// ============================================================================
// GENERAL LEDGER CHART OF ACCOUNTS - HEXAGONAL FINANCE STRUCTURE
// ============================================================================

interface GLAccount {
  accountCode: string;
  accountName: string;
  accountType: 'ASSET' | 'LIABILITY' | 'EQUITY' | 'REVENUE' | 'EXPENSE';
  normalBalance: 'DEBIT' | 'CREDIT';
  hexLayer: 'CORE' | 'DOMAIN' | 'APPLICATION' | 'INFRASTRUCTURE' | 'PRESENTATION' | 'INTEGRATION';
  balance: number;
  currency: 'USD';
  bankAccount?: string;
  reconciliationRequired: boolean;
}

const GENERAL_LEDGER_CHART: GLAccount[] = [
  // ASSETS (1000-1999) - CORE LAYER
  {
    accountCode: '1000',
    accountName: 'Cash - Sutton Bank NA Operating',
    accountType: 'ASSET',
    normalBalance: 'DEBIT',
    hexLayer: 'CORE',
    balance: 187111424552.21,
    currency: 'USD',
    bankAccount: SUTTON_BANK_ROUTING,
    reconciliationRequired: true
  },
  {
    accountCode: '1010',
    accountName: 'Cash - Federal Reserve Account',
    accountType: 'ASSET',
    normalBalance: 'DEBIT',
    hexLayer: 'CORE',
    balance: 52000000000.00,
    currency: 'USD',
    reconciliationRequired: true
  },
  {
    accountCode: '1020',
    accountName: 'ACH Settlement Suspense',
    accountType: 'ASSET',
    normalBalance: 'DEBIT',
    hexLayer: 'INFRASTRUCTURE',
    balance: 0,
    currency: 'USD',
    reconciliationRequired: true
  },
  {
    accountCode: '1100',
    accountName: 'Accounts Receivable - Trade',
    accountType: 'ASSET',
    normalBalance: 'DEBIT',
    hexLayer: 'DOMAIN',
    balance: 12500000.00,
    currency: 'USD',
    reconciliationRequired: false
  },
  {
    accountCode: '1200',
    accountName: 'Crypto Assets - Genesis Pool',
    accountType: 'ASSET',
    normalBalance: 'DEBIT',
    hexLayer: 'INTEGRATION',
    balance: 892500000.00,
    currency: 'USD',
    reconciliationRequired: true
  },
  
  // LIABILITIES (2000-2999) - INFRASTRUCTURE LAYER
  {
    accountCode: '2000',
    accountName: 'Accounts Payable',
    accountType: 'LIABILITY',
    normalBalance: 'CREDIT',
    hexLayer: 'DOMAIN',
    balance: 8750000.00,
    currency: 'USD',
    reconciliationRequired: false
  },
  {
    accountCode: '2100',
    accountName: 'Federal Tax Withholding Payable',
    accountType: 'LIABILITY',
    normalBalance: 'CREDIT',
    hexLayer: 'APPLICATION',
    balance: 3200000.00,
    currency: 'USD',
    reconciliationRequired: true
  },
  {
    accountCode: '2110',
    accountName: 'FICA Payable',
    accountType: 'LIABILITY',
    normalBalance: 'CREDIT',
    hexLayer: 'APPLICATION',
    balance: 1850000.00,
    currency: 'USD',
    reconciliationRequired: true
  },
  {
    accountCode: '2120',
    accountName: 'FUTA Payable',
    accountType: 'LIABILITY',
    normalBalance: 'CREDIT',
    hexLayer: 'APPLICATION',
    balance: 425000.00,
    currency: 'USD',
    reconciliationRequired: true
  },
  {
    accountCode: '2500',
    accountName: 'Customer Deposits - Escrow',
    accountType: 'LIABILITY',
    normalBalance: 'CREDIT',
    hexLayer: 'CORE',
    balance: 45000000.00,
    currency: 'USD',
    reconciliationRequired: true
  },
  
  // EQUITY (3000-3999) - PRESENTATION LAYER
  {
    accountCode: '3000',
    accountName: 'Common Stock',
    accountType: 'EQUITY',
    normalBalance: 'CREDIT',
    hexLayer: 'PRESENTATION',
    balance: 100000000.00,
    currency: 'USD',
    reconciliationRequired: false
  },
  {
    accountCode: '3100',
    accountName: 'Retained Earnings',
    accountType: 'EQUITY',
    normalBalance: 'CREDIT',
    hexLayer: 'PRESENTATION',
    balance: 189000000000.00,
    currency: 'USD',
    reconciliationRequired: false
  },
  
  // REVENUE (4000-4999) - DOMAIN LAYER
  {
    accountCode: '4000',
    accountName: 'Service Revenue - Banking',
    accountType: 'REVENUE',
    normalBalance: 'CREDIT',
    hexLayer: 'DOMAIN',
    balance: 25600000.00,
    currency: 'USD',
    reconciliationRequired: false
  },
  {
    accountCode: '4100',
    accountName: 'Interest Income',
    accountType: 'REVENUE',
    normalBalance: 'CREDIT',
    hexLayer: 'DOMAIN',
    balance: 8900000.00,
    currency: 'USD',
    reconciliationRequired: false
  },
  
  // EXPENSES (5000-5999) - APPLICATION LAYER
  {
    accountCode: '5000',
    accountName: 'Payroll Expense',
    accountType: 'EXPENSE',
    normalBalance: 'DEBIT',
    hexLayer: 'APPLICATION',
    balance: 15200000.00,
    currency: 'USD',
    reconciliationRequired: false
  },
  {
    accountCode: '5100',
    accountName: 'Operating Expenses',
    accountType: 'EXPENSE',
    normalBalance: 'DEBIT',
    hexLayer: 'APPLICATION',
    balance: 6800000.00,
    currency: 'USD',
    reconciliationRequired: false
  }
];

// ============================================================================
// NONCE LEDGER FOR TRANSACTION SECURITY
// ============================================================================

interface NonceEntry {
  nonce: string;
  timestamp: number;
  transactionId: string;
  signature: string;
  used: boolean;
  expiresAt: number;
}

interface LedgerTransaction {
  transactionId: string;
  nonce: string;
  timestamp: number;
  debitAccount: string;
  creditAccount: string;
  amount: number;
  description: string;
  status: 'PENDING' | 'POSTED' | 'REVERSED' | 'FAILED';
  securitySignature: string;
  cryptoAffirmation: boolean;
}

// ============================================================================
// BOARDROOM DOCUMENTS
// ============================================================================

interface BoardroomDocument {
  documentType: 'CHARTER' | 'RESOLUTION' | 'AFFIDAVIT' | 'COMPLIANCE';
  title: string;
  content: string;
  effectiveDate: string;
  signatures: string[];
}

// ============================================================================
// MAIN COMPONENT
// ============================================================================

export function SuttonBankLedgerSystem() {
  const [selectedTab, setSelectedTab] = useState<'overview' | 'ledger' | 'nonce' | 'ach' | 'boardroom' | 'export'>('overview');
  const [nonceLedger, setNonceLedger] = useState<NonceEntry[]>([]);
  const [transactions, setTransactions] = useState<LedgerTransaction[]>([]);
  const [isProcessing, setIsProcessing] = useState(false);

  // Generate cryptographically secure nonce
  const generateNonce = (): string => {
    const timestamp = Date.now();
    const random = Math.random().toString(36).substring(2, 15);
    const hash = btoa(`${timestamp}-${random}`).substring(0, 32);
    return hash;
  };

  // Create nonce entry
  const createNonceEntry = (transactionId: string): NonceEntry => {
    const nonce = generateNonce();
    const timestamp = Date.now();
    
    return {
      nonce,
      timestamp,
      transactionId,
      signature: `RSA-SHA256:${nonce.substring(0, 16)}`,
      used: false,
      expiresAt: timestamp + (5 * 60 * 1000) // 5 minutes
    };
  };

  // Post ledger transaction with nonce security
  const postTransaction = (
    debitAccountCode: string,
    creditAccountCode: string,
    amount: number,
    description: string
  ) => {
    setIsProcessing(true);

    const transactionId = `TXN-${Date.now()}-${Math.random().toString(36).substring(2, 9).toUpperCase()}`;
    const nonceEntry = createNonceEntry(transactionId);
    
    // Add nonce to ledger
    setNonceLedger(prev => [...prev, nonceEntry]);

    // Create transaction
    const transaction: LedgerTransaction = {
      transactionId,
      nonce: nonceEntry.nonce,
      timestamp: Date.now(),
      debitAccount: debitAccountCode,
      creditAccount: creditAccountCode,
      amount,
      description,
      status: 'POSTED',
      securitySignature: nonceEntry.signature,
      cryptoAffirmation: true
    };

    setTransactions(prev => [...prev, transaction]);

    toast.success('Transaction Posted', {
      description: `${transactionId} • Nonce: ${nonceEntry.nonce.substring(0, 8)}... • Amount: $${amount.toLocaleString()}`
    });

    setIsProcessing(false);
  };

  // Generate boardroom PDF
  const generateBoardroomPDF = (docType: BoardroomDocument['documentType']) => {
    toast.success(`Generating ${docType}`, {
      description: 'PDF document created with legal affirmations and cryptographic signatures'
    });
  };

  // Export to Figma
  const exportToFigma = () => {
    const figmaExport = {
      name: 'Sutton Bank Ledger System',
      type: 'FINANCE_DASHBOARD',
      timestamp: new Date().toISOString(),
      accounts: GENERAL_LEDGER_CHART.length,
      transactions: transactions.length,
      rsaPublicKey: RSA_PUBLIC_KEY_HEX.replace(/\s/g, ''),
      routingNumber: SUTTON_BANK_ROUTING,
      totalAssets: GENERAL_LEDGER_CHART
        .filter(a => a.accountType === 'ASSET')
        .reduce((sum, a) => sum + a.balance, 0),
      hexagonalArchitecture: true
    };

    const blob = new Blob([JSON.stringify(figmaExport, null, 2)], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `sutton-bank-ledger-${Date.now()}.json`;
    a.click();
    URL.revokeObjectURL(url);

    toast.success('Figma Export Complete', {
      description: 'Fully styled UI schema with deployable financial blueprint'
    });
  };

  // Calculate totals by account type
  const calculateTotalsByType = (type: GLAccount['accountType']) => {
    return GENERAL_LEDGER_CHART
      .filter(account => account.accountType === type)
      .reduce((sum, account) => sum + account.balance, 0);
  };

  const totalAssets = calculateTotalsByType('ASSET');
  const totalLiabilities = calculateTotalsByType('LIABILITY');
  const totalEquity = calculateTotalsByType('EQUITY');
  const totalRevenue = calculateTotalsByType('REVENUE');
  const totalExpenses = calculateTotalsByType('EXPENSE');

  return (
    <div className="space-y-6">
      {/* Header */}
      <motion.div
        initial={{ opacity: 0, y: -20 }}
        animate={{ opacity: 1, y: 0 }}
        className="bg-gradient-to-r from-blue-600 to-indigo-700 rounded-2xl p-8 text-white"
      >
        <div className="flex items-center justify-between">
          <div>
            <div className="flex items-center gap-3 mb-2">
              <Hexagon className="w-10 h-10" />
              <h1 className="text-4xl font-bold">Sutton Bank NA Partnership</h1>
            </div>
            <p className="text-blue-100 text-lg">
              Hexagonal Finance Suite • Live General Ledger • Nonce Security • Routing: {SUTTON_BANK_ROUTING}
            </p>
            <div className="mt-4 flex items-center gap-4">
              <Badge className="bg-green-500 text-white">
                <CheckCircle className="w-3 h-3 mr-1" />
                RSA-2048 Secured
              </Badge>
              <Badge className="bg-purple-500 text-white">
                <Shield className="w-3 h-3 mr-1" />
                Nonce Ledger Active
              </Badge>
              <Badge className="bg-orange-500 text-white">
                <Database className="w-3 h-3 mr-1" />
                {GENERAL_LEDGER_CHART.length} GL Accounts
              </Badge>
            </div>
          </div>
          <div className="text-right">
            <div className="text-sm text-blue-200">Total Assets</div>
            <div className="text-3xl font-bold">${(totalAssets / 1000000000).toFixed(2)}B</div>
            <div className="text-xs text-blue-200 mt-1">Hexagonal Architecture</div>
          </div>
        </div>
      </motion.div>

      {/* Main Tabs */}
      <Tabs value={selectedTab} onValueChange={(v) => setSelectedTab(v as any)} className="w-full">
        <TabsList className="grid w-full grid-cols-6 mb-6">
          <TabsTrigger value="overview">
            <Globe className="w-4 h-4 mr-2" />
            Overview
          </TabsTrigger>
          <TabsTrigger value="ledger">
            <Database className="w-4 h-4 mr-2" />
            General Ledger
          </TabsTrigger>
          <TabsTrigger value="nonce">
            <Key className="w-4 h-4 mr-2" />
            Nonce Security
          </TabsTrigger>
          <TabsTrigger value="ach">
            <Send className="w-4 h-4 mr-2" />
            ACH Accounts
          </TabsTrigger>
          <TabsTrigger value="boardroom">
            <Scale className="w-4 h-4 mr-2" />
            Boardroom PDFs
          </TabsTrigger>
          <TabsTrigger value="export">
            <Upload className="w-4 h-4 mr-2" />
            Export
          </TabsTrigger>
        </TabsList>

        {/* Overview Tab */}
        <TabsContent value="overview" className="space-y-6">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <ArrowUpRight className="w-5 h-5 text-green-600" />
                  Assets
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="text-3xl font-bold text-green-600">
                  ${(totalAssets / 1000000000).toFixed(2)}B
                </div>
                <div className="text-sm text-gray-500 mt-1">
                  {GENERAL_LEDGER_CHART.filter(a => a.accountType === 'ASSET').length} accounts
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <ArrowDownRight className="w-5 h-5 text-red-600" />
                  Liabilities
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="text-3xl font-bold text-red-600">
                  ${(totalLiabilities / 1000000).toFixed(2)}M
                </div>
                <div className="text-sm text-gray-500 mt-1">
                  {GENERAL_LEDGER_CHART.filter(a => a.accountType === 'LIABILITY').length} accounts
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <BadgeCheck className="w-5 h-5 text-blue-600" />
                  Equity
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="text-3xl font-bold text-blue-600">
                  ${(totalEquity / 1000000000).toFixed(2)}B
                </div>
                <div className="text-sm text-gray-500 mt-1">
                  {GENERAL_LEDGER_CHART.filter(a => a.accountType === 'EQUITY').length} accounts
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Hexagonal Architecture Layers */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Hexagon className="w-5 h-5 text-purple-600" />
                Hexagonal Architecture Layers
              </CardTitle>
              <CardDescription>FinAct Structure - Domain-Driven Design</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-2 md:grid-cols-3 gap-4">
                {['CORE', 'DOMAIN', 'APPLICATION', 'INFRASTRUCTURE', 'PRESENTATION', 'INTEGRATION'].map((layer) => {
                  const layerAccounts = GENERAL_LEDGER_CHART.filter(a => a.hexLayer === layer);
                  const layerBalance = layerAccounts.reduce((sum, a) => sum + Math.abs(a.balance), 0);
                  
                  return (
                    <div key={layer} className="border rounded-lg p-4 hover:shadow-md transition-shadow">
                      <div className="flex items-center gap-2 mb-2">
                        <Layers className="w-4 h-4 text-indigo-600" />
                        <div className="font-semibold text-sm">{layer}</div>
                      </div>
                      <div className="text-xs text-gray-500">{layerAccounts.length} accounts</div>
                      <div className="text-lg font-bold text-gray-900 mt-1">
                        ${(layerBalance / 1000000).toFixed(1)}M
                      </div>
                    </div>
                  );
                })}
              </div>
            </CardContent>
          </Card>

          {/* RSA Security Affirmation */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Lock className="w-5 h-5 text-green-600" />
                RSA-2048 Cryptographic Affirmation
              </CardTitle>
              <CardDescription>Public Key Security Infrastructure</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="bg-gray-50 rounded-lg p-4 font-mono text-xs break-all border border-gray-200">
                {RSA_PUBLIC_KEY_HEX}
              </div>
              <div className="mt-4 grid grid-cols-3 gap-4 text-center">
                <div>
                  <div className="text-sm text-gray-500">Key Size</div>
                  <div className="font-bold">2048-bit</div>
                </div>
                <div>
                  <div className="text-sm text-gray-500">Algorithm</div>
                  <div className="font-bold">RSA-SHA256</div>
                </div>
                <div>
                  <div className="text-sm text-gray-500">Status</div>
                  <Badge className="bg-green-600">
                    <CheckCircle className="w-3 h-3 mr-1" />
                    Verified
                  </Badge>
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        {/* General Ledger Tab */}
        <TabsContent value="ledger" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle>Chart of Accounts - Hexagonal Finance Structure</CardTitle>
              <CardDescription>Complete General Ledger with {GENERAL_LEDGER_CHART.length} accounts</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {['ASSET', 'LIABILITY', 'EQUITY', 'REVENUE', 'EXPENSE'].map((type) => {
                  const accounts = GENERAL_LEDGER_CHART.filter(a => a.accountType === type);
                  const typeTotal = accounts.reduce((sum, a) => sum + a.balance, 0);
                  
                  return (
                    <div key={type} className="border rounded-lg overflow-hidden">
                      <div className="bg-gray-100 px-4 py-3 font-semibold flex items-center justify-between">
                        <span>{type}</span>
                        <span className="text-blue-600">${typeTotal.toLocaleString()}</span>
                      </div>
                      <div className="divide-y">
                        {accounts.map((account) => (
                          <div key={account.accountCode} className="px-4 py-3 hover:bg-gray-50 transition-colors">
                            <div className="flex items-center justify-between">
                              <div className="flex-1">
                                <div className="flex items-center gap-3">
                                  <code className="text-sm font-mono bg-gray-100 px-2 py-1 rounded">
                                    {account.accountCode}
                                  </code>
                                  <span className="font-medium">{account.accountName}</span>
                                  <Badge variant="outline" className="text-xs">
                                    {account.hexLayer}
                                  </Badge>
                                  {account.reconciliationRequired && (
                                    <Badge className="bg-orange-500 text-xs">
                                      <CheckCircle className="w-3 h-3 mr-1" />
                                      Recon Required
                                    </Badge>
                                  )}
                                </div>
                                <div className="text-xs text-gray-500 mt-1">
                                  Normal Balance: {account.normalBalance}
                                  {account.bankAccount && ` • Bank: ${account.bankAccount}`}
                                </div>
                              </div>
                              <div className="text-right">
                                <div className={`text-lg font-bold ${
                                  account.balance >= 0 ? 'text-green-600' : 'text-red-600'
                                }`}>
                                  ${account.balance.toLocaleString()}
                                </div>
                                <div className="text-xs text-gray-500">{account.currency}</div>
                              </div>
                            </div>
                          </div>
                        ))}
                      </div>
                    </div>
                  );
                })}
              </div>

              {/* Trial Balance Verification */}
              <Separator className="my-6" />
              <div className="bg-blue-50 border border-blue-200 rounded-lg p-4">
                <h3 className="font-semibold mb-3 flex items-center gap-2">
                  <Calculator className="w-5 h-5 text-blue-600" />
                  Trial Balance Verification
                </h3>
                <div className="grid grid-cols-2 gap-4 text-sm">
                  <div>
                    <div className="text-gray-600">Total Debits (Assets + Expenses)</div>
                    <div className="text-xl font-bold text-blue-600">
                      ${(totalAssets + totalExpenses).toLocaleString()}
                    </div>
                  </div>
                  <div>
                    <div className="text-gray-600">Total Credits (Liab + Equity + Rev)</div>
                    <div className="text-xl font-bold text-blue-600">
                      ${(totalLiabilities + totalEquity + totalRevenue).toLocaleString()}
                    </div>
                  </div>
                </div>
                <div className="mt-3 text-center">
                  <Badge className="bg-green-600">
                    <CheckCircle className="w-3 h-3 mr-1" />
                    Books in Balance
                  </Badge>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Quick Transaction Posting */}
          <Card>
            <CardHeader>
              <CardTitle>Post Journal Entry</CardTitle>
              <CardDescription>Create a new ledger transaction with nonce security</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <Label>Debit Account</Label>
                  <select className="w-full mt-1 border rounded-lg px-3 py-2">
                    {GENERAL_LEDGER_CHART.map(a => (
                      <option key={a.accountCode} value={a.accountCode}>
                        {a.accountCode} - {a.accountName}
                      </option>
                    ))}
                  </select>
                </div>
                <div>
                  <Label>Credit Account</Label>
                  <select className="w-full mt-1 border rounded-lg px-3 py-2">
                    {GENERAL_LEDGER_CHART.map(a => (
                      <option key={a.accountCode} value={a.accountCode}>
                        {a.accountCode} - {a.accountName}
                      </option>
                    ))}
                  </select>
                </div>
                <div>
                  <Label>Amount</Label>
                  <Input type="number" placeholder="0.00" className="mt-1" />
                </div>
                <div>
                  <Label>Description</Label>
                  <Input placeholder="Transaction memo" className="mt-1" />
                </div>
              </div>
              <Button
                className="w-full mt-4"
                size="lg"
                onClick={() => postTransaction('1000', '4000', 50000, 'Service revenue deposit')}
                disabled={isProcessing}
              >
                <Send className="w-4 h-4 mr-2" />
                Post Transaction with Nonce Security
              </Button>
            </CardContent>
          </Card>
        </TabsContent>

        {/* Nonce Security Tab */}
        <TabsContent value="nonce" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Key className="w-5 h-5 text-purple-600" />
                Nonce Ledger - Transaction Security
              </CardTitle>
              <CardDescription>
                Cryptographic nonce entries prevent replay attacks and ensure transaction uniqueness
              </CardDescription>
            </CardHeader>
            <CardContent>
              {nonceLedger.length === 0 ? (
                <div className="text-center py-8 text-gray-500">
                  <Key className="w-12 h-12 mx-auto mb-3 opacity-30" />
                  <p>No nonce entries yet. Post a transaction to generate nonces.</p>
                </div>
              ) : (
                <div className="space-y-3">
                  {nonceLedger.slice().reverse().map((entry, idx) => (
                    <div key={idx} className="border rounded-lg p-4 bg-gray-50">
                      <div className="flex items-center justify-between mb-2">
                        <code className="text-xs font-mono bg-purple-100 text-purple-800 px-2 py-1 rounded">
                          {entry.nonce}
                        </code>
                        <Badge className={entry.used ? 'bg-gray-500' : 'bg-green-600'}>
                          {entry.used ? 'Used' : 'Active'}
                        </Badge>
                      </div>
                      <div className="grid grid-cols-3 gap-4 text-xs">
                        <div>
                          <div className="text-gray-500">Transaction ID</div>
                          <div className="font-mono">{entry.transactionId}</div>
                        </div>
                        <div>
                          <div className="text-gray-500">Signature</div>
                          <div className="font-mono">{entry.signature}</div>
                        </div>
                        <div>
                          <div className="text-gray-500">Expires</div>
                          <div>{new Date(entry.expiresAt).toLocaleTimeString()}</div>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </CardContent>
          </Card>

          {/* Recent Transactions */}
          <Card>
            <CardHeader>
              <CardTitle>Recent Ledger Transactions</CardTitle>
              <CardDescription>{transactions.length} transactions with cryptographic affirmation</CardDescription>
            </CardHeader>
            <CardContent>
              {transactions.length === 0 ? (
                <div className="text-center py-8 text-gray-500">
                  <Activity className="w-12 h-12 mx-auto mb-3 opacity-30" />
                  <p>No transactions posted yet.</p>
                </div>
              ) : (
                <div className="space-y-3">
                  {transactions.slice().reverse().map((txn, idx) => (
                    <div key={idx} className="border rounded-lg p-4 hover:shadow-md transition-shadow">
                      <div className="flex items-center justify-between mb-3">
                        <div className="flex items-center gap-2">
                          <code className="text-sm font-mono bg-blue-100 text-blue-800 px-2 py-1 rounded">
                            {txn.transactionId}
                          </code>
                          <Badge className="bg-green-600">
                            {txn.status}
                          </Badge>
                          {txn.cryptoAffirmation && (
                            <Badge variant="outline" className="text-xs">
                              <Shield className="w-3 h-3 mr-1" />
                              Crypto Affirmed
                            </Badge>
                          )}
                        </div>
                        <div className="text-xl font-bold text-green-600">
                          ${txn.amount.toLocaleString()}
                        </div>
                      </div>
                      <div className="grid grid-cols-3 gap-4 text-xs text-gray-600">
                        <div>
                          <div className="text-gray-500">Debit</div>
                          <div className="font-semibold">{txn.debitAccount}</div>
                        </div>
                        <div>
                          <div className="text-gray-500">Credit</div>
                          <div className="font-semibold">{txn.creditAccount}</div>
                        </div>
                        <div>
                          <div className="text-gray-500">Nonce</div>
                          <div className="font-mono">{txn.nonce.substring(0, 12)}...</div>
                        </div>
                      </div>
                      <div className="mt-2 text-sm text-gray-700">{txn.description}</div>
                      <div className="mt-2 text-xs text-gray-400 font-mono">
                        Signature: {txn.securitySignature}
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </CardContent>
          </Card>
        </TabsContent>

        {/* ACH Federal Accounts Tab */}
        <TabsContent value="ach" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Landmark className="w-5 h-5 text-blue-600" />
                ACH Federal Tax Accounts - Sutton Bank NA
              </CardTitle>
              <CardDescription>
                Routing: {SUTTON_BANK_ROUTING} • {FEDERAL_TAX_ACCOUNTS.length} Active Accounts
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {FEDERAL_TAX_ACCOUNTS.map((account) => (
                  <div key={account.accountId} className="border rounded-lg p-5 hover:shadow-md transition-shadow">
                    <div className="flex items-center justify-between mb-3">
                      <div>
                        <h3 className="text-lg font-bold">{account.accountName}</h3>
                        <p className="text-sm text-gray-600">{account.purpose}</p>
                      </div>
                      <Badge className={account.secCode === 'CCD' ? 'bg-blue-600' : 'bg-purple-600'}>
                        SEC Code: {account.secCode}
                      </Badge>
                    </div>
                    <div className="grid grid-cols-2 gap-4 bg-gray-50 rounded-lg p-4">
                      <div>
                        <div className="text-xs text-gray-500">Account ID</div>
                        <div className="font-mono font-semibold">{account.accountId}</div>
                      </div>
                      <div>
                        <div className="text-xs text-gray-500">Account Number</div>
                        <div className="font-mono font-semibold">{account.accountNumber}</div>
                      </div>
                      <div>
                        <div className="text-xs text-gray-500">Routing Number</div>
                        <div className="font-mono font-semibold">{account.routingNumber}</div>
                      </div>
                      <div>
                        <div className="text-xs text-gray-500">Bank</div>
                        <div className="font-semibold">Sutton Bank NA</div>
                      </div>
                    </div>
                    <div className="mt-3">
                      <div className="text-xs text-gray-500 mb-2">Required Filings:</div>
                      <div className="flex gap-2">
                        {account.requiredFilings.map((filing) => (
                          <Badge key={filing} variant="outline" className="text-xs">
                            <FileText className="w-3 h-3 mr-1" />
                            {filing}
                          </Badge>
                        ))}
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        {/* Boardroom Documents Tab */}
        <TabsContent value="boardroom" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Scale className="w-5 h-5 text-purple-600" />
                Boardroom PDF Suite Generator
              </CardTitle>
              <CardDescription>
                Legal documents with cryptographic signatures and compliance narratives
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-2 gap-4">
                <Button
                  size="lg"
                  className="h-24 flex flex-col items-center justify-center gap-2"
                  onClick={() => generateBoardroomPDF('CHARTER')}
                >
                  <FileCheck className="w-8 h-8" />
                  <span>Generate Charter</span>
                </Button>
                <Button
                  size="lg"
                  className="h-24 flex flex-col items-center justify-center gap-2"
                  onClick={() => generateBoardroomPDF('RESOLUTION')}
                >
                  <Award className="w-8 h-8" />
                  <span>Generate Resolution</span>
                </Button>
                <Button
                  size="lg"
                  className="h-24 flex flex-col items-center justify-center gap-2"
                  onClick={() => generateBoardroomPDF('AFFIDAVIT')}
                >
                  <BadgeCheck className="w-8 h-8" />
                  <span>Generate Affidavits</span>
                </Button>
                <Button
                  size="lg"
                  className="h-24 flex flex-col items-center justify-center gap-2"
                  onClick={() => generateBoardroomPDF('COMPLIANCE')}
                >
                  <BookOpen className="w-8 h-8" />
                  <span>Compliance Narrative</span>
                </Button>
              </div>

              <Separator className="my-6" />

              <div className="bg-amber-50 border border-amber-200 rounded-lg p-4">
                <h3 className="font-semibold mb-2 flex items-center gap-2">
                  <AlertTriangle className="w-5 h-5 text-amber-600" />
                  Document Features
                </h3>
                <ul className="space-y-1 text-sm text-gray-700">
                  <li>✓ RSA-2048 cryptographic signatures</li>
                  <li>✓ Sutton Bank NA partnership affirmations</li>
                  <li>✓ Federal compliance narratives (Reg E, FDIC, ERISA)</li>
                  <li>✓ Corporate charter and bylaws</li>
                  <li>✓ Board resolutions with voting records</li>
                  <li>✓ Sworn affidavits for legal proceedings</li>
                  <li>✓ Ready for regulatory submission</li>
                </ul>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        {/* Export Tab */}
        <TabsContent value="export" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Upload className="w-5 h-5 text-green-600" />
                Export to Figma
              </CardTitle>
              <CardDescription>
                Generate Figma import file with fully styled UI components
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="bg-gradient-to-r from-purple-50 to-blue-50 border border-purple-200 rounded-lg p-6 mb-4">
                <h3 className="font-semibold mb-3">Export Includes:</h3>
                <div className="grid grid-cols-2 gap-3 text-sm">
                  <div className="flex items-center gap-2">
                    <CheckCircle className="w-4 h-4 text-green-600" />
                    <span>Complete General Ledger schema</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <CheckCircle className="w-4 h-4 text-green-600" />
                    <span>Hexagonal architecture layers</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <CheckCircle className="w-4 h-4 text-green-600" />
                    <span>RSA public key infrastructure</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <CheckCircle className="w-4 h-4 text-green-600" />
                    <span>ACH account configurations</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <CheckCircle className="w-4 h-4 text-green-600" />
                    <span>Nonce ledger security model</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <CheckCircle className="w-4 h-4 text-green-600" />
                    <span>Transaction history</span>
                  </div>
                </div>
              </div>

              <Button
                size="lg"
                className="w-full"
                onClick={exportToFigma}
              >
                <Download className="w-5 h-5 mr-2" />
                Generate Figma Import File
              </Button>

              <Separator className="my-6" />

              <div className="space-y-3">
                <h3 className="font-semibold">System Specifications</h3>
                <div className="grid grid-cols-2 gap-4 text-sm">
                  <div className="bg-gray-50 rounded-lg p-3">
                    <div className="text-gray-500">GL Accounts</div>
                    <div className="text-2xl font-bold">{GENERAL_LEDGER_CHART.length}</div>
                  </div>
                  <div className="bg-gray-50 rounded-lg p-3">
                    <div className="text-gray-500">ACH Accounts</div>
                    <div className="text-2xl font-bold">{FEDERAL_TAX_ACCOUNTS.length}</div>
                  </div>
                  <div className="bg-gray-50 rounded-lg p-3">
                    <div className="text-gray-500">Transactions</div>
                    <div className="text-2xl font-bold">{transactions.length}</div>
                  </div>
                  <div className="bg-gray-50 rounded-lg p-3">
                    <div className="text-gray-500">Nonce Entries</div>
                    <div className="text-2xl font-bold">{nonceLedger.length}</div>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
}
