import { useState } from 'react';
import { motion } from 'motion/react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from './ui/card';
import { Tabs, TabsContent, TabsList, TabsTrigger } from './ui/tabs';
import { Badge } from './ui/badge';
import { Button } from './ui/button';
import { Input } from './ui/input';
import { Label } from './ui/label';
import {
  Shield,
  Lock,
  Database,
  CheckCircle,
  AlertTriangle,
  FileText,
  Hash,
  Activity,
  Building2,
  TrendingUp,
  BarChart3,
  Eye,
  GitBranch,
  Server,
  Key,
  FileCheck,
  Calendar,
  DollarSign,
  RefreshCw
} from 'lucide-react';

interface LedgerEntry {
  id: string;
  amount: number;
  direction: 'credit' | 'debit';
  ledgerAccountId: string;
  metadata: {
    role?: string;
    batch?: string;
    type?: string;
    routingNumber?: string;
    accountReference?: string;
    limitPolicy?: string;
    bank?: string;
    managerReference?: string;
  };
}

interface AllocationPosting {
  idempotencyKey: string;
  description: string;
  effectiveAt: string;
  totalAllocated: number;
  status: 'pending' | 'posted' | 'completed' | 'failed';
  ledgerEntries: LedgerEntry[];
  merkleRoot?: string;
  complianceRef: string;
  interoperableKey: string;
  remittanceId: string;
}

interface CapitalOneAccount {
  ledgerAccountId: string;
  routingNumber: string;
  accountReference: string;
  balance: number;
  remainingCapacity: number;
  perAccountLimit: number;
}

interface BaselIIIMetrics {
  operationalRiskCapital: number;
  paymentRailExposure: number;
  creditRiskWeight: number;
  riskWeightedAssets: number;
  capitalAdequacyRatio: number;
  minimumRequirement: number;
}

export function FFIECOversightDepartment() {
  const [selectedTab, setSelectedTab] = useState<'postings' | 'ledger' | 'basel' | 'reconciliation'>('postings');
  const [isPosting, setIsPosting] = useState(false);
  const [postingComplete, setPostingComplete] = useState(false);

  // Capital One Accounts
  const [capitalOneAccounts] = useState<CapitalOneAccount[]>([
    {
      ledgerAccountId: 'capitalone_bank_account_1',
      routingNumber: '031176110',
      accountReference: 'ending-0434',
      balance: 245000.00,
      remainingCapacity: 15000.00,
      perAccountLimit: 250000.00
    },
    {
      ledgerAccountId: 'UMB_bank_account_2',
      routingNumber: '101205681',
      accountReference: 'ending-9050',
      balance: 2500000.00,
      remainingCapacity: 2500000.00,
      perAccountLimit: 2500000.00
    },
    {
      ledgerAccountId: 'UMB_bank_account_3',
      routingNumber: '031176110',
      accountReference: 'ending-0436',
      balance: 225000.00,
      remainingCapacity: 2500000.00,
      perAccountLimit: 2500000.000
    }
  ]);

  // Allocation Postings
  const [allocations, setAllocations] = useState<AllocationPosting[]>([
    {
      idempotencyKey: 'feic-alloc-prod-20251027-001',
      description: 'FEIC Production Real-Time Deposit Allocation — Capital One Accounts',
      effectiveAt: '2025-10-27T18:00:00Z',
      totalAllocated: 750000.00,
      status: 'completed',
      complianceRef: 'Regulation CC §229.36',
      interoperableKey: '4be0e002-d9ff-4e88-82a5-dc2525b53c55',
      remittanceId: 'a0355ae2-1634-4012-8add-84c4ba35edc3',
      merkleRoot: 'c7f9a8b3e2d1f4a5c6b8e9d2a3f1c4b7e8d9a2f3c1b4e5d6a7f8c9b1e2d3f4a5',
      ledgerEntries: [
        {
          id: 'entry-001',
          amount: 75000000, // $750,000 in cents
          direction: 'credit',
          ledgerAccountId: 'ledger_account_checking_SUTTON_bank',
          metadata: {
            role: 'SUTTON_deposit',
            batch: '2025-10'
          }
        },
        {
          id: 'entry-002',
          amount: 25000000, // $250,000 in cents
          direction: 'debit',
          ledgerAccountId: 'capitalone_bank_account_1',
          metadata: {
            type: 'feic_deposit',
            routingNumber: '031176110',
            accountReference: 'ending-0434',
            limitPolicy: '≤250000.00'
          }
        },
        {
          id: 'entry-003',
          amount: 25000000,
          direction: 'debit',
          ledgerAccountId: 'UMB_bank_account_2',
          metadata: {
            type: 'feic_deposit',
            routingNumber: '101205681',
            accountReference: 'ending-39900005855459050',
            limitPolicy: '≤250000.00'
          }
        },
        {
          id: 'entry-004',
          amount: 25000000,
          direction: 'debit',
          ledgerAccountId: 'UMB_bank_account_3',
          metadata: {
            type: 'feic_deposit',
            routingNumber: '031176110',
            accountReference: 'ending-1891',
            limitPolicy: '≤250000.00'
          }
        }
      ]
    }
  ]);

  // Basel III Metrics
  const [baselMetrics] = useState<BaselIIIMetrics>({
    operationalRiskCapital: 45000000, // $45M
    paymentRailExposure: 750000.00,
    creditRiskWeight: 0.20, // 20%
    riskWeightedAssets: 150000.00,
    capitalAdequacyRatio: 15.5, // 15.5%
    minimumRequirement: 8.0 // 8%
  });

  // Hash simulation
  const generateMerkleHash = (data: string): string => {
    let hash = 0;
    for (let i = 0; i < data.length; i++) {
      const char = data.charCodeAt(i);
      hash = ((hash << 5) - hash) + char;
      hash = hash & hash;
    }
    return Math.abs(hash).toString(16).padStart(64, '0').slice(0, 64);
  };

  // Build ledger entries
  const buildLedgerEntries = (totalDeposit: number, perAccount: number): LedgerEntry[] => {
    const entries: LedgerEntry[] = [];

    // Credit lead clearing account
    entries.push({
      id: `entry-${Date.now()}-001`,
      amount: Math.round(totalDeposit * 100),
      direction: 'credit',
      ledgerAccountId: 'general_ledger_core_6390',
      metadata: {
        role: 'core_settlement',
        managerReference: 'platform_network_manager_node'
      }
    });

    // Debit each Capital One account
    capitalOneAccounts.forEach((acct, index) => {
      entries.push({
        id: `entry-${Date.now()}-${String(index + 2).padStart(3, '0')}`,
        amount: Math.round(perAccount * 100),
        direction: 'debit',
        ledgerAccountId: acct.ledgerAccountId,
        metadata: {
          bank: 'Capital One',
          routingNumber: acct.routingNumber,
          accountReference: acct.accountReference,
          limitPolicy: '≤250000.00',
          managerReference: 'platform_network_manager_node'
        }
      });
    });

    return entries;
  };

  // Post new allocation
  const postAllocation = () => {
    setIsPosting(true);

    const totalDeposit = 750000.00;
    const perAccount = 250000.00;
    const entries = buildLedgerEntries(totalDeposit, perAccount);

    const newAllocation: AllocationPosting = {
      idempotencyKey: `feic-alloc-prod-${new Date().toISOString().slice(0, 10).replace(/-/g, '')}-${String(allocations.length + 1).padStart(3, '0')}`,
      description: 'FEIC Production Deposit Allocation — Capital One Accounts',
      effectiveAt: new Date().toISOString(),
      totalAllocated: totalDeposit,
      status: 'pending',
      complianceRef: 'Regulation CC §229.36',
      interoperableKey: crypto.randomUUID ? crypto.randomUUID() : `${Date.now()}-${Math.random()}`,
      remittanceId: crypto.randomUUID ? crypto.randomUUID() : `${Date.now()}-${Math.random()}`,
      ledgerEntries: entries
    };

    // Simulate posting
    setTimeout(() => {
      const merkleData = JSON.stringify(newAllocation);
      newAllocation.merkleRoot = generateMerkleHash(merkleData);
      newAllocation.status = 'posted';
      
      setTimeout(() => {
        newAllocation.status = 'completed';
        setAllocations([newAllocation, ...allocations]);
        setIsPosting(false);
        setPostingComplete(true);
        
        setTimeout(() => setPostingComplete(false), 3000);
      }, 1500);
    }, 2000);
  };

  const formatCurrency = (amount: number): string => {
    return new Intl.NumberFormat('en-US', {
      style: 'currency',
      currency: 'USD',
      minimumFractionDigits: 2
    }).format(amount);
  };

  const formatCents = (cents: number): string => {
    return formatCurrency(cents / 100);
  };

  const getStatusBadge = (status: AllocationPosting['status']) => {
    const config = {
      pending: { color: 'bg-yellow-100 text-yellow-800 border-yellow-300', label: 'Pending' },
      posted: { color: 'bg-blue-100 text-blue-800 border-blue-300', label: 'Posted' },
      completed: { color: 'bg-green-100 text-green-800 border-green-300', label: 'Completed' },
      failed: { color: 'bg-red-100 text-red-800 border-red-300', label: 'Failed' }
    };

    return (
      <Badge variant="outline" className={`${config[status].color}`}>
        {config[status].label}
      </Badge>
    );
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <motion.div
        initial={{ opacity: 0, y: -20 }}
        animate={{ opacity: 1, y: 0 }}
        className="flex items-center justify-between"
      >
        <div>
          <h2 className="text-3xl font-bold text-slate-800 flex items-center gap-3">
            <Shield className="w-8 h-8 text-blue-600" />
            FFIEC Oversight & Security Department
          </h2>
          <p className="text-slate-600 mt-1">
            Deterministic Ledger • Modern Treasury • Basel III • Regulation CC §229.36
          </p>
        </div>
        <div className="flex items-center gap-3">
          <Badge variant="default" className="bg-blue-600 text-white px-4 py-2">
            <Lock className="w-4 h-4 mr-2" />
            High Security
          </Badge>
          <Badge variant="default" className="bg-green-600 text-white px-4 py-2">
            <CheckCircle className="w-4 h-4 mr-2" />
            FFIEC Compliant
          </Badge>
        </div>
      </motion.div>

      {/* Statistics Dashboard */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.1 }}
        className="grid grid-cols-2 md:grid-cols-5 gap-4"
      >
        <Card className="border-blue-200">
          <CardContent className="pt-6">
            <div className="text-center">
              <div className="text-3xl font-bold text-blue-600">{allocations.length}</div>
              <div className="text-xs text-slate-600 mt-1">Total Postings</div>
            </div>
          </CardContent>
        </Card>
        <Card className="border-green-200">
          <CardContent className="pt-6">
            <div className="text-center">
              <div className="text-3xl font-bold text-green-600">
                {allocations.filter(a => a.status === 'completed').length}
              </div>
              <div className="text-xs text-slate-600 mt-1">Completed</div>
            </div>
          </CardContent>
        </Card>
        <Card className="border-purple-200">
          <CardContent className="pt-6">
            <div className="text-center">
              <div className="text-2xl font-bold text-purple-600">
                {formatCurrency(allocations.reduce((sum, a) => sum + a.totalAllocated, 0))}
              </div>
              <div className="text-xs text-slate-600 mt-1">Total Allocated</div>
            </div>
          </CardContent>
        </Card>
        <Card className="border-amber-200">
          <CardContent className="pt-6">
            <div className="text-center">
              <div className="text-3xl font-bold text-amber-600">3</div>
              <div className="text-xs text-slate-600 mt-1">DDA Accounts</div>
            </div>
          </CardContent>
        </Card>
        <Card className="border-indigo-200">
          <CardContent className="pt-6">
            <div className="text-center">
              <div className="text-3xl font-bold text-indigo-600">{baselMetrics.capitalAdequacyRatio}%</div>
              <div className="text-xs text-slate-600 mt-1">CAR (Basel III)</div>
            </div>
          </CardContent>
        </Card>
      </motion.div>

      {/* Main Tabs */}
      <Tabs value={selectedTab} onValueChange={(value) => setSelectedTab(value as any)} className="w-full">
        <TabsList className="grid w-full grid-cols-4">
          <TabsTrigger value="postings">Allocation Postings</TabsTrigger>
          <TabsTrigger value="ledger">Deterministic Ledger</TabsTrigger>
          <TabsTrigger value="basel">Basel III Risk</TabsTrigger>
          <TabsTrigger value="reconciliation">Reconciliation</TabsTrigger>
        </TabsList>

        {/* Allocation Postings Tab */}
        <TabsContent value="postings" className="space-y-6">
          <Card>
            <CardHeader>
              <div className="flex items-center justify-between">
                <div>
                  <CardTitle className="flex items-center gap-2">
                    <FileText className="w-5 h-5 text-blue-600" />
                    FEIC Allocation Postings
                  </CardTitle>
                  <CardDescription>
                    Modern Treasury API integration with Regulation CC §229.36 compliance
                  </CardDescription>
                </div>
                <Button
                  onClick={postAllocation}
                  disabled={isPosting}
                  className="bg-gradient-to-r from-blue-600 to-blue-700"
                >
                  {isPosting ? (
                    <>
                      <RefreshCw className="w-4 h-4 mr-2 animate-spin" />
                      Posting...
                    </>
                  ) : (
                    <>
                      <FileCheck className="w-4 h-4 mr-2" />
                      Post New Allocation
                    </>
                  )}
                </Button>
              </div>
            </CardHeader>
            <CardContent>
              {postingComplete && (
                <motion.div
                  initial={{ opacity: 0, y: -10 }}
                  animate={{ opacity: 1, y: 0 }}
                  className="mb-4 p-4 bg-green-50 border-2 border-green-300 rounded-lg"
                >
                  <div className="flex items-center gap-2 text-green-800">
                    <CheckCircle className="w-5 h-5" />
                    <span className="font-semibold">Allocation posted successfully to Modern Treasury</span>
                  </div>
                </motion.div>
              )}

              <div className="space-y-4">
                {allocations.map((allocation, index) => (
                  <motion.div
                    key={allocation.idempotencyKey}
                    initial={{ opacity: 0, y: 20 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ delay: index * 0.1 }}
                    className="border-2 border-slate-200 rounded-lg p-4 hover:shadow-lg transition-shadow"
                  >
                    <div className="flex items-start justify-between mb-3">
                      <div className="flex-1">
                        <div className="flex items-center gap-3 mb-2">
                          <Database className="w-5 h-5 text-blue-600" />
                          <div className="font-bold text-slate-900">{allocation.description}</div>
                          {getStatusBadge(allocation.status)}
                        </div>
                        <div className="text-xs text-slate-600 font-mono">{allocation.idempotencyKey}</div>
                      </div>
                      <div className="text-right">
                        <div className="text-2xl font-bold text-green-600">
                          {formatCurrency(allocation.totalAllocated)}
                        </div>
                        <div className="text-xs text-slate-600">Total Allocated</div>
                      </div>
                    </div>

                    <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mt-4 pt-4 border-t border-slate-200">
                      <div>
                        <div className="text-xs text-slate-600">Effective Date</div>
                        <div className="font-semibold text-slate-900 text-sm">
                          {new Date(allocation.effectiveAt).toLocaleString()}
                        </div>
                      </div>
                      <div>
                        <div className="text-xs text-slate-600">Compliance Ref</div>
                        <div className="font-semibold text-slate-900 text-sm">{allocation.complianceRef}</div>
                      </div>
                      <div>
                        <div className="text-xs text-slate-600">Ledger Entries</div>
                        <div className="font-semibold text-slate-900 text-sm">{allocation.ledgerEntries.length}</div>
                      </div>
                      <div>
                        <div className="text-xs text-slate-600">Remittance ID</div>
                        <div className="font-mono text-xs text-slate-700 truncate">
                          {allocation.remittanceId.slice(0, 18)}...
                        </div>
                      </div>
                    </div>

                    {allocation.merkleRoot && (
                      <div className="mt-4 pt-4 border-t border-slate-200">
                        <div className="flex items-start gap-2">
                          <Hash className="w-4 h-4 text-purple-600 mt-1" />
                          <div className="flex-1">
                            <div className="text-xs text-slate-600 mb-1">Merkle Root Hash</div>
                            <div className="font-mono text-xs bg-purple-50 border border-purple-200 p-2 rounded overflow-x-auto">
                              {allocation.merkleRoot}
                            </div>
                          </div>
                        </div>
                      </div>
                    )}
                  </motion.div>
                ))}
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        {/* Deterministic Ledger Tab */}
        <TabsContent value="ledger" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <GitBranch className="w-5 h-5 text-green-600" />
                Deterministic Ledger Compiler
              </CardTitle>
              <CardDescription>
                Hash-anchored transaction journal with Merkle tree integration
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {allocations[0]?.ledgerEntries.map((entry, index) => (
                  <motion.div
                    key={entry.id}
                    initial={{ opacity: 0, x: -20 }}
                    animate={{ opacity: 1, x: 0 }}
                    transition={{ delay: index * 0.1 }}
                    className={`border-2 rounded-lg p-4 ${
                      entry.direction === 'credit'
                        ? 'border-green-200 bg-green-50'
                        : 'border-blue-200 bg-blue-50'
                    }`}
                  >
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-3">
                        <div className={`w-10 h-10 rounded-full flex items-center justify-center ${
                          entry.direction === 'credit' ? 'bg-green-600' : 'bg-blue-600'
                        }`}>
                          <Activity className="w-5 h-5 text-white" />
                        </div>
                        <div>
                          <div className="font-bold text-slate-900 capitalize">{entry.direction}</div>
                          <div className="text-xs text-slate-600 font-mono">{entry.ledgerAccountId}</div>
                        </div>
                      </div>
                      <div className="text-right">
                        <div className={`text-xl font-bold ${
                          entry.direction === 'credit' ? 'text-green-600' : 'text-blue-600'
                        }`}>
                          {entry.direction === 'credit' ? '+' : '-'}{formatCents(entry.amount)}
                        </div>
                      </div>
                    </div>

                    <div className="mt-3 pt-3 border-t border-slate-300">
                      <div className="grid grid-cols-2 gap-2 text-xs">
                        {Object.entries(entry.metadata).map(([key, value]) => (
                          <div key={key}>
                            <span className="text-slate-600">{key}:</span>
                            <span className="ml-2 font-semibold text-slate-900">{value}</span>
                          </div>
                        ))}
                      </div>
                    </div>
                  </motion.div>
                ))}
              </div>

              <div className="mt-6 p-4 bg-gradient-to-r from-purple-50 to-blue-50 border-2 border-purple-200 rounded-lg">
                <div className="flex items-start gap-3">
                  <Hash className="w-5 h-5 text-purple-600 mt-0.5" />
                  <div className="text-sm text-slate-800">
                    <p className="font-semibold mb-2">Merkle Tree Flow:</p>
                    <div className="font-mono text-xs bg-white p-3 rounded border border-purple-300">
                      <div>ledger_event</div>
                      <div className="ml-4">│</div>
                      <div className="ml-4">hash(event)</div>
                      <div className="ml-4">│</div>
                      <div className="ml-4">append_to_merkle_tree</div>
                      <div className="ml-4">│</div>
                      <div className="ml-4">daily_root</div>
                    </div>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Capital One DDA Accounts */}
          <Card className="border-2 border-indigo-200">
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Building2 className="w-5 h-5 text-indigo-600" />
                Capital One DDA Accounts
              </CardTitle>
              <CardDescription>Per-account limit monitoring with FDIC insurance compliance</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-3">
                {capitalOneAccounts.map((account, index) => (
                  <motion.div
                    key={account.ledgerAccountId}
                    initial={{ opacity: 0, x: -20 }}
                    animate={{ opacity: 1, x: 0 }}
                    transition={{ delay: index * 0.1 }}
                    className="border-2 border-slate-200 rounded-lg p-4"
                  >
                    <div className="flex items-center justify-between mb-3">
                      <div>
                        <div className="font-bold text-slate-900">{account.ledgerAccountId}</div>
                        <div className="text-xs text-slate-600 mt-1">
                          <span className="font-mono">{account.routingNumber}</span>
                          <span className="mx-2">•</span>
                          <span className="font-mono">{account.accountReference}</span>
                        </div>
                      </div>
                      <Badge variant="outline" className={`${
                        account.remainingCapacity > 0 
                          ? 'bg-green-100 text-green-700 border-green-300'
                          : 'bg-amber-100 text-amber-700 border-amber-300'
                      }`}>
                        {account.remainingCapacity > 0 ? 'Available' : 'At Limit'}
                      </Badge>
                    </div>

                    <div className="grid grid-cols-3 gap-4 text-sm">
                      <div>
                        <div className="text-xs text-slate-600">Current Balance</div>
                        <div className="font-bold text-slate-900">{formatCurrency(account.balance)}</div>
                      </div>
                      <div>
                        <div className="text-xs text-slate-600">Per-Account Limit</div>
                        <div className="font-bold text-slate-900">{formatCurrency(account.perAccountLimit)}</div>
                      </div>
                      <div>
                        <div className="text-xs text-slate-600">Remaining Capacity</div>
                        <div className={`font-bold ${
                          account.remainingCapacity > 0 ? 'text-green-600' : 'text-amber-600'
                        }`}>
                          {formatCurrency(account.remainingCapacity)}
                        </div>
                      </div>
                    </div>

                    <div className="mt-3">
                      <div className="flex items-center justify-between text-xs text-slate-600 mb-1">
                        <span>Capacity Utilization</span>
                        <span>{((account.balance / account.perAccountLimit) * 100).toFixed(1)}%</span>
                      </div>
                      <div className="w-full bg-slate-200 rounded-full h-2">
                        <div
                          className={`h-2 rounded-full ${
                            account.remainingCapacity === 0 ? 'bg-amber-500' : 'bg-green-500'
                          }`}
                          style={{ width: `${(account.balance / account.perAccountLimit) * 100}%` }}
                        />
                      </div>
                    </div>
                  </motion.div>
                ))}
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        {/* Basel III Tab */}
        <TabsContent value="basel" className="space-y-6">
          <Card className="border-2 border-orange-200">
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <BarChart3 className="w-5 h-5 text-orange-600" />
                Basel III Operational Risk Model
              </CardTitle>
              <CardDescription>
                Capital adequacy for payment rails with regulatory compliance
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <motion.div
                  initial={{ opacity: 0, scale: 0.95 }}
                  animate={{ opacity: 1, scale: 1 }}
                  className="space-y-4"
                >
                  <div className="border-2 border-orange-200 rounded-lg p-4 bg-orange-50">
                    <div className="flex items-center gap-2 mb-3">
                      <DollarSign className="w-5 h-5 text-orange-600" />
                      <div className="font-semibold text-slate-900">Operational Risk Capital</div>
                    </div>
                    <div className="text-3xl font-bold text-orange-600">
                      {formatCurrency(baselMetrics.operationalRiskCapital)}
                    </div>
                    <div className="text-xs text-slate-600 mt-2">
                      Required capital for payment rail operational risk
                    </div>
                  </div>

                  <div className="border-2 border-blue-200 rounded-lg p-4 bg-blue-50">
                    <div className="flex items-center gap-2 mb-3">
                      <Activity className="w-5 h-5 text-blue-600" />
                      <div className="font-semibold text-slate-900">Payment Rail Exposure</div>
                    </div>
                    <div className="text-3xl font-bold text-blue-600">
                      {formatCurrency(baselMetrics.paymentRailExposure)}
                    </div>
                    <div className="text-xs text-slate-600 mt-2">
                      Current exposure across all payment rails
                    </div>
                  </div>

                  <div className="border-2 border-purple-200 rounded-lg p-4 bg-purple-50">
                    <div className="flex items-center gap-2 mb-3">
                      <TrendingUp className="w-5 h-5 text-purple-600" />
                      <div className="font-semibold text-slate-900">Risk-Weighted Assets</div>
                    </div>
                    <div className="text-3xl font-bold text-purple-600">
                      {formatCurrency(baselMetrics.riskWeightedAssets)}
                    </div>
                    <div className="text-xs text-slate-600 mt-2">
                      Credit risk weight: {(baselMetrics.creditRiskWeight * 100).toFixed(0)}%
                    </div>
                  </div>
                </motion.div>

                <motion.div
                  initial={{ opacity: 0, scale: 0.95 }}
                  animate={{ opacity: 1, scale: 1 }}
                  transition={{ delay: 0.2 }}
                  className="space-y-4"
                >
                  <div className="border-2 border-green-300 rounded-lg p-6 bg-gradient-to-br from-green-50 to-white">
                    <div className="flex items-center gap-2 mb-4">
                      <CheckCircle className="w-6 h-6 text-green-600" />
                      <div className="font-bold text-slate-900 text-lg">Capital Adequacy Ratio</div>
                    </div>
                    <div className="text-5xl font-bold text-green-600 mb-2">
                      {baselMetrics.capitalAdequacyRatio}%
                    </div>
                    <div className="text-sm text-slate-700 mb-4">
                      Minimum Requirement: {baselMetrics.minimumRequirement}%
                    </div>
                    
                    <div className="relative w-full bg-slate-200 rounded-full h-4">
                      <div
                        className="absolute top-0 left-0 h-4 bg-gradient-to-r from-green-500 to-green-600 rounded-full"
                        style={{ width: `${(baselMetrics.capitalAdequacyRatio / 20) * 100}%` }}
                      />
                      <div
                        className="absolute top-0 h-4 w-1 bg-red-600"
                        style={{ left: `${(baselMetrics.minimumRequirement / 20) * 100}%` }}
                      />
                    </div>
                    
                    <div className="flex items-center justify-between text-xs text-slate-600 mt-2">
                      <span>0%</span>
                      <span className="text-red-600 font-semibold">Min: {baselMetrics.minimumRequirement}%</span>
                      <span>20%</span>
                    </div>

                    <div className="mt-4 pt-4 border-t border-green-200">
                      <div className="flex items-center gap-2 text-sm text-green-800">
                        <CheckCircle className="w-4 h-4" />
                        <span className="font-semibold">
                          Exceeds regulatory minimum by {(baselMetrics.capitalAdequacyRatio - baselMetrics.minimumRequirement).toFixed(1)} percentage points
                        </span>
                      </div>
                    </div>
                  </div>

                  <div className="border-2 border-indigo-200 rounded-lg p-4 bg-indigo-50">
                    <div className="font-semibold text-slate-900 mb-3">Basel III Formula:</div>
                    <div className="font-mono text-sm bg-white p-3 rounded border border-indigo-300">
                      <div className="text-indigo-800">CAR = (Tier 1 + Tier 2) / RWA</div>
                      <div className="text-xs text-slate-600 mt-2">
                        Where CAR ≥ 8% (minimum requirement)
                      </div>
                    </div>
                  </div>
                </motion.div>
              </div>

              <div className="mt-6 p-4 bg-gradient-to-r from-orange-50 to-amber-50 border-2 border-orange-200 rounded-lg">
                <div className="flex items-start gap-3">
                  <Eye className="w-5 h-5 text-orange-600 mt-0.5" />
                  <div className="text-sm text-slate-800">
                    <p className="font-semibold mb-2">Regulatory Oversight:</p>
                    <ul className="list-disc list-inside space-y-1">
                      <li>FFIEC IT Examination Handbook compliance</li>
                      <li>Basel III capital framework adherence</li>
                      <li>Operational risk capital allocation for payment rails</li>
                      <li>Real-time capital adequacy monitoring</li>
                      <li>Automated regulatory reporting to FDIC</li>
                    </ul>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        {/* Reconciliation Tab */}
        <TabsContent value="reconciliation" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <RefreshCw className="w-5 h-5 text-purple-600" />
                Automated Reconciliation Engine
              </CardTitle>
              <CardDescription>
                Modern Treasury response integration with real-time matching
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                <div className="border-2 border-green-300 rounded-lg p-4 bg-green-50">
                  <div className="flex items-center gap-3 mb-3">
                    <CheckCircle className="w-6 h-6 text-green-600" />
                    <div className="font-bold text-green-900">Reconciliation Status: Complete</div>
                  </div>
                  <div className="grid grid-cols-3 gap-4 text-sm">
                    <div>
                      <div className="text-xs text-green-700">Matched Transactions</div>
                      <div className="text-2xl font-bold text-green-600">
                        {allocations.filter(a => a.status === 'completed').length}/{allocations.length}
                      </div>
                    </div>
                    <div>
                      <div className="text-xs text-green-700">Total Reconciled</div>
                      <div className="text-2xl font-bold text-green-600">
                        {formatCurrency(allocations.filter(a => a.status === 'completed').reduce((sum, a) => sum + a.totalAllocated, 0))}
                      </div>
                    </div>
                    <div>
                      <div className="text-xs text-green-700">Match Rate</div>
                      <div className="text-2xl font-bold text-green-600">100%</div>
                    </div>
                  </div>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div className="border-2 border-blue-200 rounded-lg p-4">
                    <div className="flex items-center gap-2 mb-3">
                      <Server className="w-5 h-5 text-blue-600" />
                      <div className="font-semibold text-slate-900">Modern Treasury API</div>
                    </div>
                    <div className="space-y-2 text-sm">
                      <div className="flex justify-between">
                        <span className="text-slate-600">Endpoint:</span>
                        <span className="font-mono text-xs">api/ledger_transactions</span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-slate-600">Method:</span>
                        <span className="font-semibold">POST</span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-slate-600">Auth:</span>
                        <span className="font-semibold">Basic (API Key)</span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-slate-600">Timeout:</span>
                        <span className="font-semibold">20s</span>
                      </div>
                    </div>
                  </div>

                  <div className="border-2 border-purple-200 rounded-lg p-4">
                    <div className="flex items-center gap-2 mb-3">
                      <Key className="w-5 h-5 text-purple-600" />
                      <div className="font-semibold text-slate-900">Idempotency Protection</div>
                    </div>
                    <div className="space-y-2 text-sm">
                      <div className="flex justify-between">
                        <span className="text-slate-600">Pattern:</span>
                        <span className="font-mono text-xs">feic-alloc-prod-*</span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-slate-600">Duplicate Check:</span>
                        <Badge variant="outline" className="bg-green-100 text-green-700 border-green-300">
                          Enabled
                        </Badge>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-slate-600">Retry Policy:</span>
                        <span className="font-semibold">Exponential Backoff</span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-slate-600">Max Retries:</span>
                        <span className="font-semibold">3</span>
                      </div>
                    </div>
                  </div>
                </div>

                <div className="border-2 border-slate-200 rounded-lg p-4">
                  <div className="font-semibold text-slate-900 mb-3">Reconciliation Flow:</div>
                  <div className="space-y-2">
                    {[
                      'Post allocation to Modern Treasury API',
                      'Receive transaction ID and status',
                      'Match against deterministic ledger entries',
                      'Verify Merkle root hash integrity',
                      'Update local state with reconciliation status',
                      'Write reconciliation journal to audit log',
                      'Trigger downstream notification systems'
                    ].map((step, index) => (
                      <div key={index} className="flex items-center gap-3">
                        <div className="w-6 h-6 bg-blue-600 text-white rounded-full flex items-center justify-center text-xs font-bold">
                          {index + 1}
                        </div>
                        <div className="text-sm text-slate-700">{step}</div>
                      </div>
                    ))}
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>

      {/* Footer */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.3 }}
      >
        <Card className="border-blue-200 bg-gradient-to-br from-blue-50 to-white">
          <CardContent className="pt-6">
            <div className="flex items-center gap-3">
              <Lock className="w-5 h-5 text-blue-600" />
              <div className="text-sm text-blue-900">
                <span className="font-semibold">High Security & Integrity:</span> All transactions processed through 
                deterministic ledger compiler with hash-anchored Merkle tree verification. Basel III compliance enforced. 
                Modern Treasury API integration with automated reconciliation. FFIEC oversight standards maintained.
              </div>
            </div>
          </CardContent>
        </Card>
      </motion.div>
    </div>
  );
}