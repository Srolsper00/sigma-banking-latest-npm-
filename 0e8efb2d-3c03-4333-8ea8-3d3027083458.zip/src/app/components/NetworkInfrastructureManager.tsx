/**
 * Network Infrastructure Manager
 * Copyright © 2026 VOM Services Corporation
 * Matthew James Sauls - OCIO, CCO, CEO, CFO, CTO
 * EIN: 83-1427324 | FCC FRN: 0033213463
 * FINRA Org ID: TM6ZAS58-RRGKPOZW-OBLMFGJE-030961767-0033213463
 */

import { useState } from 'react';
import { motion } from 'motion/react';
import { Card } from './ui/card';
import { Button } from './ui/button';
import { Input } from './ui/input';
import { Label } from './ui/label';
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle } from './ui/dialog';
import { 
  Network, 
  Globe, 
  Shield, 
  Server, 
  Database,
  Lock,
  CheckCircle2,
  AlertCircle,
  Building2,
  MapPin,
  Zap,
  Activity,
  Settings,
  Plus,
  Trash2,
  Eye,
  RefreshCw
} from 'lucide-react';
import { toast } from 'sonner';

interface NetworkConfig {
  id: string;
  name: string;
  cidr: string;
  vnetId: string;
  datacenter: string;
  status: 'active' | 'provisioning' | 'error';
  subnets: SubnetConfig[];
  routes: RouteConfig[];
  createdAt: string;
  metadata: {
    owner: string;
    environment: string;
    compliance: string[];
    encryption: boolean;
  };
}

interface SubnetConfig {
  id: string;
  name: string;
  cidr: string;
  zone: string;
  purpose: string;
  nodeCount: number;
}

interface RouteConfig {
  id: string;
  destination: string;
  gateway: string;
  source: string;
  priority: number;
}

export function NetworkInfrastructureManager() {
  const [selectedNetwork, setSelectedNetwork] = useState<string | null>(null);
  const [showRoutes, setShowRoutes] = useState(false);

  // VOM Services Corporation Network Infrastructure
  const networks: NetworkConfig[] = [
    {
      id: 'net-3xpres5-prod',
      name: '3xpres5 Production Network',
      cidr: '10.0.0.0/16',
      vnetId: 'mathieu_et_favvarrow',
      datacenter: '3xpres5 Datacenter - Seattle, WA',
      status: 'active',
      createdAt: '2026-01-15T08:00:00Z',
      metadata: {
        owner: 'VOM Services Corporation (Matthew James Sauls)',
        environment: 'production',
        compliance: ['SOC 2 Type II', 'PCI DSS v4.0', 'NIST SP 800-57', 'FFIEC'],
        encryption: true
      },
      subnets: [
        {
          id: 'subnet-dmz',
          name: 'DMZ Zone (APISIX Gateway)',
          cidr: '10.0.1.0/24',
          zone: 'us-west-2a',
          purpose: 'dmz',
          nodeCount: 3
        },
        {
          id: 'subnet-compute',
          name: 'Compute Cluster',
          cidr: '10.0.10.0/24',
          zone: 'us-west-2b',
          purpose: 'compute',
          nodeCount: 6
        },
        {
          id: 'subnet-hsm',
          name: 'HSM Security Zone',
          cidr: '10.0.20.0/24',
          zone: 'us-west-2c',
          purpose: 'hsm',
          nodeCount: 2
        },
        {
          id: 'subnet-storage',
          name: 'Storage & Ledger',
          cidr: '10.0.30.0/24',
          zone: 'us-west-2a',
          purpose: 'storage',
          nodeCount: 4
        },
        {
          id: 'subnet-mgmt',
          name: 'Management Network',
          cidr: '10.0.100.0/24',
          zone: 'us-west-2b',
          purpose: 'management',
          nodeCount: 2
        }
      ],
      routes: [
        {
          id: 'route-umb-na',
          destination: 'UMB Bank NA',
          gateway: 'vpn-gateway-umb.3xpres5.local',
          source: '10.0.10.0/24',
          priority: 100
        },
        {
          id: 'route-fidelity',
          destination: 'Fidelity Investments',
          gateway: 'vpn-gateway-fidelity.3xpres5.local',
          source: '10.0.10.0/24',
          priority: 100
        },
        {
          id: 'route-nacha',
          destination: 'NACHA ACH Network',
          gateway: 'vpn-gateway-nacha.3xpres5.local',
          source: '10.0.10.0/24',
          priority: 90
        },
        {
          id: 'route-fedwire',
          destination: 'Fedwire System',
          gateway: 'vpn-gateway-fedwire.3xpres5.local',
          source: '10.0.10.0/24',
          priority: 90
        }
      ]
    },
    {
      id: 'net-vom-corp',
      name: 'VOM Services Corporate Network',
      cidr: '192.168.1.0/24',
      vnetId: 'vom-corp-vnet',
      datacenter: 'Seattle Office - Washington State',
      status: 'active',
      createdAt: '2025-11-01T10:00:00Z',
      metadata: {
        owner: 'Doc Sportivo Mobi - VOM Services Corporation',
        environment: 'production',
        compliance: ['FINRA', 'SEC', 'Washington State Compliance'],
        encryption: true
      },
      subnets: [
        {
          id: 'subnet-executive',
          name: 'Executive Network',
          cidr: '192.168.1.0/26',
          zone: 'office-floor-3',
          purpose: 'management',
          nodeCount: 5
        },
        {
          id: 'subnet-operations',
          name: 'Operations Network',
          cidr: '192.168.1.64/26',
          zone: 'office-floor-2',
          purpose: 'compute',
          nodeCount: 12
        },
        {
          id: 'subnet-secure',
          name: 'Secure Trading Network',
          cidr: '192.168.1.128/26',
          zone: 'office-floor-1',
          purpose: 'hsm',
          nodeCount: 3
        }
      ],
      routes: [
        {
          id: 'route-finra',
          destination: 'FINRA Gateway',
          gateway: 'finra-vpn.vom-services.local',
          source: '192.168.1.128/26',
          priority: 100
        },
        {
          id: 'route-3xpres5',
          destination: '3xpres5 Datacenter',
          gateway: 'datacenter-link.vom-services.local',
          source: '192.168.1.0/24',
          priority: 90
        }
      ]
    },
    {
      id: 'net-banking-dmz',
      name: 'Banking API DMZ Network',
      cidr: '172.16.0.0/12',
      vnetId: 'banking-dmz-vnet',
      datacenter: '3xpres5 Edge Network',
      status: 'active',
      createdAt: '2026-02-01T12:00:00Z',
      metadata: {
        owner: 'Sigma Production Banking Platform',
        environment: 'production',
        compliance: ['PCI DSS', 'FFIEC', 'Regulation E'],
        encryption: true
      },
      subnets: [
        {
          id: 'subnet-apisix-edge',
          name: 'APISIX Edge Gateway',
          cidr: '172.16.1.0/24',
          zone: 'dmz-edge',
          purpose: 'dmz',
          nodeCount: 4
        },
        {
          id: 'subnet-waf',
          name: 'Web Application Firewall',
          cidr: '172.16.2.0/24',
          zone: 'dmz-waf',
          purpose: 'dmz',
          nodeCount: 3
        }
      ],
      routes: [
        {
          id: 'route-internet',
          destination: 'Internet Gateway',
          gateway: 'titaniumite5',
          source: '172.16.0.0/12',
          priority: 50
        },
        {
          id: 'route-internal',
          destination: 'Internal Network',
          gateway: '10.0.1.1',
          source: '172.16.0.0/12',
          priority: 100
        }
      ]
    }
  ];

  const apisixRoutes = [
    {
      id: 'banking-transaction-route',
      name: 'Banking Transaction API',
      uri: '/api/v1/transactions/*',
      methods: ['POST', 'GET', 'PUT'],
      rateLimit: '100 req/sec',
      upstream: ['compute-b', 'compute-c', 'compute-d']
    },
    {
      id: 'ach-batch-route',
      name: 'ACH Batch Processing',
      uri: '/api/v1/ach/batch/*',
      methods: ['POST'],
      rateLimit: '10 req/sec',
      upstream: ['compute-c']
    },
    {
      id: 'hsm-signature-route',
      name: 'HSM Signature Service',
      uri: '/api/v1/hsm/sign',
      methods: ['POST'],
      rateLimit: '50 req/sec',
      upstream: ['hsm-node-1', 'hsm-node-2']
    },
    {
      id: 'ledger-query-route',
      name: 'Ledger Query API',
      uri: '/api/v1/ledger/*',
      methods: ['GET'],
      rateLimit: '200 req/sec',
      upstream: ['compute-b', 'compute-d']
    },
    {
      id: 'compliance-export-route',
      name: 'Compliance Evidence Export',
      uri: '/api/v1/compliance/export/*',
      methods: ['GET'],
      rateLimit: '5 req/sec',
      upstream: ['compute-f']
    }
  ];

  const getStatusBadge = (status: string) => {
    switch (status) {
      case 'active':
        return 'bg-green-100 text-green-700';
      case 'provisioning':
        return 'bg-blue-100 text-blue-700';
      case 'error':
        return 'bg-red-100 text-red-700';
      default:
        return 'bg-slate-100 text-slate-700';
    }
  };

  const getPurposeIcon = (purpose: string) => {
    switch (purpose) {
      case 'dmz':
        return <Shield className="w-4 h-4" />;
      case 'compute':
        return <Server className="w-4 h-4" />;
      case 'hsm':
        return <Lock className="w-4 h-4" />;
      case 'storage':
        return <Database className="w-4 h-4" />;
      case 'management':
        return <Settings className="w-4 h-4" />;
      default:
        return <Network className="w-4 h-4" />;
    }
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <motion.div
        initial={{ opacity: 0, y: -20 }}
        animate={{ opacity: 1, y: 0 }}
        className="bg-gradient-to-r from-blue-600 to-purple-600 rounded-lg p-6 text-white"
      >
        <div className="flex items-center gap-3 mb-4">
          <Network className="w-8 h-8" />
          <div>
            <h2 className="text-2xl font-bold">Network Infrastructure Manager</h2>
            <p className="text-blue-100 text-sm">
              VOM Services Corporation • 3xpres5 Datacenter • APISIX Gateway Configuration
            </p>
          </div>
        </div>

        <div className="bg-blue-700/30 rounded-lg p-4">
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4 text-sm">
            <div>
              <div className="text-blue-200 text-xs mb-1">Corporate Owner</div>
              <div className="font-semibold">VOM Services Corp</div>
            </div>
            <div>
              <div className="text-blue-200 text-xs mb-1">Principal</div>
              <div className="font-semibold">Matthew James Sauls</div>
            </div>
            <div>
              <div className="text-blue-200 text-xs mb-1">EIN</div>
              <div className="font-mono text-xs">83-1427324</div>
            </div>
            <div>
              <div className="text-blue-200 text-xs mb-1">FCC FRN</div>
              <div className="font-mono text-xs">0033213463</div>
            </div>
          </div>
        </div>
      </motion.div>

      {/* Network Overview */}
      <div className="grid grid-cols-3 gap-4">
        <Card className="p-4 bg-gradient-to-br from-blue-50 to-blue-100">
          <div className="flex items-center gap-3">
            <div className="bg-blue-600 p-3 rounded-lg">
              <Globe className="w-6 h-6 text-white" />
            </div>
            <div>
              <div className="text-sm text-slate-600">Total Networks</div>
              <div className="text-2xl font-bold text-blue-600">{networks.length}</div>
            </div>
          </div>
        </Card>

        <Card className="p-4 bg-gradient-to-br from-green-50 to-green-100">
          <div className="flex items-center gap-3">
            <div className="bg-green-600 p-3 rounded-lg">
              <Server className="w-6 h-6 text-white" />
            </div>
            <div>
              <div className="text-sm text-slate-600">Total Subnets</div>
              <div className="text-2xl font-bold text-green-600">
                {networks.reduce((sum, net) => sum + net.subnets.length, 0)}
              </div>
            </div>
          </div>
        </Card>

        <Card className="p-4 bg-gradient-to-br from-purple-50 to-purple-100">
          <div className="flex items-center gap-3">
            <div className="bg-purple-600 p-3 rounded-lg">
              <Zap className="w-6 h-6 text-white" />
            </div>
            <div>
              <div className="text-sm text-slate-600">APISIX Routes</div>
              <div className="text-2xl font-bold text-purple-600">{apisixRoutes.length}</div>
            </div>
          </div>
        </Card>
      </div>

      {/* Networks List */}
      <div className="space-y-4">
        {networks.map((network, index) => (
          <motion.div
            key={network.id}
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: index * 0.1 }}
          >
            <Card className="p-6">
              <div className="flex items-start justify-between mb-4">
                <div className="flex-1">
                  <div className="flex items-center gap-3 mb-2">
                    <Globe className="w-6 h-6 text-blue-600" />
                    <h3 className="text-lg font-semibold">{network.name}</h3>
                    <span className={`px-2 py-1 rounded-full text-xs font-semibold ${getStatusBadge(network.status)}`}>
                      {network.status.toUpperCase()}
                    </span>
                  </div>

                  <div className="grid grid-cols-2 md:grid-cols-4 gap-3 text-sm mb-4">
                    <div>
                      <div className="text-slate-500 text-xs">CIDR Block</div>
                      <div className="font-mono font-semibold">{network.cidr}</div>
                    </div>
                    <div>
                      <div className="text-slate-500 text-xs">VNet ID</div>
                      <div className="font-mono text-xs">{network.vnetId}</div>
                    </div>
                    <div>
                      <div className="text-slate-500 text-xs">Datacenter</div>
                      <div className="font-semibold text-xs">{network.datacenter}</div>
                    </div>
                    <div>
                      <div className="text-slate-500 text-xs">Environment</div>
                      <div className="font-semibold text-xs">{network.metadata.environment}</div>
                    </div>
                  </div>

                  <div className="bg-slate-50 p-3 rounded-lg mb-3">
                    <div className="text-xs text-slate-500 mb-1">Network Owner</div>
                    <div className="font-semibold text-sm">{network.metadata.owner}</div>
                  </div>

                  {/* Compliance Badges */}
                  <div className="flex flex-wrap gap-2 mb-4">
                    {network.metadata.compliance.map((comp, idx) => (
                      <span
                        key={idx}
                        className="px-2 py-1 bg-purple-100 text-purple-700 rounded text-xs font-semibold"
                      >
                        {comp}
                      </span>
                    ))}
                    {network.metadata.encryption && (
                      <span className="px-2 py-1 bg-green-100 text-green-700 rounded text-xs font-semibold flex items-center gap-1">
                        <Lock className="w-3 h-3" />
                        Encrypted
                      </span>
                    )}
                  </div>

                  {/* Subnets */}
                  <div className="mb-4">
                    <h4 className="font-semibold text-sm mb-3 flex items-center gap-2">
                      <Server className="w-4 h-4 text-blue-600" />
                      Subnets ({network.subnets.length})
                    </h4>
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                      {network.subnets.map((subnet) => (
                        <div
                          key={subnet.id}
                          className="bg-white border border-slate-200 rounded-lg p-3"
                        >
                          <div className="flex items-center gap-2 mb-2">
                            {getPurposeIcon(subnet.purpose)}
                            <div className="font-semibold text-sm">{subnet.name}</div>
                          </div>
                          <div className="grid grid-cols-2 gap-2 text-xs">
                            <div>
                              <div className="text-slate-500">CIDR</div>
                              <div className="font-mono font-semibold">{subnet.cidr}</div>
                            </div>
                            <div>
                              <div className="text-slate-500">Zone</div>
                              <div className="font-semibold">{subnet.zone}</div>
                            </div>
                            <div>
                              <div className="text-slate-500">Purpose</div>
                              <div className="font-semibold capitalize">{subnet.purpose}</div>
                            </div>
                            <div>
                              <div className="text-slate-500">Nodes</div>
                              <div className="font-semibold">{subnet.nodeCount}</div>
                            </div>
                          </div>
                        </div>
                      ))}
                    </div>
                  </div>

                  {/* Routes */}
                  {network.routes.length > 0 && (
                    <div>
                      <Button
                        variant="outline"
                        size="sm"
                        onClick={() => {
                          if (selectedNetwork === network.id) {
                            setSelectedNetwork(null);
                          } else {
                            setSelectedNetwork(network.id);
                          }
                        }}
                        className="mb-3"
                      >
                        <Eye className="w-4 h-4 mr-2" />
                        {selectedNetwork === network.id ? 'Hide' : 'Show'} Network Routes ({network.routes.length})
                      </Button>

                      {selectedNetwork === network.id && (
                        <motion.div
                          initial={{ opacity: 0, height: 0 }}
                          animate={{ opacity: 1, height: 'auto' }}
                          className="space-y-2"
                        >
                          {network.routes.map((route) => (
                            <div
                              key={route.id}
                              className="bg-slate-50 border border-slate-200 rounded-lg p-3"
                            >
                              <div className="flex items-center justify-between">
                                <div className="flex-1">
                                  <div className="font-semibold text-sm mb-1">{route.destination}</div>
                                  <div className="grid grid-cols-3 gap-2 text-xs">
                                    <div>
                                      <div className="text-slate-500">Gateway</div>
                                      <div className="font-mono">{route.gateway}</div>
                                    </div>
                                    <div>
                                      <div className="text-slate-500">Source</div>
                                      <div className="font-mono">{route.source}</div>
                                    </div>
                                    <div>
                                      <div className="text-slate-500">Priority</div>
                                      <div className="font-semibold">{route.priority}</div>
                                    </div>
                                  </div>
                                </div>
                              </div>
                            </div>
                          ))}
                        </motion.div>
                      )}
                    </div>
                  )}
                </div>

                <div className="flex gap-2 ml-4">
                  <Button variant="outline" size="sm">
                    <Settings className="w-4 h-4" />
                  </Button>
                  <Button variant="outline" size="sm">
                    <RefreshCw className="w-4 h-4" />
                  </Button>
                </div>
              </div>
            </Card>
          </motion.div>
        ))}
      </div>

      {/* APISIX Routes */}
      <Card className="p-6">
        <h3 className="text-lg font-semibold mb-4 flex items-center gap-2">
          <Zap className="w-5 h-5 text-purple-600" />
          APISIX Banking Routes
        </h3>

        <div className="space-y-3">
          {apisixRoutes.map((route, index) => (
            <motion.div
              key={route.id}
              initial={{ opacity: 0, x: -20 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ delay: index * 0.1 }}
              className="bg-white border border-slate-200 rounded-lg p-4"
            >
              <div className="flex items-start justify-between">
                <div className="flex-1">
                  <div className="font-semibold mb-2">{route.name}</div>
                  <div className="grid grid-cols-2 md:grid-cols-4 gap-3 text-xs">
                    <div>
                      <div className="text-slate-500">URI Pattern</div>
                      <div className="font-mono font-semibold">{route.uri}</div>
                    </div>
                    <div>
                      <div className="text-slate-500">Methods</div>
                      <div className="font-semibold">{route.methods.join(', ')}</div>
                    </div>
                    <div>
                      <div className="text-slate-500">Rate Limit</div>
                      <div className="font-semibold text-orange-600">{route.rateLimit}</div>
                    </div>
                    <div>
                      <div className="text-slate-500">Upstreams</div>
                      <div className="font-semibold">{route.upstream.length} nodes</div>
                    </div>
                  </div>
                  <div className="mt-2 flex flex-wrap gap-1">
                    {route.upstream.map((node, idx) => (
                      <span
                        key={idx}
                        className="px-2 py-1 bg-blue-50 text-blue-700 rounded text-xs font-mono"
                      >
                        {node}
                      </span>
                    ))}
                  </div>
                </div>
              </div>
            </motion.div>
          ))}
        </div>
      </Card>

      {/* Status Summary */}
      <Card className="p-4 bg-green-50 border-green-200">
        <div className="flex items-center gap-3">
          <CheckCircle2 className="w-6 h-6 text-green-600" />
          <div>
            <div className="font-semibold text-green-900">All Networks Operational</div>
            <div className="text-sm text-green-700">
              {networks.length} networks • {networks.reduce((sum, n) => sum + n.subnets.length, 0)} subnets • 
              {' '}{apisixRoutes.length} APISIX routes active
            </div>
          </div>
        </div>
      </Card>
    </div>
  );
}