import React, { useState, useEffect } from 'react';
import { motion } from 'motion/react';
import { Tabs, TabsContent, TabsList, TabsTrigger } from './components/ui/tabs';
import { ArchitectureNode } from './components/ArchitectureNode';
import { ConnectionArrow } from './components/ConnectionArrow';
import { EncryptionCodeViewer } from './components/EncryptionCodeViewer';
import { LedgerTransactionViewer } from './components/LedgerTransactionViewer';
import { DeploymentArchitectureDiagram } from './infrastructure/deployment-architecture-diagram';
import { AssetManagementControlModule } from './components/AssetManagementControlModule';
import { GenesisClearing } from './components/GenesisClearing';
import { PayrollTransactionProcessor } from './components/PayrollTransactionProcessor';
import { MortgageEscrowTitlePartnership } from './components/MortgageEscrowTitlePartnership';
import { RegulatoryPackageGenerator } from './components/RegulatoryPackageGenerator';
import { LiveBankingPlatform } from './components/LiveBankingPlatform';
import { FundsTransferBuilder } from './components/funds-transfer-builder';
import { FirewallSecurityDashboard } from './components/firewall-security-dashboard';
import { SuttonBankGeneralLedger } from './components/SuttonBankGeneralLedger';
import { AthenaLifetimeAnalytics } from './components/AthenaLifetimeAnalytics';
import { DataPersistenceManager } from './utils/data-persistence';
import { SecurityStatusBanner } from './components/security-status-banner';
import { ErrorBoundary } from './components/ErrorBoundary';

export default function App() {
  const [selectedNode, setSelectedNode] = useState<string | null>(null);
  const [showCode, setShowCode] = useState(false);
  const [showLedger, setShowLedger] = useState(false);

  // Initialize data persistence and auto-save
  useEffect(() => {
    try {
      DataPersistenceManager.initialize();
      console.log('🚀 Sigma Banking Platform initialized');
      console.log('💾 All data is auto-saved every 30 seconds');
      console.log('🔐 Encryption: ACTIVE (NIST SP 800-57)');
      console.log('🛡️ Firewall: ACTIVE (Blocking unrelenting communication)');
      console.log('⚡ Athena Analytics: LIVE (3xpres5 Express Infrastructure)');
    } catch (error) {
      console.error('Failed to initialize platform:', error);
    }
  }, []);

  // Architecture nodes configuration - updated for production
  const nodes = [
    {
      id: 'client',
      title: 'Client / Operator / System',
      subtitle: '(UI / CLI / Service)',
      details: 'Entry point for all system interactions',
      color: 'bg-slate-100'
    },
    {
      id: 'gateway',
      title: 'API Gateway (Node.js)',
      subtitle: null,
      details: 'TLS termination • mTLS identity • OAuth2 token validation',
      color: 'bg-blue-50'
    },
    {
      id: 'wallet',
      title: 'Wallet Service',
      subtitle: null,
      details: 'create wallet • holds / releases • balance checks',
      color: 'bg-emerald-50'
    },
    {
      id: 'ledger',
      title: 'Ledger Service',
      subtitle: null,
      details: 'double-entry • immutable log • ACID transactions',
      color: 'bg-amber-50'
    },
    {
      id: 'cryptopool',
      title: 'Genesis Pool (Crypto)',
      subtitle: null,
      details: 'ETH, WBTC, BTC, USDC balances',
      color: 'bg-purple-50'
    },
    {
      id: 'db',
      title: 'Database (PostgreSQL)',
      subtitle: null,
      details: 'wallet metadata • transaction journal • audit trail',
      color: 'bg-indigo-50'
    },
    {
      id: 'umb',
      title: 'UMB NA Banking Partner',
      subtitle: 'Federal Wire / ACH Settlement',
      details: 'Real-time settlement • Fedwire network • ACH processing',
      color: 'bg-green-50'
    }
  ];

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 via-blue-50 to-indigo-50 p-8">
      <div className="max-w-[1800px] mx-auto">
        {/* Header */}
        <motion.div
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          className="mb-8"
        >
          <div className="bg-white/80 backdrop-blur-sm border border-gray-200 rounded-2xl p-6 shadow-xl">
            <div className="flex items-center justify-between">
              <div>
                <h1 className="text-4xl font-bold bg-gradient-to-r from-blue-600 via-indigo-600 to-purple-600 bg-clip-text text-transparent">
                  Sigma Production Banking Platform
                </h1>
                <p className="mt-2 text-gray-600">
                  Comprehensive Financial Infrastructure • UMB NA Banking Partner • VOM Services Corporation (EIN 83-1427324)
                </p>
                <p className="mt-1 text-sm text-gray-500">
                  Regulation E Compliant • NIST SP 800-57 Cryptography • Tier-1 Security • Genesis Pool Integration • Athena Express Analytics
                </p>
              </div>
              <div className="text-right">
                <div className="inline-block bg-green-100 border border-green-300 rounded-lg px-4 py-2">
                  <div className="text-xs font-semibold text-green-800 uppercase tracking-wider">Production</div>
                  <div className="text-lg font-bold text-green-900">LIVE</div>
                </div>
              </div>
            </div>
          </div>
        </motion.div>

        {/* Main Content Tabs */}
        <Tabs defaultValue="architecture" className="w-full">
          <TabsList className="flex w-full flex-wrap gap-1 mb-6 bg-white/80 backdrop-blur-sm border border-gray-200 rounded-xl p-2">
            <TabsTrigger value="firewall" className="flex-1 min-w-[100px]">🔒 Firewall</TabsTrigger>
            <TabsTrigger value="architecture" className="flex-1 min-w-[100px]">Architecture</TabsTrigger>
            <TabsTrigger value="deployment" className="flex-1 min-w-[100px]">AWS Deploy</TabsTrigger>
            <TabsTrigger value="asset-mgmt" className="flex-1 min-w-[100px]">Asset Mgmt</TabsTrigger>
            <TabsTrigger value="genesis" className="flex-1 min-w-[100px]">Genesis</TabsTrigger>
            <TabsTrigger value="ledger" className="flex-1 min-w-[100px]">Ledger</TabsTrigger>
            <TabsTrigger value="payroll" className="flex-1 min-w-[100px]">Payroll</TabsTrigger>
            <TabsTrigger value="partnership" className="flex-1 min-w-[100px]">Partnership</TabsTrigger>
            <TabsTrigger value="regulatory" className="flex-1 min-w-[100px]">Regulatory</TabsTrigger>
            <TabsTrigger value="live-banking" className="flex-1 min-w-[100px]">Live Banking</TabsTrigger>
            <TabsTrigger value="funds" className="flex-1 min-w-[100px]">Funds TX</TabsTrigger>
            <TabsTrigger value="sutton-bank" className="flex-1 min-w-[100px]">🏛️ Sutton Bank</TabsTrigger>
            <TabsTrigger value="athena-analytics" className="flex-1 min-w-[100px]">⚡ Athena Express</TabsTrigger>
          </TabsList>

          {/* Tab 1: Firewall Security Dashboard (NEW - DEFAULT) */}
          <TabsContent value="firewall" className="mt-0">
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              className="bg-white/90 backdrop-blur-sm border border-gray-200 rounded-2xl p-8 shadow-xl"
            >
              <ErrorBoundary>
                <FirewallSecurityDashboard />
              </ErrorBoundary>
            </motion.div>
          </TabsContent>

          {/* Tab 2: Architecture Diagram */}
          <TabsContent value="architecture" className="mt-0">
            <ErrorBoundary>
              <motion.div
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                className="bg-white/90 backdrop-blur-sm border border-gray-200 rounded-2xl p-8 shadow-xl"
              >
                <h2 className="text-2xl font-bold text-gray-900 mb-6">Payment System Architecture</h2>
                
                {/* Architecture visualization */}
                <div className="relative min-h-[600px]">
                  <svg className="absolute inset-0 w-full h-full pointer-events-none" style={{ zIndex: 0 }}>
                    <ConnectionArrow from="client" to="gateway" />
                    <ConnectionArrow from="gateway" to="wallet" />
                    <ConnectionArrow from="wallet" to="ledger" />
                    <ConnectionArrow from="wallet" to="cryptopool" />
                    <ConnectionArrow from="ledger" to="db" />
                    <ConnectionArrow from="wallet" to="umb" />
                  </svg>

                  {/* Nodes */}
                  <div className="relative z-10 grid gap-12">
                    <div className="grid grid-cols-1 gap-8">
                      <ArchitectureNode
                        {...nodes[0]}
                        isSelected={selectedNode === nodes[0].id}
                        onClick={() => setSelectedNode(nodes[0].id)}
                      />
                    </div>

                    <div className="grid grid-cols-1 gap-8">
                      <ArchitectureNode
                        {...nodes[1]}
                        isSelected={selectedNode === nodes[1].id}
                        onClick={() => setSelectedNode(nodes[1].id)}
                      />
                    </div>

                    <div className="grid grid-cols-3 gap-8">
                      <ArchitectureNode
                        {...nodes[2]}
                        isSelected={selectedNode === nodes[2].id}
                        onClick={() => setSelectedNode(nodes[2].id)}
                      />
                      <ArchitectureNode
                        {...nodes[3]}
                        isSelected={selectedNode === nodes[3].id}
                        onClick={() => setSelectedNode(nodes[3].id)}
                      />
                      <ArchitectureNode
                        {...nodes[4]}
                        isSelected={selectedNode === nodes[4].id}
                        onClick={() => setSelectedNode(nodes[4].id)}
                      />
                    </div>

                    <div className="grid grid-cols-2 gap-8">
                      <ArchitectureNode
                        {...nodes[5]}
                        isSelected={selectedNode === nodes[5].id}
                        onClick={() => setSelectedNode(nodes[5].id)}
                      />
                      <ArchitectureNode
                        {...nodes[6]}
                        isSelected={selectedNode === nodes[6].id}
                        onClick={() => setSelectedNode(nodes[6].id)}
                      />
                    </div>
                  </div>
                </div>

                {/* Action buttons */}
                <div className="mt-8 flex gap-4">
                  <button
                    onClick={() => setShowCode(!showCode)}
                    className="px-6 py-3 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors font-medium"
                  >
                    {showCode ? 'Hide' : 'View'} Encryption Code
                  </button>
                  <button
                    onClick={() => setShowLedger(!showLedger)}
                    className="px-6 py-3 bg-green-600 text-white rounded-lg hover:bg-green-700 transition-colors font-medium"
                  >
                    {showLedger ? 'Hide' : 'View'} Ledger
                  </button>
                </div>

                {/* Code viewer */}
                {showCode && (
                  <motion.div
                    initial={{ opacity: 0, height: 0 }}
                    animate={{ opacity: 1, height: 'auto' }}
                    exit={{ opacity: 0, height: 0 }}
                    className="mt-6"
                  >
                    <EncryptionCodeViewer />
                  </motion.div>
                )}

                {/* Ledger viewer */}
                {showLedger && (
                  <motion.div
                    initial={{ opacity: 0, height: 0 }}
                    animate={{ opacity: 1, height: 'auto' }}
                    exit={{ opacity: 0, height: 0 }}
                    className="mt-6"
                  >
                    <LedgerTransactionViewer />
                  </motion.div>
                )}
              </motion.div>
            </ErrorBoundary>
          </TabsContent>

          {/* Tab 2: AWS Deployment Architecture */}
          <TabsContent value="deployment" className="mt-0">
            <ErrorBoundary>
              <DeploymentArchitectureDiagram />
            </ErrorBoundary>
          </TabsContent>

          {/* Tab 3: Asset Management */}
          <TabsContent value="asset-mgmt" className="mt-0">
            <ErrorBoundary>
              <AssetManagementControlModule />
            </ErrorBoundary>
          </TabsContent>

          {/* Tab 4: Genesis Clearing */}
          <TabsContent value="genesis" className="mt-0">
            <ErrorBoundary>
              <GenesisClearing />
            </ErrorBoundary>
          </TabsContent>

          {/* Tab 5: Ledger */}
          <TabsContent value="ledger" className="mt-0">
            <ErrorBoundary>
              <LedgerTransactionViewer />
            </ErrorBoundary>
          </TabsContent>

          {/* Tab 6: Payroll */}
          <TabsContent value="payroll" className="mt-0">
            <ErrorBoundary>
              <PayrollTransactionProcessor />
            </ErrorBoundary>
          </TabsContent>

          {/* Tab 7: Partnership */}
          <TabsContent value="partnership" className="mt-0">
            <ErrorBoundary>
              <MortgageEscrowTitlePartnership />
            </ErrorBoundary>
          </TabsContent>

          {/* Tab 8: Regulatory */}
          <TabsContent value="regulatory" className="mt-0">
            <ErrorBoundary>
              <RegulatoryPackageGenerator />
            </ErrorBoundary>
          </TabsContent>

          {/* Tab 9: Live Banking */}
          <TabsContent value="live-banking" className="mt-0">
            <ErrorBoundary>
              <LiveBankingPlatform />
            </ErrorBoundary>
          </TabsContent>

          {/* Tab 10: Funds Transfer (NEW) */}
          <TabsContent value="funds" className="mt-0">
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              className="bg-white/90 backdrop-blur-sm border border-gray-200 rounded-2xl p-8 shadow-xl"
            >
              <ErrorBoundary>
                <FundsTransferBuilder />
              </ErrorBoundary>
            </motion.div>
          </TabsContent>

          {/* Tab 11: Sutton Bank General Ledger (NEW) */}
          <TabsContent value="sutton-bank" className="mt-0">
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              className="bg-white/90 backdrop-blur-sm border border-gray-200 rounded-2xl p-8 shadow-xl"
            >
              <ErrorBoundary>
                <SuttonBankGeneralLedger />
              </ErrorBoundary>
            </motion.div>
          </TabsContent>

          {/* Tab 13: Athena Lifetime Analytics - 3xpres5 Express (NEW) */}
          <TabsContent value="athena-analytics" className="mt-0">
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              className="bg-white/90 backdrop-blur-sm border border-gray-200 rounded-2xl p-8 shadow-xl"
            >
              <ErrorBoundary>
                <AthenaLifetimeAnalytics />
              </ErrorBoundary>
            </motion.div>
          </TabsContent>
        </Tabs>

        {/* Footer */}
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 0.5 }}
          className="mt-8 text-center text-sm text-gray-500"
        >
          <p>
            © 2026 VOM Services Corporation • EIN 83-1427324 • Banking Partner: UMB NA
          </p>
          <p className="mt-1">
            NIST SP 800-57 Compliant • Regulation E • FDIC Insured (where applicable) • Tier-1 Security Model • Athena Express Analytics (3xpres5)
          </p>
        </motion.div>
      </div>

      {/* Security Status Banner */}
      {/* Temporarily disabled for debugging
      <ErrorBoundary fallback={null}>
        <SecurityStatusBanner />
      </ErrorBoundary>
      */}
    </div>
  );
}