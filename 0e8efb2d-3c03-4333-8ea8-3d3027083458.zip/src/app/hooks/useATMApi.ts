import { useState, useEffect } from 'react';

// Local mock data - no Supabase required
interface ATMDevice {
  id: string;
  location: string;
  branch: string;
  status: 'online' | 'offline' | 'revoked';
  certificate: string;
  lastSeen: string;
  nonceRange: string;
  transactions24h: number;
}

interface Transaction {
  id: string;
  atmId: string;
  amount: number;
  timestamp: string;
  hash: string;
  nonce: string;
  signature: string;
  deviceFingerprint: string;
  status: 'completed' | 'pending_validation' | 'offline_sealed';
}

export function useATMApi() {
  const [devices, setDevices] = useState<ATMDevice[]>([]);
  const [transactions, setTransactions] = useState<Transaction[]>([]);
  const [offlineTransactions, setOfflineTransactions] = useState<Transaction[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  // Initialize with mock data
  const initializeDefaultDevices = () => {
    const defaultDevices: ATMDevice[] = [
      {
        id: 'ATM-UMB-001',
        location: '1234 Main St, Kansas City, MO',
        branch: 'Downtown Branch',
        status: 'online',
        certificate: 'cert-e7f8a9b0c1d2',
        lastSeen: new Date().toISOString(),
        nonceRange: '100000-199999',
        transactions24h: 847
      },
      {
        id: 'ATM-UMB-002',
        location: '5678 Oak Ave, Kansas City, MO',
        branch: 'Westport Branch',
        status: 'online',
        certificate: 'cert-d3e4f5g6h7i8',
        lastSeen: new Date().toISOString(),
        nonceRange: '200000-299999',
        transactions24h: 612
      },
      {
        id: 'ATM-UMB-003',
        location: '9012 Elm St, Overland Park, KS',
        branch: 'Plaza Branch',
        status: 'offline',
        certificate: 'cert-j9k0l1m2n3o4',
        lastSeen: new Date(Date.now() - 3600000).toISOString(),
        nonceRange: '300000-399999',
        transactions24h: 423
      }
    ];
    
    setDevices(defaultDevices);
  };

  // Create or update ATM device
  const createDevice = async (device: ATMDevice) => {
    setDevices(prev => {
      const exists = prev.find(d => d.id === device.id);
      if (exists) {
        return prev.map(d => d.id === device.id ? device : d);
      }
      return [...prev, device];
    });
  };

  // Update ATM device
  const updateDevice = async (id: string, updates: Partial<ATMDevice>) => {
    setDevices(prev => prev.map(d => d.id === id ? { ...d, ...updates } : d));
  };

  // Revoke ATM certificate
  const revokeATM = async (atmId: string, scope: 'single' | 'branch' | 'fleet') => {
    if (scope === 'single') {
      setDevices(prev => prev.map(d => d.id === atmId ? { ...d, status: 'revoked' as const } : d));
    } else if (scope === 'branch') {
      const device = devices.find(d => d.id === atmId);
      if (device) {
        setDevices(prev => prev.map(d => d.branch === device.branch ? { ...d, status: 'revoked' as const } : d));
      }
    } else if (scope === 'fleet') {
      setDevices(prev => prev.map(d => ({ ...d, status: 'revoked' as const })));
    }
  };

  // Restore ATM
  const restoreATM = async (atmId: string) => {
    setDevices(prev => prev.map(d => d.id === atmId ? { ...d, status: 'online' as const } : d));
  };

  // Save transaction receipt
  const saveTransaction = async (transaction: Transaction) => {
    setTransactions(prev => [...prev, transaction]);
  };

  // Save offline transaction
  const saveOfflineTransaction = async (transaction: Transaction) => {
    setOfflineTransactions(prev => [...prev, transaction]);
  };

  // Validate offline transactions
  const validateOfflineTransactions = async (transactionIds: string[]) => {
    const validated = offlineTransactions.filter(t => transactionIds.includes(t.id));
    setOfflineTransactions(prev => prev.filter(t => !transactionIds.includes(t.id)));
    setTransactions(prev => [...prev, ...validated.map(t => ({ ...t, status: 'completed' as const }))]);
  };

  // Initialize data
  useEffect(() => {
    const init = async () => {
      setLoading(true);
      initializeDefaultDevices();
      setLoading(false);
    };
    init();
  }, []);

  return {
    devices,
    transactions,
    offlineTransactions,
    loading,
    error,
    createDevice,
    updateDevice,
    revokeATM,
    restoreATM,
    saveTransaction,
    saveOfflineTransaction,
    validateOfflineTransactions,
    refetch: async () => {
      // Local state - nothing to refetch
    },
  };
}