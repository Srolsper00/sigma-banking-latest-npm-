#!/bin/bash
#
# APISIX Route Deployment Script
# 3xpres5 Clearing Platform - Sigma Banking
#
# Usage: ./deploy-apisix-routes.sh [environment]
# Example: ./deploy-apisix-routes.sh production
#

set -euo pipefail

# Configuration
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
PROJECT_ROOT="$(dirname "$SCRIPT_DIR")"
APISIX_ROUTES_FILE="${PROJECT_ROOT}/apisix-banking-routes.json"

# Environment-specific configuration
ENVIRONMENT="${1:-production}"

case "$ENVIRONMENT" in
  production)
    APISIX_ADMIN_URL="http://127.0.0.1:9180"
    APISIX_ADMIN_KEY="${APISIX_ADMIN_KEY_PROD}"
    ;;
  staging)
    APISIX_ADMIN_URL="http://127.0.0.1:9180"
    APISIX_ADMIN_KEY="${APISIX_ADMIN_KEY_STAGING}"
    ;;
  development)
    APISIX_ADMIN_URL="http://127.0.0.1:9180"
    APISIX_ADMIN_KEY="${APISIX_ADMIN_KEY_DEV}"
    ;;
  *)
    echo "❌ Error: Unknown environment '$ENVIRONMENT'"
    echo "Usage: $0 [production|staging|development]"
    exit 1
    ;;
esac

# Colors for output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m' # No Color

# Helper functions
log_info() {
  echo -e "${BLUE}ℹ${NC} $1"
}

log_success() {
  echo -e "${GREEN}✅${NC} $1"
}

log_warning() {
  echo -e "${YELLOW}⚠${NC} $1"
}

log_error() {
  echo -e "${RED}❌${NC} $1"
}

# Validate prerequisites
validate_prerequisites() {
  log_info "Validating prerequisites..."
  
  # Check if jq is installed
  if ! command -v jq &> /dev/null; then
    log_error "jq is not installed. Please install it first."
    exit 1
  fi
  
  # Check if curl is installed
  if ! command -v curl &> /dev/null; then
    log_error "curl is not installed. Please install it first."
    exit 1
  fi
  
  # Check if APISIX admin key is set
  if [ -z "${APISIX_ADMIN_KEY:-}" ]; then
    log_error "APISIX_ADMIN_KEY is not set for environment: $ENVIRONMENT"
    exit 1
  fi
  
  # Check if routes file exists
  if [ ! -f "$APISIX_ROUTES_FILE" ]; then
    log_error "Routes file not found: $APISIX_ROUTES_FILE"
    exit 1
  fi
  
  log_success "Prerequisites validated"
}

# Test APISIX connectivity
test_apisix_connection() {
  log_info "Testing APISIX Admin API connectivity..."
  
  local response
  response=$(curl -s -w "%{http_code}" \
    -H "X-API-KEY: ${APISIX_ADMIN_KEY}" \
    "${APISIX_ADMIN_URL}/apisix/admin/routes" \
    -o /dev/null)
  
  if [ "$response" != "200" ]; then
    log_error "Failed to connect to APISIX Admin API (HTTP $response)"
    log_error "URL: ${APISIX_ADMIN_URL}"
    exit 1
  fi
  
  log_success "APISIX Admin API is accessible"
}

# Deploy a single route
deploy_route() {
  local route_id="$1"
  local route_name="$2"
  local route_config="$3"
  
  log_info "Deploying route: $route_name (ID: $route_id)"
  
  local response
  response=$(curl -s -w "\n%{http_code}" \
    -X PUT \
    -H "X-API-KEY: ${APISIX_ADMIN_KEY}" \
    -H "Content-Type: application/json" \
    "${APISIX_ADMIN_URL}/apisix/admin/routes/${route_id}" \
    -d "$route_config")
  
  local http_code
  http_code=$(echo "$response" | tail -n1)
  local body
  body=$(echo "$response" | sed '$d')
  
  if [ "$http_code" = "200" ] || [ "$http_code" = "201" ]; then
    log_success "Route deployed: $route_name"
    return 0
  else
    log_error "Failed to deploy route: $route_name (HTTP $http_code)"
    echo "$body" | jq '.' 2>/dev/null || echo "$body"
    return 1
  fi
}

# Deploy all routes
deploy_all_routes() {
  log_info "Deploying all routes from: $APISIX_ROUTES_FILE"
  
  local routes
  routes=$(jq -c '.routes[]' "$APISIX_ROUTES_FILE")
  
  local total_routes
  total_routes=$(echo "$routes" | wc -l)
  
  local deployed=0
  local failed=0
  
  while IFS= read -r route; do
    local route_id
    route_id=$(echo "$route" | jq -r '.id')
    
    local route_name
    route_name=$(echo "$route" | jq -r '.name')
    
    # Remove id and name from config (APISIX sets these separately)
    local route_config
    route_config=$(echo "$route" | jq 'del(.id, .name)')
    
    if deploy_route "$route_id" "$route_name" "$route_config"; then
      ((deployed++))
    else
      ((failed++))
    fi
  done <<< "$routes"
  
  echo ""
  log_info "Deployment summary:"
  echo "  Total routes: $total_routes"
  echo "  Deployed: $deployed"
  echo "  Failed: $failed"
  
  if [ $failed -gt 0 ]; then
    log_error "Some routes failed to deploy"
    return 1
  else
    log_success "All routes deployed successfully"
    return 0
  fi
}

# List deployed routes
list_routes() {
  log_info "Fetching deployed routes..."
  
  local response
  response=$(curl -s \
    -H "X-API-KEY: ${APISIX_ADMIN_KEY}" \
    "${APISIX_ADMIN_URL}/apisix/admin/routes")
  
  echo "$response" | jq -r '.list[] | "\(.value.id)\t\(.value.name // "N/A")\t\(.value.uri)"' | \
    column -t -s $'\t' -N "ID,Name,URI"
}

# Verify route health
verify_routes() {
  log_info "Verifying route health..."
  
  local routes
  routes=$(jq -c '.routes[]' "$APISIX_ROUTES_FILE")
  
  local healthy=0
  local unhealthy=0
  
  while IFS= read -r route; do
    local route_id
    route_id=$(echo "$route" | jq -r '.id')
    
    local route_name
    route_name=$(echo "$route" | jq -r '.name')
    
    local response
    response=$(curl -s -w "%{http_code}" \
      -H "X-API-KEY: ${APISIX_ADMIN_KEY}" \
      "${APISIX_ADMIN_URL}/apisix/admin/routes/${route_id}" \
      -o /dev/null)
    
    if [ "$response" = "200" ]; then
      log_success "Route healthy: $route_name"
      ((healthy++))
    else
      log_error "Route unhealthy: $route_name (HTTP $response)"
      ((unhealthy++))
    fi
  done <<< "$routes"
  
  echo ""
  log_info "Health check summary:"
  echo "  Healthy: $healthy"
  echo "  Unhealthy: $unhealthy"
  
  if [ $unhealthy -gt 0 ]; then
    return 1
  else
    return 0
  fi
}

# Backup existing routes
backup_routes() {
  local backup_file="${PROJECT_ROOT}/backups/apisix-routes-backup-$(date +%Y%m%d-%H%M%S).json"
  
  log_info "Backing up existing routes to: $backup_file"
  
  mkdir -p "$(dirname "$backup_file")"
  
  curl -s \
    -H "X-API-KEY: ${APISIX_ADMIN_KEY}" \
    "${APISIX_ADMIN_URL}/apisix/admin/routes" \
    > "$backup_file"
  
  log_success "Backup created: $backup_file"
}

# Main deployment flow
main() {
  echo ""
  echo "╔════════════════════════════════════════════════════════╗"
  echo "║                                                        ║"
  echo "║   APISIX Route Deployment - 3xpres5 Clearing Platform ║"
  echo "║                                                        ║"
  echo "╚════════════════════════════════════════════════════════╝"
  echo ""
  
  log_info "Environment: $ENVIRONMENT"
  log_info "APISIX URL: $APISIX_ADMIN_URL"
  echo ""
  
  # Step 1: Validate prerequisites
  validate_prerequisites
  
  # Step 2: Test APISIX connection
  test_apisix_connection
  
  # Step 3: Backup existing routes
  backup_routes
  
  # Step 4: Deploy all routes
  if deploy_all_routes; then
    # Step 5: Verify route health
    verify_routes
    
    # Step 6: List deployed routes
    echo ""
    list_routes
    
    echo ""
    log_success "✨ Deployment completed successfully!"
    exit 0
  else
    log_error "Deployment failed"
    exit 1
  fi
}

# Run main function
main
