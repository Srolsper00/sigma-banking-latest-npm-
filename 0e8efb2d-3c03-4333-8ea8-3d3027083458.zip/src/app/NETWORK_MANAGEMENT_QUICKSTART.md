# Network Management System - Quick Start Guide

**Get your Network Infrastructure Manager running in 5 minutes!**

---

## 🎯 What You're Building

A comprehensive network management system with:
- ✅ **Mock Management UI** - Works in browser, no backend needed
- ✅ **WebSocket Server (mmd02)** - Real-time event streaming
- ✅ **REST API** - HTTP endpoints for network operations
- ✅ **CLI Tool** - Terminal-based network management

---

## 🚀 Option 1: Mock Mode (Fastest - 2 Minutes)

Perfect for development and testing. No backend required!

### Step 1: Update Your Dashboard

Add the enhanced network manager to your dashboard:

```tsx
// In your App.tsx or Dashboard component
import { NetworkInfrastructureManagerEnhanced } from './components/NetworkInfrastructureManagerEnhanced';

// Add to your tabs or page
<NetworkInfrastructureManagerEnhanced />
```

### Step 2: Done!

That's it! The component includes:
- ✅ Create/delete networks
- ✅ Add/remove subnets
- ✅ Event stream visualization
- ✅ Mock driver (all in-browser)

---

## 🔌 Option 2: Full Stack with WebSocket (10 Minutes)

Get real-time WebSocket events and persistent storage.

### Step 1: Start the mmd02 Server

```bash
# Navigate to mmd02 directory
cd mmd02

# Install dependencies
npm install

# Start development server
npm run dev
```

You should see:
```
🚀 mmd02 Network Management Server
📡 HTTP API: http://localhost:8081
🔌 WebSocket: ws://localhost:8081/ws
💚 Health Check: http://localhost:8081/health
```

### Step 2: Configure Your React App

Create `.env.local` in your project root:

```bash
NEXT_PUBLIC_MMD02_API_URL=http://localhost:8081
NEXT_PUBLIC_MMD02_WS_URL=ws://localhost:8081/ws
```

### Step 3: Use API-Integrated Component

```tsx
import { NetworkInfrastructureManagerEnhanced } from './components/NetworkInfrastructureManagerEnhanced';
import { networkApi } from './utils/networkApi';
import { useEffect } from 'react';

function Dashboard() {
  useEffect(() => {
    // Connect to WebSocket
    networkApi.connectWebSocket();

    return () => {
      networkApi.disconnectWebSocket();
    };
  }, []);

  return <NetworkInfrastructureManagerEnhanced />;
}
```

### Step 4: Test It

1. Open your banking platform in browser
2. Navigate to Network Infrastructure Manager
3. Look for "WS Connected (mmd02)" badge in header
4. Create a network - you'll see real-time events!

---

## 🛠️ Option 3: CLI Tool (5 Minutes)

Manage networks from the terminal.

### Step 1: Setup CLI

```bash
# Create CLI directory
mkdir rnet-cli
cd rnet-cli

# Install dependencies
npm init -y
npm install yargs eventemitter3 chalk
```

### Step 2: Run Commands

```bash
# Set mock driver
export RNET_DRIVER=mock

# Create network
node index.ts create production-net --cidr 10.0.0.0/16

# List networks
node index.ts list

# Add subnet
node index.ts subnet add net-123 dmz-zone 10.0.1.0/24
```

---

## 📊 Testing Your Setup

### Test HTTP API

```bash
# Health check
curl http://localhost:8081/health

# Create network
curl -X POST http://localhost:8081/api/network/create \
  -H "Content-Type: application/json" \
  -d '{"name":"Test Network","cidr":"10.0.0.0/16"}'

# Get events
curl http://localhost:8081/api/events
```

### Test WebSocket

```bash
# Install wscat
npm install -g wscat

# Connect to WebSocket
wscat -c ws://localhost:8081/ws

# You should see connection confirmation
```

### Test UI

1. Go to your banking platform
2. Navigate to "Network Infrastructure Manager"
3. Click "Create Network"
4. Fill in:
   - **Name**: Test Network
   - **CIDR**: 10.0.0.0/16
   - **Environment**: Development
5. Click "Create Network"
6. Watch the event stream for `network.created` event!

---

## 🎨 Integration with Your Banking Platform

### Current Dashboard Integration

Your platform already has multiple tabs. Add the network manager:

```tsx
// In your main Dashboard or App component
import { NetworkInfrastructureManagerEnhanced } from './components/NetworkInfrastructureManagerEnhanced';

const tabs = [
  // ... existing tabs ...
  {
    id: 'network',
    label: 'Network Infrastructure',
    icon: Network,
    component: NetworkInfrastructureManagerEnhanced
  }
];
```

### Example Tab Structure

```tsx
<Tabs value={activeTab} onValueChange={setActiveTab}>
  <TabsList>
    <TabsTrigger value="genesis">Genesis Clearing</TabsTrigger>
    <TabsTrigger value="ledger">General Ledger</TabsTrigger>
    <TabsTrigger value="network">Network Infrastructure</TabsTrigger>
    {/* ... more tabs ... */}
  </TabsList>

  <TabsContent value="network">
    <NetworkInfrastructureManagerEnhanced />
  </TabsContent>
</Tabs>
```

---

## 🐛 Troubleshooting

### "WS Disconnected" Badge

**Problem**: WebSocket not connecting  
**Solution**:
1. Check mmd02 server is running: `curl http://localhost:8081/health`
2. Verify environment variables are set
3. Check browser console for errors

### "Failed to create network"

**Problem**: API not responding  
**Solution**:
1. Verify mmd02 server is running
2. Check `NEXT_PUBLIC_MMD02_API_URL` is correct
3. Look for CORS errors in console
4. Try mock mode first to rule out backend issues

### Port 8081 Already in Use

**Problem**: Another service using port  
**Solution**:
```bash
# Find what's using the port
lsof -i :8081

# Kill the process
kill -9 <PID>

# Or use different port
PORT=8082 npm run dev
```

---

## 📈 What's Next?

### Deploy to Production

1. **Deploy mmd02 to Railway**:
   ```bash
   railway login
   railway init
   railway up
   ```

2. **Update environment variables**:
   ```bash
   NEXT_PUBLIC_MMD02_API_URL=https://mmd02-production.up.railway.app
   NEXT_PUBLIC_MMD02_WS_URL=wss://mmd02-production.up.railway.app/ws
   ```

3. **Configure CORS** in mmd02:
   ```typescript
   app.use(cors({
     origin: 'https://your-banking-platform.com'
   }));
   ```

### Add Features

- **Authentication**: Add JWT tokens to API calls
- **Persistence**: Connect to PostgreSQL or MongoDB
- **Multi-tenancy**: Add organization/user filtering
- **RBAC**: Role-based access control
- **Audit Logs**: Enhanced compliance logging

---

## 🎓 Understanding the Architecture

### How It All Works Together

```
┌─────────────────────────────────────────────────┐
│  Browser (React App)                            │
│  - NetworkInfrastructureManagerEnhanced         │
│  - Creates/manages networks                     │
│  - Displays real-time events                    │
└──────────────┬──────────────────────────────────┘
               │ HTTP/WebSocket
               ▼
┌─────────────────────────────────────────────────┐
│  mmd02 Server (Node.js)                         │
│  - HTTP API for operations                      │
│  - WebSocket for real-time events               │
│  - Event storage and broadcasting               │
└──────────────┬──────────────────────────────────┘
               │ Events
               ▼
┌─────────────────────────────────────────────────┐
│  CLI Tool (Optional)                            │
│  - Terminal commands                            │
│  - Emits events to server                       │
│  - Alternative to UI                            │
└─────────────────────────────────────────────────┘
```

### Data Flow Example

1. **User clicks "Create Network" in UI**
2. **React component calls** `networkApi.createNetwork()`
3. **API client sends** `POST /api/network/create`
4. **mmd02 server**:
   - Creates network
   - Stores event
   - Broadcasts via WebSocket
5. **All connected clients receive event**
6. **UI updates automatically**

---

## 💡 Pro Tips

### Development Workflow

1. **Start mmd02 in one terminal**:
   ```bash
   cd mmd02
   npm run dev
   ```

2. **Start your React app in another**:
   ```bash
   npm run dev
   ```

3. **Use browser DevTools**:
   - Network tab → WS to see WebSocket messages
   - Console to see event logs

### Mock vs Real Server

**Use Mock Mode when**:
- Developing UI
- No internet connection
- Quick prototyping
- Demos

**Use Real Server when**:
- Testing WebSocket events
- Multi-user scenarios
- Production deployment
- CLI integration

---

## 📚 Documentation Links

- [Full Deployment Architecture](/NETWORK_MANAGEMENT_DEPLOYMENT_ARCHITECTURE.md)
- [mmd02 Server README](/mmd02/README.md)
- [API Reference](/NETWORK_MANAGEMENT_DEPLOYMENT_ARCHITECTURE.md#-api-reference)

---

## ✅ Checklist

Before going to production:

- [ ] mmd02 server deployed to cloud
- [ ] Environment variables configured
- [ ] HTTPS/WSS enabled
- [ ] CORS properly configured
- [ ] Authentication implemented
- [ ] Error handling tested
- [ ] Logging configured
- [ ] Health checks set up
- [ ] Documentation reviewed
- [ ] Team trained

---

**Need Help?**

Check the comprehensive documentation at `/NETWORK_MANAGEMENT_DEPLOYMENT_ARCHITECTURE.md`

---

© 2026 VOM Services Corporation  
Matthew James Sauls - OCIO, CCO, CEO, CFO, CTO
