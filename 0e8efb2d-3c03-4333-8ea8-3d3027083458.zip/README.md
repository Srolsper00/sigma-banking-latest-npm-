
  # M-Ledger Allocationione

  This is a code bundle for M-Ledger Allocationione. The original project is available at https://www.figma.com/design/ZCYWnm1PngDpOXCxWIHOX5/M-Ledger-Allocationione.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  